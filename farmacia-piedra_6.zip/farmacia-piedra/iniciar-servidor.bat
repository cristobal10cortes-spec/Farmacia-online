@echo off
rem Inicia Farmacias Piedra (tienda + panel de administracion).
rem Deja esta ventana abierta mientras uses la pagina. Para detenerla, cierrala.
chcp 65001 >nul
title Farmacias Piedra - Servidor
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Falta Node.js en este computador.
  echo   1. Descargalo desde https://nodejs.org  ^(boton "LTS"^) e instalalo.
  echo   2. Vuelve a abrir este archivo.
  echo.
  pause
  exit /b 1
)
set OPEN_BROWSER=1
node --disable-warning=ExperimentalWarning server\index.mjs
echo.
pause

@echo off
rem Crea un administrador del panel o le cambia la contrasena (si se olvido).
chcp 65001 >nul
title Farmacias Piedra - Administrador
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Falta Node.js. Descargalo desde https://nodejs.org ^(boton "LTS"^) e instalalo.
  echo.
  pause
  exit /b 1
)
node --disable-warning=ExperimentalWarning server\scripts\crear-admin.mjs
echo.
pause

# Farmacias Piedra — tienda online y panel de administración

Sitio completo de farmacia online (catálogo, buscador, carro, compra con receta, cuenta, Club, farmacias de turno, cotizador de recetas, asistente de ayuda) con un **servidor propio** donde vive el **panel de administración**.

El nombre, el logo (una piedra de lapislázuli, la piedra nacional de Chile), los textos, los dibujos de los envases y el catálogo son **originales o de ejemplo**: no se copió contenido, imágenes ni marcas de Cruz Verde ni de otra empresa.

---

## 1. Cómo está armado

```
            Clientes                              Tú (administrador)
               │                                        │
     https://tu-sitio.cl/                    https://tu-sitio.cl/admin/
               │                                        │
     ┌─────────▼─────────┐                   ┌──────────▼──────────┐
     │  TIENDA (pública) │                   │  PANEL (aparte)     │
     │  sin botón ni     │                   │  usuario +          │
     │  código del panel │                   │  contraseña         │
     └─────────┬─────────┘                   └──────────┬──────────┘
               │ lee catálogo y envía pedidos           │ sesión segura
               └──────────────┐          ┌──────────────┘
                        ┌─────▼──────────▼─────┐
                        │      SERVIDOR        │
                        │  valida todo y lo    │
                        │  guarda en la base   │
                        │  datos/farmacia.db   │
                        └──────────────────────┘
```

- **La tienda** no tiene botón «Administrador» ni el código del panel: aunque alguien revise el código de la página, no hay nada que atacar ahí. Solo muestra lo que el servidor le entrega y le envía los pedidos.
- **El panel** es otra aplicación, en su propia dirección (`/admin/`, se puede cambiar). A quien no ha ingresado el servidor **solo le entrega la pantalla de ingreso**: el código del panel se descarga recién después de entrar con usuario, contraseña (y el código del celular, si activas la verificación en dos pasos). Cada cambio pasa por el servidor, que revisa la sesión y los datos.
- **El servidor** calcula los precios y el stock con sus propios datos (no confía en lo que manda el navegador), descuenta el stock de cada venta y guarda pedidos, recetas, productos, banners, tarjetas del menú, farmacias y movimientos en una base de datos (un solo archivo: `datos/farmacia.db`). Los datos de los clientes y las recetas se guardan **cifrados**.

## 2. Echarlo a andar en tu computador

1. Instala **Node.js** (gratis): entra a [nodejs.org](https://nodejs.org), descarga la versión **LTS** e instálala con las opciones de siempre. (Sirve la 22.13 o cualquier versión más nueva.)
2. Descomprime la carpeta del proyecto donde quieras (por ejemplo, en Documentos).
3. **Windows:** doble clic en **`iniciar-servidor.bat`**. **Mac:** doble clic en **`iniciar-servidor-mac.command`** (si el Mac no lo deja abrir: clic derecho → Abrir). **Otros:** en una terminal, `npm start`.
4. Se abre una ventana negra (el servidor) y el navegador:
   - **La primera vez** se abre el cuadro celeste **«Ingresar administrador»** para crear tu usuario y tu contraseña (mínimo 10 caracteres, con letras y números). Ese enlace de primera vez solo sirve una vez; si cierras sin crearlo, vuelve a abrir el servidor y sale otro.
   - Las veces siguientes se abre el panel y te pide usuario y contraseña.
5. Direcciones (mientras la ventana negra esté abierta):
   - Tienda: **http://localhost:3000/**
   - Panel: **http://localhost:3000/admin/**

Para detener el servidor, cierra la ventana negra. Tus datos quedan guardados en la carpeta `datos/`.

> **La llave de cifrado.** La primera vez se crea `datos/clave-cifrado.key`: con ella se cifran los datos de los clientes y las recetas. **Guarda una copia en un pendrive** (y no la subas a internet ni la mandes por correo). Sin ese archivo, los pedidos guardados y los respaldos no se pueden leer.

> Así como viene, el servidor solo responde en tu computador (nadie más de la red ni de internet puede entrar). Para publicarlo en internet, mira el punto 6.

**¿Olvidaste la contraseña o perdiste el celular?** Doble clic en **`crear-administrador.bat`** (o `npm run crear-admin`) en el computador del servidor y escribe tu usuario: puedes poner una contraseña nueva y, si tenías la verificación en dos pasos, desactivarla. Sirve también para crear otro administrador. Se cierran las sesiones abiertas de ese usuario.

**Respaldos:** doble clic en **`respaldar-datos.bat`** (o `npm run respaldar`). Funciona con el servidor encendido y deja una copia en la carpeta `respaldos/` (guarda las 30 más recientes). Guarda copias fuera del computador. Los datos de clientes y recetas van cifrados en el respaldo: para usarlo necesitas también `datos/clave-cifrado.key` (guárdala aparte). Para restaurar: detén el servidor, borra `datos/farmacia.db-wal` y `datos/farmacia.db-shm` (si existen), reemplaza `datos/farmacia.db` por el respaldo (con ese mismo nombre) y deja en `datos/` la misma `clave-cifrado.key`.

## 3. El panel de administración

Arriba tiene **Ver tienda** (abre la tienda en otra pestaña), tu usuario, **Seguridad** y **Salir** (al salir, la página se recarga y el panel queda cerrado en ese navegador).

| Sección | Para qué sirve |
|---|---|
| **Resumen** | Ventas de la página con un gráfico que sube a medida que vendes, con botones **Mes**, **Año completo** e **Histórico**. También pedidos, ticket promedio, unidades vendidas (comparado con el período anterior), productos más vendidos, stock por reponer y últimos pedidos. «Incluir ventas de ejemplo» llena el gráfico con datos ficticios solo para ver cómo se ve. |
| **Productos y stock** | Busca un producto por nombre, marca o código (acepta errores de escritura) y toca **+ Stock** para sumar unidades a una farmacia, a la bodega online de una zona o a todas a la vez. En **Editar** subes o cambias **la foto del producto**, fijas la cantidad exacta por ubicación, cambias el precio, la oferta y el **precio costo** (con el margen), o lo ocultas de la tienda. Con **Carga masiva (Excel o CSV)** cargas existencia, costos, precios y productos nuevos desde una planilla, incluido el Excel de eleventa (ver abajo). |
| **Nuevo producto** | Crea productos con nombre, marca, categoría, precio, stock inicial, foto (opcional) y palabras para el buscador. Sin foto, el dibujo del envase se genera solo. |
| **Pedidos** | Todos los pedidos con su etapa (filtros: por confirmar, en preparación, en camino o listos, entregados, anulados) y su fecha de entrega. En el detalle **avanzas el pedido por etapas** y **cambias la fecha de entrega** (ver abajo), ves los datos del cliente, la entrega, el pago y **las recetas adjuntas** (se abren solo con tu sesión), y puedes anular el pedido: las unidades vuelven al stock. También puedes **contactar al cliente** por correo, WhatsApp o llamada. |
| **Farmacias** | Agrega, edita o elimina tus farmacias: nombre, dirección, comuna, teléfono, horario de lunes a viernes, sábado y domingo (o 24 horas), **días de turno** y recetario magistral. Al crear una puedes cargar el mismo stock inicial para todos los productos. |
| **Banners** | El carrusel de arriba de la portada y los **banners de más abajo** (los recuadros grandes después de «Ofertas destacadas»). Crea, edita textos y fotos, ordena con flechas, pausa o elimina, y programa fechas «desde / hasta». En «Así se ve hoy tu portada» tocas **Editar este banner** sobre el que se está viendo. |
| **Menú** | Las tarjetas de color que aparecen a la derecha cuando el cliente abre **Categorías** (y al final del menú del celular). Crea, edita, ordena con flechas, pausa o elimina, con fechas opcionales y una imagen de fondo si quieres. Se ven hasta 4 a la vez y puedes guardar hasta 12. |
| **Servicios Piedra** | Los recuadros de servicios de la portada (Farmacias y turnos, Cotiza tu receta, Mi Tratamiento…): título de la sección, y de cada servicio el ícono, el título, el texto y a dónde lleva. Ordénalos, ocúltalos, quítalos o agrega nuevos (hasta 12). |
| **Movimientos** | Registro de cada ingreso, ajuste, venta, anulación, cambio de precio, foto, producto, farmacia, banner, tarjeta del menú y servicio, con quién lo hizo. Filtra por tipo, por **fechas** (hoy, ayer, últimos 7 o 30 días, este mes, mes pasado o un rango) y por **farmacia**; con fechas o farmacia busca en todo el historial y te dice cuántas unidades entraron y salieron. |
| **Seguridad** | Revisión de lo que está protegido y lo que falta, **verificación en dos pasos** (activar, códigos de respaldo, desactivar), cambio de contraseña, **sesiones abiertas** (y cerrar las demás) y **registro de ingresos**: quién entró, cuándo, desde qué IP y equipo, y los intentos fallidos. |

Los cambios se ven en la tienda en menos de un minuto (y al instante para quien entra o recarga la página). El panel revisa solo cada 15 segundos si llegaron pedidos nuevos.

**Foto de un producto:** en **Productos y stock** abre el producto y, en «Foto del producto», toca **Subir foto** (o arrástrala). El panel te dice cuánto mide tu foto en píxeles y si sirve:

- **Medida ideal: 800 × 800 píxeles** (cuadrada). **Mínimo: 300 × 300.** Formato **JPG o PNG**, hasta 15 MB.
- Si es más grande, se achica sola a 800 px por el lado más largo. Si no es cuadrada, se ve completa, con espacio a los lados. Un PNG con fondo transparente se mantiene transparente.
- Ves la foto antes de guardarla. Con **Quitar foto** vuelve el dibujo del envase.

**Farmacias:** la tienda parte **sin farmacias**. Mientras no agregues ninguna, solo vende con despacho a domicilio (no aparece el retiro en farmacia). Cuando agregas una, aparece en la página Farmacias con su horario y si está abierta, se puede elegir para retirar pedidos y se ve su stock en cada producto. Los **días de turno** que indiques la muestran en «Farmacias de turno» (ese día atiende toda la noche). Una farmacia nueva parte con stock 0, salvo que indiques un stock inicial.

**Cómo crear un banner:** en **Banners** toca **Nuevo banner** (o **Nuevo banner de abajo**) y completa: el texto (etiqueta, título, frase y botón), a dónde lleva el botón (una sección, categoría, búsqueda o producto), el diseño (color de la marca u otro; si es claro, el texto se pone oscuro solo) con una ilustración, el dibujo de un producto, **una foto propia** o sin imagen; y si se muestra, con fechas opcionales. Arriba ves la vista previa **en computador y en celular**, y al lado el cuadro **«Carga la imagen aquí»** (también puedes arrastrar la foto). Los banners de ejemplo pasan a ser tuyos apenas cambies cualquiera; el del Club muestra solo la campaña del día hasta que edites su texto. Siempre queda al menos uno en cada lugar: si no quieres mostrarlo, páusalo.

**Medidas de las fotos** (JPG o PNG; se achican solas para que la página cargue rápido, y el panel te avisa si tu foto es chica o de otra forma y se va a recortar):

| Dónde | Medida ideal |
|---|---|
| Carrusel de la portada, en computador | **1.600 × 430 px** (horizontal; si pones tu texto encima, deja libre el lado izquierdo) |
| Carrusel, foto para celular (opcional) | **800 × 800 px** (cuadrada; si no la subes, se usa la de computador recortada al centro) |
| Banners de más abajo | **1.200 × 540 px** (horizontal) |
| Tarjetas del menú «Categorías» (opcional) | **600 × 300 px** (va detrás del texto, con un velo del color elegido) |

Con la foto eliges **«Con mi texto encima»** (se oscurece un poco para que el texto se lea) o **«Solo la foto»**, para una imagen que ya trae su propio texto (por ejemplo, hecha en Canva): entonces todo el banner es el enlace.

**Tarjetas del menú «Categorías»:** en **Menú** toca **Nueva tarjeta** y completa la etiqueta (por ejemplo «Solo esta semana»), el título, una frase corta, a dónde lleva (una sección, categoría, búsqueda o producto), el color de fondo (6 colores, todos con texto blanco que se lee bien), un ícono y, si quieres, una imagen de fondo de 600 × 300 px. A la derecha ves cómo quedará y ahí mismo cargas la imagen. Las dos de ejemplo (Club Piedra y Bioequivalentes) pasan a ser tuyas apenas cambies cualquiera; la del Club muestra sola la campaña del día hasta que edites su texto. Si pausas todas, el menú se muestra sin esa columna.

**Etapas de un pedido:** cada pedido nuevo llega **«Por confirmar»**. En su detalle, el recuadro «Etapa del pedido» te muestra el botón del paso siguiente:

1. **Confirmar pedido y pasar a embalaje** (revisa antes la receta, si tiene) → el cliente ve «Pedido confirmado: lo estamos preparando y embalando».
2. **Marcar «En camino»** (despacho) o **«Listo para retiro»** (retiro en farmacia) → el cliente ve que va en camino y cuándo llega, o dónde retirarlo.
3. **Marcar «Entregado»** o **«Retirado»**.

En cada paso puedes escribir un **mensaje adicional** (por ejemplo «El repartidor llega en la tarde»). El cliente ve todos los mensajes en **«Sigue tu pedido»** y en **«Mi cuenta → Mis pedidos»** (la página se actualiza sola). Además, el último mensaje queda con botones **Correo** y **WhatsApp** por si quieres avisarle también por ahí. Si marcaste una etapa por error, **«Volver a…»** la deshace (sin mensaje nuevo). El cliente puede anular su pedido solo mientras está «Por confirmar».

**Fecha de entrega:** al comprar con despacho, el cliente **elige el día** entre los próximos días hábiles disponibles (de lunes a sábado; en express es el mismo día). En el detalle del pedido puedes **cambiarla** con «Cambiar fecha»: el cliente ve la fecha nueva destacada como «Actualizada» y un mensaje con el cambio. En los retiros en farmacia también puedes cambiar el día de retiro.

**Contactar a un cliente:** abre el pedido en **Pedidos**. En «Cliente» ves su **correo** y su **celular** (los dos son obligatorios al comprar), con botones para copiarlos. Elige el **motivo** (consulta, falta la receta, producto sin stock, pedido confirmado, coordinar la entrega, pedido en camino, listo para retiro, fecha de entrega, pedido entregado o anulado; aparece primero el de la etapa actual) y el mensaje se escribe solo con el número de pedido y su nombre; puedes cambiarlo. Luego toca **Enviar correo** (abre tu programa de correo), **WhatsApp** (abre WhatsApp Web o la aplicación con el mensaje) o **Llamar**. Nada se envía solo: siempre lo revisas y lo mandas tú.

**Carga masiva (Excel o CSV): existencia, precio costo, precio de venta y productos nuevos.** En **Productos y stock** toca **Carga masiva (Excel o CSV)**.

1. **Prepara la planilla.** La primera fila lleva los títulos, de izquierda a derecha: **Código · Nombre del producto · Cantidad · Precio costo · Precio venta · Departamento**. Solo el código es obligatorio: las columnas que no traigas (o las celdas en blanco) no cambian nada. Con **Descargar planilla** obtienes un Excel o CSV con todos tus productos, sus precios y la cantidad en blanco. Se aceptan títulos parecidos («SKU», «Descripción», «Stock», «P. Costo», «P. Venta», «Precio al público», «Existencia»…) en cualquier orden, y los precios como `$2,830`, `$2.830` o `2830`.
   - **¿Usas eleventa?** Sube directo el Excel de inventario que descargas de ahí (Código, Producto, P. Costo, P. Venta, P. Mayoreo, Existencia, Inv. Mínimo, Inv. Máximo, Departamento). En eleventa el **P. Venta es el precio al público**: es el que se usa en la tienda. P. Mayoreo e inventario mínimo/máximo no se usan.
2. **Sube el archivo** (o arrástralo). Sirven .xlsx y .csv, hasta 5 MB y 5.000 filas. Si tienes un .xls antiguo, en Excel usa Archivo › Guardar como › «Libro de Excel (.xlsx)».
3. **Elige qué se carga:**
   - **Existencia** (si la planilla trae cantidad): **dónde** (una farmacia o la bodega online de una zona) y si se **suma** al stock actual (llegó mercadería) o lo **reemplaza** (un conteo, o tu inventario de eleventa). Recuerda: el **despacho a domicilio** sale de la bodega online de cada zona y el **retiro** de cada farmacia.
   - **Actualizar el precio de venta** (el precio al público). Si el producto tenía una oferta más alta que el precio nuevo, la oferta se quita.
   - **Guardar el precio costo.** Solo lo ves tú en el panel, con el **margen** de cada producto (en su ficha, en «Precio, oferta y costo», también puedes cambiarlo a mano). **La tienda nunca recibe el costo.**
   - **Crear los productos que no existen** (necesitan nombre y precio de venta). Para cada **departamento** eliges la **categoría** de la tienda («Automático» la deduce del nombre: principio activo y palabras como «shampoo», «protector solar» o «pañal») y la **condición**: *Venta directa*, *Con receta* o *No publicar* (se crea oculto). Por defecto: Perfumería, Naturales, Insumos, Dermatológicos, etc. de venta directa; Controlados, Recetario e Inyectables no se publican (y los controlados quedan con receta retenida); el resto de los medicamentos, con receta. Lo que elijas se recuerda para la próxima vez en ese navegador. La marca o laboratorio, el contenido (por ejemplo «30 comprimidos» o «200 ml»), la concentración y el principio activo también se sacan del nombre; revisa y corrige cualquier producto en su ficha.
   - **Ocultar los productos de ejemplo** (la primera vez que cargas tu catálogo). Dejan de verse en la tienda y siguen en el panel (filtro «Ocultos»).
4. **Revisa** antes de guardar: para cada fila ves si se crea o se actualiza, la existencia de ahora y con cuánto queda, el costo y el precio. Las filas con error (código con caracteres raros, cantidad con decimales o negativa, precio en $0 o con texto, producto nuevo sin precio) se marcan en rojo y **no se cargan**; un nombre que no coincide con el del código, un código repetido (las cantidades se suman) o un costo mayor que el precio se marcan para revisar. Con **Descargar filas con problemas** obtienes esas filas en un CSV.
5. **Confirma**: se guarda todo junto y queda en **Movimientos** como «Carga masiva · nombre del archivo». Si vuelves a subir el mismo archivo con «Sumar», el panel te avisa para que no cargues dos veces lo mismo. La próxima vez que subas el inventario de eleventa, los productos ya existen (se reconocen por su código): solo se actualizan existencia, costo y precio.

**Cómo funciona el stock:** cada venta descuenta unidades en el servidor (despacho → bodega de la zona; retiro → la farmacia elegida y lo que falte, de la bodega), cada anulación las repone, y si dos personas compran lo último al mismo tiempo, el servidor solo acepta la primera. Si mientras alguien compra cambió el precio o se acabó el stock, la tienda le avisa y actualiza el carro.

## 4. Seguridad

### Qué protege a cada página

**La tienda** es pública por naturaleza (como cualquier sitio web, el navegador de cada visitante descarga su código para poder mostrarla). Por eso no tiene nada que proteger adentro: **no contiene el panel, ni enlaces a él, ni claves**. Los precios, el stock y los pedidos los decide el servidor, que no confía en lo que manda el navegador: aunque alguien modifique la página en su computador, no puede cambiar un precio, inventar stock ni ver pedidos de otros.

**El panel** está cerrado con varias capas:

- **Su código no se entrega sin ingresar.** Sin sesión, la dirección del panel solo muestra la pantalla de ingreso (22 KB); el panel completo (`server/privado/panel.js`) está fuera de la carpeta pública y el servidor responde «no existe» si no hay una sesión válida.
- **Verificación en dos pasos (opcional, recomendada):** en **Seguridad** la activas escaneando un código QR con Google Authenticator o Microsoft Authenticator. Desde ahí, además de la contraseña se pide el código de 6 números del celular. Recibes 10 **códigos de respaldo** (cada uno sirve una vez) por si pierdes el celular; y si pierdes ambos, se desactiva con `crear-administrador` en el computador del servidor. Desactivarla o crear códigos nuevos pide contraseña y código.
- **Contraseñas** guardadas con **scrypt** y sal aleatoria (nunca la contraseña). No hay contraseñas por defecto: la primera la creas tú.
- **Bloqueo por intentos:** 5 contraseñas incorrectas para un usuario (o 10 desde una misma conexión) bloquean el ingreso por 15 minutos, también si llegan todas al mismo tiempo. Con la verificación en dos pasos, 5 códigos incorrectos bloquean el código del celular por 15 minutos (tú puedes seguir entrando con un código de respaldo, así nadie te deja afuera). El mensaje de error no revela si el usuario existe, y al entrar el panel **te avisa si desde tu último ingreso alguien falló contraseñas o códigos**.
- **Sesión** en una cookie **HttpOnly y SameSite=Strict** (JavaScript no la puede leer y otros sitios no la pueden usar), que se cierra sola tras **2 horas sin uso** y como máximo a las **12 horas**. En **Seguridad** ves tus sesiones abiertas y puedes cerrar las de otros equipos.
- **Registro de ingresos:** cada ingreso, salida, contraseña o código incorrecto y cambio de seguridad queda anotado con fecha, IP y equipo.
- Protección contra **CSRF** (ficha secreta por sesión + revisión del origen + solo datos JSON), **clickjacking** (el panel no se puede mostrar dentro de otra página) y **cabeceras de seguridad** (CSP sin scripts externos ni en línea, HSTS con https, nosniff; los buscadores no indexan el panel).

### Cifrado

- **En el camino (https):** al publicarla, todo viaja cifrado. **Desde internet el panel solo abre con https**: si alguien entra con `http://`, ve un aviso y no puede ni intentar ingresar (así la contraseña nunca viaja a la vista). En tu computador o en la red de tu casa/oficina se permite `http://` (no sale a internet). Si usas un proxy (Caddy, Nginx o el del hosting), define `TRUST_PROXY=1`: sin eso el servidor no puede saber si la visita llegó con https y, por seguridad, el panel no abre desde internet.
- **En el disco:** los datos de los clientes de cada pedido (nombre, RUT, correo, celular, dirección), las **recetas** (archivo y nombre) y las claves de la verificación en dos pasos se guardan cifrados con **AES-256-GCM**. Si alguien se lleva la base de datos o un respaldo sin la llave (`datos/clave-cifrado.key`), no puede leerlos ni modificarlos sin que se note. Los pedidos guardados antes de esta versión se cifran solos al iniciar.
- La carpeta `datos/` y sus archivos solo los puede leer el usuario que ejecuta el servidor.

### Otras protecciones

- El servidor **revisa todo lo que llega** (tamaños, formatos, RUT, comunas, precios, stock; las recetas deben ser de verdad JPG, PNG, WebP o PDF, revisando su contenido) y usa consultas preparadas en la base de datos.
- Límites para frenar abusos: 10 pedidos cada 10 minutos por conexión, hasta 25 productos y 60 unidades por pedido, y 900 solicitudes por minuto.
- Las recetas solo se pueden abrir con la sesión del panel. En el seguimiento de pedidos (con número y correo) el RUT y el celular se muestran a medias.
- Sin dependencias externas en el servidor (nada que se pueda «infectar» al instalar paquetes).
- Todo esto está cubierto por pruebas automáticas que intentan ataques reales (contraseñas en paralelo, códigos a la fuerza, rutas de archivos, inyección de código, CSRF, cookies falsas, archivos disfrazados, datos cifrados modificados). Aun así, **ningún sistema es 100% seguro**: antes de manejar recetas reales conviene una auditoría profesional.

### Lista para publicarla segura

1. **https** (ver punto 6) con `FORCE_HTTPS=1` y `TRUST_PROXY=1`.
2. **Activa la verificación en dos pasos** en Seguridad para cada administrador.
3. Pon el panel en **su propio subdominio** (`ADMIN_HOST=panel.tudominio.cl` y `STORE_URL=https://tudominio.cl`) o, al menos, en una dirección propia (`ADMIN_PATH=/una-direccion-tuya`).
4. Si te conectas siempre desde el mismo lugar, limita el panel a tu IP: `ADMIN_IPS=190.x.x.x` (para cualquier otra IP, el panel simplemente no existe).
5. Contraseña larga y única; no compartas el enlace de primera vez.
6. Respalda seguido y guarda **la llave de cifrado aparte** de los respaldos.
7. Revisa de vez en cuando el **registro de ingresos** en Seguridad.

Toda la configuración está explicada en **`.env.example`** (cópialo como `.env` y quita el `#` de lo que quieras cambiar).

## 5. Pruebas incluidas

```bash
npm test          # 281 pruebas del motor + 52 del servidor y su seguridad
npm run e2e       # recorre tienda y panel en un navegador real (escritorio y celular)
```

Las de punta a punta necesitan Python 3 y Playwright (`pip install playwright && playwright install chromium`). Levantan el servidor con una base de datos nueva y prueban: compras con receta, retiro y despacho, seguimiento y anulación, cuentas, el primer administrador, ingreso, contraseña, verificación en dos pasos (con un código QR que se escanea de verdad), sesión vencida, stock, precios, productos nuevos, pedidos, etapas y fechas de entrega, contacto con el cliente, recetas, banners (con fotos de computador y celular), banners de más abajo, tarjetas del menú, Servicios Piedra, filtros de movimientos por fecha y farmacia, ventas y la versión de celular.

## 6. Publicarlo como sitio oficial

Ahora el sitio necesita un **servidor con Node.js y un disco que guarde los datos** (un hosting estático como Netlify ya no basta, porque no guarda pedidos ni tiene panel). Opciones:

- **Un servidor virtual (VPS)** de cualquier proveedor (nacional o extranjero): instalas Node.js, subes la carpeta y lo dejas funcionando (por ejemplo con `pm2` o como servicio del sistema), con **Caddy** delante: consigue y renueva solo el certificado https gratis. El archivo **`Caddyfile.ejemplo`** trae la configuración lista (solo cambia el dominio). Es la opción más simple para una base de datos en archivo.
- **Un servicio de aplicaciones con disco persistente** (por ejemplo Render con disco, que es de pago; Railway o Fly.io con volumen). Comando de inicio: `npm start`. Pon `DATA_DIR` apuntando al disco (por ejemplo `DATA_DIR=/var/data`), `TRUST_PROXY=1` y `FORCE_HTTPS=1`. Sin disco persistente **los datos se borran en cada actualización**.

Pasos generales: 1) contrata el hosting; 2) sube el proyecto (las carpetas `server/public` y `server/privado` ya vienen listas: no hace falta `npm install` para funcionar) **sin la carpeta `datos/`** de tu computador, salvo que quieras llevar tus datos (en ese caso, súbela completa con su `clave-cifrado.key`, o define la llave en la variable `DATA_KEY`); 3) define las variables del punto 4; 4) inicia y crea el administrador con el enlace de primera vez que aparece en el registro del servidor, o con `ADMIN_USER` y `ADMIN_PASSWORD` (bórralas después de entrar); 5) conecta tu dominio `.cl` (se registra en NIC Chile); 6) entra al panel con `https://` y activa la verificación en dos pasos.

**https directo, sin Caddy:** si ya tienes un certificado (archivos `.pem`), indícalo con `TLS_CERT` y `TLS_KEY` (y `HTTP_REDIRECT_PORT=80` para que `http://` lleve a `https://`).

Si cambias algo en `src/` (textos, productos, colores), vuelve a generar la tienda y el panel con `npm install` (la primera vez) y `npm run build`.

**Archivo sin servidor (demostración):** `dist/farmacia-piedra.html` es la tienda en un solo archivo, con datos de ejemplo y **sin panel**. Las compras de prueba quedan solo en ese navegador. Sirve para mostrar el diseño, no para vender.

## 7. Antes de vender de verdad

1. **Pasarela de pago real** (por ejemplo Webpay de Transbank, Mercado Pago o Flow). El pago actual es **simulado**: el sitio nunca pide ni guarda datos de tarjetas.
2. **Cuentas de clientes en el servidor.** Hoy los pedidos, el stock y el panel están en el servidor, pero las cuentas de los clientes (registro, direcciones, favoritos, Club, Mi Tratamiento) siguen guardadas en el navegador de cada cliente. Por eso los descuentos del Club y de Mi Tratamiento los declara el cliente: el pedido lo marca para que lo revises.
3. **Autorizaciones sanitarias** para vender medicamentos por internet, validación de recetas por un químico farmacéutico y su resguardo.
4. **Protección de datos personales:** las recetas son datos de salud (datos sensibles). Revisa las obligaciones de la Ley 21.719, que entra en vigencia el 1 de diciembre de 2026.
5. **Boleta y factura electrónica** (SII), textos legales definitivos y los datos reales de la empresa y del director técnico.
6. Cambia `demo: true` por `demo: false` en `src/js/config.js` para quitar los avisos de demostración.

## 8. El buscador

El buscador entiende cómo escriben los pacientes, aunque escriban mal:

| El paciente escribe | El sitio muestra |
|---|---|
| `paqazetami`, `parasetamol`, `pracetamol` | Paracetamol («Mostrando resultados para paracetamol») |
| `acetaminofen`, `panadol`, `kitadol` | Paracetamol (otros nombres y marcas) |
| `ivuprofeno`, `amosicilina`, `lozartan`, `omeprasol` | Ibuprofeno, Amoxicilina, Losartán, Omeprazol |
| `dolor de cabeza`, `remedio para la tos`, `dolor de guata` | Productos para ese síntoma |
| `larroche`, `seravé`, `bloqueador`, `pañitos humedos` | La Roche‑Posay, CeraVe, protector solar, toallitas húmedas |

Ignora tildes y mayúsculas, compara cómo **suenan** las palabras en español (z/s/c, b/v, q/k, h muda, ll/y), tolera letras de más o de menos, reconoce marcas, síntomas y palabras chilenas (guata, guagua, paspadura…) y autocompleta mientras se escribe. **Para enseñarle palabras nuevas** edita `src/js/data/synonyms.js` (sin tildes):

```js
{ words: ['tapsin'], to: ['antigripal'] },               // marca → producto
{ words: ['dolor de guata', 'empacho'], to: ['antiacido'] }, // síntoma → tipo de remedio
```

## 9. El asistente de ayuda (ventanita de la esquina)

Siempre presente en la tienda, va diciendo «¿Necesitas ayuda?», «¿Lo puedo asesorar en algo?» y otras frases (una según la página). Tiene botones rápidos y un campo para escribir; al usarlos se abre como chat. Responde al instante y sin costo: busca remedios aunque estén mal escritos o por síntoma, contesta preguntas frecuentes, dice cuánto cuesta y cuándo llega el despacho a una comuna, muestra farmacias de turno y explica cómo seguir un pedido.

- **Orientación de salud** («Tengo un síntoma»): para 19 síntomas comunes explica qué hacer en casa, qué hay en la farmacia (solo productos de venta directa), **cuándo consultar a un médico** y **cuándo ir a urgencias**.
- **Señales de alarma:** ante algo grave (dolor de pecho, no poder respirar, desmayo, intoxicación…) no muestra productos: indica llamar al **SAMU 131** (o al **CITUC +56 2 2635 3800** en intoxicaciones). Si alguien expresa que quiere hacerse daño, responde con la **línea *4141**.
- **No es médico, y lo dice:** no diagnostica, no receta ni indica dosis. Si piden «un médico», ofrece **Salud Responde 600 360 7777** y el químico farmacéutico de la farmacia.
- Frases: `src/js/config.js` → `HELPBOT`. Respuestas: `src/js/engine/assistant.js`. Síntomas y consejos: `src/js/data/health.js` (conviene que un profesional de la salud los revise antes de publicar).

## 10. Qué cambiar y dónde

| Quiero cambiar… | Archivo |
|---|---|
| Nombre, teléfono, WhatsApp, correo, horario, director técnico, aviso de demostración | `src/js/config.js` (`BRAND`) |
| Costos y zonas de despacho, despacho gratis, express, máximos por producto | `src/js/config.js` (`ZONES`, `RULES`) |
| Club Piedra: campañas por día, Mi Tratamiento, cupones | `src/js/config.js` (`CLUB`, `COUPONS`) |
| **Logo** | `src/js/ui/logo.js` → reemplaza el dibujo en `markSvg()` o pon tu imagen en `logo()` |
| **Colores** | `src/css/base.css` → variables al inicio (`--lapis` = color principal, `--pyrite` = dorado del Club) |
| **Catálogo base** (productos y precios de partida) | `src/js/data/products.js`. Para el día a día usa el panel: los cambios del panel quedan en la base de datos y se aplican sobre este catálogo |
| **Farmacias** (direcciones, horarios, turnos), **fotos de productos**, **banners**, **tarjetas del menú Categorías** y **Servicios Piedra** | Desde el panel (secciones Farmacias, Productos y stock, Banners, Menú y Servicios Piedra) |
| Categorías y regiones | `src/js/data/categories.js`, `regions.js` |
| Banners y servicios de ejemplo, preguntas frecuentes y textos legales | `src/js/data/content.js` (los reales, desde el panel) |
| Configuración del servidor (puerto, dirección del panel, IP permitidas, https, sesión) | `.env` (ver `.env.example`) |

## 11. Estructura

```
iniciar-servidor.bat       inicia todo en Windows (doble clic)
crear-administrador.bat    crea un administrador o cambia su contraseña
respaldar-datos.bat        respalda la base de datos
server/
  index.mjs                arranque del servidor
  app.mjs                  rutas: tienda, API pública y API del panel
  config.mjs               configuración (variables de .env)
  lib/                     seguridad, cifrado, verificación en dos pasos, base de datos (SQLite),
                           pedidos y stock, HTTP
  scripts/                 crear-admin y respaldar
  public/                  tienda y pantalla de ingreso del panel ya construidas (públicas)
  privado/                 el panel ya construido (solo se entrega con la sesión iniciada)
  test/                    pruebas del servidor y su seguridad
src/
  js/main.js               tienda pública
  js/admin/                panel de administración (acceso.js = pantalla de ingreso pública, main.js = panel,
                           api.js = conexión con el servidor, qr.js = códigos QR, photo.js = fotos)
  js/engine/               buscador, precios, despacho, stock, pedidos, banners, menú, contacto, planillas Excel/CSV e importación de productos (importar.js) (lo usan tienda, panel y servidor)
  js/pages/                secciones (admin*.js = pantallas del panel; admin-stores.js = farmacias, admin-menu.js = menú, admin-contact.js = contacto, admin-carga.js = carga masiva)
  js/ui/, js/data/, css/   diseño, componentes, catálogo y textos
dist/                      tienda en un solo archivo (sin servidor, sin panel)
datos/                     base de datos y llave de cifrado (se crean al iniciar; respáldalas por separado)
build.mjs                  construye server/public, server/privado y dist a partir de src/
Caddyfile.ejemplo          https automático para un servidor propio (VPS)
tests/                     pruebas del motor y de punta a punta (fixtures/ = planillas de ejemplo de Excel, LibreOffice y CSV)
```

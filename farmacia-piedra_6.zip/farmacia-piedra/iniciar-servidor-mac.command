#!/bin/bash
# Inicia Farmacias Piedra en Mac (doble clic). Deja la ventana abierta mientras uses la página.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Falta Node.js. Descárgalo desde https://nodejs.org (botón LTS) e instálalo."
  echo ""
  read -n 1 -s -r -p "Presiona una tecla para cerrar"
  exit 1
fi
OPEN_BROWSER=1 node --disable-warning=ExperimentalWarning server/index.mjs

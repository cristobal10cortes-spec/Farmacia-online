@echo off
rem Respalda los datos de Farmacias Piedra (pedidos, stock, productos, banners, recetas).
rem Se puede usar con el servidor funcionando. Los respaldos quedan en la carpeta "respaldos".
chcp 65001 >nul
title Farmacias Piedra - Respaldo
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Falta Node.js. Descargalo desde https://nodejs.org ^(boton "LTS"^) e instalalo.
  echo.
  pause
  exit /b 1
)
node --disable-warning=ExperimentalWarning server\scripts\respaldar.mjs
echo.
pause

// Construye la tienda y el panel de administración.
//   node build.mjs          (requiere esbuild: npm install)
//
// Genera:
//   server/public/            lo que entrega el servidor (sitio oficial)
//     index.html, assets/       la TIENDA, conectada a la API del servidor
//     admin/                    pantalla de INGRESO al panel (lo único público del panel)
//   server/privado/panel.js   el PANEL DE ADMINISTRACIÓN: el servidor solo lo entrega
//                             a quien ya ingresó (fuera de public/ a propósito)
//   dist/farmacia-piedra.html   la tienda en un solo archivo, sin servidor
//                               (datos de ejemplo, para probar o mostrar)
//   dist/artifact.html          la misma tienda para publicarla como vista previa
//
// El panel NO se incluye en dist/: solo existe en el servidor, detrás del ingreso.

import { readFileSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = dirname(fileURLToPath(import.meta.url));
let esbuild;
try {
  esbuild = await import('esbuild');
} catch {
  try {
    esbuild = await import('/opt/npm-tools/node_modules/esbuild/lib/main.js');
  } catch {
    console.error('Falta esbuild. Ejecuta primero:  npm install');
    process.exit(1);
  }
}

const minify = !process.argv.includes('--dev');
const VERSION = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version;
const STORE_CSS = ['base.css', 'components.css', 'layout.css', 'pages.css'];
const PANEL_CSS = [...STORE_CSS, 'admin.css', 'panel.css'];
const FONTS = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Figtree:wght@400;500;600;700;800&display=swap';
const FAVICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><path d="M6.5 27.5C6.5 17.3 14.6 9.5 25.1 9.5 35.2 9.5 42 15.9 42 24.8 42 34.4 34.3 40.5 23.8 40.5 13.6 40.5 6.5 35.6 6.5 27.5Z" fill="#24479B"/><circle cx="30.5" cy="30" r="2.2" fill="#E5C55A"/><circle cx="35" cy="24.6" r="1.5" fill="#E5C55A"/></svg>';

async function bundle(entry) {
  const out = await esbuild.build({
    entryPoints: [join(root, entry)],
    bundle: true,
    format: 'iife',
    target: ['es2020'],
    minify,
    charset: 'utf8',
    legalComments: 'none',
    define: { __APP_VERSION__: JSON.stringify(VERSION) },
    write: false,
  });
  const js = out.outputFiles[0].text;
  if (js.includes('</script')) throw new Error(`${entry}: el JS contiene "</script".`);
  return js;
}

async function styles(files) {
  const raw = files.map((f) => readFileSync(join(root, 'src/css', f), 'utf8')).join('\n');
  return (await esbuild.transform(raw, { loader: 'css', minify, charset: 'utf8' })).code;
}

const hash = (s) => createHash('sha256').update(s).digest('hex').slice(0, 10);
const kb = (s) => `${(Buffer.byteLength(s) / 1024).toFixed(0)} KB`;
const write = (rel, data) => {
  const file = join(root, rel);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, data);
};

const [storeJs, accessJs, panelJs, storeCss, panelCss] = await Promise.all([
  bundle('src/js/main.js'),
  bundle('src/js/admin/acceso.js'),
  bundle('src/js/admin/main.js'),
  styles(STORE_CSS),
  styles(PANEL_CSS),
]);

// Seguridad: el código del panel no puede terminar dentro de la tienda…
for (const marker of ['Ingresar administrador', 'Crear administrador e ingresar', 'X-CSRF-Token']) {
  if (storeJs.includes(marker)) throw new Error(`La tienda incluye código del panel ("${marker}").`);
}
// …ni dentro de la pantalla de ingreso (que se entrega sin sesión)
for (const marker of ['Productos y stock', '/2fa/enable', 'Registro de ingresos', 'Anular y reponer stock', '/products']) {
  if (accessJs.includes(marker)) throw new Error(`La pantalla de ingreso incluye código del panel ("${marker}").`);
}

// ── Tienda sin servidor (un solo archivo) ────────────────────
const template = readFileSync(join(root, 'src/index.html'), 'utf8');
const standalone = template
  .replace('__FAVICON__', `data:image/svg+xml,${encodeURIComponent(FAVICON_SVG)}`)
  .replace('__CSS__', () => storeCss)
  .replace('__JS__', () => storeJs);

// Vista previa publicada (el visor agrega doctype, head y body)
const artifact = `<title>Farmacias Piedra</title>
<link rel="stylesheet" href="${FONTS}">
<style>${storeCss}</style>
<div id="app"></div>
<script>${storeJs}</script>
`;

write('dist/farmacia-piedra.html', standalone);
write('dist/artifact.html', artifact);

// ── Sitio oficial: tienda + panel en el servidor ─────────────
const head = ({ title, description = '', robots = '', css, extra = '' }) => `<!doctype html>
<html lang="es-CL">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${title}</title>
${description ? `<meta name="description" content="${description}">\n` : ''}${robots ? `<meta name="robots" content="${robots}">\n` : ''}<meta name="theme-color" content="#172E66">
${extra}<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${FONTS}">
<link rel="stylesheet" href="${css}">
</head>`;

const pub = 'server/public';
const priv = 'server/privado';
rmSync(join(root, pub), { recursive: true, force: true });
rmSync(join(root, priv), { recursive: true, force: true });

const sv = hash(storeJs + storeCss);
write(`${pub}/assets/tienda.js`, storeJs);
write(`${pub}/assets/tienda.css`, storeCss);
write(`${pub}/favicon.svg`, FAVICON_SVG);
write(`${pub}/robots.txt`, 'User-agent: *\nDisallow: /api/\n');
write(`${pub}/index.html`, `${head({
  title: 'Farmacias Piedra',
  description: 'Farmacia online: medicamentos, dermocosmética, vitaminas y cuidado personal. Despacho a todo Chile y retiro en farmacia.',
  css: `/assets/tienda.css?v=${sv}`,
  extra: '<meta name="piedra-api" content="/api">\n<link rel="icon" href="/favicon.svg" type="image/svg+xml">\n',
})}
<body>
<div id="app"></div>
<noscript><p style="padding:24px;font-family:sans-serif">Farmacias Piedra necesita JavaScript activado para funcionar.</p></noscript>
<script src="/assets/tienda.js?v=${sv}" defer></script>
</body>
</html>
`);

// Panel: rutas relativas para que funcione en cualquier dirección (ADMIN_PATH).
// Público: la pantalla de ingreso y los estilos. Privado: el panel (panel.js).
const pv = hash(panelJs);
const av = hash(accessJs + panelCss);
write(`${priv}/panel.js`, panelJs);
write(`${pub}/admin/acceso.js`, accessJs);
write(`${pub}/admin/panel.css`, panelCss);
write(`${pub}/admin/index.html`, `${head({
  title: 'Panel de administración · Farmacias Piedra',
  robots: 'noindex, nofollow',
  css: `panel.css?v=${av}`,
  extra: `<meta name="referrer" content="no-referrer">\n<meta name="panel-app" content="panel.js?v=${pv}">\n<link rel="icon" href="../favicon.svg" type="image/svg+xml">\n`,
})}
<body class="is-panel">
<div id="app"></div>
<noscript><p style="padding:24px;font-family:sans-serif">El panel necesita JavaScript activado.</p></noscript>
<script src="acceso.js?v=${av}" defer></script>
</body>
</html>
`);

console.log(`OK  tienda  dist/farmacia-piedra.html ${kb(standalone)} · dist/artifact.html ${kb(artifact)} · server/public (JS ${kb(storeJs)}, CSS ${kb(storeCss)})`);
console.log(`OK  panel   ingreso público server/public/admin (JS ${kb(accessJs)}, CSS ${kb(panelCss)}) · panel privado server/privado/panel.js (${kb(panelJs)})`);

// Pruebas del motor (búsqueda, precios, RUT, despacho). Ejecutar: node tests/engine.test.mjs
import { productIndex, byId, listProducts, alternativesFor, getProduct } from '../src/js/engine/catalog.js';
import { validateRut, formatRut, rutDv, validPhone } from '../src/js/engine/rut.js';
import { cartTotals, evaluateCoupon, shippingCost, promoDiscount } from '../src/js/engine/pricing.js';
import { deliveryInfo, storeStatus, storesNear, productAvailability } from '../src/js/engine/inventory.js';
import { phonetic, stem, tokenize } from '../src/js/engine/text.js';
import { STORES } from '../src/js/data/stores.js';
import { REGIONS } from '../src/js/data/regions.js';
import * as catalog from '../src/js/engine/catalog.js';
import { applyCatalogOverrides } from '../src/js/engine/catalog.js';
import { onlineStock, stockMovesFor, deliveryShortages, isTurno, isoToday, storeStockRaw } from '../src/js/engine/inventory.js';
import { setStores } from '../src/js/data/stores.js';
import { cleanStore, timeToHours, hoursToTime } from '../src/js/engine/storedef.js';
import { createOrder, cancelOrder, syncRemoteOrder } from '../src/js/engine/orders.js';
import { setOverridesMap } from '../src/js/engine/stockdata.js';
import { validLoc, stockAt, stockSnapshot, stockTotals, stockLevel } from '../src/js/engine/stock.js';
import { bannerList, liveFrom, bannerStatus, cleanBanner, photoFit, PHOTO_SIZES, imageSrc, setMediaBase, isImageRef, DEFAULT_PROMOS, PROMO_VISIBLE } from '../src/js/engine/bannerlist.js';
import { bannerSlideHtml, promoCardHtml, promoGridHtml } from '../src/js/ui/banners.js';
import { servicesSection, liveServices, cleanServices, DEFAULT_SERVICES, MAX_SERVICES } from '../src/js/engine/services.js';
import { cleanDef } from '../src/js/engine/productdef.js';
import { ALL_SUBS } from '../src/js/data/categories.js';
import { emptyState } from '../src/js/ui/components.js';
import { productImg, setPhotoBase } from '../src/js/ui/art.js';
import { botReply, teasersFor, faqSearch } from '../src/js/engine/assistant.js';
import { menuCardList, liveMenuCards, cleanMenuCard, menuCardStatus, DEFAULT_MENU_CARDS, MENU_VISIBLE } from '../src/js/engine/menucards.js';
import { menuCardHtml, menuCardsHtml, withLiveMenuText } from '../src/js/ui/megacards.js';
import { contactTemplates, mailtoHref, whatsappHref, telHref, suggestedTemplate } from '../src/js/engine/contact.js';
import { deliveryDates, deliveryWhen, nextStatus, prevStatus, statusMessage, dateMessage, validIso, calOf } from '../src/js/engine/orderflow.js';
import { orderTimeline as tlOf, statusLabel as labelOf } from '../src/js/engine/orders.js';
import { readPlanilla, parseCsv, parseQty, parseMoney, cleanCode, checkItems, findHeader, planillaCsv, planillaXlsx, decodeText, nameMatches } from '../src/js/engine/planilla.js';
import { proposeProduct, prettyName, parseContent } from '../src/js/engine/importar.js';
import { cleanDef as cleanDefP } from '../src/js/engine/productdef.js';
import { readFileSync } from 'node:fs';

let pass = 0;
let fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; } else { fail++; console.log(`  ✗ ${msg}`); }
}
const top = (q, opts) => {
  const r = productIndex.search(q, opts);
  return { r, names: r.items.map((i) => byId.get(i.id).name) };
};
const firstHas = (q, word, opts) => {
  const { r, names } = top(q, opts);
  ok(names.length && names[0].toLowerCase().includes(word), `"${q}" → primero debería contener "${word}" (obtuvo: ${names[0] || 'nada'})`);
  return r;
};

console.log('Texto');
ok(phonetic('paqazetami') === 'pakasetami', 'fonética paqazetami');
ok(phonetic('paracetamol') === 'parasetamol', 'fonética paracetamol');
ok(phonetic('amoxisilina') === phonetic('amoxicilina'), 'fonética amoxicilina');
ok(phonetic('ivuprofeno') === phonetic('ibuprofeno'), 'fonética ibuprofeno');
ok(stem('panales') === stem('panal'), 'raíz pañales/pañal');
ok(stem('sobres') === stem('sobre'), 'raíz sobres/sobre');
ok(tokenize('Paracetamol 500mg').join('|') === 'paracetamol|500|mg', 'tokenize 500mg');

console.log('Búsqueda tolerante a errores');
const r1 = firstHas('paqazetami', 'paracetamol');
ok(r1.corrected === 'paracetamol', '¿Quisiste decir? paracetamol');
firstHas('parasetamol', 'paracetamol');
firstHas('pracetamol', 'paracetamol');
firstHas('acetaminofen', 'paracetamol');
firstHas('acetaminofem', 'paracetamol');
firstHas('panadol', 'paracetamol');
firstHas('kitadol', 'paracetamol');
firstHas('ivuprofeno', 'ibuprofeno');
firstHas('iboprufeno', 'ibuprofeno');
firstHas('amoxisilina', 'amoxicilina');
firstHas('zetirizina', 'cetirizina');
firstHas('omeprasol', 'omeprazol');
firstHas('clonasepam', 'clonazepam');
firstHas('idrocortisona', 'hidrocortisona');
firstHas('aspirina', 'acetilsalicílico');
firstHas('dipirona', 'metamizol');
firstHas('lorata', 'loratadina');
firstHas('loratadina 10', 'loratadina 10');
firstHas('paracetamol 1g', 'paracetamol 1 g');
firstHas('paracetamol jarabe', 'jarabe');
firstHas('paracetamol niños', 'paracetamol');
firstHas('ibuprofeno jarabe', 'suspensión');
firstHas('pañales', 'pañales');
firstHas('pañal xg', 'talla xg');
firstHas('bloqueador', 'fps');
firstHas('dolor de cabeza', 'paracetamol');
firstHas('pastillas para dormir', 'melatonina');
firstHas('pastillas para la presion', 'losartán');
firstHas('remedio para la tos', 'ambroxol');
firstHas('jarave para la tos', 'jarabe');
firstHas('desgarro', 'ambroxol');
firstHas('estitiquez', 'lactulosa');
firstHas('piojos', 'permetrina');
firstHas('condones', 'preservativos');
firstHas('curitas', 'curitas');
firstHas('pildora del dia despues', 'levonorgestrel');
firstHas('paspadura', 'coceduras');
firstHas('seravé', 'crema hidratante');
firstHas('larroche', 'anthelios');
firstHas('rosamosqueta', 'rosa mosqueta');
firstHas('ketoconasol champu', 'ketoconazol');
firstHas('t4', 'levotiroxina');
firstHas('paresetamol', 'paracetamol');
firstHas('lozartan', 'losartán');
firstHas('atorbastatina', 'atorvastatina');
firstHas('crema para la cara', 'crema');
firstHas('pañitos humedos', 'toallitas húmedas');
firstHas('dolor de guata', 'antiácido');
firstHas('amoxi', 'amoxicilina');
ok(top('amoxi').r.corrected === null, 'amoxi no se "corrige" a una marca (es el comienzo de amoxicilina)');
ok(!/covid/i.test(top('comida de perro').r.corrected || ''), 'comida de perro no se corrige a covid');
ok(!/barra/i.test(top('crema para la cara').r.corrected || ''), 'cara no se corrige a barra');
ok(top('xyzzyq').r.total === 0, 'consulta sin sentido → sin resultados');
ok(top('paracetamol 650').r.partial, 'paracetamol 650 → resultados parciales');

console.log('Autocompletar');
const ac = productIndex.search('parac', { prefix: true });
ok(ac.completion === 'paracetamol', 'parac → paracetamol');
ok(productIndex.search('paqaz', { prefix: true }).completion === 'paracetamol', 'paqaz → paracetamol');
ok(productIndex.search('ibu', { prefix: true }).completion === 'ibuprofeno', 'ibu → ibuprofeno');
ok(productIndex.search('protector s', { prefix: true }).completion === 'protector solar', 'protector s → protector solar');

console.log('Listado, filtros y orden');
const L = listProducts({ q: 'paracetamol', sort: 'precio-asc', filters: {} });
ok(L.total >= 7, 'paracetamol lista ≥ 7');
ok(L.all.every((p, i, a) => !i || (a[i - 1].offer || a[i - 1].price) <= (p.offer || p.price)), 'orden por precio ascendente');
const L2 = listProducts({ cat: 'medicamentos', filters: { venta: ['directa'] } });
ok(L2.all.every((p) => p.rx === 'directa'), 'filtro venta directa');
const L3 = listProducts({ cat: 'dermocosmetica', sub: 'proteccion-solar', filters: {} });
ok(L3.total === 8, `protección solar = 8 (obtuvo ${L3.total})`);
const L4 = listProducts({ view: 'bioequivalentes', filters: {} });
ok(L4.all.every((p) => p.be), 'vista bioequivalentes');

console.log('Bioequivalentes');
const para = getProduct(L.all.find((p) => p.brand === 'Lab. Andino' && p.units === 16).slug);
const alts = alternativesFor(para);
ok(alts.length >= 2 && alts.every((a) => a.ingredients[0] === 'paracetamol'), 'alternativas de paracetamol 500');

console.log('RUT y teléfono');
ok(rutDv('12345678') === '5', 'DV de 12.345.678 = 5');
ok(validateRut('12.345.678-5'), 'RUT válido');
ok(!validateRut('12.345.678-4'), 'RUT inválido');
ok(validateRut('11.111.111-1'), 'RUT 11.111.111-1');
ok(formatRut('123456785') === '12.345.678-5', 'formato RUT');
ok(validPhone('+56 9 1234 5678') && !validPhone('22345678'), 'celular');

console.log('Precios, promociones y cupones');
ok(promoDiscount('2x1', 2, 1000) === 1000, '2x1 con 2 unidades');
ok(promoDiscount('3x2', 4, 1000) === 1000, '3x2 con 4 unidades');
ok(promoDiscount('2da-50', 3, 1000) === 500, '2da al 50% con 3 unidades');
const deo = [...byId.values()].find((p) => p.promo === '2x1');
const t = cartTotals([{ product: deo, qty: 2 }], { member: false });
ok(t.subtotal === deo.price, '2x1 en el carro cobra 1');
const rx = [...byId.values()].find((p) => p.rx === 'simple');
const t2 = cartTotals([{ product: rx, qty: 1 }], {});
ok(!evaluateCoupon('BIENVENIDA10', t2, {}).ok, 'cupón no aplica a receta');
const otc = [...byId.values()].find((p) => p.rx === 'directa' && !p.promo && p.price > 9000);
const t3 = cartTotals([{ product: otc, qty: 1 }], {});
ok(evaluateCoupon('BIENVENIDA10', t3, {}).ok, 'cupón aplica a venta directa');
ok(!evaluateCoupon('BIENVENIDA10', t3, { ordersCount: 1 }).ok, 'cupón primera compra');
ok(!evaluateCoupon('NOEXISTE', t3, {}).ok, 'cupón inexistente');
ok(shippingCost({ zone: 'RM', subtotal: 10000 }) === 2990, 'despacho RM');
ok(shippingCost({ zone: 'RM', subtotal: 30000 }) === 0, 'despacho RM gratis');
ok(shippingCost({ zone: 'AUSTRAL', subtotal: 50000 }) === 6990, 'despacho austral');

console.log('Despacho y farmacias');
const wed10 = new Date('2026-10-07T13:00:00Z'); // miércoles 10:00 en Santiago
const d1 = deliveryInfo({ region: 'RM', comuna: 'Providencia' }, { now: wed10 });
ok(d1.home.ok && d1.express.ok, 'Providencia: despacho y express');
ok(!deliveryInfo({ region: 'V', comuna: 'Isla de Pascua' }, { now: wed10 }).home.ok, 'Isla de Pascua sin despacho');
ok(!deliveryInfo({ region: 'X', comuna: 'Osorno' }, { hasCold: true, now: wed10 }).home.ok, 'refrigerado fuera de RM');
ok(REGIONS.reduce((a, r) => a + r.comunas.length, 0) === 346, '346 comunas');
// Sin farmacias (así parte la tienda): solo despacho
ok(STORES.length === 0, 'la tienda parte sin farmacias');
const av0 = productAvailability(para, { region: 'RM', comuna: 'Santiago' }, wed10);
ok(av0.noStores && !av0.pickup.ok && /despacho/.test(av0.pickup.text) && av0.stores.length === 0, 'sin farmacias: no se ofrece retiro');
ok(!/retirar en farmacia/.test(deliveryInfo({ region: 'V', comuna: 'Isla de Pascua' }, { now: wed10 }).home.reason), 'sin farmacias no se sugiere retirar en farmacia');
ok(storeStatus && storesNear({ region: 'RM', comuna: 'Santiago' }).length === 0, 'sin farmacias cercanas');

console.log('Farmacias administradas desde el panel');
ok(timeToHours('08:30') === 8.5 && timeToHours('00:00', { closing: true }) === 24 && timeToHours('25:00') === null && hoursToTime(20.75) === '20:45' && hoursToTime(24) === '00:00', 'horarios: HH:MM ↔ horas');
const base = { name: 'Farmacia Piedra Centro', address: 'Huérfanos 1000', region: 'RM', comuna: 'Santiago', hours: { wk: [9, 21], sat: [10, 14], sun: null } };
ok(cleanStore({ ...base, comuna: 'Temuco' }).error && cleanStore({ ...base, region: 'XX' }).error && cleanStore({ ...base, name: '' }).error, 'comuna de otra región, región inexistente o sin nombre: error');
ok(cleanStore({ ...base, hours: { wk: [21, 9] } }).error && cleanStore({ ...base, hours: {} }).error, 'cierre antes de la apertura o sin horario: error');
ok(cleanStore({ ...base, hours: {}, h24: true }).store?.h24 === true, '24 horas no necesita horario');
ok(cleanStore({ ...base, phone: '<script>' }).error && cleanStore({ ...base, phone: '+56 2 2345 6789' }).store?.phone === '+56 2 2345 6789', 'teléfono validado');
const turnoDay = isoToday(wed10);
const c1 = cleanStore({ ...base, recetario: true, turnos: [turnoDay, '2020-01-01', 'mañana', turnoDay], extra: 'x' }, { today: turnoDay });
ok(c1.store && c1.store.turnos.join() === turnoDay && c1.store.services.includes('recetario') && c1.store.extra === undefined, 'turnos: sin repetidos ni fechas viejas; campos desconocidos fuera');
setStores([
  { ...c1.store, id: 'FTEST1' },
  { ...cleanStore({ ...base, name: 'Farmacia Piedra Las Condes', address: 'Apoquindo 4499', comuna: 'Las Condes', h24: true }).store, id: 'FTEST2' },
  { ...cleanStore({ ...base, name: 'Farmacia Piedra Temuco', address: 'Manuel Montt 800', region: 'IX', comuna: 'Temuco' }).store, id: 'FTEST3' },
]);
ok(STORES.length === 3 && storesNear({ region: 'RM', comuna: 'Las Condes' })[0].comuna === 'Las Condes', 'farmacias cercanas primero en la comuna');
ok(storeStatus(STORES.find((x) => x.h24), wed10).open, 'farmacia 24 h abierta');
const centro = STORES.find((x) => x.id === 'FTEST1');
ok(isTurno(centro, wed10) && storeStatus(centro, new Date('2026-10-08T05:00:00Z')).open === false, 'de turno solo los días indicados');
ok(storeStatus(centro, wed10).turno && storeStatus(centro, wed10).open, 'el día de turno atiende toda la noche');
ok(storeStockRaw(para, centro) === 0, 'una farmacia nueva parte sin stock');
const av = productAvailability(para, { region: 'RM', comuna: 'Santiago' }, wed10);
ok(!av.noStores && av.stores.length === 2 && !av.pickup.ok, 'con farmacias: se ven las de la región (sin stock aún)');
ok(/retirar en farmacia/.test(deliveryInfo({ region: 'V', comuna: 'Isla de Pascua' }, { now: wed10 }).home.reason), 'con farmacias se sugiere retirar');

console.log('Datos administrados (los aplica la tienda; los cambia el panel en el servidor)');
const ap = getProduct('paracetamol-500-mg-16-comprimidos-lab-andino');
const orig = { price: ap.price, offer: ap.offer };
const loc0 = `s:${STORES[0].id}`;
ok(validLoc('o:RM') && validLoc(loc0) && !validLoc('o:MARTE') && !validLoc('s:F999') && !validLoc('o:RM:1') && !validLoc(''), 'ubicaciones de stock válidas e inválidas');
const nid = 'NPRUEBA01';
const ndef = cleanDef({ n: 'Jarabe de propóleo 120 ml', b: 'Piedra Vital', c: 'medicamentos/resfrio-y-tos', ai: ['propóleo'], f: 'jarabe', u: 120, un: 'ml', rx: 'directa', p: 4990, t: ['tos'] });
ok(ndef.def && !ndef.error, 'ficha de producto nuevo válida');
const ov = new Map([
  [ap.id, { priceSet: true, price: 2000, offer: 1500, stock: { o: { RM: 4 }, s: { [STORES[0].id]: 30 } }, stockAt: 1 }],
  ['420104', { hidden: true }],
  [nid, { def: ndef.def, createdAt: 1, stock: { o: { RM: 3 }, s: {} }, stockAt: 1 }],
]);
setOverridesMap(ov);
applyCatalogOverrides(ov);
ok(ap.price === 2000 && ap.offer === 1500, 'precio y oferta del panel');
ok(stockAt(ap, 'o:RM') === 4 && stockAt(ap, loc0) === 30, 'stock fijado por el panel');
const hiddenP = byId.get('420104');
ok(hiddenP.hidden && !catalog.PRODUCTS.includes(hiddenP) && !catalog.productIndex.search('paracetamol 1 g').items.some((i) => i.id === '420104'), 'producto oculto sale de la tienda y del buscador');
const np = byId.get(nid);
ok(np && np.custom && onlineStock(np, 'RM') === 3 && onlineStock(np, 'NORTE') === 0, 'producto nuevo con su stock (0 donde no se indicó)');
ok(catalog.productIndex.search('propolio').items.some((i) => i.id === nid), 'el producto nuevo se encuentra con errores de escritura');
ok(deliveryShortages([{ product: np, qty: 4 }], 'RM').length === 1, 'detecta stock insuficiente para despacho');
const t0 = stockTotals(np);
ok(t0.online === 3 && t0.total === 3 && stockLevel(np, t0) === 'bajo', 'totales y nivel de stock');
const withPhoto = new Map([...ov, ['420102', { photo: { v: 'k3x9', w: 800, h: 600 } }], ['420103', { photo: { v: '"><img src=x onerror=alert(1)>', w: 1, h: 1 } }]]);
setOverridesMap(withPhoto);
applyCatalogOverrides(withPhoto);
const ph = byId.get('420102');
ok(ph.photo?.v === 'k3x9' && productImg(ph).startsWith('data:image/svg'), 'sin servidor no se piden fotos (se usa el dibujo)');
setPhotoBase('/api/fotos/');
ok(productImg(ph) === '/api/fotos/420102?v=k3x9', 'con servidor, la foto se pide con su versión');
ok(!byId.get('420103').photo && productImg(byId.get('420103')).startsWith('data:image/svg'), 'una versión de foto rara se ignora');
setPhotoBase('');
setOverridesMap(ov);
applyCatalogOverrides(ov);
ok(!byId.get('420102').photo, 'al quitar la foto vuelve el dibujo');
const snap = stockSnapshot(ap);
ok(Object.keys(snap.o).length === 5 && Object.keys(snap.s).length === STORES.length, 'foto del stock por ubicación');

console.log('Compras sin servidor (archivo de demostración)');
const ord = createOrder({ customer: { nombre: 'A', apellidos: 'B', rut: '12.345.678-5', email: 'a@b.cl', phone: '912345678' }, delivery: { type: 'despacho', comuna: 'Santiago' }, payment: { method: 'tarjeta', status: 'aprobado' }, totals: cartTotals([{ product: np, qty: 2 }], {}), shipping: 0, stockMoves: stockMovesFor([{ product: np, qty: 2 }], { type: 'despacho', zone: 'RM' }) });
ok(onlineStock(np, 'RM') === 1, 'la venta descuenta el stock en este navegador');
ok(cancelOrder(ord.id) && onlineStock(np, 'RM') === 3, 'anular repone el stock');
ok(!cancelOrder('PD00000000'), 'no anula pedidos que no existen');
const remoteOrder = syncRemoteOrder({ ...ord, id: 'PD99999999', cancelled: false });
ok(remoteOrder.remote && !cancelOrder('PD99999999'), 'los pedidos del servidor se anulan en el servidor, no aquí');

// Vuelta al catálogo original
setOverridesMap(new Map());
applyCatalogOverrides(new Map());
ok(ap.price === orig.price && ap.offer === orig.offer && !byId.has(nid) && !byId.get('420104').hidden, 'sin datos del panel vuelve el catálogo original');

console.log('Banners de la portada');
const examples = bannerList([]);
ok(examples.length >= 3 && examples.every((b) => b.builtin) && liveFrom([]).length === examples.length, 'sin banners guardados se muestran los de ejemplo');
ok(bannerStatus({ active: true, from: '2026-12-01' }, '2026-10-06') === 'programado'
  && bannerStatus({ active: true, until: '2026-10-01' }, '2026-10-06') === 'vencido'
  && bannerStatus({ active: true, from: '2026-10-01', until: '2026-10-06' }, '2026-10-06') === 'activo'
  && bannerStatus({ active: false }, '2026-10-06') === 'pausado', 'fechas: programado, terminado, vigente (incluye el último día) y pausado');
const stored = [{ id: 'B2', title: 'Segundo', order: 1, active: true }, { id: 'B1', title: 'Primero', order: 0, active: true }, { id: 'B3', title: 'Pausado', order: 2, active: false }];
ok(liveFrom(stored).map((b) => b.id).join() === 'B1,B2', 'la portada muestra los activos en orden');
const cb = cleanBanner({ title: '  Hasta 30%  ', to: '/ofertas', tone: 'custom', color: '#F2C200', visual: 'none', hack: 1, order: 5000 });
ok(cb.banner && cb.banner.title === 'Hasta 30%' && cb.banner.hack === undefined && cb.banner.order === 999 && cb.banner.color === '#F2C200', 'el banner se limpia (campos conocidos y rangos)');
ok(cleanBanner({ title: 'x', to: '//otro-sitio.cl' }).error && cleanBanner({ title: 'x', to: 'javascript:alert(1)' }).error && cleanBanner({ title: 'x', to: 'https://otro.cl' }).error, 'el botón solo lleva a páginas del sitio');
ok(cleanBanner({ title: 'x', to: '/', visual: 'photo', image: 'data:image/svg+xml;base64,PHN2Zz4=' }).error, 'la foto debe ser JPG, PNG o WebP');
ok(cleanBanner({ title: '', to: '/' }).error && cleanBanner({ title: 'x', to: '/', from: '2026-10-10', until: '2026-10-01' }).error, 'título obligatorio y fechas en orden');
ok(cleanBanner({ title: 'x', to: '/', tone: 'custom', color: 'red;}' }).banner.tone === 'lapis', 'color inválido vuelve al tono de la marca');

console.log('Fotos de banners y banners de más abajo');
ok(PHOTO_SIZES.hero.w === 1600 && PHOTO_SIZES.hero.h === 430 && PHOTO_SIZES.heroM.w === 800 && PHOTO_SIZES.promo.w === 1200 && PHOTO_SIZES.menu.w === 600, 'medidas recomendadas: 1.600 × 430 (carrusel), 800 × 800 (celular), 1.200 × 540 (abajo) y 600 × 300 (menú)');
ok(photoFit(1600, 430, PHOTO_SIZES.hero).tone === 'ok' && photoFit(1920, 500, PHOTO_SIZES.hero).tone === 'ok', 'una foto de la medida (o parecida y más grande) está bien');
const fitSmall = photoFit(500, 134, PHOTO_SIZES.hero);
ok(fitSmall.tone === 'warn' && /chica/.test(fitSmall.text) && fitSmall.text.includes('1.600 × 430 px'), 'una foto chica avisa que puede verse borrosa y dice la medida ideal');
const fitShape = photoFit(1200, 1200, PHOTO_SIZES.hero);
ok(fitShape.tone === 'warn' && /arriba y abajo/.test(fitShape.text), 'una foto cuadrada para el carrusel avisa que se recorta arriba y abajo');
ok(/los lados/.test(photoFit(3000, 400, PHOTO_SIZES.promo).text), 'una foto muy alargada avisa que se recortan los lados');
ok(isImageRef('media:bn-B1?v=abc12') && isImageRef('data:image/jpeg;base64,AAAA') && !isImageRef('media:../x?v=1') && !isImageRef('javascript:alert(1)') && !isImageRef('https://otro.cl/a.jpg'), 'solo se aceptan fotos subidas o guardadas en el servidor');
setMediaBase('/api/imagenes/');
ok(imageSrc('media:bn-B1?v=abc12') === '/api/imagenes/bn-B1?v=abc12' && imageSrc('https://otro.cl/a.jpg') === '' && imageSrc("data:image/png;base64,AA');x") === '', 'la dirección de la foto se arma desde la referencia (lo demás se descarta)');
ok(bannerList([]).every((b) => b.place === 'hero') && bannerList([], 'promo').map((b) => b.id).join() === DEFAULT_PROMOS.map((b) => b.id).join(), 'cada lugar tiene sus propios ejemplos');
const mixed = [{ id: 'H1', title: 'Arriba', active: true, order: 0 }, { id: 'P1', place: 'promo', title: 'Abajo', active: true, order: 0 }];
ok(liveFrom(mixed).map((b) => b.id).join() === 'H1' && liveFrom(mixed, 'promo').map((b) => b.id).join() === 'P1', 'los banners guardados sin lugar son del carrusel; los de abajo van aparte');
ok(liveFrom(Array.from({ length: 6 }, (_, i) => ({ id: `P${i}`, place: 'promo', title: 'x', active: true, order: i })), 'promo').length === PROMO_VISIBLE, `abajo se ven hasta ${PROMO_VISIBLE}`);
const cp = cleanBanner({ place: 'promo', title: 'x', to: '/', visual: 'photo', image: 'media:bn-P1?v=a1', imageM: 'media:bn-P1-m?v=a1', photoOnly: true, dynamic: 'club' });
ok(cp.banner.place === 'promo' && cp.banner.imageM === '' && cp.banner.photoOnly === true && cp.banner.dynamic === '', 'abajo: sin foto para celular ni texto automático del Club');
ok(cleanBanner({ place: 'promo', title: 'x', to: '/', visual: 'art', art: 'sun' }).banner.visual === 'none', 'abajo no hay ilustraciones (queda solo color)');
ok(cleanBanner({ title: 'x', to: '/', visual: 'photo' }).error && cleanBanner({ title: 'x', to: '/', visual: 'photo', image: 'media:bn-1?v=1', imageM: 'javascript:1' }).error, 'foto propia exige una foto válida (y la del celular también debe serlo)');
ok(cleanBanner({ title: 'x', to: '/', visual: 'art', art: 'be', image: 'media:bn-1?v=1', photoOnly: true }).banner.image === '' && cleanBanner({ title: 'x', to: '/', visual: 'art', art: 'be', photoOnly: true }).banner.photoOnly === false, 'sin «Foto propia» no se guarda foto ni «solo la foto»');
const slide = bannerSlideHtml({ title: '<b>T</b>', cta: 'Ver', to: '/ofertas', visual: 'photo', image: 'media:bn-1?v=1', imageM: 'media:bn-1-m?v=1' });
ok(slide.includes("--img:url('/api/imagenes/bn-1?v=1')") && slide.includes('has-m') && !slide.includes('<b>T</b>') && slide.includes('hero__cta'), 'diapositiva con foto: fondo para computador y celular, texto escapado');
const only = bannerSlideHtml({ title: 'Cyber', cta: 'Ver', to: '/ofertas', visual: 'photo', image: 'media:bn-1?v=1', photoOnly: true });
ok(only.includes('hero__slide--only') && only.includes('hero__fill') && only.includes('aria-label="Cyber: Ver"') && !only.includes('hero__title'), '«Solo la foto»: todo el banner es el enlace y el título queda para lectores de pantalla');
ok(!bannerSlideHtml({ title: 'x', visual: 'photo', image: 'https://otro.cl/x.jpg' }).includes('otro.cl'), 'una foto de otro sitio no se muestra');
const pc = promoCardHtml({ title: '<img src=x>', eyebrow: 'Ley', text: 'Texto', cta: 'Ir', to: '/bioequivalentes', tone: 'basalt' });
ok(pc.startsWith('<a class="promo-card promo-card--basalt"') && pc.includes('href="#/bioequivalentes"') && !pc.includes('<img') && pc.includes('pebbles'), 'banner de abajo: color, enlace y texto escapado');
ok(promoCardHtml({ title: 'x', to: '/', visual: 'photo', image: 'media:bn-2?v=1' }).includes('promo-card--photo') && promoCardHtml({ title: 'x', to: 'javascript:alert(1)' }).includes('href="#/"'), 'banner de abajo con foto; un enlace inválido lleva al inicio');
ok(promoCardHtml({ title: 'x', to: '/', tone: 'custom', color: '#F6D365' }).includes('promo-card--light'), 'color claro: texto oscuro');
ok(promoGridHtml([]) === '' && (promoGridHtml(DEFAULT_PROMOS).match(/promo-card /g) || []).length === 2, 'sin banners de abajo activos no se dibuja nada');

console.log('Servicios Piedra');
ok(servicesSection(null).builtin && servicesSection(null).items.length === DEFAULT_SERVICES.items.length && servicesSection(null).title === 'Servicios Piedra', 'sin guardar se usan los de ejemplo');
ok(liveServices({ title: 'Lo nuestro', items: [{ id: 'a', title: 'A', to: '/', active: true }, { id: 'b', title: 'B', to: '/', active: false }] }).items.map((x) => x.id).join() === 'a', 'la portada muestra solo los visibles, en orden');
ok(liveServices({ title: 'x', items: [] }).items.length === 0, 'si se quitan todos, la sección no se muestra');
const cs = cleanServices({ title: '  ', items: [{ id: 'dup', title: '  Turno  ', text: 'x'.repeat(200), to: '/farmacias', icon: 'bomba', hack: 1 }, { id: 'dup', title: 'Otro', to: '/' }] });
ok(cs.section && cs.section.title === 'Servicios Piedra' && cs.section.items[0].title === 'Turno' && cs.section.items[0].text.length === 90 && cs.section.items[0].icon === 'star' && !('hack' in cs.section.items[0]), 'limpia la sección: título por defecto, textos con largo máximo, ícono conocido');
ok(cs.section.items[0].id !== cs.section.items[1].id, 'los identificadores repetidos se corrigen');
ok(cleanServices({ items: [{ title: '', to: '/' }] }).index === 0 && /Servicio 1/.test(cleanServices({ items: [{ title: '', to: '/' }] }).error), 'el error dice qué servicio revisar');
ok(cleanServices({ items: [{ title: 'x', to: 'https://otro.cl' }] }).error && cleanServices({ items: [{ title: 'x', to: '//otro.cl' }] }).error && cleanServices({}).error, 'los servicios solo llevan a páginas del sitio');
ok(cleanServices({ items: Array.from({ length: MAX_SERVICES + 1 }, (_, i) => ({ title: `S${i}`, to: '/' })) }).error, `hasta ${MAX_SERVICES} servicios`);

console.log('Textos escapados');
ok(!emptyState({ title: 'Sin resultados', text: 'No encontramos “<img src=x onerror=alert(1)>”' }).includes('<img'), 'el texto de los avisos vacíos no se interpreta como HTML (búsquedas con código)');

console.log('Fichas de productos nuevos');
ok(cleanDef({ n: 'X', b: 'Y', c: 'nada/raro', u: 1, p: 100 }).error, 'categoría inexistente');
ok(cleanDef({ n: 'X', b: 'Y', c: 'medicamentos/dolor-y-fiebre', u: 1, p: 100 }).error, 'medicamento sin principio activo');
ok(cleanDef({ n: 'X', b: 'Y', c: 'cuidado-personal/' + ALL_SUBS.find((x) => x.cat === 'cuidado-personal').id, u: 1, p: 100, o: 150 }).error, 'oferta mayor que el precio');
const dd = cleanDef({ n: 'Crema <b>x</b>', b: 'Y', c: 'cuidado-personal/' + ALL_SUBS.find((x) => x.cat === 'cuidado-personal').id, u: 1, p: 100, rx: 'retenida', ai: ['x'] });
ok(dd.def && dd.def.rx === 'directa' && !dd.def.ai, 'fuera de medicamentos siempre es venta directa');
ok(cleanDef({ n: 'X', b: 'Y', c: 'medicamentos/dolor-y-fiebre', u: 1, p: 100, ai: ['x'], rx: 'constructor' }).def.rx === 'directa', 'condición de venta desconocida vuelve a venta directa');

console.log('Asistente de ayuda');
const kinds = (rr) => rr.map((m) => m.type);
const allText = (rr) => JSON.stringify(rr);
const lines = teasersFor('/producto/algo');
ok(lines[0] === '¿Necesitas ayuda?' && lines[1] === '¿Lo puedo asesorar en algo?' && lines.includes('¿Tienes dudas sobre este producto?'), 'la ventanita dice "¿Necesitas ayuda?" y "¿Lo puedo asesorar en algo?" (y una frase de la página)');
let rr = botReply('hola');
ok(rr[0].type === 'text' && rr[0].text.includes('asistente virtual') && kinds(rr).includes('chips'), 'saluda y ofrece opciones');
rr = botReply('paqazetami');
ok(rr[0].type === 'products' && rr[0].items.some((p) => /paracetamol/i.test(p.name)) && rr[0].title.includes('paracetamol'), 'entiende "paqazetami" y muestra paracetamol');
rr = botReply('dolor de cabeza');
ok(rr[0].type === 'health' && kinds(rr).includes('products'), 'por síntoma da orientación de salud y muestra productos');
rr = botReply('¿cuánto cuesta el despacho?');
ok(rr[0].type === 'faq' && rr[0].q === '¿Cuánto cuesta el despacho?' && !kinds(rr).includes('products'), 'pregunta de despacho responde la pregunta frecuente (sin productos)');
rr = botReply('hacen despacho a temuco');
ok(rr[0].type === 'text' && rr[0].text.includes('despachamos a Temuco'), 'despacho a una comuna con costo y fecha');
rr = botReply('farmacias de turno');
ok(kinds(rr).includes('stores') && rr.find((m) => m.type === 'stores').items.length > 0, 'farmacias de turno cerca de la comuna');
rr = botReply('¿Dónde está mi pedido?');
ok(allText(rr).includes('/seguimiento'), 'pedido: explica cómo seguirlo');
rr = botReply('Hablar con una persona');
ok(kinds(rr).includes('contact'), 'hablar con una persona: teléfono, WhatsApp y correo');
rr = botReply('¿Cómo compro con receta?');
ok(rr[0].type === 'faq' && /receta/i.test(rr[0].q) && allText(rr).includes('/cotizar-receta'), 'compra con receta: pregunta frecuente y enlace para cotizar');
rr = botReply('asdfgh qwerty');
ok(rr[0].type === 'text' && rr[0].text.startsWith('No encontré'), 'si no entiende, lo dice y ofrece ayuda');
ok(faqSearch('medios de pago').length > 0, 'búsqueda en preguntas frecuentes');

console.log('Orientación de salud');
rr = botReply('me duele la cabeza');
ok(rr[0].type === 'health' && rr[0].title === 'Dolor de cabeza' && rr[0].doctor.length && rr[0].urgent.length, 'síntoma: orientación con qué hacer, cuándo consultar y cuándo ir a urgencias');
ok(rr.some((m) => m.type === 'products' && m.items.every((p) => p.rx === 'directa')), 'por síntoma solo sugiere productos de venta directa');
rr = botReply('mi guagua tiene fiebre');
ok(rr[0].type === 'health' && rr[0].title === 'Fiebre' && rr[0].notes.some((n) => n.includes('pediatra')), 'si es para una guagua o un niño, recuerda consultar al pediatra');
rr = botReply('me duele el pecho');
ok(rr[0].type === 'alert' && rr[0].lines.some((l) => l.tel === '131'), 'dolor de pecho: aviso de urgencia con el SAMU 131');
rr = botReply('no puedo respirar');
ok(rr[0].type === 'alert' && !kinds(rr).includes('products'), 'dificultad para respirar: urgencia, sin productos');
rr = botReply('mi hijo se tomó todas las pastillas');
ok(rr[0].type === 'alert' && rr[0].lines.some((l) => l.label.includes('CITUC')), 'posible intoxicación: CITUC y SAMU');
rr = botReply('quiero morirme');
ok(rr.length === 1 && rr[0].tone === 'care' && rr[0].lines.some((l) => l.tel === '*4141'), 'crisis: línea *4141 y nada más');
ok(botReply('me quiero cortar las uñas')[0].type !== 'alert', 'no confunde "cortarme las uñas" con una crisis');
rr = botReply('quiero hablar con un médico');
ok(rr[0].text.startsWith('No soy médico') && allText(rr).includes('600 360 7777'), 'pide un médico: aclara que no lo es y da Salud Responde');
rr = botReply('jarabe para la tos');
ok(rr[0].type === 'products' && allText(rr).includes('Orientación: Tos'), 'si busca un producto, primero los productos y ofrece la orientación');
rr = botReply('¿necesito receta médica para el ibuprofeno?');
ok(rr[0].type === 'products' && rr[0].rxAll && rr[0].items.some((p) => /ibuprofeno/i.test(p.name)), 'responde si un medicamento necesita receta');

console.log('Menú «Categorías»');
ok(menuCardList([]).length === DEFAULT_MENU_CARDS.length && menuCardList([]).every((c) => c.builtin), 'sin tarjetas guardadas se usan las de ejemplo');
ok(menuCardList([]).map((c) => c.id).join() === 'club,bioeq', 'ejemplos: Club Piedra y Bioequivalentes, en ese orden');
ok(liveMenuCards([{ id: 'x', title: 'Pausada', to: '/', active: false, order: 0 }]).length === 0, 'si el dueño pausó todas, el menú queda sin tarjetas');
const many = Array.from({ length: 7 }, (_, i) => ({ id: `M${i}`, title: `T${i}`, to: '/', active: true, order: 6 - i }));
const lm = liveMenuCards(many);
ok(lm.length === MENU_VISIBLE && lm[0].id === 'M6', `se ven hasta ${MENU_VISIBLE}, en el orden elegido`);
ok(menuCardStatus({ active: true, from: '2999-01-01' }) === 'programado' && menuCardStatus({ active: true, until: '2000-01-01' }) === 'vencido', 'fechas: programada y terminada');
const mc = cleanMenuCard({ title: '  Hasta 30%  ', kicker: 'x'.repeat(80), to: '/ofertas', tone: 'rosado', icon: 'bomba', hack: 1, order: 9999 });
ok(mc.card && mc.card.title === 'Hasta 30%' && mc.card.kicker.length === 28 && mc.card.tone === 'lapis' && mc.card.icon === '' && !('hack' in mc.card) && mc.card.order === 999, 'limpia la tarjeta: textos con largo máximo, color e ícono conocidos, sin campos extra');
ok(cleanMenuCard({ title: 'x', to: '//otro.cl' }).error && cleanMenuCard({ title: 'x', to: 'javascript:alert(1)' }).error && cleanMenuCard({ title: 'x', to: 'https://otro.cl' }).error, 'la tarjeta solo lleva a páginas del sitio');
ok(cleanMenuCard({ title: '', to: '/' }).error && cleanMenuCard({ title: 'x', to: '/', from: '2026-10-10', until: '2026-10-01' }).error, 'título obligatorio y fechas en orden');
ok(cleanMenuCard({ title: 'x', to: '/', tone: '__proto__', icon: 'constructor' }).card.tone === 'lapis', 'no acepta nombres raros como color o ícono');
const mh = menuCardHtml({ title: '<img src=x onerror=alert(1)>', kicker: '"><b>', text: '&', to: '/buscar?q=a&b=1', tone: 'jade', icon: 'sun' });
ok(!mh.includes('<img') && !mh.includes('"><b>') && mh.includes('href="#/buscar?q=a&amp;b=1"') && mh.includes('mcard--jade'), 'la tarjeta escapa los textos y el enlace');
ok(menuCardHtml({ title: 'x', to: 'javascript:alert(1)' }).includes('href="#/"'), 'un enlace inválido lleva al inicio');
ok(menuCardHtml({ title: 'x', to: '/' }, { tag: 'div' }).startsWith('<div') && !menuCardHtml({ title: 'x', to: '/' }, { tag: 'div' }).includes('href'), 'vista previa del panel: sin enlace');
ok(menuCardsHtml([]) === '', 'sin tarjetas activas no se dibuja nada');
ok(menuCardHtml({ title: 'x', to: '/', image: 'media:mc-M1?v=1' }).includes("mcard--photo") && menuCardHtml({ title: 'x', to: '/', image: 'media:mc-M1?v=1' }).includes("--img:url('/api/imagenes/mc-M1?v=1')"), 'tarjeta con imagen de fondo');
ok(cleanMenuCard({ title: 'x', to: '/', image: 'data:image/svg+xml;base64,PHN2Zz4=' }).error && cleanMenuCard({ title: 'x', to: '/', image: 'media:mc-1?v=1' }).card.image === 'media:mc-1?v=1' && cleanMenuCard({ title: 'x', to: '/' }).card.image === '', 'la imagen de la tarjeta es opcional y debe ser válida');
const clubCard = DEFAULT_MENU_CARDS[0];
const lt = withLiveMenuText(clubCard);
ok(lt.title && (lt === clubCard || lt.kicker === 'Hoy en el Club'), 'la tarjeta del Club muestra la campaña del día (si hay)');
ok(withLiveMenuText({ ...clubCard, dynamic: '' }).title === clubCard.title, 'si el dueño editó su texto, queda fijo');

console.log('Contacto con el cliente');
const co = {
  id: 'PD12345678', customer: { nombre: 'Ana María', apellidos: 'Pérez', email: 'ana+test@ejemplo.cl', phone: '912345678' },
  items: [{ name: 'Paracetamol 500 mg', rx: 'directa' }, { name: 'Amoxicilina 500 mg', rx: 'simple' }],
  delivery: { type: 'despacho', address: 'Av. Siempre Viva 742', comuna: 'Santiago', eta: 'Llega mañana' }, payment: { status: 'aprobado' },
};
let tp = contactTemplates(co);
ok(tp[0].id === 'consulta' && tp.every((t) => t.body.includes('PD12345678') && t.body.startsWith('Hola Ana,') && t.body.endsWith('Farmacias Piedra')), 'mensajes con el número de pedido, el nombre y la firma');
ok(tp.some((t) => t.id === 'receta' && t.body.includes('Amoxicilina') && !t.body.includes('Paracetamol')), 'si falta la receta, nombra solo los productos que la necesitan');
ok(tp.some((t) => t.id === 'camino' && t.body.includes('va en camino')) && tp.some((t) => t.id === 'entrega') && tp.some((t) => t.id === 'confirmado') && !tp.some((t) => t.id === 'listo'), 'despacho: confirmado, coordinar la entrega y pedido en camino');
tp = contactTemplates({ ...co, items: [co.items[0]], delivery: { type: 'retiro', storeName: 'Farmacia Piedra Centro', storeAddress: 'Huérfanos 1000, Santiago' }, cancelled: true });
ok(tp.some((t) => t.id === 'listo' && t.body.includes('Huérfanos 1000')) && !tp.some((t) => t.id === 'receta') && tp.some((t) => t.id === 'anulado' && t.body.includes('devolución')), 'retiro: listo para retiro; anulado: avisa la devolución');
const mt = mailtoHref('ana+test@ejemplo.cl', 'Tu pedido', 'Hola\nAna & co');
ok(mt.startsWith('mailto:ana%2Btest@ejemplo.cl?subject=Tu%20pedido&body=') && mt.includes('Hola%0D%0AAna%20%26%20co'), 'correo: dirección, asunto y mensaje bien codificados');
ok(mailtoHref('ana?cc=x&bcc=y@ejemplo.cl', 's', 'b').startsWith('mailto:ana%3Fcc%3Dx%26bcc%3Dy@ejemplo.cl?subject=s&body=b'), 'un correo con ? o & no agrega destinatarios');
ok(mailtoHref('no-es-correo') === '' && whatsappHref('123') === '' && telHref('') === '', 'sin datos válidos no hay enlace');
ok(whatsappHref('+56 9 1234 5678', 'Hola & chao') === 'https://wa.me/56912345678?text=Hola%20%26%20chao' && telHref('912345678') === 'tel:+56912345678', 'WhatsApp y llamada con el celular en formato internacional');

console.log('Etapas del pedido y fechas de entrega');
const ddays = deliveryDates({ year: 2026, month: 10, day: 17 });
ok(ddays.length === 6 && ddays[0] === "2026-10-17" && !ddays.includes("2026-10-18") && ddays[1] === "2026-10-19", 'días de entrega: desde el primero posible, sin domingos');
ok(validIso('2026-10-31') && !validIso('2026-02-30') && !validIso('mañana') && calOf('2026-10-15').weekday === 4, 'fechas válidas');
const mo = { id: 'PD1', status: 'recibido', createdAt: 1, history: [{ at: 1, status: 'recibido' }], customer: { nombre: 'Ana' }, delivery: { type: 'despacho', address: 'Moneda 1100', comuna: 'Santiago', date: '2026-10-20' }, payment: { method: 'tarjeta' } };
ok(nextStatus(mo) === 'embalaje' && prevStatus(mo) === null, 'recibido → embalaje');
ok(nextStatus({ ...mo, status: 'embalaje' }) === 'camino' && nextStatus({ ...mo, status: 'embalaje', delivery: { type: 'retiro' } }) === 'listo', 'despacho va en camino; retiro queda listo para retiro');
ok(nextStatus({ ...mo, status: 'entregado' }) === null, 'entregado es la última etapa');
let mtl = tlOf(mo);
ok(mtl.managed && mtl.canCancel && mtl.steps.length === 4 && !mtl.done, 'pedido por confirmar: 4 etapas y se puede anular');
ok(labelOf(mo).text === 'Por confirmar', 'estado: por confirmar');
mtl = tlOf({ ...mo, status: 'camino', history: [...mo.history, { at: 5, status: 'embalaje' }, { at: 9, status: 'camino' }] });
ok(!mtl.canCancel && mtl.steps[2].done && mtl.steps[2].at === 9 && mtl.next.key === 'entregado', 'en camino: ya no se anula y la siguiente es entregado');
ok(labelOf({ ...mo, status: 'entregado' }).tone === 'ok', 'entregado en verde');
const sm = statusMessage(mo, 'camino', 'Llega en la tarde.');
ok(sm.title === 'Tu pedido va en camino' && sm.text.includes('Moneda 1100') && sm.text.includes('martes 20 de octubre') && sm.text.endsWith('Llega en la tarde.'), 'mensaje «en camino» con dirección, fecha y nota');
ok(dateMessage(mo, '2026-10-22').text.includes('jueves 22 de octubre'), 'mensaje de cambio de fecha');
ok(deliveryWhen(mo, new Date('2026-10-19T15:00:00Z')).startsWith('Llega mañana martes 20'), 'la fecha se escribe según el día de hoy');
ok(deliveryWhen({ delivery: { type: 'retiro', date: '2026-10-20', from: 'desde las 10:00' } }, new Date('2026-10-15T15:00:00Z')) === 'Retira martes 20 de octubre desde las 10:00', 'retiro: día y hora');
ok(deliveryWhen({ delivery: { eta: 'Llega mañana' } }) === 'Llega mañana', 'pedidos de antes (sin fecha) se muestran como estaban');
ok(suggestedTemplate({ ...mo, status: 'embalaje' }) === 'confirmado' && suggestedTemplate({ ...mo, cancelled: true }) === 'anulado', 'el contacto propone el aviso de la etapa actual');

console.log('Carga masiva: planillas CSV y Excel');
const enc = (t) => new TextEncoder().encode(t);
const fx = (f) => new Uint8Array(readFileSync(new URL(`./fixtures/${f}`, import.meta.url)));
ok(JSON.stringify(parseCsv('Código;Nombre;Cantidad\r\n1;"A; ""b""";2\r\n')) === JSON.stringify([['Código', 'Nombre', 'Cantidad'], ['1', 'A; "b"', '2']]), 'CSV con ; y comillas');
ok(parseCsv('codigo,nombre,cantidad\n1,a,2\n')[1][2] === '2' && parseCsv('codigo\tnombre\tcantidad\n1\ta\t2')[1][1] === 'a', 'CSV con coma o tabulador');
ok(parseCsv('sep=,\nCódigo,Cantidad\n1,"1,5"\n')[1][1] === '1,5', 'CSV con la línea sep= de Excel');
ok(decodeText(new Uint8Array([0x43, 0xf3, 0x64])) === 'Cód' && decodeText(new Uint8Array([0xef, 0xbb, 0xbf, 0x43, 0xc3, 0xb3])) === 'Có', 'texto ANSI de Excel y UTF-8 con BOM');
ok(parseQty('1.200').qty === 1200 && parseQty('1 200').qty === 1200 && parseQty('12,0').qty === 12 && parseQty('7').qty === 7, 'cantidades con separador de miles');
ok(!!parseQty('2,5').error && !!parseQty('-3').error && !!parseQty('diez').error && !!parseQty('100000').error && parseQty('  ').empty, 'cantidades inválidas o vacías');
ok(cleanCode("'420101") === '420101' && cleanCode('SKU 420101') === '420101' && cleanCode('420101.0') === '420101' && cleanCode('n12ab') === 'N12AB', 'códigos: apóstrofo, «SKU», .0 y minúsculas');
const hd = findHeader([['Inventario sucursal'], [], ['Descripción', 'Stock', 'SKU']]);
ok(hd && hd.row === 2 && hd.code === 2 && hd.name === 0 && hd.qty === 1, 'títulos en otra fila, otro orden y con otros nombres');
let pl = await readPlanilla(enc('Código;Nombre del producto;Cantidad\n420101;Paracetamol;5\n\n420102;;\n'));
ok(pl.kind === 'csv' && pl.items.length === 2 && pl.items[0].line === 2 && pl.items[1].line === 4, 'CSV: filas con su número como en Excel (sin las vacías)');
pl = await readPlanilla(enc('420101;Paracetamol;5\n420102;Ibuprofeno;2\n'));
ok(pl.noHeader && pl.items.length === 2, 'sin títulos: se leen las columnas A, B y C');
let badMsg = '';
try { await readPlanilla(enc('hola;mundo\nfoo;bar\n')); } catch (e) { badMsg = e.message; }
ok(/títulos/.test(badMsg), 'planilla sin las columnas: avisa qué títulos poner');
badMsg = '';
try { await readPlanilla(new Uint8Array([0xd0, 0xcf, 0x11, 0xe0, 0, 0])); } catch (e) { badMsg = e.message; }
ok(/\.xls/.test(badMsg), 'Excel antiguo (.xls): pide guardarlo como .xlsx o CSV');
pl = await readPlanilla(fx('inventario-excel.xlsx'));
ok(pl.kind === 'xlsx' && pl.sheet === 'Stock octubre' && pl.items.length === 7, 'xlsx de Excel: textos compartidos, títulos en la fila 3');
ok(pl.items[0].code === '420101' && pl.items[1].qtyText === '1200' && pl.items[2].qtyText === '7' && pl.items[6].code === '7801234567890', 'xlsx: números como se ven (sin 7.0 ni notación científica)');
pl = await readPlanilla(fx('inventario-libreoffice.xlsx'));
ok(pl.items.length === 2 && pl.items[0].qtyText === '10', 'xlsx de LibreOffice');
pl = await readPlanilla(fx('inventario-una-columna.xlsx'));
ok(pl.items.length === 2 && pl.items[1].code === '420106', 'CSV abierto todo en la columna A: se vuelve a separar');
pl = await readPlanilla(fx('inventario-ansi.csv'));
ok(pl.items[1].name === 'Crema niño ñandú', 'CSV guardado por Excel en Windows (ANSI): tildes y ñ');
const rowsT = [['420101', 'Paracetamol 500 mg · Piedra', ''], ['420102', '=HYPERLINK("x")', 4]];
pl = await readPlanilla(planillaXlsx(rowsT, { help: ['Cómo llenarla'] }));
ok(pl.sheet === 'Inventario' && pl.items.length === 2 && pl.items[0].qtyText === '' && pl.items[1].qtyText === '4' && pl.items[1].name === '=HYPERLINK("x")', 'la planilla .xlsx que descargamos se vuelve a leer igual');
const csvT = planillaCsv(rowsT);
ok(csvT.startsWith('﻿Código;Nombre del producto;Cantidad\r\n') && csvT.includes(`;"'=HYPERLINK(""x"")";4`), 'CSV para Excel: ; con BOM y sin fórmulas peligrosas');
const prodsT = new Map([['420101', { id: '420101', name: 'Paracetamol 500 mg 16 comprimidos', brand: 'Piedra' }], ['420102', { id: '420102', name: 'Ibuprofeno 400 mg', brand: 'Lab. Andino' }]]);
const ck = checkItems([
  { line: 2, code: '420101', name: 'Paracetamol 500mg', qtyText: '10' },
  { line: 3, code: 'no-existe', name: 'x', qtyText: '3' },
  { line: 4, code: '420101', name: '', qtyText: '5' },
  { line: 5, code: '420102', name: 'Shampoo anticaspa', qtyText: '2' },
  { line: 6, code: '420102', name: '', qtyText: '' },
  { line: 7, code: '', name: 'Sin código', qtyText: '1' },
], (c) => prodsT.get(c) || null);
ok(ck.counts.error === 2 && ck.counts.warn === 3 && ck.counts.empty === 1, 'revisión: errores, advertencias y filas sin cantidad');
ok(ck.load.length === 2 && ck.load.find((x) => x.p.id === '420101').qty === 15, 'el mismo código dos veces se suma');
ok(ck.rows[3].msg.includes('no coincide') && ck.rows[1].msg.includes('no existe'), 'avisa nombre distinto y código inexistente');
ok(nameMatches('Paracetamol 500 mg', 'Paracetamol 500 mg 16 comprimidos · Piedra') && !nameMatches('Shampoo anticaspa', 'Ibuprofeno 400 mg'), 'comparación de nombres');

console.log('Carga masiva: precios, costo, eleventa y productos nuevos');
ok(parseMoney('$2,830').value === 2830 && parseMoney('$2.830').value === 2830 && parseMoney('2830.00').value === 2830 && parseMoney('$ 12.990').value === 12990, 'precios: formato de eleventa ($2,830) y chileno ($2.830)');
ok(parseMoney('').empty && !!parseMoney('-5').error && !!parseMoney('doce').error && parseMoney('$0').value === 0, 'precios vacíos, negativos o con texto');
ok(parseQty('2.00').qty === 2 && parseQty('1,234.00').qty === 1234 && !!parseQty('1.50').error, 'existencia de eleventa (2.00)');
const hx = findHeader([['Código', 'Producto', 'P. Costo', 'P. Venta', 'P. Mayoreo', 'Existencia', 'Inv. Mínimo', 'Inv. Máximo', 'Departamento']]);
ok(hx && hx.code === 0 && hx.name === 1 && hx.cost === 2 && hx.price === 3 && hx.qty === 5 && hx.dept === 8, 'títulos de eleventa: costo, venta, existencia y departamento (sin P. Mayoreo ni Inv. Mínimo)');
ok(findHeader([['SKU', 'Precio al público']])?.price === 1, 'una planilla solo con código y precio sirve');
pl = await readPlanilla(fx('inventario-eleventa.xlsx'));
ok(pl.has.cost && pl.has.price && pl.has.qty && pl.has.dept && pl.items.length === 10 && pl.items[0].costText === '$1,250', 'Excel de eleventa: se leen todas las columnas');
const prodE = new Map([['420101', { id: '420101', name: 'Paracetamol 500 mg 16 comprimidos', brand: 'Piedra', price: 1190 }]]);
let ce = checkItems(pl.items, (c) => prodE.get(c) || null);
ok(ce.counts.error === 9 && ce.load.length === 1 && ce.load[0].price === 1290 && ce.load[0].cost === 600 && ce.load[0].qty === 40, 'sin crear: solo se actualiza el producto que existe (precio, costo y existencia)');
ce = checkItems(pl.items, (c) => prodE.get(c) || null, { create: true });
ok(ce.counts.create === 8 && ce.counts.update === 1 && ce.rows.find((r) => r.code === 'ABC 123').key === 'ABC123', 'creando: 8 productos nuevos (el código con espacio se junta)');
ok(ce.rows.find((r) => r.line === 11).status === 'error' && /\$0/.test(ce.rows.find((r) => r.line === 11).msg), 'precio de venta en $0: no se carga');
ok(checkItems([{ line: 2, code: '420101', name: '', qtyText: '', costText: '$2,000', priceText: '' }], (c) => prodE.get(c) || null).rows[0].msg.includes('costo es mayor'), 'avisa si el costo es mayor que el precio');
ok(checkItems([{ line: 2, code: 'NUEVO1', name: 'Algo', qtyText: '3', costText: '', priceText: '' }], () => null, { create: true }).rows[0].msg.includes('sin precio'), 'producto nuevo sin precio de venta: no se crea');
const pp = (code, name, dept, choice) => proposeProduct({ code, name, dept, price: 1990 }, choice);
let pr = pp('1', 'Losartan 50mg x 30 Com.Rec. Lab Demo', 'BIOEQUIVALENTES');
ok(pr.sub === 'medicamentos/cardiovascular' && pr.def.ai[0] === 'losartán' && pr.def.rx === 'simple' && pr.def.be === 1 && pr.def.u === 30 && pr.def.un === 'comprimido' && pr.def.st === '50 mg' && pr.def.b === 'Demo', 'medicamento: principio activo, categoría, receta, BE, contenido, concentración y laboratorio');
pr = pp('2', 'Crema Dental Menta Fresca 90gr Sonrisa', 'Perfumeria');
ok(pr.sub === 'cuidado-personal/cuidado-bucal' && !pr.hidden && pr.def.u === 90 && pr.def.un === 'g' && pr.def.b === 'Sonrisa', 'perfumería: cuidado bucal, 90 g, marca al final');
ok(pp('3', 'Shampoo Anticaspa 400ml Cabellera', 'Perfumeria').def.c === 'cuidado-personal/cuidado-capilar', 'shampoo → cuidado capilar');
pr = pp('4', 'Clonazepam 2mg x 30 Com. Lab Demo', 'Controlados');
ok(pr.hidden && pr.def.rx === 'retenida' && pr.sub === 'medicamentos/salud-mental-y-sueno', 'controlados: no se publican y quedan con receta retenida');
ok(pp('5', 'Helado Vasito Frutilla 170 ML', 'Helados').hidden, 'helados: no se publican');
pr = pp('6', 'Termometro Digital Flexible Medic', 'Insumos Medicos');
ok(pr.sub === 'medicamentos/monitores-y-diagnostico' && pr.def.rx === 'directa', 'insumos: termómetro de venta directa');
ok(pp('7', 'Vacidox Crema Vaginal 30 Gr Estriol', 'ANTICON Y HORMONAS').def.c === 'medicamentos/anticonceptivos', 'una crema hormonal no se va a dermocosmética');
pr = pp('8', 'Losartan 50mg x 30 Com.Rec. Lab Demo', 'BIOEQUIVALENTES', { sub: 'medicamentos/otros-medicamentos', rx: 'directa' });
ok(pr.sub === 'medicamentos/otros-medicamentos' && pr.def.rx === 'directa', 'lo elegido en el panel para el departamento manda');
ok(prettyName('ALCOHOL 95° 1000 CC ELITE') === 'Alcohol 95° 1000 cc Elite' && prettyName('Colgate Total 12') === 'Colgate Total 12', 'nombres en mayúsculas se ordenan');
ok(parseContent('Abrilar 35 Mg/5mL 100 ML Hedera Helix').u === 100 && parseContent('Valax 160mg x 30 Com.Rec. Valsartan').u === 30 && parseContent('Accualaxan Caja x 7 Sobres (17gr)').un === 'sobre', 'contenido: ml, comprimidos y sobres');
ok(cleanDefP(pp('9', 'Producto sin principio 30 Comp', 'Marca').def, { imported: true }).def && !!cleanDefP({ ...pp('9', 'Producto sin principio 30 Comp', 'Marca').def }).error, 'el principio activo es opcional solo para productos de planilla');
const big = planillaXlsx([['7801', 'X', '', 500, 990, 'Perfumería']]);
pl = await readPlanilla(big);
ok(pl.items[0].costText === '500' && pl.items[0].priceText === '990' && pl.items[0].deptText === 'Perfumería', 'la planilla que descargamos trae costo, precio y departamento');

console.log(`\n${pass} pruebas OK, ${fail} con error`);
if (fail) process.exit(1);

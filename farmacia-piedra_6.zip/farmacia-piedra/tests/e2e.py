"""Pruebas de punta a punta (Playwright) de Farmacias Piedra: la tienda y el
panel de administración, funcionando con el servidor real.

Requisitos: Node.js 22.13+, Python 3 + Playwright (pip install playwright && playwright install chromium).
Uso (desde la carpeta del proyecto, después de "node build.mjs"):
    python3 tests/e2e.py            # todo
    python3 tests/e2e.py tienda     # solo la tienda (escritorio)
    python3 tests/e2e.py panel      # solo el panel de administración
    python3 tests/e2e.py celular    # solo celular
Levanta el servidor con una base de datos nueva (carpeta temporal) y recorre
los flujos principales con datos de prueba. Además prueba la tienda en un solo
archivo (dist/), que funciona sin servidor."""
import asyncio, json, re, subprocess, sys, time, os, struct, zlib, tempfile, hmac, hashlib, base64
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST = os.path.join(ROOT, 'dist')
PORT = int(os.environ.get('E2E_PORT', '8765'))
DIST_PORT = PORT + 1
STORE = f'http://127.0.0.1:{PORT}/'
PANEL = f'http://127.0.0.1:{PORT}/admin/'
LOCAL = f'http://127.0.0.1:{DIST_PORT}/farmacia-piedra.html'
BASE = STORE
TMP = tempfile.mkdtemp(prefix='piedra-e2e-')
SHOTS = os.path.join(TMP, 'capturas')
os.makedirs(SHOTS, exist_ok=True)
SETUP_LINK = ''
ADMIN = {'user': 'admin', 'pw': 'Piedra-Segura-2026'}


def _png(path, w=60, h=80):
    """Imagen PNG mínima (receta de prueba) sin librerías externas."""
    raw = b''.join(b'\x00' + bytes([245, 245, 240] * w) for _ in range(h))
    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    data = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(data)


RX_FILE = os.path.join(TMP, 'receta.png')
_png(RX_FILE)
BANNER_FILE = os.path.join(TMP, 'banner.png')
_png(BANNER_FILE, 900, 320)
PHOTO_FILE = os.path.join(TMP, 'foto-producto.png')
_png(PHOTO_FILE, 900, 700)
SMALL_PHOTO = os.path.join(TMP, 'foto-chica.png')
_png(SMALL_PHOTO, 200, 200)
NOT_PHOTO = os.path.join(TMP, 'documento.pdf')
with open(NOT_PHOTO, 'wb') as fh:
    fh.write(b'%PDF-1.4 prueba')
results = []
console_errors = []


def check(name, cond, detail=''):
    results.append((name, bool(cond), detail))
    print(('  ok   ' if cond else '  FAIL ') + name + (f'  ->  {detail}' if detail and not cond else ''), flush=True)


async def go(pg, r, wait=300):
    await pg.evaluate(f"window.Piedra.go({json.dumps(r)})")
    await pg.wait_for_timeout(wait)


async def route(pg):
    return await pg.evaluate("location.hash.slice(1)")


async def txt(pg, sel):
    loc = pg.locator(sel).first
    if await loc.count() == 0:
        return ''
    return (await loc.inner_text()).strip()


async def kill_toasts(pg):
    await pg.evaluate("document.querySelectorAll('.toast').forEach(t=>t.remove())")




def _console(tag):
    def on(m):
        if m.type not in ('error', 'warning'):
            return
        t = m.text
        # Esperables: fuentes externas sin internet y respuestas 4xx de pruebas a propósito (contraseña mala, sin stock…)
        if 'ERR_TUNNEL' in t or 'fonts.g' in t or re.search(r'status of 4\d\d', t):
            return
        console_errors.append(f'[{tag}] {m.type}: {t}')
    return on


async def new_page(browser, url=None, mobile=False, dark=False, wait='#q', tag=None):
    ctx = await browser.new_context(
        viewport={'width': 390, 'height': 844} if mobile else {'width': 1366, 'height': 900},
        locale='es-CL', timezone_id='America/Santiago', is_mobile=mobile, has_touch=mobile,
        color_scheme='dark' if dark else 'light')
    pg = await ctx.new_page()
    pg.set_default_timeout(10000)
    tag = tag or ('mobile' if mobile else 'desktop')
    pg.on('console', _console(tag))
    pg.on('pageerror', lambda e: console_errors.append(f'[{tag}] pageerror: {e}'))
    pg.on('dialog', lambda d: (console_errors.append(f'[{tag}] native dialog: {d.message}'), asyncio.ensure_future(d.dismiss())))
    await pg.goto(url or STORE)
    await pg.wait_for_selector(wait)
    await pg.wait_for_timeout(300)
    return ctx, pg


async def wait_js(pg, expr, timeout=10000, step=120):
    """Espera a que una expresión sea verdadera. (wait_for_function no sirve aquí:
    la política de seguridad de las páginas (CSP) no permite evaluar texto como código.)"""
    end = time.time() + timeout / 1000
    while True:
        try:
            if await pg.evaluate(expr):
                return True
        except Exception:
            pass
        if time.time() > end:
            raise TimeoutError(f'No se cumplió a tiempo: {expr}')
        await pg.wait_for_timeout(step)


async def store_ready(pg):
    """Espera a que la tienda tenga los datos del servidor."""
    await wait_js(pg, 'window.Piedra && window.Piedra.ds.ready', timeout=10000)
    await pg.wait_for_timeout(150)


async def store_sync(pg):
    """Recarga la tienda (como un cliente que entra después del cambio)."""
    await pg.reload()
    await pg.wait_for_selector('#q')
    await store_ready(pg)


async def pgo(ap, r, wait=350):
    await ap.evaluate(f"window.PiedraPanel.go({json.dumps(r)})")
    await ap.wait_for_timeout(wait)


async def panel_refresh(ap):
    await ap.evaluate('window.PiedraPanel.refresh(true)')
    await ap.wait_for_timeout(300)


async def panel_login(ap, user=None, pw=None):
    if await ap.locator('#al-form').count() == 0:
        return
    await ap.fill('#al-form [name=user]', user or ADMIN['user'])
    await ap.fill('#al-form [name=pass]', pw or ADMIN['pw'])
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    await ap.wait_for_timeout(300)


def totp(secret, offset=0):
    """Código de 6 números como el de la app del celular (RFC 6238)."""
    s = re.sub(r'\s', '', secret).upper()
    s += '=' * ((8 - len(s) % 8) % 8)
    key = base64.b32decode(s)
    h = hmac.new(key, struct.pack('>Q', int(time.time() // 30) + offset), hashlib.sha1).digest()
    o = h[-1] & 15
    return '%06d' % ((struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 1000000)


async def overflow(pg):
    return await pg.evaluate("document.documentElement.scrollWidth > window.innerWidth + 1")


# ─────────────────────────────────────────────────────────────
async def flow_search(pg):
    print('\n· Búsqueda y autocompletado')
    await pg.click('#q')
    await pg.keyboard.type('paqazetami', delay=35)
    await pg.wait_for_selector('#ac:not([hidden])', timeout=4000)
    ac = (await txt(pg, '#ac')).lower()
    check('Autocompletado sugiere paracetamol al escribir "paqazetami"', 'paracetamol' in ac, ac[:200])
    await pg.keyboard.press('Enter')
    await pg.wait_for_timeout(500)
    r = await route(pg)
    check('Enter lleva a /buscar', r.startswith('/buscar'), r)
    h1 = await txt(pg, 'h1')
    check('Título de resultados corregido a paracetamol', 'paracetamol' in h1.lower(), h1)
    note = await txt(pg, '.search-note')
    check('Aviso "Mostrando resultados para paracetamol"', 'Mostrando resultados para' in note and 'paqazetami' in note, note)
    n = await pg.locator('.pcard').count()
    check('Hay tarjetas de paracetamol', n >= 5, str(n))
    names = (await pg.locator('.pcard__name').all_inner_texts())[:6]
    check('Los primeros resultados son paracetamol', all('aracetamol' in x or 'ntigripal' in x for x in names[:4]), str(names))

    # otras búsquedas típicas con errores
    cases = {
        'acetaminofen': 'paracetamol', 'ibuprofeno400': 'ibuprofeno', 'amoxisilina': 'amoxicilina',
        'panadol': 'paracetamol', 'loratadina': 'loratadina', 'protector solar': 'solar', 'pañales': 'pañal',
        'dolor de cabeza': None, 'larroche': 'roche', 'vitamina c': 'vitamina c',
    }
    for q, expect in cases.items():
        await go(pg, f'/buscar?q={q}', 350)
        cnt = await pg.locator('.pcard').count()
        first = (await pg.locator('.pcard__name').all_inner_texts())[:3]
        brands = (await pg.locator('.pcard__brand').all_inner_texts())[:3]
        blob = ' '.join(first + brands).lower()
        ok = cnt > 0 and (expect is None or expect in blob)
        check(f'Búsqueda "{q}" encuentra resultados relevantes', ok, f'{cnt} · {first}')

    # sin resultados
    await go(pg, '/buscar?q=xqzwv', 350)
    empty = await txt(pg, 'main')
    check('Búsqueda sin sentido muestra estado vacío útil', 'No encontramos' in empty, empty[:160])

    # navegación por teclado en el autocompletado
    await go(pg, '/', 300)
    await pg.fill('#q', '')
    await pg.click('#q')
    await pg.keyboard.type('ibupro', delay=35)
    await pg.wait_for_selector('#ac:not([hidden])', timeout=4000)
    await pg.keyboard.press('ArrowDown')
    act = await pg.evaluate("document.querySelector('#ac .is-active')?.textContent?.trim() || ''")
    check('Flecha abajo marca una opción del autocompletado', bool(act), act)
    await pg.keyboard.press('Enter')
    await pg.wait_for_timeout(450)
    r = await route(pg)
    check('Enter sobre la opción navega', r.startswith('/buscar') or r.startswith('/producto') or r.startswith('/categoria'), r)
    await pg.fill('#q', '')
    await pg.keyboard.press('Escape')


async def flow_cart_checkout(pg):
    print('\n· Carro y compra como invitado (con receta)')
    await go(pg, '/buscar?q=paracetamol', 400)
    first_add = pg.locator('.pcard [data-action="add"]').first
    pid = await first_add.get_attribute('data-id')
    await first_add.click()
    await pg.wait_for_timeout(250)
    check('Contador del carro = 1 tras agregar', (await txt(pg, '#cart-count')) == '1', await txt(pg, '#cart-count'))
    check('Aviso (toast) de producto agregado', 'Agregaste' in await txt(pg, '#toasts'))
    await pg.locator(f'[data-cart-slot="{pid}"] [data-action="qty-inc"]').click()
    await pg.wait_for_timeout(200)
    check('Botón + del stepper suma (2)', (await txt(pg, '#cart-count')) == '2', await txt(pg, '#cart-count'))
    await pg.locator(f'[data-cart-slot="{pid}"] [data-action="qty-dec"]').click()
    await pg.wait_for_timeout(200)
    check('Botón − del stepper resta (1)', (await txt(pg, '#cart-count')) == '1')

    # producto con receta: losartán
    await go(pg, '/buscar?q=losartan', 400)
    await pg.locator('.pcard__name a').first.click()
    await pg.wait_for_timeout(450)
    r = await route(pg)
    check('Clic en nombre abre ficha de producto', r.startswith('/producto/'), r)
    pdp_title = await txt(pg, 'h1')
    check('Ficha muestra el nombre', 'osart' in pdp_title, pdp_title)
    pdp_text = await txt(pg, 'main')
    check('Ficha indica condición de venta con receta', 'Receta' in pdp_text or 'receta' in pdp_text)
    stock_btn = pg.locator('[data-stock]').first
    if await stock_btn.count():
        await stock_btn.click()
        await pg.wait_for_selector('.ov--modal.is-open', timeout=3000)
        st = await txt(pg, '.ov--modal .ov__body')
        check('Modal "Ver stock" lista farmacias', 'Piedra' in st or 'unidades' in st.lower() or 'stock' in st.lower(), st[:120])
        await pg.keyboard.press('Escape')
        await pg.wait_for_timeout(300)
    else:
        check('Botón Ver stock presente', False)
    main_add = pg.locator('.pdp [data-add-qty]').first
    await main_add.click()
    await pg.wait_for_timeout(300)
    check('Agregar desde la ficha suma al carro (2)', (await txt(pg, '#cart-count')) == '2', await txt(pg, '#cart-count'))

    # tercer producto para probar quitar
    await go(pg, '/buscar?q=protector solar', 400)
    third = pg.locator('.pcard [data-action="add"]').first
    third_id = await third.get_attribute('data-id')
    await third.click()
    await pg.wait_for_timeout(250)

    # mini carro
    await kill_toasts(pg)
    await pg.click('[data-action="open-cart"]')
    await pg.wait_for_selector('.ov--drawer.is-open', timeout=3000)
    mini = await txt(pg, '.ov--drawer .ov__body')
    check('Mini carro lista los 3 productos', mini.count('×') >= 0 and 'osart' in mini and 'aracetamol' in mini, mini[:200])
    await pg.click('.ov--drawer a[href="#/carro"]')
    await pg.wait_for_timeout(450)
    check('"Ir al carro" abre /carro', (await route(pg)) == '/carro')
    check('Mini carro se cierra al navegar', await pg.locator('.ov--drawer.is-open').count() == 0)

    lines = await pg.locator('.cline').count()
    check('Carro con 3 líneas', lines == 3, str(lines))
    cart_txt = await txt(pg, 'main')
    check('Carro avisa que hay medicamentos con receta', 'medicamentos con receta' in cart_txt)

    # cupones
    await pg.fill('#f-coupon', 'NOEXISTE')
    await pg.click('#coupon-form button[type=submit]')
    await pg.wait_for_timeout(200)
    err = await txt(pg, '#coupon-form .field__error')
    check('Cupón inválido muestra error', bool(err), err)
    await pg.fill('#f-coupon', 'bienvenida10')
    await pg.click('#coupon-form button[type=submit]')
    await pg.wait_for_timeout(300)
    summ = await txt(pg, '.summary')
    check('Cupón BIENVENIDA10 aplicado (en minúsculas)', 'BIENVENIDA10' in summ, summ[:200])

    # quitar con confirmación (cancelar y luego confirmar)
    await kill_toasts(pg)
    await pg.click(f'[data-remove="{third_id}"]')
    await pg.wait_for_selector('.ov--modal.is-open [data-answer="no"]', timeout=3000)
    await pg.click('.ov--modal.is-open [data-answer="no"]')
    await pg.wait_for_timeout(300)
    check('Cancelar en el diálogo mantiene la línea', await pg.locator('.cline').count() == 3)
    await pg.click(f'[data-remove="{third_id}"]')
    await pg.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await pg.click('.ov--modal.is-open [data-answer="yes"]')
    await pg.wait_for_timeout(400)
    check('Confirmar quita la línea', await pg.locator('.cline').count() == 2, str(await pg.locator('.cline').count()))
    total_cart = await txt(pg, '.summary__total b')

    # checkout
    await pg.click('a[href="#/checkout"]')
    await pg.wait_for_timeout(450)
    check('Continuar compra abre /checkout', (await route(pg)) == '/checkout')
    f = pg.locator('#f-customer')
    await f.locator('[name=nombre]').fill('Prueba')
    await f.locator('[name=apellidos]').fill('Demo Piedra')
    await f.locator('[name=rut]').fill('12.345.678-9')
    await f.locator('[name=phone]').fill('81234567')
    await f.locator('[name=email]').fill('correo-malo')
    await f.locator('button[type=submit]').click()
    await pg.wait_for_timeout(250)
    errs = await pg.locator('#f-customer .field__error').all_inner_texts()
    errs = [e for e in errs if e.strip()]
    check('Paso 1 valida RUT, celular y correo', len(errs) >= 3, str(errs))
    await f.locator('[name=rut]').fill('12345678-5')
    await f.locator('[name=phone]').fill('9 1234 5678')
    await f.locator('[name=email]').fill('prueba.demo@example.com')
    await f.locator('button[type=submit]').click()
    await pg.wait_for_timeout(500)
    s1 = await txt(pg, '#co-1 .co-step__summary')
    check('Paso 1 completo y resumido', 'Prueba' in s1 and 'example.com' in s1, s1)

    # paso 2 despacho
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(250)
    errs = [e for e in await pg.locator('#f-address .field__error').all_inner_texts() if e.strip()]
    check('Paso 2 exige calle y número', len(errs) >= 2, str(errs))
    await pg.fill('#f-address [name=calle]', 'Av. Libertador Bernardo O\'Higgins')
    await pg.fill('#f-address [name=numero]', '1234')
    await pg.fill('#f-address [name=depto]', 'Depto. 501')
    exp = pg.locator('input[name=speed][value=express]')
    if await exp.count() and await exp.is_enabled():
        await exp.check()
        await pg.wait_for_timeout(200)
        sm = await txt(pg, '#co-summary')
        check('Express actualiza el costo de despacho en el resumen', 'Despacho' in sm and '$' in sm, sm[-120:])
        await pg.locator('input[name=speed][value=estandar]').check()
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(500)
    check('Pasa al paso de recetas', await pg.locator('#co-3:not(.is-locked)').count() == 1)

    # paso 3 recetas
    await pg.click('[data-continue="3"]')
    await pg.wait_for_timeout(200)
    check('Sin receta adjunta muestra error', 'Falta adjuntar' in await txt(pg, '#rx-error'))
    await pg.set_input_files('[data-rx-file]', RX_FILE)
    await pg.wait_for_selector('.rx-upload__file', timeout=4000)
    check('Receta adjunta con miniatura', await pg.locator('.rx-upload__file img').count() == 1)
    await pg.click('[data-continue="3"]')
    await pg.wait_for_timeout(200)
    check('Exige la declaración de autenticidad', 'declaración' in await txt(pg, '#rx-error'))
    await pg.check('#rx-declare')
    await pg.click('[data-continue="3"]')
    await pg.wait_for_timeout(500)
    check('Pasa al paso de pago', await pg.locator('#co-4:not(.is-locked)').count() == 1)

    # paso 4 pago
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(200)
    check('Exige aceptar términos', 'términos' in await txt(pg, '#pay-error'))
    await pg.click('[data-doc="factura"]')
    await pg.wait_for_timeout(300)
    await pg.check('#co-terms')
    await pg.fill('#f-factura [name=rut]', '76.123.456-0')
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(250)
    ferr = [e for e in await pg.locator('#f-factura .field__error').all_inner_texts() if e.strip()]
    check('Factura valida RUT empresa, razón social y giro', len(ferr) >= 2, str(ferr))
    await pg.click('[data-doc="boleta"]')
    await pg.wait_for_timeout(300)
    if not await pg.locator('#co-terms').is_checked():
        await pg.check('#co-terms')
    pay_label = await txt(pg, '[data-pay]')
    await pg.click('[data-pay]')
    await pg.wait_for_selector('.ov--modal.is-open [data-gw]', timeout=3000)
    gw = await txt(pg, '.gateway__amount')
    check('Pasarela muestra el mismo monto que el botón', gw.replace('.', '') in pay_label.replace('.', ''), f'{gw} vs {pay_label}')
    await pg.click('[data-gw="no"]')
    await pg.wait_for_timeout(400)
    check('Pago rechazado avisa y no crea pedido', 'rechazado' in await txt(pg, '#toasts') and (await route(pg)) == '/checkout')
    await pg.click('[data-pay]')
    await pg.wait_for_selector('.ov--modal.is-open [data-gw="ok"]', timeout=3000)
    await pg.click('[data-gw="ok"]')
    await pg.wait_for_timeout(1800)
    r = await route(pg)
    check('Pago aprobado lleva a la confirmación del pedido', r.startswith('/pedido/PD') and 'nuevo=1' in r, r)
    order_id = re.search(r'/pedido/(PD\w+)', r).group(1) if 'PD' in r else ''
    thanks = await txt(pg, '.thanks')
    check('Página de gracias con nombre y número', 'Prueba' in thanks and order_id in thanks, thanks[:160])
    check('Carro queda vacío tras comprar', (await txt(pg, '#cart-count')) == '0')
    tot = await txt(pg, '.summary__total')
    check('Resumen dice "Total pagado" (tarjeta)', 'Total pagado' in tot, tot)
    check('Pedido registra la receta adjunta', 'receta.png' in await txt(pg, 'main'))
    await pg.screenshot(path=f'{SHOTS}/order_confirm.png', full_page=True)

    # seguimiento
    await go(pg, '/seguimiento', 400)
    await pg.fill('#track-form [name=pedido]', order_id.lower())
    await pg.fill('#track-form [name=email]', 'otro@example.com')
    await pg.click('#track-form button[type=submit]')
    await pg.wait_for_timeout(700)
    tf = await txt(pg, '#track-form')
    check('Seguimiento rechaza correo distinto (lo revisa el servidor)', 'No encontramos un pedido con ese número y ese correo' in tf, tf)
    await pg.fill('#track-form [name=email]', 'PRUEBA.demo@example.com')
    await pg.click('#track-form button[type=submit]')
    await pg.wait_for_timeout(700)
    check('Seguimiento encuentra el pedido (id en minúsculas)', (await route(pg)) == f'/pedido/{order_id}', await route(pg))
    # anular
    await kill_toasts(pg)
    if await pg.locator('[data-cancel]').count():
        await pg.click('[data-cancel]')
        await pg.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
        await pg.click('.ov--modal.is-open [data-answer="yes"]')
        await pg.wait_for_timeout(900)
        check('Anular pedido muestra estado anulado', 'Anulado' in await txt(pg, '#tl') or 'anulado' in (await txt(pg, '#tl')).lower(), await txt(pg, '#tl'))
    else:
        check('Botón anular disponible en pedido nuevo', False)
    return order_id


async def flow_account(pg):
    print('\n· Cuenta: registro, sesión, pestañas, compra con retiro')
    await go(pg, '/registro', 400)
    await pg.click('#reg-form button[type=submit]')
    await pg.wait_for_timeout(250)
    errs = [e for e in await pg.locator('#reg-form .field__error').all_inner_texts() if e.strip()]
    check('Registro vacío muestra errores', len(errs) >= 5, str(errs))
    f = pg.locator('#reg-form')
    await f.locator('[name=rut]').fill('11.111.111-1')
    await f.locator('[name=nombre]').fill('Camila')
    await f.locator('[name=apellidoP]').fill('Rojas')
    await f.locator('[name=apellidoM]').fill('Soto')
    await f.locator('[name=email]').fill('camila.prueba@example.com')
    await f.locator('[name=phone]').fill('+56 9 8765 4321')
    await f.locator('[name=password]').fill('corta')
    hint = await txt(pg, '#reg-form [name=password] ~ .field__hint') or await pg.evaluate("document.querySelector('#reg-form [name=password]').closest('.field').querySelector('.field__hint').textContent")
    check('Indicador de contraseña pide más requisitos', 'Falta' in hint, hint)
    test_pw = 'Prueba' + str(int(time.time()) % 10000) + 'x'
    await f.locator('[name=password]').fill(test_pw)
    await f.locator('[name=password2]').fill(test_pw)
    await f.locator('[name=terms]').check()
    await f.locator('button[type=submit]').click()
    await pg.wait_for_timeout(700)
    r = await route(pg)
    check('Registro exitoso lleva a Mi cuenta', r.startswith('/cuenta'), r)
    check('Cabecera saluda a la usuaria', 'Camila' in await txt(pg, '#acct-label'), await txt(pg, '#acct-label'))

    for tab in ['pedidos', 'recetas', 'direcciones', 'favoritos', 'tratamiento', 'datos']:
        await go(pg, f'/cuenta/{tab}', 300)
        h = await txt(pg, '.acct h2.sec-title, .acct .sec-title')
        check(f'Pestaña {tab} carga', bool(h), h)

    # dirección
    await go(pg, '/cuenta/direcciones', 300)
    await pg.fill('#addr-form [name=alias]', 'Casa')
    await pg.fill('#addr-form [name=calle]', 'Los Aromos')
    await pg.fill('#addr-form [name=numero]', '55')
    await pg.click('#addr-form button[type=submit]')
    await pg.wait_for_timeout(400)
    check('Guardar dirección la muestra en la lista', 'Los Aromos 55' in await txt(pg, 'main'))

    # receta guardada
    await go(pg, '/cuenta/recetas', 300)
    await pg.set_input_files('[data-save-rx]', RX_FILE)
    await pg.wait_for_timeout(700)
    check('Subir receta en Mis recetas la guarda', 'receta.png' in await txt(pg, 'main'))

    # mis datos
    await go(pg, '/cuenta/datos', 300)
    await pg.fill('#data-form [name=phone]', '123')
    await pg.click('#data-form button[type=submit]')
    await pg.wait_for_timeout(250)
    check('Mis datos valida celular', 'celular' in (await txt(pg, '#data-form')).lower())
    await pg.fill('#data-form [name=phone]', '987654322')
    await pg.click('#data-form button[type=submit]')
    await pg.wait_for_timeout(300)
    check('Mis datos guarda cambios', 'Guardamos' in await txt(pg, '#toasts'))

    # tratamiento
    await go(pg, '/cuenta/tratamiento', 300)
    btn = pg.locator('[data-treat]').first
    if await btn.count():
        await btn.click()
        await pg.wait_for_timeout(350)
        check('Inscribir en Mi Tratamiento', 'Inscritos (1/' in await txt(pg, 'main'), (await txt(pg, 'main'))[:200])
    else:
        check('Hay productos elegibles para Mi Tratamiento', False)

    # favoritos
    await go(pg, '/', 400)
    fav = pg.locator('.pcard .fav').first
    await fav.click()
    await pg.wait_for_timeout(250)
    check('Corazón marca favorito', await pg.locator('.pcard .fav.is-on').count() >= 1)
    await go(pg, '/cuenta/favoritos', 300)
    check('Favorito aparece en Mi cuenta', await pg.locator('.acct .pcard').count() == 1)

    # club page with member
    await go(pg, '/club', 400)
    club = await txt(pg, 'main')
    check('Página Club carga beneficios', 'Club' in club and ('Lunes' in club or 'lunes' in club))

    # compra logueada con retiro y pago en farmacia
    await go(pg, '/categoria/cuidado-personal', 400)
    await pg.locator('.pcard [data-action="add"]').first.click()
    await pg.wait_for_timeout(250)
    await go(pg, '/checkout', 500)
    check('Usuaria con sesión parte en el paso de entrega', await pg.locator('#co-1.is-done').count() == 1)
    await pg.click('[data-dtype="retiro"]')
    await pg.wait_for_timeout(350)
    radios = await pg.locator('input[name=store]').count()
    check('Retiro lista farmacias', radios > 0, str(radios))
    if radios > 1:
        await pg.locator('input[name=store]').nth(1).check()
    await pg.click('[data-pickup-by="otra"]')
    await pg.wait_for_timeout(300)
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(250)
    check('Retiro por otra persona exige nombre y RUT', len([e for e in await pg.locator('#f-pickup .field__error').all_inner_texts() if e.strip()]) >= 2)
    await pg.fill('#f-pickup [name=pickupName]', 'Pedro Rojas')
    await pg.fill('#f-pickup [name=pickupRut]', '9.876.543-3')
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(450)
    pay_step = await pg.locator('.co-step:not(.is-locked) [data-pay]').count()
    check('Sin receta pasa directo a pago (3 pasos)', pay_step == 1)
    await pg.locator('label.radio-card', has=pg.locator('input[name=pay][value=farmacia]')).click()
    await pg.wait_for_timeout(300)
    await pg.check('#co-terms')
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(700)
    r = await route(pg)
    check('Pago en farmacia confirma sin pasarela', r.startswith('/pedido/PD'), r)
    m = await txt(pg, 'main')
    check('Pedido de retiro muestra farmacia y quién retira', 'Pedro Rojas' in m and 'Retiro en farmacia' in m)
    check('Pago pendiente dice "Total a pagar"', 'Total a pagar' in m)
    await go(pg, '/cuenta/pedidos', 300)
    check('Mis pedidos lista el pedido', await pg.locator('.order-card').count() >= 1)

    # cerrar sesión y volver a entrar
    await go(pg, '/cuenta', 300)
    await pg.click('.acct-hello [data-logout]')
    await pg.wait_for_timeout(400)
    check('Cerrar sesión vuelve al inicio', (await route(pg)) == '/' and 'Ingresa' in await txt(pg, '#acct-label'))
    await go(pg, '/ingresar', 300)
    await pg.fill('#login-form [name=email]', 'camila.prueba@example.com')
    await pg.fill('#login-form [name=password]', test_pw + 'mal')
    await pg.click('#login-form button[type=submit]')
    await pg.wait_for_timeout(500)
    check('Contraseña incorrecta muestra error', bool(await txt(pg, '#login-error')), await txt(pg, '#login-error'))
    await pg.fill('#login-form [name=password]', test_pw)
    await pg.click('#login-form button[type=submit]')
    await pg.wait_for_timeout(600)
    check('Ingreso correcto', (await route(pg)).startswith('/cuenta') and 'Camila' in await txt(pg, '#acct-label'))
    # recuperar contraseña
    await go(pg, '/cuenta', 300)
    await pg.click('.acct-hello [data-logout]')
    await pg.wait_for_timeout(300)
    await go(pg, '/ingresar', 300)
    await pg.click('[data-forgot]')
    await pg.wait_for_selector('#forgot', timeout=3000)
    await pg.fill('#forgot [name=email]', 'camila.prueba@example.com')
    await pg.click('#forgot button[type=submit]')
    await pg.wait_for_timeout(250)
    check('Recuperar contraseña confirma envío', 'enlace' in await txt(pg, '.ov--modal.is-open'))
    await pg.keyboard.press('Escape')
    await pg.wait_for_timeout(250)


async def flow_pages(pg):
    print('\n· Otras secciones')
    # farmacias
    await go(pg, '/farmacias', 400)
    n_all = await pg.locator('.store').count()
    check('Farmacias lista locales de la región', n_all > 0, str(n_all))
    await pg.check('#stores-form [name=turno]')
    await pg.wait_for_timeout(400)
    check('Filtro "De turno" cambia el título', 'turno' in (await txt(pg, 'h1')).lower())
    await pg.select_option('#s-region', 'VIII')
    await pg.wait_for_timeout(400)
    reg = await txt(pg, '.toolbar__count')
    check('Cambiar región filtra farmacias', 'Biob' in reg or await pg.locator('.store').count() >= 0, reg)
    await go(pg, '/farmacias', 400)
    b = pg.locator('[data-set-loc]').first
    loc_target = (await b.get_attribute('data-set-loc')).split('|')[1]
    await b.click()
    await pg.wait_for_timeout(300)
    check('"Ver stock de…" cambia la comuna', loc_target in await txt(pg, '.js-loc'), f'{loc_target} vs {await txt(pg, ".js-loc")}')

    # cotizar receta
    await go(pg, '/cotizar-receta', 400)
    await pg.click('#qs')
    await pg.keyboard.type('losartan 50', delay=30)
    await pg.wait_for_selector('#qac:not([hidden])', timeout=3000)
    await pg.keyboard.press('Enter')
    await pg.wait_for_timeout(250)
    await pg.keyboard.type('paqazetami', delay=30)
    await pg.wait_for_selector('#qac:not([hidden])', timeout=3000)
    qac = await txt(pg, '#qac')
    check('Cotizador corrige "paqazetami"', 'aracetamol' in qac, qac[:120])
    await pg.keyboard.press('Enter')
    await pg.wait_for_timeout(250)
    check('Cotizador agrega 2 líneas', await pg.locator('.qline').count() == 2)
    swap = pg.locator('[data-swap]').first
    if await swap.count():
        await swap.click()
        await pg.wait_for_timeout(250)
        check('Cambiar a alternativa más económica', await pg.locator('.qline').count() >= 1)
    before = int(await txt(pg, '#cart-count') or 0)
    await pg.click('[data-q-all]')
    await pg.wait_for_timeout(450)
    check('Agregar todo lleva al carro', (await route(pg)) == '/carro' and int(await txt(pg, '#cart-count')) >= before + 2)
    # cotizar por foto
    await go(pg, '/cotizar-receta?modo=foto', 400)
    await pg.click('#photo-form button[type=submit]')
    await pg.wait_for_timeout(200)
    check('Cotizar por foto exige archivo', 'Adjunta' in await txt(pg, '#photo-error'))
    await pg.set_input_files('#photo-form [name=file]', RX_FILE)
    await pg.fill('#photo-form [name=nombre]', 'Luis Prueba')
    await pg.fill('#photo-form [name=phone]', '912345678')
    await pg.fill('#photo-form [name=email]', 'luis@example.com')
    await pg.click('#photo-form button[type=submit]')
    await pg.wait_for_timeout(300)
    check('Cotizar por foto entrega folio', 'folio' in await txt(pg, 'main'))

    # bioequivalentes
    await go(pg, '/bioequivalentes', 400)
    bio = await txt(pg, 'main')
    check('Página bioequivalentes carga', 'bioequivalente' in bio.lower())
    await go(pg, '/bioequivalentes/todos', 400)
    check('Listado de bioequivalentes con productos', await pg.locator('.pcard').count() > 5)

    # marcas
    await go(pg, '/marcas', 400)
    links = pg.locator('.brand-list a')
    nb = await links.count()
    check('Marcas lista enlaces', nb > 10, str(nb))
    if nb:
        await links.first.click()
        await pg.wait_for_timeout(450)
        check('Marca abre listado filtrado', await pg.locator('.pcard').count() > 0, await route(pg))

    # ayuda
    await go(pg, '/ayuda', 400)
    await pg.fill('#help-q', 'cuanto demora el despacho')
    await pg.click('#help-form button[type=submit]')
    await pg.wait_for_timeout(400)
    check('Buscador de ayuda encuentra respuestas', 'respuesta' in await txt(pg, 'main'))
    await go(pg, '/ayuda/contacto', 400)
    await pg.click('#contact-form button[type=submit]')
    await pg.wait_for_timeout(200)
    check('Contacto valida campos', len([e for e in await pg.locator('#contact-form .field__error').all_inner_texts() if e.strip()]) >= 3)
    await pg.fill('#contact-form [name=nombre]', 'Ana')
    await pg.fill('#contact-form [name=email]', 'ana@example.com')
    await pg.fill('#contact-form [name=mensaje]', 'Hola, consulta de prueba.')
    await pg.click('#contact-form button[type=submit]')
    await pg.wait_for_timeout(250)
    check('Contacto confirma envío', 'Recibimos tu mensaje' in await txt(pg, 'main'))
    await go(pg, '/ayuda/reclamos', 400)
    await pg.fill('#claim-form [name=nombre]', 'Ana Prueba')
    await pg.fill('#claim-form [name=rut]', '12.345.678-0')
    await pg.fill('#claim-form [name=email]', 'ana@example.com')
    await pg.fill('#claim-form [name=detalle]', 'Detalle de prueba.')
    await pg.click('#claim-form button[type=submit]')
    await pg.wait_for_timeout(200)
    check('Reclamos valida RUT', 'RUT' in await txt(pg, '#claim-form'))
    await pg.fill('#claim-form [name=rut]', '12.345.678-5')
    await pg.click('#claim-form button[type=submit]')
    await pg.wait_for_timeout(250)
    check('Reclamo entrega folio', 'folio' in await txt(pg, 'main'))

    # legales y 404
    for doc in ['terminos', 'privacidad', 'quienes-somos', 'trabaja-con-nosotros']:
        await go(pg, f'/legal/{doc}', 300)
        check(f'Legal {doc} carga', bool(await txt(pg, 'h1')) and 'No encontramos' not in await txt(pg, 'h1'), await txt(pg, 'h1'))
    await go(pg, '/no-existe-esta-pagina', 300)
    check('Ruta inexistente muestra 404', '404' in await txt(pg, 'main'))
    await go(pg, '/producto/no-existe', 300)
    check('Producto inexistente muestra aviso', 'No encontramos' in await txt(pg, 'main'))
    await go(pg, '/pedido/PD000', 300)
    check('Pedido inexistente muestra aviso', 'No encontramos' in await txt(pg, 'main'))


async def flow_listing(pg):
    print('\n· Listados: filtros, orden, paginación, categorías')
    await go(pg, '/categoria/medicamentos', 450)
    total0 = await txt(pg, '.toolbar__count b')
    opt = pg.locator('.filters [data-filter="marca"]').first
    await opt.check()
    await pg.wait_for_timeout(450)
    r = await route(pg)
    check('Filtro de marca agrega parámetro', 'marca=' in r, r)
    total1 = await txt(pg, '.toolbar__count b')
    check('Filtro reduce resultados', int(total1.replace('.', '')) < int(total0.replace('.', '')), f'{total0} -> {total1}')
    check('Chip de filtro activo visible', await pg.locator('.active-filters button').count() >= 1)
    await pg.locator('.active-filters button').first.click()
    await pg.wait_for_timeout(450)
    check('Quitar chip limpia el filtro', 'marca=' not in await route(pg))
    await pg.select_option('#sort', 'precio-asc')
    await pg.wait_for_timeout(450)
    check('Ordenar agrega parámetro', 'orden=precio-asc' in await route(pg), await route(pg))
    prices = await pg.evaluate("[...document.querySelectorAll('.pcard .price__now')].map(e=>+e.textContent.replace(/\\D/g,''))")
    check('Orden por menor precio es ascendente', prices == sorted(prices), str(prices[:8]))
    await pg.select_option('#sort', 'precio-desc')
    await pg.wait_for_timeout(450)
    prices = await pg.evaluate("[...document.querySelectorAll('.pcard .price__now')].map(e=>+e.textContent.replace(/\\D/g,''))")
    check('Orden por mayor precio es descendente', prices == sorted(prices, reverse=True), str(prices[:8]))
    pager = pg.locator('.pager a, .pager button').filter(has_text='2')
    if await pager.count():
        await pager.first.click()
        await pg.wait_for_timeout(450)
        check('Paginación va a la página 2', 'pag=2' in await route(pg), await route(pg))
    sub = pg.locator('.sub-chips a').nth(1)
    await sub.click()
    await pg.wait_for_timeout(450)
    r = await route(pg)
    check('Subcategoría abre su listado', r.count('/') >= 3, r)
    for c in ['dermocosmetica', 'vitaminas-y-suplementos', 'infantil-y-mama', 'cuidado-personal', 'belleza', 'mascotas']:
        await go(pg, f'/categoria/{c}', 350)
        check(f'Categoría {c} con productos', await pg.locator('.pcard').count() > 0)
    await go(pg, '/ofertas', 350)
    check('Ofertas con productos', await pg.locator('.pcard').count() > 0)
    # precio filtro
    await go(pg, '/categoria/dermocosmetica', 400)
    grp = pg.locator('.filters details.fgroup', has=pg.locator('[data-filter="precio"]'))
    if not await grp.evaluate('d => d.open'):
        await grp.locator('summary').click()
    pr = pg.locator('.filters [data-filter="precio"]:not([value=""])').first
    await pr.check()
    await pg.wait_for_timeout(450)
    check('Filtro de precio aplica', 'precio=' in await route(pg), await route(pg))
    prices = await pg.evaluate("[...document.querySelectorAll('.pcard .price__now')].map(e=>+e.textContent.replace(/\\D/g,''))")
    rng = (await route(pg)).split('precio=')[1].split('&')[0]
    lo, hi = [int(x) for x in rng.split('-')] if '-' in rng else (0, 10**9)
    check('Precios dentro del rango elegido', all(lo <= x <= hi for x in prices), f'{rng}: {prices[:8]}')


async def flow_header(pg):
    print('\n· Cabecera: comuna, megamenú, asistente')
    await go(pg, '/', 300)
    await kill_toasts(pg)
    await pg.click('.hdr-act--loc')
    await pg.wait_for_selector('#loc-form', timeout=3000)
    await pg.select_option('#loc-region', 'IX')
    await pg.wait_for_timeout(150)
    await pg.select_option('#loc-comuna', 'Temuco')
    await pg.click('#loc-form button[type=submit]')
    await pg.wait_for_timeout(350)
    check('Modal de comuna cambia a Temuco', 'Temuco' in await txt(pg, '.js-loc'))
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 450)
    pdp = await txt(pg, 'main')
    check('Ficha recalcula entrega para Temuco', 'Temuco' in pdp, pdp[:300])
    # megamenú
    await go(pg, '/', 300)
    await pg.click('.catnav__all')
    await pg.wait_for_timeout(300)
    check('Megamenú se abre', await pg.locator('#mega:not([hidden])').count() == 1)
    cards = await pg.evaluate("""[...document.querySelectorAll('#mega .mcard')].map(a => { const r = a.getBoundingClientRect(); const cs = getComputedStyle(a);
        const mid = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
        return { t: a.textContent.replace(/\\s+/g, ' ').trim(), color: cs.color, bg: cs.backgroundImage, display: cs.display, left: r.left, right: r.right, w: r.width, top: mid ? a.contains(mid) : false }; })""")
    check('Menú «Categorías»: tarjetas del Club y Bioequivalentes', len(cards) == 2 and ('Club Piedra' in cards[0]['t'] or 'Hoy en el Club' in cards[0]['t']) and 'Bioequivalentes' in cards[1]['t'], str(cards)[:300])
    check('Tarjetas del menú: texto blanco sobre fondo de color (se notan)', all(c['color'] == 'rgb(255, 255, 255)' and 'gradient' in c['bg'] and c['display'] == 'grid' for c in cards), str(cards)[:300])
    check('Tarjetas del menú: dentro de su columna, del mismo ancho y alineadas', cards and all(c['right'] <= 1366 and abs(c['left'] - cards[0]['left']) < 1 and abs(c['w'] - cards[0]['w']) < 1 for c in cards), str(cards)[:300])
    check('Con el menú abierto, el asistente no tapa las tarjetas', all(c['top'] for c in cards), str(cards)[:300])
    link = pg.locator('#mega a[href^="#/categoria/"]').nth(3)
    href = await link.get_attribute('href')
    await link.click()
    await pg.wait_for_timeout(450)
    check('Enlace del megamenú navega y lo cierra', (await route(pg)) == href[1:] and await pg.locator('#mega[hidden]').count() == 1, f'{await route(pg)} vs {href}')
    # asistente: ventanita fija en la esquina
    await go(pg, '/', 300)
    check('Ventanita de ayuda visible en la esquina', await pg.locator('#hb .hb__card').is_visible())
    t1 = await txt(pg, '.hb__say')
    await pg.wait_for_timeout(6600)
    t2 = await txt(pg, '.hb__say')
    check('La ventanita va cambiando la frase', t1 and t2 and t1 != t2 and t2.startswith('¿'), f'{t1} -> {t2}')
    await pg.click('.hb__quick .hb__chip:has-text("Farmacias de turno")')
    await pg.wait_for_timeout(1700)
    check('Botón de la ventanita abre la conversación y responde', await pg.locator('#hb.is-chat').count() == 1 and await pg.locator('#hb-log .hbs').count() >= 1)
    await pg.fill('#hb-q', 'hacen despacho a temuco')
    await pg.press('#hb-q', 'Enter')
    await pg.wait_for_timeout(1700)
    check('Asistente responde sobre despacho', 'despachamos a Temuco' in await txt(pg, '#hb-log'))
    await pg.fill('#hb-q', 'paqazetami')
    await pg.press('#hb-q', 'Enter')
    await pg.wait_for_timeout(1700)
    first = pg.locator('#hb-log .hbp').first
    check('Asistente encuentra productos con errores de escritura', await first.count() == 1 and 'aracetamol' in await first.inner_text())
    await first.click()
    await pg.wait_for_timeout(500)
    check('Producto del chat abre su ficha (el chat sigue abierto)', (await route(pg)).startswith('/producto/') and await pg.locator('#hb.is-chat').count() == 1, await route(pg))
    await pg.focus('#hb-q')
    await pg.keyboard.press('Escape')
    await pg.wait_for_timeout(250)
    check('Escape cierra la conversación (en la ficha queda el botón, sin tapar la compra)', await pg.locator('#hb.is-chat').count() == 0 and await pg.locator('#hb .hb__pill').is_visible() and not await pg.locator('#hb .hb__card').is_visible())
    await go(pg, '/', 300)
    check('En la portada vuelve la ventanita', await pg.locator('#hb .hb__card').is_visible())
    await pg.click('#hb [data-hb="shrink"]')
    await pg.wait_for_timeout(250)
    check('Botón "–" la achica a un botón que sigue presente', await pg.locator('#hb .hb__pill').is_visible() and not await pg.locator('#hb .hb__card').is_visible())
    await pg.click('#hb .hb__pill')
    await pg.wait_for_timeout(400)
    check('El botón abre la conversación con lo ya hablado', await pg.locator('#hb.is-chat').count() == 1 and await pg.locator('#hb-log .hbm--user').count() >= 2)
    await go(pg, '/admin', 300)
    m404 = await txt(pg, 'main')
    check('La tienda no tiene panel: /admin no existe', 'No encontramos' in m404 or '404' in m404, m404[:120])
    await go(pg, '/', 300)
    check('La ventanita sigue presente en la tienda', await pg.locator('#hb:not([hidden])').count() == 1)
    await pg.click('#hb [data-hb="shrink"]')
    await pg.wait_for_timeout(250)
    # suscripción
    await pg.fill('#news-email', 'malo')
    await pg.click('#news-form button')
    await pg.wait_for_timeout(200)
    check('Newsletter valida correo', 'válido' in await txt(pg, '#toasts'))
    await pg.fill('#news-email', 'suscrito@example.com')
    await pg.click('#news-form button')
    await pg.wait_for_timeout(200)
    check('Newsletter confirma', 'suscribiste' in await txt(pg, '#toasts'))
    # atajo "/"
    await pg.click('h2 >> nth=0')
    await pg.keyboard.press('/')
    check('Tecla "/" enfoca el buscador', await pg.evaluate("document.activeElement.id") == 'q')
    # historial: atrás
    await go(pg, '/ofertas', 300)
    await go(pg, '/club', 300)
    await pg.go_back()
    await pg.wait_for_timeout(400)
    check('Botón atrás del navegador vuelve a /ofertas', (await route(pg)) == '/ofertas', await route(pg))


async def slide_titles(pg):
    return await pg.evaluate("[...document.querySelectorAll('#hero .hero__slide .hero__title')].map(t => t.textContent.trim())")


async def flow_banners(pg, ap):
    print('\n· Panel: banners de la portada (y lo que ve la tienda)')
    await pgo(ap, '/admin/banners', 450)
    examples = await ap.locator('.blist:not(.blist--promo) .bcard').count()
    check('Lista de banners muestra los de ejemplo', examples >= 3 and 'banners de ejemplo' in await txt(ap, 'main'), examples)
    check('Vista de la portada dentro del panel', await ap.locator('#bhero .hero__slide').count() == examples)
    check('El banner del Club avisa que cambia solo', await ap.locator('.bcard .chip--club').count() == 1)
    more = ap.locator('.bnow a.link-more, a.link-more:has-text("portada")').first
    check('"Ir a la portada" abre la tienda en otra pestaña', await more.get_attribute('href') == '/#/' and await more.get_attribute('target') == '_blank')
    # Crear un banner con color propio claro y el dibujo de un producto
    await ap.click('a[href="#/admin/banners/nuevo"]')
    await ap.wait_for_selector('#bform', timeout=3000)
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(250)
    check('Banner sin título muestra error', 'Escribe el título' in await txt(ap, '#bform'))
    await ap.fill('#b-eyebrow', 'Solo esta semana')
    await ap.fill('#b-title', 'Semana de la vitamina C')
    await ap.fill('#b-text', 'Hasta 30% en vitaminas seleccionadas.')
    await ap.fill('#b-cta', 'Ver vitaminas')
    await ap.select_option('#b-dest', '/categoria/vitaminas-y-suplementos')
    await ap.click('.swatch--custom')
    await ap.evaluate("() => { const i = document.querySelector('#bform [name=color]'); i.value = '#f6d365'; i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new Event('change', { bubbles: true })); }")
    await ap.click('.seg-radio:has(input[value=product])')
    vprod = await ap.evaluate("[...document.querySelectorAll('#b-vprod option')].find(o => o.value)?.value")
    await ap.select_option('#b-vprod', vprod)
    await ap.wait_for_timeout(300)
    check('Vista previa muestra el título mientras se escribe', 'Semana de la vitamina C' in await txt(ap, '#bpreview'))
    check('Color claro: la vista previa usa texto oscuro', await ap.locator('#bpreview .hero__slide--custom.hero__slide--light').count() == 1)
    check('Vista previa muestra el producto', await ap.locator('#bpreview .hero__art--product img').count() == 1)
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(1000)
    check('Crear banner vuelve a la lista', (await ap.evaluate('location.hash')) == '#/admin/banners', await ap.evaluate('location.hash'))
    check('La lista suma el banner nuevo al final', await ap.locator('.blist:not(.blist--promo) .bcard').count() == examples + 1 and 'Semana de la vitamina C' in await txt(ap, '.bcard:last-child'))
    check('Los de ejemplo pasan a ser editables (los de abajo siguen de ejemplo)', 'Estos son los banners de ejemplo.' not in await txt(ap, 'main') and 'banners de ejemplo</b> de más abajo' in await ap.inner_html('main'))
    await store_sync(pg)
    await go(pg, '/', 500)
    titles = await slide_titles(pg)
    check('El banner nuevo aparece en el carrusel de la tienda', titles[-1:] == ['Semana de la vitamina C'], titles)
    n = len(titles)
    await pg.click(f'#hero [data-slide="{n - 1}"]')
    await pg.wait_for_timeout(500)
    on = pg.locator('#hero .hero__slide.is-on')
    check('Los puntos del carrusel muestran ese banner', 'Semana de la vitamina C' in await on.inner_text())
    check('Fondo claro: puntos y flechas oscuros', await pg.locator('#hero.hero--light').count() == 1)
    await on.locator('.hero__cta').click()
    await pg.wait_for_timeout(500)
    check('El botón del banner lleva a su destino', (await route(pg)).startswith('/categoria/vitaminas-y-suplementos'), await route(pg))
    await go(pg, '/', 400)
    await pg.click('#hero [data-hero="next"]')
    await pg.wait_for_timeout(400)
    check('Flecha "siguiente" cambia de banner', await pg.locator('#hero .hero__slide.is-on .hero__title').inner_text() != titles[0])
    # Ordenar: subir el banner nuevo una posición
    await pgo(ap, '/admin/banners', 450)
    await ap.click('.bcard:last-child [data-bmove="-1"]')
    await ap.wait_for_timeout(800)
    check('Subir un banner cambia su posición', 'Semana de la vitamina C' in await txt(ap, f'.bcard:nth-child({examples})'))
    await store_sync(pg)
    await go(pg, '/', 400)
    titles = await slide_titles(pg)
    check('La portada respeta el nuevo orden', len(titles) > 1 and titles[-2] == 'Semana de la vitamina C', titles)
    # Banner con foto propia: el cuadro «Carga la imagen aquí» está al lado de la vista previa
    await pgo(ap, '/admin/banners/nuevo', 450)
    side = await txt(ap, '#bside')
    check('Al lado de la vista previa: «Carga la imagen aquí» con la medida ideal', 'Carga la imagen aquí' in side and '1.600 × 430 px' in side and '800 × 800 px' in side, side[:200])
    check('Vista previa en computador y en celular', await ap.locator('#bpreview .hero__slide').count() == 1 and await ap.locator('#bpreview-m .hero__slide').count() == 1)
    await ap.fill('#b-title', 'Vacunatorio en tu farmacia')
    await ap.select_option('#b-dest', 'search')
    await ap.fill('#b-q', 'vacuna')
    await ap.click('.seg-radio:has(input[value=photo])')
    check('Con foto propia se oculta el color de fondo', await ap.locator('[data-colorpick]').is_hidden())
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(250)
    check('Foto propia sin foto muestra error', 'Sube la foto' in await txt(ap, '#bside'))
    await ap.set_input_files('[data-idrop="photo"] input', BANNER_FILE)
    await wait_js(ap, "document.querySelector('[data-idrop=photo]').classList.contains('has-img')", timeout=5000)
    fit = await txt(ap, '[data-idrop="photo"] .idrop__fit')
    check('Revisa la medida de la foto subida y avisa si se recorta', '900 × 320 px' in fit and 'recortará' in fit, fit)
    check('La foto se prepara y se ve en la vista previa', await ap.evaluate("getComputedStyle(document.querySelector('#bpreview .hero__slide')).backgroundImage.startsWith('url(\"data:image/jpeg')"))
    await ap.set_input_files('[data-idrop="photoM"] input', BANNER_FILE)
    await wait_js(ap, "document.querySelector('[data-idrop=photoM]').classList.contains('has-img')", timeout=5000)
    check('Foto para celular: la vista previa del celular la usa', await ap.evaluate("getComputedStyle(document.querySelector('#bpreview-m .hero__slide')).backgroundImage.startsWith('url(\"data:image/jpeg')") and await ap.locator('#bpreview-m .hero__slide.has-m').count() == 1)
    await ap.check('input[name=photoOnly][value="1"]')
    await ap.wait_for_timeout(300)
    check('«Solo la foto»: la vista previa quita el texto', await ap.locator('#bpreview .hero__slide--only').count() == 1 and await ap.locator('#bpreview .hero__title').count() == 0)
    await ap.check('input[name=photoOnly][value="0"]')
    await ap.click('[data-idrop="photoM"] .idrop__del')
    await ap.wait_for_timeout(200)
    check('Quitar la foto del celular', await ap.locator('#bpreview-m .hero__slide.has-m').count() == 0)
    await ap.fill('#b-until', '2020-01-01')
    await ap.fill('#b-from', '2020-02-01')
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(250)
    check('Fecha final antes de la inicial muestra error', 'posterior' in await txt(ap, '#bform'))
    await ap.fill('#b-from', '')
    await ap.fill('#b-until', '')
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(1000)
    check('El banner con foto se guarda en el servidor', 'Vacunatorio' in await txt(ap, '.blist'))
    check('La lista indica que el banner tiene foto', 'Con foto' in await txt(ap, '.bcard:has-text("Vacunatorio")'))
    await store_sync(pg)
    await go(pg, '/', 400)
    photo = await pg.evaluate("(() => { const s = [...document.querySelectorAll('#hero .hero__slide')].find(s => s.textContent.includes('Vacunatorio')); return s ? [s.className, getComputedStyle(s).backgroundImage] : ['', '']; })()")
    check('Banner con foto en la portada de la tienda', 'hero__slide--photo' in photo[0], photo[0])
    check('La foto se pide aparte al servidor (no va dentro del catálogo)', '/api/imagenes/bn-' in photo[1], photo[1][:80])
    loaded = await pg.evaluate("(async () => { const u = getComputedStyle([...document.querySelectorAll('#hero .hero__slide')].find(s => s.textContent.includes('Vacunatorio'))).backgroundImage.slice(5, -2); const r = await fetch(u); return [r.status, r.headers.get('content-type')]; })()")
    check('La foto del banner se descarga bien', loaded == [200, 'image/jpeg'], str(loaded))
    # Editar desde «Así se ve hoy tu portada»
    await pgo(ap, '/admin/banners', 450)
    await ap.click('#bhero [data-slide="1"]')
    await ap.wait_for_timeout(300)
    second = await ap.evaluate("document.querySelectorAll('#bhero .hero__slide')[1].querySelector('.hero__title')?.textContent.trim()")
    await ap.click('#bhero-edit')
    await ap.wait_for_selector('#bform', timeout=3000)
    check('«Editar este banner» abre el que se está viendo', (await ap.input_value('#b-title')) == second or second.startswith('Sábado') or 'Club' in (await txt(ap, 'main')), f'{second} / {await ap.input_value("#b-title")}')
    # Programar: desde mañana ya no se ve hoy
    await pgo(ap, '/admin/banners', 450)
    href = await ap.locator('.bcard:has-text("Vacunatorio") a[href*="/admin/banners/"]').get_attribute('href')
    await pgo(ap, href[1:], 450)
    tomorrow = await ap.evaluate("(() => { const d = new Date(Date.now() + 36 * 3600e3); return d.toISOString().slice(0, 10); })()")
    await ap.fill('#b-from', tomorrow)
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(1000)
    check('Banner con fecha futura queda "Programado"', 'Programado' in await txt(ap, '.bcard:has-text("Vacunatorio")'))
    await store_sync(pg)
    await go(pg, '/', 400)
    check('Banner programado no se ve todavía en la tienda', not any('Vacunatorio' in t for t in await slide_titles(pg)))
    # Pausar y activar
    await ap.click('.bcard:has-text("Semana de la vitamina C") [data-bactive="0"]')
    await ap.wait_for_timeout(800)
    check('Pausar deja el banner "Pausado"', 'Pausado' in await txt(ap, '.bcard:has-text("Semana de la vitamina C")'))
    await store_sync(pg)
    await go(pg, '/', 400)
    check('Banner pausado sale de la portada', 'Semana de la vitamina C' not in await slide_titles(pg))
    await ap.click('.bcard:has-text("Semana de la vitamina C") [data-bactive="1"]')
    await ap.wait_for_timeout(800)
    await store_sync(pg)
    await go(pg, '/', 400)
    check('Activar lo devuelve a la portada', 'Semana de la vitamina C' in await slide_titles(pg))
    # Eliminar
    count = await ap.locator('.bcard').count()
    await ap.click('.bcard:has-text("Vacunatorio") [data-bdel]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(800)
    check('Eliminar un banner lo quita de la lista', await ap.locator('.bcard').count() == count - 1 and 'Vacunatorio' not in await txt(ap, '.blist'))
    await pgo(ap, '/admin/movimientos?tipo=banner', 450)
    check('Los cambios de banners quedan en Movimientos', 'Banner eliminado' in await txt(ap, '.atable') and 'Banner creado' in await txt(ap, '.atable'))
    for r in ['/admin/banners', '/admin/banners/nuevo']:
        await pgo(ap, r, 350)
        check(f'Sin desborde horizontal en {r}', not await overflow(ap))


async def promo_titles(pg):
    return await pg.evaluate("[...document.querySelectorAll('.split .promo-card')].map(c => (c.querySelector('h3')?.textContent || c.getAttribute('aria-label') || '').trim())")


async def flow_promos(pg, ap):
    print('\n· Panel: banners de más abajo (y lo que ve la tienda)')
    await store_sync(pg)
    await go(pg, '/', 400)
    check('La tienda muestra los dos banners de abajo de ejemplo', await promo_titles(pg) == ['Compara con bioequivalentes', 'Cotiza tu receta en minutos'], str(await promo_titles(pg)))
    await pgo(ap, '/admin/banners?ver=abajo', 500)
    box = await txt(ap, '#b-promo')
    check('Panel: sección «Banners de más abajo» con la medida de la foto', '1.200 × 540 px' in box and await ap.locator('#bpromos .promo-card').count() == 2, box[:160])
    check('Cada banner de abajo tiene su botón Editar a la vista', await ap.locator('#bpromos .bnow__edit').count() == 2)
    await ap.locator('#bpromos .bnow__item', has_text='Cotiza tu receta').locator('.bnow__edit').click()
    await ap.wait_for_selector('#bform', timeout=3000)
    check('Editor del banner de abajo', 'Editar banner de abajo' in await txt(ap, 'h1') and await ap.locator('[data-idrop="photoM"]').count() == 0 and '1.200 × 540 px' in await txt(ap, '#bside'))
    check('Abajo no hay ilustraciones: solo color o foto', await ap.locator('#bform input[name=visual]').count() == 2)
    await ap.fill('#b-title', 'Receta en 5 minutos')
    await ap.fill('#b-cta', 'Cotizar ahora')
    await ap.set_input_files('[data-idrop="photo"] input', BANNER_FILE)
    await wait_js(ap, "document.querySelector('[data-idrop=photo]').classList.contains('has-img')", timeout=5000)
    check('Subir la foto marca «Foto propia»', await ap.is_checked('#bform input[name=visual][value=photo]'))
    check('Vista previa del banner de abajo con la foto', await ap.locator('#bpreview .promo-card--photo').count() == 1 and 'Receta en 5 minutos' in await txt(ap, '#bpreview'))
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(1000)
    check('Guardar vuelve a la sección de abajo', (await route(ap)) == '/admin/banners?ver=abajo', await route(ap))
    await store_sync(pg)
    await go(pg, '/', 400)
    check('La tienda muestra el banner de abajo editado', 'Receta en 5 minutos' in await promo_titles(pg), str(await promo_titles(pg)))
    bg = await pg.evaluate("getComputedStyle([...document.querySelectorAll('.split .promo-card')][1]).backgroundImage")
    check('El banner de abajo usa la foto subida', '/api/imagenes/bn-abajo-receta' in bg, bg[:80])
    await pg.locator('.split .promo-card', has_text='Receta en 5 minutos').click()
    await pg.wait_for_timeout(400)
    check('El banner de abajo lleva a su destino', (await route(pg)).startswith('/cotizar-receta'), await route(pg))
    # Uno nuevo: queda solo en su fila y ocupa todo el ancho
    await pgo(ap, '/admin/banners/nuevo?lugar=abajo', 450)
    await ap.fill('#b-eyebrow', 'Nuevo')
    await ap.fill('#b-title', 'Vacunatorio Piedra')
    await ap.select_option('#b-dest', 'search')
    await ap.fill('#b-q', 'vacuna')
    await ap.click('#bform button[type=submit]')
    await ap.wait_for_timeout(1000)
    await store_sync(pg)
    await go(pg, '/', 400)
    widths = await pg.evaluate("(() => { const s = document.querySelector('.split'); return [s.clientWidth, ...[...s.children].map(c => Math.round(c.getBoundingClientRect().width))]; })()")
    check('Con tres banners abajo, el tercero ocupa todo el ancho', len(widths) == 4 and abs(widths[3] - widths[0]) < 3 and widths[1] < widths[0] * 0.6, str(widths))
    # Pausar uno lo quita de la tienda
    await pgo(ap, '/admin/banners?ver=abajo', 450)
    await ap.locator('.blist--promo .bcard', has_text='Vacunatorio Piedra').locator('[data-bactive="0"]').click()
    await ap.wait_for_timeout(800)
    await store_sync(pg)
    await go(pg, '/', 400)
    check('Banner de abajo pausado no se ve en la tienda', 'Vacunatorio Piedra' not in await promo_titles(pg), str(await promo_titles(pg)))
    check('Sin desborde horizontal en el editor de banners de abajo', not await overflow(ap))


async def flow_services(pg, ap):
    print('\n· Panel: Servicios Piedra (y lo que ve la tienda)')
    await store_sync(pg)
    await go(pg, '/', 400)
    svc = await pg.evaluate("[...document.querySelectorAll('.services .service b')].map(b => b.textContent.trim())")
    check('La portada muestra los servicios de ejemplo', len(svc) == 6 and svc[0] == 'Farmacias y turnos', str(svc))
    await pgo(ap, '/admin/servicios', 500)
    check('Pestaña «Servicios Piedra» en el panel', await ap.locator('.admin__tabs a.is-on', has_text='Servicios Piedra').count() == 1)
    check('Lista con los 6 servicios y la vista de la portada', await ap.locator('.srow').count() == 6 and await ap.locator('#spreview .service').count() == 6 and 'servicios de ejemplo' in await txt(ap, 'main'))
    row1 = ap.locator('.srow').nth(0)
    await row1.locator('[name=title]').fill('Farmacia de turno')
    await row1.locator('[name=icon]').select_option('moon')
    await row1.locator('[name=dest]').select_option('/farmacias?turno=1')
    await ap.wait_for_timeout(300)
    check('La vista previa cambia mientras se escribe', 'Farmacia de turno' in await txt(ap, '#spreview') and 'Tienes cambios sin guardar' in await txt(ap, '.sform__actions'))
    await ap.locator('.srow', has_text='Venta telefónica').locator('[name=active]').uncheck(force=True)
    await ap.wait_for_timeout(200)
    check('Ocultar un servicio lo saca de la vista previa', 'Venta telefónica' not in await txt(ap, '#spreview'))
    await ap.click('#s-add')
    await ap.wait_for_timeout(300)
    new = ap.locator('.srow').last
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(300)
    check('Un servicio sin título muestra error', 'Escribe el título del servicio' in await new.inner_text())
    await new.locator('[name=title]').fill('Vacunatorio')
    await new.locator('[name=text]').fill('Vacunas de temporada sin hora.')
    await new.locator('[name=icon]').select_option('shield')
    await new.locator('[name=dest]').select_option('search')
    await new.locator('[name=q]').fill('vacuna')
    key = await new.get_attribute('data-key')
    for _ in range(2):
        await ap.locator(f'.srow[data-key="{key}"] [data-smove="-1"]').click()
        await ap.wait_for_timeout(200)
    await ap.fill('#s-title', 'Servicios de tu farmacia')
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(1200)
    check('Guardar servicios', 'Tienes cambios sin guardar' not in await txt(ap, '.sform__actions') and 'servicios de ejemplo' not in await txt(ap, 'main'))
    await store_sync(pg)
    await go(pg, '/', 400)
    head = await pg.evaluate("document.querySelector('#svc-t')?.textContent.trim()")
    svc = await pg.evaluate("[...document.querySelectorAll('.services .service b')].map(b => b.textContent.trim())")
    check('La portada muestra el título nuevo', head == 'Servicios de tu farmacia', str(head))
    check('La portada muestra los servicios editados, en orden y sin los ocultos', svc[0] == 'Farmacia de turno' and 'Venta telefónica' not in svc and svc[-2:] == ['Vacunatorio', 'Sigue tu pedido'] and len(svc) == 6, str(svc))
    await pg.locator('.services .service', has_text='Vacunatorio').click()
    await pg.wait_for_timeout(400)
    check('El servicio nuevo lleva a donde eligió el dueño', (await route(pg)).startswith('/buscar?q=vacuna'), await route(pg))
    await go(pg, '/', 300)
    await pg.locator('.services .service', has_text='Farmacia de turno').click()
    await pg.wait_for_timeout(400)
    check('«Farmacia de turno» lleva a las farmacias de turno', (await route(pg)).startswith('/farmacias?turno=1'), await route(pg))
    await pgo(ap, '/admin/movimientos?tipo=servicios', 450)
    check('Movimientos registra los cambios de servicios', 'Servicios actualizados' in await txt(ap, 'main'))
    await pgo(ap, '/admin/servicios', 450)
    check('Sin desborde horizontal en Servicios Piedra', not await overflow(ap))


async def flow_moves_filters(pg, ap):
    print('\n· Panel: movimientos filtrados por fechas y por farmacia')
    await pgo(ap, '/admin/movimientos', 450)
    check('Botones «Fechas» y «Farmacia» junto a los tipos', await ap.locator('#am-dates summary').count() == 1 and await ap.locator('#am-locs summary').count() == 1)
    await ap.click('#am-dates summary')
    await ap.wait_for_timeout(200)
    check('Fechas: atajos y rango', 'Últimos 7 días' in await txt(ap, '#am-dates') and await ap.locator('#am-dform input[type=date]').count() == 2)
    await ap.click('#am-dates a:has-text("Hoy")')
    await wait_js(ap, "!!document.querySelector('.am-sum')", timeout=8000)
    today = _today_cl()
    r = await route(ap)
    check('Filtro «Hoy» busca en el servidor', f'desde={today}' in r and f'hasta={today}' in r and await ap.locator('#am-dates .fbtn.is-on').count() == 1, r)
    total_today = await txt(ap, '.am-sum')
    check('Resumen con cantidad de movimientos', 'movimiento' in total_today, total_today)
    # Rango al revés: error
    await ap.click('#am-dates summary')
    await ap.fill('#am-dform [name=desde]', today)
    await ap.fill('#am-dform [name=hasta]', '2020-01-01')
    await ap.click('#am-dform button[type=submit]')
    await ap.wait_for_timeout(200)
    check('Rango de fechas al revés muestra error', 'posterior' in await txt(ap, '#am-derr'))
    # Fechas viejas: nada
    await ap.fill('#am-dform [name=desde]', '2020-01-01')
    await ap.fill('#am-dform [name=hasta]', '2020-01-31')
    await ap.click('#am-dform button[type=submit]')
    await wait_js(ap, "!!document.querySelector('.am-sum')", timeout=8000)
    check('Un rango sin movimientos lo dice', 'No hay movimientos con estos filtros' in await txt(ap, 'main') and '01-01-2020 al 31-01-2020' in await txt(ap, '#am-dates summary'))
    # Farmacia
    await pgo(ap, '/admin/movimientos?tipo=venta', 450)
    await ap.click('#am-locs summary')
    await ap.wait_for_timeout(200)
    names = await ap.evaluate("[...document.querySelectorAll('#am-locs .fpop__list a')].map(a => a.firstChild.textContent.trim())")
    check('Farmacia: lista con todas las farmacias y bodegas', 'Todas las farmacias' in names and any('Bodega online' in n for n in names) and len(names) >= 4, str(names[:6]))
    store = next((n for n in names if n != 'Todas las farmacias' and 'Bodega' not in n), '')
    await ap.click(f'#am-locs .fpop__list a:has-text("{store}")')
    await wait_js(ap, "!!document.querySelector('.am-sum')", timeout=8000)
    r = await route(ap)
    locs = await ap.evaluate("[...document.querySelectorAll('.atable--moves .atable__row:not(.atable__row--head) span:nth-child(4)')].map(s => s.textContent.trim())")
    check('Filtro por farmacia (y tipo): solo movimientos de esa farmacia', 'local=s%3A' in r or 'local=s:' in r, r)
    check('Las filas son todas de la farmacia elegida', all(l == store for l in locs), f'{store}: {locs[:5]}')
    check('El botón muestra la farmacia elegida', store in await txt(ap, '#am-locs summary'))
    await ap.click('a.fclear')
    await ap.wait_for_timeout(400)
    check('«Limpiar filtros» vuelve a todos', (await route(ap)) == '/admin/movimientos', await route(ap))
    check('Sin desborde horizontal en Movimientos', not await overflow(ap))


async def hb_ask(pg, text, wait=1800):
    await pg.fill('#hb-q', text)
    await pg.press('#hb-q', 'Enter')
    await pg.wait_for_timeout(wait)


async def flow_health(pg):
    print('\n· Asistente: orientación de salud')
    await go(pg, '/', 300)
    await kill_toasts(pg)
    if await pg.locator('#hb.is-chat').count() == 0:
        if await pg.locator('#hb .hb__card').is_visible():
            await pg.click('#hb .hb__quick .hb__chip:has-text("Tengo un síntoma")')
        else:
            await pg.click('#hb .hb__pill')
            await pg.wait_for_timeout(500)
            await hb_ask(pg, 'Tengo un síntoma')
    else:
        await hb_ask(pg, 'Tengo un síntoma')
    await pg.wait_for_timeout(1800)
    check('"Tengo un síntoma" pregunta qué sientes y ofrece síntomas', 'Cuéntame qué sientes' in await txt(pg, '#hb-log') and await pg.locator('#hb-log .hb__chip:has-text("Fiebre")').count() >= 1)
    await pg.click('#hb-log .hb__chip:has-text("Fiebre")')
    await pg.wait_for_timeout(2000)
    card = await txt(pg, '#hb-log .hbm--health')
    check('Orientación de salud: qué hacer, cuándo consultar y cuándo ir a urgencias', 'Qué puedes hacer' in card and 'Consulta a un médico' in card and 'SAMU 131' in card, card[:200])
    check('Aclara que no reemplaza una consulta médica', 'no reemplaza una consulta médica' in card)
    await hb_ask(pg, 'me duele el pecho')
    alert = await txt(pg, '#hb-log .hbm--alert')
    check('Dolor de pecho: aviso de urgencia con el SAMU 131', 'urgencia' in alert and '131' in alert, alert[:160])
    await hb_ask(pg, 'quiero hablar con un médico')
    log = await txt(pg, '#hb-log')
    check('Pedir un médico: aclara que es un asistente y da Salud Responde', 'No soy médico' in log and '600 360 7777' in log)
    await pg.focus('#hb-q')
    await pg.keyboard.press('Escape')
    await pg.wait_for_timeout(250)


async def flow_sandbox(browser):
    print('\n· Visor que bloquea formularios (página dentro de un marco con restricciones)')
    ctx = await browser.new_context(viewport={'width': 1366, 'height': 900}, locale='es-CL', timezone_id='America/Santiago')
    pg = await ctx.new_page()
    blocked = []
    pg.on('console', lambda m: blocked.append(m.text) if 'Blocked form submission' in m.text else None)
    await pg.set_content(f'<iframe id="f" sandbox="allow-scripts allow-same-origin" src="{LOCAL}" style="width:1340px;height:880px;border:0"></iframe>')
    fr = pg.frame_locator('#f')
    await fr.locator('#q').wait_for(timeout=10000)
    await pg.wait_for_timeout(1500)
    await fr.locator('#q').fill('ibuprofeno')
    await fr.locator('#q').press('Enter')
    await pg.wait_for_timeout(700)
    h = await fr.locator('body').evaluate('() => location.hash')
    check('El buscador funciona con Enter aunque el visor bloquee formularios', h.startswith('#/buscar'), h)
    # en el listado el asistente queda como botón: la ventanita completa está en la portada
    await fr.locator('body').evaluate("() => { location.hash = '#/' }")
    await pg.wait_for_timeout(600)
    await fr.locator('#hb .hb__quick .hb__chip:has-text("Buscar un remedio")').click()
    await pg.wait_for_timeout(1700)
    await fr.locator('#hb-q').fill('paracetamol')
    await fr.locator('#hb-q').press('Enter')
    await pg.wait_for_timeout(1900)
    check('El asistente envía con Enter (antes se quedaba pegado)', await fr.locator('#hb-log .hbm--user').count() == 2 and await fr.locator('#hb-log .hbp').count() >= 1)
    await fr.locator('#hb-q').fill('tengo tos')
    await fr.locator('.hb__send').click()
    await pg.wait_for_timeout(1900)
    check('El asistente envía con el botón', await fr.locator('#hb-log .hbm--user').count() == 3 and await fr.locator('#hb-q').input_value() == '')
    check('Sin envíos de formulario bloqueados', not blocked, blocked[:2])
    await ctx.close()


async def flow_mobile(pg):
    print('\n· Celular: menú, filtros, barra de compra')
    await pg.click('[data-action="open-menu"]')
    await pg.wait_for_selector('.mmenu', timeout=3000)
    check('Menú móvil muestra las tarjetas destacadas', await pg.locator('.ov--drawer.is-open .mmenu__cards .mcard').count() >= 2)
    await pg.locator('[data-mm-cat]').nth(1).click()
    await pg.wait_for_timeout(300)
    sub = pg.locator('.ov--drawer.is-open a[href^="#/categoria/"]').nth(1)
    href = await sub.get_attribute('href')
    await sub.click()
    await pg.wait_for_timeout(450)
    check('Menú móvil navega a subcategoría', (await route(pg)) == href[1:], f'{await route(pg)} vs {href}')
    check('Menú móvil se cierra al navegar', await pg.locator('.ov--drawer.is-open').count() == 0)
    await pg.click('[data-open-filters]')
    await pg.wait_for_selector('.ov--drawer.is-open [data-filter]', timeout=3000)
    await pg.locator('.ov--drawer.is-open [data-filter="marca"]').first.check()
    await pg.wait_for_timeout(450)
    check('Filtro desde el panel móvil aplica', 'marca=' in await route(pg), await route(pg))
    await pg.keyboard.press('Escape')
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 450)
    check('Barra fija oculta mientras se ve el botón principal', not await pg.locator('#buybar').is_visible())
    await pg.evaluate("window.scrollTo(0, document.querySelector('.pdp__buy').getBoundingClientRect().bottom + window.scrollY + 400)")
    await pg.wait_for_timeout(500)
    check('Barra de compra fija aparece al bajar', await pg.locator('#buybar').is_visible())
    before = await txt(pg, '#cart-count')
    await pg.click('#buybar [data-add-qty]')
    await pg.wait_for_timeout(300)
    check('Barra de compra agrega al carro', await txt(pg, '#cart-count') != before)
    # asistente en el celular: globo con la frase y conversación a pantalla completa
    await go(pg, '/', 400)
    await kill_toasts(pg)
    check('Globo de ayuda visible en el celular', await pg.locator('#hb .hb__pill').is_visible() and len(await txt(pg, '.hb__pill-say')) > 3)
    await pg.click('#hb .hb__pill')
    await pg.wait_for_timeout(700)
    box = await pg.locator('#hb .hb__card').bounding_box()
    check('En el celular la conversación ocupa la pantalla', box and box['width'] >= 389 and box['height'] >= 800, box)
    await pg.fill('#hb-q', 'farmacia de turno')
    await pg.press('#hb-q', 'Enter')
    await pg.wait_for_timeout(1700)
    check('Responde en el celular', await pg.locator('#hb-log .hbs').count() >= 1)
    check('Sin desborde con la conversación abierta', not await overflow(pg))
    await pg.click('#hb [data-hb="shrink"]')
    await pg.wait_for_timeout(300)
    await pg.click('#hb .hb__x')
    await pg.wait_for_timeout(300)
    check('La × deja solo el ícono (sigue presente)', await pg.locator('#hb .hb__pill').is_visible() and not await pg.locator('.hb__pill-say').is_visible())
    for r in ['/', '/carro', '/checkout', '/cuenta', '/farmacias', '/club', '/cotizar-receta', '/ayuda', '/bioequivalentes', '/marcas', '/registro', '/seguimiento']:
        await go(pg, r, 350)
        check(f'Sin desborde horizontal en {r}', not await overflow(pg))


# ─────────────────────────────────────────────────────────────
# Panel de administración (aplicación aparte, en el servidor)
async def flow_admin_access(ap, pg):
    print('\n· Panel aparte: primer administrador, ingreso, salida y contraseña')
    # La tienda ya no tiene panel
    await go(pg, '/', 300)
    check('La tienda no tiene enlaces al panel', await pg.locator('a[href*="admin"]').count() == 0)
    await go(pg, '/admin', 300)
    main = await txt(pg, 'main')
    check('En la tienda, /admin es una página que no existe', '404' in main or 'No encontramos' in main, main[:120])
    js = await pg.evaluate("fetch('/assets/tienda.js').then(r => r.text())")
    check('El código del panel no viaja con la tienda', 'Ingresar administrador' not in js and 'X-CSRF-Token' not in js)
    check('La tienda está conectada al servidor', await pg.evaluate('window.Piedra.ds.mode') == 'api')
    # Panel sin administrador: solo con el enlace de primera vez
    await ap.wait_for_selector('.admin-login__card', timeout=8000)
    card = await txt(ap, '.admin-login__card')
    check('Sin administrador, el panel pide el enlace de primera configuración', 'primera configuración' in card and await ap.locator('#al-form').count() == 0, card[:200])
    await ap.goto(SETUP_LINK)
    await ap.wait_for_selector('#al-form [name=pass2]', timeout=8000)
    check('El enlace de primera vez pide usuario, contraseña y repetirla', 'INGRESAR ADMINISTRADOR' in (await txt(ap, '.admin-login__title')).upper())
    await ap.fill('#al-form [name=user]', ADMIN['user'])
    await ap.fill('#al-form [name=pass]', 'corta1')
    await ap.fill('#al-form [name=pass2]', 'corta1')
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_timeout(250)
    check('Exige contraseña segura', 'necesita' in await txt(ap, '#al-form'))
    await ap.fill('#al-form [name=pass]', ADMIN['pw'])
    await ap.fill('#al-form [name=pass2]', ADMIN['pw'])
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    await ap.wait_for_timeout(400)
    check('Crear el administrador entra al panel', ADMIN['user'] in await txt(ap, '#pbar-who'))
    check('La clave de primera vez desaparece de la dirección', 'clave=' not in ap.url and ap.url.endswith('#/admin'), ap.url)
    check('El panel muestra "Conectado al servidor"', 'Conectado al servidor' in await txt(ap, '.admin-mode'))
    # Salir y volver a entrar
    await kill_toasts(ap)
    await ap.click('[data-action="admin-logout"]')
    await ap.wait_for_selector('#al-form', timeout=5000)
    check('Salir vuelve al cuadro de ingreso (usuario y contraseña)', await ap.locator('#al-form [name=pass2]').count() == 0 and not await ap.locator('#pbar-who').is_visible())
    check('Al salir avisa que se cerró la sesión', 'Cerraste la sesión' in await txt(ap, '.admin-login__card'))
    check('Al salir, el código del panel ya no está cargado', await ap.evaluate('typeof window.PiedraPanel') == 'undefined')
    # Sin sesión, el código del panel no se entrega
    st = await ap.evaluate("fetch('panel.js', { cache: 'no-store' }).then(r => r.status)")
    check('Sin sesión, el código del panel (panel.js) no se entrega', st == 404, str(st))
    acc = await ap.evaluate("fetch('acceso.js').then(r => r.text())")
    check('La pantalla de ingreso no trae el código del panel', 'Productos y stock' not in acc and '/2fa/enable' not in acc and len(acc) < 60000, str(len(acc)))
    await ap.fill('#al-form [name=user]', ADMIN['user'])
    await ap.fill('#al-form [name=pass]', 'otraClave99x')
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_timeout(900)
    check('Contraseña incorrecta muestra error', 'incorrectos' in await txt(ap, '#al-error'), await txt(ap, '#al-error'))
    await ap.click('[data-eye="f-pass"]')
    check('Botón del ojo muestra la contraseña', await ap.get_attribute('#f-pass', 'type') == 'text')
    await panel_login(ap)
    check('Usuario y contraseña correctos entran al panel', await ap.locator('.admin__tabs').count() == 1)
    # La sesión se mantiene al recargar y la cookie está protegida
    await ap.reload()
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    check('Recargar el panel mantiene la sesión', ADMIN['user'] in await txt(ap, '#pbar-who'))
    ck = [c for c in await ap.context.cookies() if 'piedra_panel' in c['name']]
    check('Cookie de sesión HttpOnly y SameSite=Strict', len(ck) == 1 and ck[0]['httpOnly'] and ck[0]['sameSite'] == 'Strict', str(ck))
    check('JavaScript no puede leer la cookie de sesión', 'piedra_panel' not in await ap.evaluate('document.cookie'))
    # El enlace de primera vez ya no sirve
    await ap.goto(SETUP_LINK)
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    await ap.wait_for_timeout(300)
    check('Con sesión, el enlace de primera vez lleva al resumen', ap.url.endswith('#/admin'), ap.url)
    # Cambiar contraseña (en Seguridad)
    await ap.click('#pbar-security')
    await ap.wait_for_selector('[data-sec="password"]', timeout=5000)
    await ap.click('[data-sec="password"]')
    await ap.wait_for_selector('#cp-form')
    await ap.fill('#f-cur', 'no-es-esta-123')
    await ap.fill('#f-np', 'Nueva-Clave-2027')
    await ap.fill('#f-np2', 'Nueva-Clave-2027')
    await ap.click('#cp-form button[type=submit]')
    await ap.wait_for_timeout(900)
    check('Cambiar contraseña exige la actual', 'no es correcta' in await txt(ap, '#cp-form'), await txt(ap, '#cp-form'))
    await ap.fill('#f-cur', ADMIN['pw'])
    await ap.click('#cp-form button[type=submit]')
    await ap.wait_for_timeout(1200)
    check('Cambiar contraseña confirma', 'Cambiaste la contraseña' in await txt(ap, '#toasts') and await ap.locator('#cp-form').count() == 0)
    ADMIN['pw'] = 'Nueva-Clave-2027'
    check('Sigue dentro del panel después de cambiarla', await ap.locator('.admin__tabs').count() == 1)
    link = ap.locator('.pbar a[target=_blank]')
    check('"Ver tienda" abre la tienda en otra pestaña', await link.get_attribute('href') == '/' and await link.get_attribute('rel') == 'noopener')


async def flow_admin(pg, ap, rx_order=''):
    print('\n· Panel: stock, precios, productos, pedidos y ventas (y lo que ve la tienda)')
    # Tienda: carro vacío y comuna Santiago
    await go(pg, '/carro', 400)
    if await pg.locator('[data-clear-cart]').count():
        await pg.click('[data-clear-cart]')
        await pg.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
        await pg.click('.ov--modal.is-open [data-answer="yes"]')
        await pg.wait_for_timeout(300)
    await kill_toasts(pg)
    await pg.click('.hdr-act--loc')
    await pg.wait_for_selector('#loc-form', timeout=3000)
    await pg.select_option('#loc-region', 'RM')
    await pg.select_option('#loc-comuna', 'Santiago')
    await pg.click('#loc-form button[type=submit]')
    await pg.wait_for_timeout(300)

    # Agregar stock desde la lista
    await pgo(ap, '/admin/productos?q=losartan', 450)
    check('Buscador del panel encuentra losartán', 'osart' in await txt(ap, '.atable'), (await txt(ap, '.atable'))[:120])
    row_btn = ap.locator('[data-qstock]').first
    pid = await row_btn.get_attribute('data-qstock')
    await row_btn.click()
    await ap.wait_for_selector('#mqs-form', timeout=3000)
    store_opt = await ap.evaluate("[...document.querySelectorAll('#mqs-loc option')].find(o => o.value.startsWith('s:')).value")
    await ap.select_option('#mqs-loc', store_opt)
    await ap.fill('#mqs-qty', '7')
    prev_txt = await txt(ap, '#mqs-preview')
    check('Vista previa del ingreso muestra cuánto quedará', 'quedarán' in prev_txt, prev_txt)
    before = int(re.search(r'Hoy hay (\d+)', prev_txt.replace('.', '')).group(1))
    await ap.click('#mqs-form button[type=submit]')
    await ap.wait_for_timeout(800)
    check('Agregar stock confirma con aviso', 'Agregaste' in await txt(ap, '#toasts'))
    await pgo(ap, f'/admin/productos/{pid}', 450)
    val = await ap.locator(f'input[data-loc="{store_opt}"]').input_value()
    check('Stock de la farmacia subió en 7', int(val) == before + 7, f'{before} -> {val}')
    # Ajuste exacto en bodega RM
    await ap.fill('input[data-loc="o:RM"]', '3')
    check('Botón guardar se habilita al cambiar', await ap.locator('#stock-form button[type=submit]').is_enabled())
    await ap.click('#stock-form button[type=submit]')
    await ap.wait_for_timeout(800)
    check('Ajuste de bodega guardado', await ap.locator('input[data-loc="o:RM"]').input_value() == '3')
    # Precio y oferta
    await ap.fill('#price-form [name=price]', '3990')
    await ap.fill('#price-form [name=offer]', '2990')
    await ap.click('#price-form button[type=submit]')
    await ap.wait_for_timeout(800)
    check('Guardar precio confirma', 'nuevo precio' in await txt(ap, '#toasts'))
    view = ap.locator('.aprod-head__view')
    href = await view.get_attribute('href')
    check('"Ver en la tienda" abre la ficha de la tienda en otra pestaña', href.startswith('/#/producto/') and await view.get_attribute('target') == '_blank', href)
    await store_sync(pg)
    await go(pg, href.split('#', 1)[1], 450)
    pdp = await txt(pg, '.pdp')
    check('La tienda muestra el nuevo precio oferta', '$2.990' in pdp and '$3.990' in pdp, pdp[:200])
    # Ocultar y volver a mostrar
    await ap.click('label.switch:has(#vis)')
    await ap.wait_for_timeout(800)
    await store_sync(pg)
    await go(pg, '/buscar?q=losartan', 450)
    ids = await pg.evaluate("[...document.querySelectorAll('.pcard [data-id]')].map(e => e.dataset.id)")
    check('Producto oculto no aparece en la tienda', pid not in ids, str(ids))
    await go(pg, href.split('#', 1)[1], 450)
    check('La ficha de un producto oculto no se puede comprar', await pg.locator('.pdp [data-add-qty]').count() == 0 or 'disponible' in (await txt(pg, 'main')).lower(), (await txt(pg, 'main'))[:160])
    await ap.click('label.switch:has(#vis)')
    await ap.wait_for_timeout(800)
    await store_sync(pg)
    await go(pg, '/buscar?q=losartan', 450)
    ids = await pg.evaluate("[...document.querySelectorAll('.pcard [data-id]')].map(e => e.dataset.id)")
    check('Producto vuelve a la tienda al mostrarlo', pid in ids, str(ids))

    # Producto nuevo
    await pgo(ap, '/admin/productos/nuevo', 400)
    await ap.click('#pform button[type=submit]')
    await ap.wait_for_timeout(250)
    errs = [e for e in await ap.locator('#pform .field__error').all_inner_texts() if e.strip()]
    check('Formulario de producto valida campos', len(errs) >= 3, str(errs))
    await ap.fill('#f-n', 'Jarabe de propóleo y miel 120 ml')
    await ap.fill('#f-b', 'Piedra Vital')
    await ap.select_option('#f-c', 'medicamentos/resfrio-y-tos')
    await ap.select_option('#f-f', 'jarabe')
    await ap.fill('#f-u', '120')
    await ap.select_option('#pform [name=un]', 'ml')
    await ap.fill('#f-ai', 'propóleo')
    await ap.fill('#f-p', '4990')
    await ap.fill('#f-o', '3990')
    await ap.fill('#f-so', '1')
    await ap.fill('#f-ss', '2')
    await ap.fill('#f-t', 'tos, garganta')
    await ap.set_input_files('#np-file', PHOTO_FILE)
    await wait_js(ap, "document.querySelector('#np-check')?.textContent.includes('900')")
    await ap.wait_for_timeout(300)
    check('Vista previa muestra el producto nuevo', 'propóleo' in (await txt(ap, '#pform-preview')).lower())
    check('La vista previa del producto nuevo usa la foto elegida', (await ap.get_attribute('#pform-preview img', 'src')).startswith('data:image/jpeg'))
    await ap.click('#pform button[type=submit]')
    await ap.wait_for_timeout(1000)
    r = await ap.evaluate('location.hash.slice(1)')
    check('Crear producto abre su ficha de administración', r.startswith('/admin/productos/N'), r)
    new_id = r.rsplit('/', 1)[-1]
    await ap.wait_for_timeout(400)
    check('El producto nuevo se crea con su foto', 'Foto propia' in await txt(ap, '.pphoto'), (await txt(ap, '.pphoto'))[:120])
    await store_sync(pg)
    await go(pg, '/buscar?q=propolio', 450)
    names = (await pg.locator('.pcard__name').all_inner_texts())
    check('La tienda encuentra el producto nuevo aunque se escriba mal', any('propóleo' in n for n in names), str(names))
    # Dos unidades con solo 1 en bodega: el checkout lo impide
    await pg.locator(f'.pcard [data-action="add"][data-id="{new_id}"]').click()
    await pg.wait_for_timeout(250)
    await pg.locator(f'[data-cart-slot="{new_id}"] [data-action="qty-inc"]').click()
    await pg.wait_for_timeout(200)
    await go(pg, '/checkout', 500)
    f = pg.locator('#f-customer')
    if await f.locator('[name=nombre]').is_visible():
        await f.locator('[name=nombre]').fill('Admin')
        await f.locator('[name=apellidos]').fill('Prueba')
        await f.locator('[name=rut]').fill('12.345.678-5')
        await f.locator('[name=phone]').fill('912345678')
        await f.locator('[name=email]').fill('admin.prueba@example.com')
        await f.locator('button[type=submit]').click()
        await pg.wait_for_timeout(450)
    await pg.fill('#f-address [name=calle]', 'Huérfanos')
    await pg.fill('#f-address [name=numero]', '1000')
    await kill_toasts(pg)
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(400)
    check('Checkout avisa cuando no hay stock suficiente para despacho', 'No hay stock suficiente' in await txt(pg, '#toasts') and 'quedan 1' in await txt(pg, '#toasts'), await txt(pg, '#toasts'))
    # Con 1 unidad sí se puede comprar
    await go(pg, '/carro', 400)
    await pg.locator(f'[data-line="{new_id}"] [data-action="qty-dec"]').click()
    await pg.wait_for_timeout(250)
    await go(pg, '/checkout', 500)
    if await pg.locator('#f-address [name=calle]').is_visible():
        await pg.fill('#f-address [name=calle]', 'Huérfanos')
        await pg.fill('#f-address [name=numero]', '1000')
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(450)
    await pg.locator('label.radio-card', has=pg.locator('input[name=pay][value=transferencia]')).click()
    await pg.wait_for_timeout(300)
    if not await pg.locator('#co-terms').is_checked():
        await pg.check('#co-terms')
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(1200)
    r = await route(pg)
    check('Compra del producto nuevo crea el pedido en el servidor', r.startswith('/pedido/PD'), r)
    order_id = re.search(r'/pedido/(PD\w+)', r).group(1) if 'PD' in r else ''
    # El panel se entera solo (revisa cada 15 segundos)
    try:
        await wait_js(ap, f"window.PiedraPanel.bo.orders.some(o => o.id === '{order_id}')", timeout=20000, step=500)
        got = True
    except Exception:
        got = False
    check('El panel recibe el pedido nuevo sin recargar', got)
    await pgo(ap, '/admin', 450)
    kp = int((await txt(ap, '.kpi:nth-child(2) .kpi__value')).replace('.', '') or 0)
    check('Resumen cuenta el pedido del mes', kp >= 1, await txt(ap, '.kpis'))
    await pgo(ap, f'/admin/productos/{new_id}', 450)
    check('La venta descontó la unidad de la bodega RM', await ap.locator('input[data-loc="o:RM"]').input_value() == '0', await ap.locator('input[data-loc="o:RM"]').input_value())
    view = await ap.locator('.aprod-head__view').get_attribute('href')
    await go(pg, view.split('#', 1)[1], 450)
    check('La tienda se actualiza después de comprar: sin stock para despacho', 'Sin stock para despacho' in await txt(pg, '.pdp'), (await txt(pg, '.pdp'))[:300])
    # Pedidos y anulación desde el panel
    await pgo(ap, '/admin/pedidos', 450)
    check('Pedidos del panel lista la compra', order_id in await txt(ap, '.atable'))
    await pgo(ap, f'/admin/pedidos/{order_id}', 450)
    check('Detalle del pedido muestra stock descontado', 'Bodega online' in await txt(ap, 'main'))
    # Contactar al cliente: correo, WhatsApp y llamada con el mensaje listo
    mail = await ap.get_attribute('#cc-mail', 'href') or ''
    wa = await ap.get_attribute('#cc-wa', 'href') or ''
    tel = await ap.get_attribute('#cc-tel', 'href') or ''
    check('Pedido: botón de correo al cliente con el número de pedido', mail.startswith('mailto:') and order_id in mail and 'subject=' in mail, mail[:160])
    check('Pedido: WhatsApp y llamada al celular del cliente', re.match(r'^https://wa\.me/569\d{8}\?text=', wa) and re.match(r'^tel:\+569\d{8}$', tel), f'{wa[:80]} {tel}')
    check('WhatsApp se abre en otra pestaña, sin dar acceso al panel', (await ap.get_attribute('#cc-wa', 'rel') or '').find('noopener') >= 0 and await ap.get_attribute('#cc-wa', 'target') == '_blank')
    await ap.select_option('#cc-reason', 'entrega')
    await ap.wait_for_timeout(150)
    msg = await ap.input_value('#cc-msg')
    mail2 = await ap.get_attribute('#cc-mail', 'href') or ''
    check('Elegir el motivo cambia el mensaje y el asunto', 'coordinar la entrega' in msg and order_id in msg and 'Coordinemos' in mail2, msg[:120])
    await ap.fill('#cc-msg', 'Hola, mensaje escrito por la farmacia.')
    await ap.wait_for_timeout(150)
    check('El mensaje editado va en el correo y en WhatsApp', 'mensaje%20escrito' in (await ap.get_attribute('#cc-mail', 'href')) and 'mensaje%20escrito' in (await ap.get_attribute('#cc-wa', 'href')))
    await panel_refresh(ap)
    check('Lo escrito no se pierde si llegan datos nuevos', 'mensaje escrito' in await ap.input_value('#cc-msg'))
    await kill_toasts(ap)
    await ap.click('.ccontact__copy >> nth=0')
    await ap.wait_for_timeout(250)
    check('Copiar el correo del cliente', 'Copiado' in await txt(ap, '#toasts'), await txt(ap, '#toasts'))
    await kill_toasts(ap)
    await kill_toasts(ap)
    await ap.click('[data-cancel]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(900)
    await pgo(ap, f'/admin/productos/{new_id}', 450)
    check('Anular el pedido repone el stock', await ap.locator('input[data-loc="o:RM"]').input_value() == '1', await ap.locator('input[data-loc="o:RM"]').input_value())
    await go(pg, f'/pedido/{order_id}', 1200)
    check('El cliente ve su pedido anulado por la farmacia', 'anulado' in (await txt(pg, '#tl')).lower(), await txt(pg, '#tl'))
    # Receta del pedido de la tienda: solo con la sesión del panel
    if rx_order:
        await pgo(ap, f'/admin/pedidos/{rx_order}', 450)
        link = ap.locator('.rx-files a').first
        check('El pedido con receta trae el archivo para revisarlo', await link.count() == 1)
        if await link.count():
            rhref = await link.get_attribute('href')
            info = await ap.evaluate("async (u) => { const r = await fetch(u); return [r.status, r.headers.get('content-type') || '']; }", rhref)
            check('La receta se abre con la sesión del panel', info[0] == 200 and info[1].startswith('image/'), str(info))
            st = await pg.evaluate("async (u) => (await fetch(u)).status", '/admin/' + rhref)
            check('Sin sesión (desde la tienda) la receta no se puede ver', st == 401, str(st))
    # Movimientos
    await pgo(ap, '/admin/movimientos', 400)
    mv = await txt(ap, '.atable')
    check('Movimientos registra ingresos, ventas y anulaciones', 'Ingreso' in mv and 'Venta' in mv and 'Anulación' in mv, mv[:200])
    # Resumen de ventas
    await pgo(ap, '/admin', 450)
    await ap.click('label.switch:has(#demo-sales)')
    await ap.wait_for_timeout(500)
    check('Ventas de ejemplo llenan el gráfico', await ap.locator('#sales-chart svg .lchart__line--main').count() == 1)
    ticks = await ap.evaluate("[...document.querySelectorAll('#sales-chart .lchart__ytick')].map(e => e.textContent)")
    check('Eje Y con números', len(ticks) >= 3 and ticks[0].startswith('$'), str(ticks))
    xt = await ap.evaluate("[...document.querySelectorAll('#sales-chart .lchart__xtick')].map(e => e.textContent)")
    check('Eje X con días del mes', len(xt) >= 3, str(xt))
    for rng, label in (('anio', 'Año completo'), ('historico', 'Histórico')):
        await ap.click(f'.seg--range a:has-text("{label}")')
        await ap.wait_for_timeout(500)
        check(f'Botón "{label}" cambia el período', f'rango={rng}' in await ap.evaluate('location.hash') and await ap.locator('#sales-chart svg').count() == 1, await ap.evaluate('location.hash'))
    box = await ap.query_selector('#sales-chart svg')
    await box.scroll_into_view_if_needed()
    bb = await box.bounding_box()
    await ap.mouse.move(bb['x'] + bb['width'] * 0.5, bb['y'] + bb['height'] * 0.5)
    await ap.wait_for_timeout(250)
    check('Pasar el mouse muestra el detalle', await ap.locator('.lchart__tip:not([hidden])').count() == 1 and '$' in await txt(ap, '.lchart__tip'))
    await ap.focus('#sales-chart')
    await ap.keyboard.press('Home')
    t1 = await txt(ap, '.lchart__tip-title')
    await ap.keyboard.press('ArrowRight')
    t2 = await txt(ap, '.lchart__tip-title')
    check('El gráfico se recorre con el teclado', t1 and t2 and t1 != t2, f'{t1} -> {t2}')
    await ap.click('.chart-table summary')
    check('Vista de tabla del gráfico', await ap.locator('.chart-table tbody tr').count() >= 2)
    await ap.click('.seg--range a:has-text("Mes")')
    await ap.wait_for_timeout(300)
    await ap.click('label.switch:has(#demo-sales)')
    await ap.wait_for_timeout(300)
    # Eliminar el producto nuevo
    await pgo(ap, f'/admin/productos/{new_id}', 400)
    await ap.click('[data-delete]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(800)
    check('Eliminar vuelve a la lista de productos', (await ap.evaluate('location.hash')).startswith('#/admin/productos'))
    await store_sync(pg)
    await go(pg, '/buscar?q=propoleo', 450)
    check('Producto eliminado ya no está en la tienda', 'propóleo' not in (await txt(pg, 'main')).lower() or await pg.locator('.pcard').count() == 0)


async def flow_farmacias(pg, ap):
    print('\n· Panel: farmacias (agregar, editar, turnos, eliminar)')
    await panel_refresh(ap)  # trae las farmacias de prueba recién creadas
    await pgo(ap, '/admin/farmacias', 450)
    n0 = await ap.locator('.scard').count()
    check('La sección Farmacias lista las farmacias', n0 >= 1 and 'Farmacia Piedra' in await txt(ap, '.slist'), n0)
    await ap.click('a[href="#/admin/farmacias/nueva"]')
    await ap.wait_for_selector('#sform')
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(250)
    errs = [e for e in await ap.locator('#sform .field__error').all_inner_texts() if e.strip()]
    check('Farmacia sin nombre ni dirección muestra errores', len(errs) >= 2, str(errs))
    await ap.fill('#f-name', 'Farmacia Piedra Ñuñoa')
    await ap.fill('#f-address', 'Av. Irarrázaval 3450')
    await ap.select_option('#f-region', 'RM')
    await ap.select_option('#f-comuna', 'Ñuñoa')
    await ap.fill('#f-phone', '+56 2 2222 3333')
    await ap.fill('#sf-wk-a', '08:30')
    await ap.fill('#sf-wk-b', '21:30')
    await ap.fill('#sf-sat-a', '10:00')
    await ap.fill('#sf-sat-b', '09:00')
    await ap.check('#sf-sun-off')
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(300)
    check('Cierre antes de la apertura muestra error', 'cierre' in await txt(ap, '#sf-hours-error'), await txt(ap, '#sf-hours-error'))
    await ap.fill('#sf-sat-b', '14:00')
    today = _today_cl()
    await ap.fill('#sf-turno', today)
    await ap.click('[data-add-turno]')
    await ap.wait_for_timeout(200)
    check('Agregar un día de turno lo muestra en la lista', await ap.locator('#sf-turnos [data-del-turno]').count() == 1)
    await ap.fill('#f-initial', '15')
    await ap.wait_for_timeout(200)
    pv = await txt(ap, '#sf-preview')
    check('Vista previa de la farmacia con su horario y turno', 'Farmacia Piedra Ñuñoa' in pv and 'De turno hoy' in pv and '08:30' in pv, pv[:200])
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(1200)
    check('Agregar farmacia vuelve a la lista con la nueva', (await ap.evaluate('location.hash')) == '#/admin/farmacias' and await ap.locator('.scard').count() == n0 + 1 and 'Ñuñoa' in await txt(ap, '.slist'))
    await store_sync(pg)
    await go(pg, '/farmacias?region=RM&comuna=%C3%91u%C3%B1oa', 450)
    sp = await txt(pg, 'main')
    check('La tienda muestra la farmacia nueva con teléfono y turno', 'Farmacia Piedra Ñuñoa' in sp and '+56 2 2222 3333' in sp and 'De turno hoy' in sp, sp[:300])
    await go(pg, '/farmacias?turno=1', 450)
    check('Aparece en «Farmacias de turno»', 'Farmacia Piedra Ñuñoa' in await txt(pg, 'main'))
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 450)
    await pg.locator('[data-stock]').first.click()
    await pg.wait_for_selector('#st-list')
    await pg.select_option('#st-comuna', 'Ñuñoa')
    await pg.wait_for_timeout(300)
    stx = await txt(pg, '#st-list')
    check('El stock inicial de la farmacia se ve en la ficha', 'Farmacia Piedra Ñuñoa' in stx and 'Stock disponible' in stx, stx[:200])
    await pg.keyboard.press('Escape')
    # Editar: 24 horas
    await pgo(ap, '/admin/farmacias', 400)
    await ap.click('.scard:has-text("Ñuñoa") a[href*="/admin/farmacias/F"]')
    await ap.wait_for_selector('#sform')
    check('Editar muestra los datos guardados', await ap.input_value('#f-name') == 'Farmacia Piedra Ñuñoa' and await ap.input_value('#sf-wk-a') == '08:30')
    await ap.fill('#f-name', 'Farmacia Piedra Ñuñoa Centro')
    await ap.check('input[name=h24]')
    await ap.wait_for_timeout(150)
    check('24 horas oculta el horario y los turnos', await ap.locator('#sf-hours').is_hidden() and await ap.locator('#sf-turnos-box').is_hidden())
    await ap.click('#sform button[type=submit]')
    await ap.wait_for_timeout(1000)
    card = await txt(ap, '.scard:has-text("Ñuñoa")')
    check('Guardar cambios actualiza la farmacia', 'Ñuñoa Centro' in card and '24 horas' in card, card[:200])
    # Eliminar
    await ap.click('.scard:has-text("Ñuñoa") a[href*="/admin/farmacias/F"]')
    await ap.wait_for_selector('#sform [data-sdel]')
    await ap.click('[data-sdel]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(1000)
    check('Eliminar farmacia la quita de la lista', await ap.locator('.scard').count() == n0 and 'Ñuñoa' not in await txt(ap, '.slist'))
    await store_sync(pg)
    await go(pg, '/farmacias?region=RM', 400)
    check('Y deja de aparecer en la tienda', 'Ñuñoa' not in await txt(pg, 'main'))
    await pgo(ap, '/admin/movimientos?tipo=farmacia', 450)
    mv = await txt(ap, '.atable')
    check('Los cambios de farmacias quedan en Movimientos', 'Farmacia creada' in mv and 'Farmacia eliminada' in mv, mv[:200])
    for r in ['/admin/farmacias', '/admin/farmacias/nueva']:
        await pgo(ap, r, 350)
        check(f'Sin desborde horizontal en {r}', not await overflow(ap))


async def flow_fotos(pg, ap):
    print('\n· Panel: foto del producto (medida en píxeles, JPG o PNG)')
    await pgo(ap, '/admin/productos/420102', 500)
    box = await txt(ap, '.pphoto')
    check('La ficha dice la medida ideal y la mínima', '800 × 800 px' in box and '300 × 300 px' in box and 'JPG o PNG' in box, box[:200])
    await ap.set_input_files('#pp-file', SMALL_PHOTO)
    await wait_js(ap, "document.querySelector('#pp-check')?.textContent.includes('px')")
    ck = await txt(ap, '#pp-check')
    check('Foto chica: dice su medida y no deja guardarla', '200 × 200 px' in ck and 'pequeña' in ck and await ap.locator('#pp-actions').is_hidden(), ck)
    await ap.set_input_files('#pp-file', NOT_PHOTO)
    await wait_js(ap, "document.querySelector('#pp-check')?.textContent.includes('JPG o PNG')")
    check('Un archivo que no es JPG ni PNG se rechaza', 'JPG o PNG' in await txt(ap, '#pp-check'))
    await ap.set_input_files('#pp-file', PHOTO_FILE)
    await wait_js(ap, "document.querySelector('#pp-check')?.textContent.includes('900')")
    ck = await txt(ap, '#pp-check')
    check('Foto buena: muestra su medida y cómo se guardará', '900 × 700 px' in ck and 'Se guardará en 800 × 622 px' in ck and 'No es cuadrada' in ck, ck)
    check('Vista previa de la foto antes de guardar', (await ap.get_attribute('#pp-img', 'src')).startswith('data:image/') and await ap.locator('#pp-actions').is_visible())
    await kill_toasts(ap)
    await ap.click('[data-pp-save]')
    await ap.wait_for_timeout(1200)
    check('Guardar foto confirma', 'Guardamos la foto' in await txt(ap, '#toasts'))
    await wait_js(ap, "(document.querySelector('#pp-img')?.getAttribute('src') || '').includes('api/fotos/420102?v=') && document.querySelector('#pp-img').naturalWidth > 0")
    check('El panel muestra la foto guardada (desde el servidor)', 'Foto propia' in await txt(ap, '.pphoto') and '800 × 622 px' in await txt(ap, '.pphoto'))
    await store_sync(pg)
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 300)
    await go(pg, '/buscar?q=paracetamol', 600)
    card = pg.locator('.pcard[data-pid="420102"] .pcard__media img')
    await wait_js(pg, "(() => { const i = document.querySelector('.pcard[data-pid=\"420102\"] .pcard__media img'); return i && i.complete && i.naturalWidth > 0; })()")
    src = await card.get_attribute('src')
    nw = await card.evaluate('i => i.naturalWidth')
    check('La tienda muestra la foto en la tarjeta del producto', src.startswith('/api/fotos/420102?v=') and nw == 800, f'{src} {nw}')
    # Quitar
    await ap.click('[data-pp-remove]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(1000)
    check('Quitar la foto vuelve al dibujo', (await ap.get_attribute('#pp-img', 'src')).startswith('data:image/svg') and 'Dibujo automático' in await txt(ap, '.pphoto'))
    await store_sync(pg)
    await go(pg, '/buscar?q=paracetamol', 500)
    check('En la tienda también vuelve el dibujo', (await pg.locator('.pcard[data-pid="420102"] .pcard__media img').get_attribute('src')).startswith('data:image/svg'))


async def menu_cards(pg):
    await go(pg, '/', 300)
    await kill_toasts(pg)
    await pg.click('.catnav__all')
    await pg.wait_for_timeout(300)
    out = await pg.evaluate("[...document.querySelectorAll('#mega .mcard')].map(a => a.querySelector('.mcard__title').textContent.trim())")
    await pg.keyboard.press('Escape')
    return out


async def flow_menu(pg, ap):
    print('\n· Panel: tarjetas del menú «Categorías» (y lo que ve la tienda)')
    await pgo(ap, '/admin/menu', 450)
    check('Sección Menú en el panel con las tarjetas de ejemplo', await ap.locator('.mlist .mrow').count() == 2 and 'tarjetas de ejemplo' in await txt(ap, 'main'))
    check('Vista de cómo se ve hoy en la tienda', await ap.locator('.mnow__cards .mcard').count() == 2)
    await ap.click('a:has-text("Nueva tarjeta")')
    await ap.wait_for_selector('#mform', timeout=3000)
    await ap.fill('#m-kicker', 'Solo esta semana')
    await ap.fill('#m-title', 'Hasta 30% en protectores')
    await ap.select_option('#m-dest', 'custom')
    await ap.fill('#m-path', 'https://otro-sitio.example')
    await ap.click('#mform button[type=submit]')
    await ap.wait_for_timeout(250)
    check('La tarjeta solo puede llevar a páginas del sitio', 'empiece con /' in await txt(ap, '#mform'))
    await ap.select_option('#m-dest', 'search')
    await ap.fill('#m-q', 'protector solar')
    await ap.locator('label.swatch', has=ap.locator('input[value=coral]')).click()
    await ap.locator('label.icon-pick__opt', has=ap.locator('input[value=sun]')).click()
    await ap.wait_for_timeout(300)
    check('Al lado de la vista previa: imagen de fondo con su medida', '600 × 300 px' in await txt(ap, '.mform-prev'))
    await ap.set_input_files('[data-idrop="mphoto"] input', BANNER_FILE)
    await wait_js(ap, "document.querySelector('[data-idrop=mphoto]').classList.contains('has-img')", timeout=5000)
    check('La vista previa de la tarjeta muestra la imagen', await ap.locator('#mpreview .mcard--photo').count() == 1)
    prev = await ap.evaluate("(() => { const c = document.querySelector('#mpreview .mcard'); return c ? [c.className, c.textContent.replace(/\\s+/g, ' ').trim()] : null; })()")
    check('La vista previa muestra la tarjeta mientras se escribe', prev and 'mcard--coral' in prev[0] and 'Hasta 30% en protectores' in prev[1] and 'Solo esta semana' in prev[1], str(prev))
    await ap.click('#mform button[type=submit]')
    await ap.wait_for_timeout(900)
    check('Crear tarjeta vuelve a la lista', (await route(ap)) == '/admin/menu' and await ap.locator('.mlist .mrow').count() == 3, await route(ap))
    await store_sync(pg)
    titles = await menu_cards(pg)
    check('La tienda muestra la tarjeta nueva en el menú', titles[-1:] == ['Hasta 30% en protectores'] and len(titles) == 3, str(titles))
    await go(pg, '/', 300)
    await pg.click('.catnav__all')
    await pg.wait_for_timeout(300)
    bg = await pg.evaluate("getComputedStyle([...document.querySelectorAll('#mega .mcard')].find(c => c.textContent.includes('Hasta 30% en protectores'))).backgroundImage")
    check('La tarjeta del menú muestra su imagen en la tienda', '/api/imagenes/mc-' in bg, bg[:80])
    await pg.locator('#mega .mcard', has_text='Hasta 30% en protectores').click()
    await pg.wait_for_timeout(500)
    check('La tarjeta lleva a donde eligió el dueño', (await route(pg)).startswith('/buscar?q=protector') and await pg.locator('#mega[hidden]').count() == 1, await route(pg))
    # Ordenar: la nueva sube al primer lugar
    for _ in range(2):
        await ap.locator('.mrow', has_text='Hasta 30% en protectores').locator('[data-mmove="-1"]').click()
        await ap.wait_for_timeout(700)
    await store_sync(pg)
    titles = await menu_cards(pg)
    check('El orden del panel es el orden del menú', titles and titles[0] == 'Hasta 30% en protectores', str(titles))
    # Pausar
    await ap.locator('.mrow', has_text='Hasta 30% en protectores').locator('[data-mactive]').click()
    await ap.wait_for_timeout(800)
    check('Pausar la tarjeta en el panel', 'Pausada' in await ap.locator('.mrow', has_text='Hasta 30% en protectores').inner_text())
    await store_sync(pg)
    titles = await menu_cards(pg)
    check('Una tarjeta pausada no se ve en la tienda', 'Hasta 30% en protectores' not in titles and len(titles) == 2, str(titles))
    # Editar la del Club: deja de cambiar sola
    await ap.locator('.mrow', has_text='Precios de socio').locator('a:has-text("Editar")').click()
    await ap.wait_for_selector('#mform', timeout=3000)
    await ap.fill('#m-title', 'Socios: 2x1 en vitaminas')
    await ap.click('#mform button[type=submit]')
    await ap.wait_for_timeout(900)
    await store_sync(pg)
    titles = await menu_cards(pg)
    check('Editar una tarjeta cambia la tienda', 'Socios: 2x1 en vitaminas' in titles, str(titles))
    # Eliminar
    await kill_toasts(ap)
    await ap.locator('.mrow', has_text='Hasta 30% en protectores').locator('[data-mdel]').click()
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(900)
    check('Eliminar la tarjeta', await ap.locator('.mrow', has_text='Hasta 30% en protectores').count() == 0 and await ap.locator('.mlist .mrow').count() == 2)
    await pgo(ap, '/admin/movimientos?tipo=menu', 450)
    mv = await txt(ap, 'main')
    check('Movimientos registra los cambios del menú', 'Tarjeta creada' in mv and 'Tarjeta eliminada' in mv, mv[:200])
    check('Sin desborde horizontal en la sección Menú', not await overflow(ap))


async def flow_security(pg, ap):
    print('\n· Panel: seguridad y verificación en dos pasos')
    await pgo(ap, '/admin', 500)
    check('Resumen sugiere activar la verificación en dos pasos', 'verificación en dos pasos' in await txt(ap, 'main') and await ap.locator('main a[href="#/admin/seguridad"]').count() >= 1)
    await pgo(ap, '/admin/seguridad', 600)
    await ap.wait_for_selector('.schk', timeout=5000)
    chk = await txt(ap, '.schk')
    check('Seguridad: revisión con cifrado de datos y contraseñas protegidas', 'Datos de clientes y recetas cifrados' in chk and 'Contraseñas protegidas' in chk, chk[:200])
    check('Seguridad: muestra este equipo en las sesiones', 'Este equipo' in await txt(ap, '.sess'))
    check('Seguridad: registro de ingresos con los intentos fallidos', 'Contraseña incorrecta' in await txt(ap, '.atable--log') and 'Ingreso' in await txt(ap, '.atable--log'))
    # Activar
    await ap.click('[data-tfa="start"]')
    await ap.wait_for_selector('#tfa-form', timeout=5000)
    secret = (await ap.text_content('#tfa-key') or '').strip()
    check('Activar muestra el código QR y la clave', await ap.locator('.tfa-qr svg.qr').count() == 1 and len(secret.replace(' ', '')) == 32, secret)
    try:
        import cv2, numpy as np
        png = await ap.locator('.tfa-qr').screenshot()
        img = cv2.imdecode(np.frombuffer(png, np.uint8), cv2.IMREAD_COLOR)
        val = cv2.QRCodeDetector().detectAndDecode(img)[0]
        check('El código QR se puede escanear y trae la clave', val.startswith('otpauth://totp/') and secret.replace(' ', '') in val, val[:80])
    except ImportError:
        pass
    await ap.fill('#f-tfa-code', '000000' if totp(secret) != '000000' else '111111')
    await ap.fill('#f-tfa-pass', ADMIN['pw'])
    await ap.click('#tfa-form button[type=submit]')
    await ap.wait_for_timeout(600)
    check('Un código equivocado no activa', 'no es correcto' in await txt(ap, '#tfa-form'), await txt(ap, '#tfa-form'))
    await ap.fill('#f-tfa-code', totp(secret))
    await ap.click('#tfa-form button[type=submit]')
    await ap.wait_for_selector('.rcodes', timeout=5000)
    codes = await ap.eval_on_selector_all('.rcodes__list code', 'els => els.map(e => e.textContent)')
    check('Al activar entrega 10 códigos de respaldo', len(codes) == 10 and all(re.match(r'^[a-z2-9]{4}-[a-z2-9]{4}$', c) for c in codes), str(codes[:2]))
    async with ap.expect_download() as dl:
        await ap.click('[data-rc="download"]')
    d = await dl.value
    check('Los códigos de respaldo se pueden descargar', d.suggested_filename.endswith('.txt'))
    await ap.click('[data-tfa="done"]')
    await ap.wait_for_timeout(700)
    check('Seguridad muestra la verificación activa', 'Activa.' in await txt(ap, '#tfa-body'))
    # Salir y entrar: ahora pide el código
    await ap.click('[data-action="admin-logout"]')
    await ap.wait_for_selector('#al-form', timeout=5000)
    await ap.fill('#al-form [name=user]', ADMIN['user'])
    await ap.fill('#al-form [name=pass]', ADMIN['pw'])
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_selector('#tf-form', timeout=5000)
    check('Con la contraseña correcta pide el código del celular', 'dos pasos' in (await txt(ap, '.admin-login__title')).lower())
    st = await ap.evaluate("fetch('panel.js', { cache: 'no-store' }).then(r => r.status)")
    check('Sin el código, el panel sigue cerrado', st == 404, str(st))
    await ap.fill('#f-code', '123456' if totp(secret) != '123456' else '654321')
    await ap.click('#tf-form button[type=submit]')
    await ap.wait_for_timeout(600)
    check('Código incorrecto muestra error', 'no es correcto' in await txt(ap, '#tf-error'), await txt(ap, '#tf-error'))
    # El código de la activación ya se usó: el siguiente de la app (válido por el margen de reloj)
    await ap.fill('#f-code', totp(secret, 1))
    await ap.click('#tf-form button[type=submit]')
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    await ap.wait_for_timeout(500)
    check('Con el código del celular entra al panel', ADMIN['user'] in await txt(ap, '#pbar-who'))
    # Código de respaldo
    await kill_toasts(ap)
    await ap.click('[data-action="admin-logout"]')
    await ap.wait_for_selector('#al-form', timeout=5000)
    await ap.fill('#al-form [name=user]', ADMIN['user'])
    await ap.fill('#al-form [name=pass]', ADMIN['pw'])
    await ap.click('#al-form button[type=submit]')
    await ap.wait_for_selector('#tf-form', timeout=5000)
    await ap.click('[data-recovery="1"]')
    await ap.fill('#f-code', codes[0])
    await ap.click('#tf-form button[type=submit]')
    await ap.wait_for_selector('.admin__tabs', timeout=8000)
    await ap.wait_for_timeout(700)
    check('Con un código de respaldo también entra y avisa cuántos quedan', 'quedan 9' in await txt(ap, '#toasts'), await txt(ap, '#toasts'))
    # Desactivar (con contraseña y un código de respaldo)
    await pgo(ap, '/admin/seguridad', 600)
    await ap.wait_for_selector('[data-tfa="disable"]', timeout=5000)
    await ap.click('[data-tfa="disable"]')
    await ap.wait_for_selector('#tfx-form')
    await ap.fill('#f-tfx-pass', ADMIN['pw'])
    await ap.fill('#f-tfx-code', codes[0])
    await ap.click('#tfx-form button[type=submit]')
    await ap.wait_for_timeout(600)
    check('Un código de respaldo ya usado no sirve', 'no es correcto' in await txt(ap, '#tfx-form'), await txt(ap, '#tfx-form'))
    await ap.fill('#f-tfx-code', codes[1])
    await ap.click('#tfx-form button[type=submit]')
    await ap.wait_for_timeout(900)
    check('Desactivar la verificación en dos pasos', 'Desactivada.' in await txt(ap, '#tfa-body'), await txt(ap, '#tfa-body'))
    log = await txt(ap, '.atable--log')
    check('El registro muestra la activación, el código incorrecto y el ingreso con respaldo', 'Activó la verificación' in log and 'Código de verificación incorrecto' in log and 'código de respaldo' in log)
    check('Sin desborde horizontal en Seguridad', not await overflow(ap))


async def buy_with_date(pg, email, day_index=2):
    """Compra en la tienda eligiendo un día de entrega. Devuelve (pedido, fecha elegida)."""
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 450)
    await kill_toasts(pg)
    await pg.locator('.pdp [data-add-qty]').first.click()
    await pg.wait_for_timeout(250)
    await go(pg, '/checkout', 600)
    f = pg.locator('#f-customer')
    if await f.count():
        await f.locator('[name=nombre]').fill('Etapa')
        await f.locator('[name=apellidos]').fill('Prueba')
        await f.locator('[name=rut]').fill('12.345.678-5')
        await f.locator('[name=phone]').fill('912345678')
        await f.locator('[name=email]').fill(email)
        await f.locator('button[type=submit]').click()
        await pg.wait_for_timeout(450)
    await pg.locator('[data-dtype="despacho"]').click()
    await pg.wait_for_timeout(300)
    await pg.fill('#f-address [name=calle]', 'Moneda')
    await pg.fill('#f-address [name=numero]', '1100')
    days = pg.locator('label.ddate')
    n = await days.count()
    chosen = await days.nth(min(day_index, n - 1)).locator('input').get_attribute('value')
    await days.nth(min(day_index, n - 1)).click()
    await pg.wait_for_timeout(200)
    when = await txt(pg, '#std-when')
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(450)
    await pg.locator('label.radio-card', has=pg.locator('input[name=pay][value=transferencia]')).click()
    await pg.wait_for_timeout(250)
    await pg.check('#co-terms')
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(1500)
    m = re.search(r'/pedido/(PD\d+)', await route(pg))
    return (m.group(1) if m else ''), chosen, n, when


async def flow_order_stages(pg, ap):
    print('\n· Pedidos: día de entrega, etapas y mensajes al cliente')
    oid, chosen, ndays, when = await buy_with_date(pg, 'etapas@example.com', 3)
    check('Al comprar, el cliente elige entre varios días de entrega', ndays >= 5 and chosen, f'{ndays} {chosen}')
    check('Al elegir el día cambia la fecha que se muestra', when.startswith('Llega '), when)
    check('La compra con día elegido crea el pedido', bool(oid))
    if not oid:
        return
    owhen = await txt(pg, '#owhen')
    check('La confirmación muestra la fecha de entrega elegida', 'Fecha de entrega' in owhen.title() or 'FECHA DE ENTREGA' in owhen.upper(), owhen)
    check('Antes de confirmarlo, el cliente lo puede anular', await pg.locator('[data-cancel]').count() == 1)
    check('El cliente ve el primer mensaje de la farmacia', 'Recibimos tu pedido' in await txt(pg, '#omsgs'))
    # Panel: etapas
    try:
        await wait_js(ap, f"window.PiedraPanel.bo.orders.some(o => o.id === '{oid}')", timeout=20000, step=500)
    except Exception:
        await panel_refresh(ap)
    await pgo(ap, f'/admin/pedidos/{oid}', 500)
    check('Panel: el pedido nuevo está «Por confirmar» con su fecha', 'Por confirmar' in await txt(ap, '#oflow') and chosen == await ap.input_value('#of-date-in'), await txt(ap, '#oflow'))
    await pgo(ap, '/admin/pedidos?estado=recibido', 400)
    check('Panel: filtro «Por confirmar» lo muestra', oid in await txt(ap, '.atable'))
    await pgo(ap, f'/admin/pedidos/{oid}', 500)
    await ap.fill('#of-note', 'Tu receta está correcta.')
    await kill_toasts(ap)
    await ap.click('[data-flow="embalaje"]')
    await ap.wait_for_timeout(1000)
    check('Confirmar pasa el pedido a embalaje', 'En preparación' in await txt(ap, '#oflow .panel__head') and await ap.locator('[data-flow="camino"]').count() == 1, await txt(ap, '#oflow .panel__head'))
    check('El aviso queda listo para enviarlo por correo o WhatsApp', await ap.locator('.omsg__item.is-last [data-send="correo"]').count() == 1 and await ap.locator('.omsg__item.is-last [data-send="whatsapp"]').count() == 1)
    mail = await ap.get_attribute('.omsg__item.is-last [data-send="correo"]', 'href') or ''
    check('El correo lleva el mensaje de la etapa', mail.startswith('mailto:') and 'Pedido%20confirmado' in mail and oid in mail, mail[:120])
    await go(pg, f'/pedido/{oid}', 1600)
    msgs = await txt(pg, '#omsgs')
    check('La tienda muestra «Pedido confirmado» con la nota de la farmacia', 'Pedido confirmado' in msgs and 'Tu receta está correcta.' in msgs, msgs[:200])
    check('Confirmado, el cliente ya no lo puede anular', await pg.locator('[data-cancel]').count() == 0)
    # En camino + cambio de fecha
    await ap.click('[data-flow="camino"]')
    await ap.wait_for_timeout(1000)
    new_date = await ap.evaluate("(() => { const d = new Date(Date.now() + 9 * 86400000); return d.toISOString().slice(0, 10); })()")
    await ap.fill('#of-date-in', new_date)
    await ap.click('#of-date button[type=submit]')
    await ap.wait_for_timeout(1000)
    check('Panel: cambiar la fecha de entrega', new_date == await ap.input_value('#of-date-in') and 'Cambió la fecha' in await txt(ap, '.omsg'), await txt(ap, '.oflow__date'))
    await go(pg, f'/pedido/{oid}', 1600)
    check('La tienda muestra «En camino», la fecha nueva y que se actualizó', 'Tu pedido va en camino' in await txt(pg, '#omsgs') and 'Actualizada' in await txt(pg, '#owhen') and 'Cambió la fecha de entrega' in await txt(pg, '#omsgs'), await txt(pg, '#owhen'))
    # Volver atrás por error y luego entregar
    await ap.click('[data-flow-back]')
    await ap.wait_for_selector('.ov--modal.is-open [data-answer="yes"]', timeout=3000)
    await ap.click('.ov--modal.is-open [data-answer="yes"]')
    await ap.wait_for_timeout(1000)
    check('Volver una etapa atrás', 'En preparación' in await txt(ap, '#oflow .panel__head'))
    await ap.click('[data-flow="camino"]')
    await ap.wait_for_timeout(900)
    await ap.click('[data-flow="entregado"]')
    await ap.wait_for_timeout(1000)
    check('Marcar entregado', 'Entregado' in await txt(ap, '#oflow .panel__head') and await ap.locator('#of-date').count() == 0)
    await go(pg, f'/pedido/{oid}', 1600)
    check('La tienda muestra el pedido entregado', 'Pedido entregado' in await txt(pg, '#omsgs') and 'ENTREGADO' in (await txt(pg, '#owhen')).upper(), await txt(pg, '#owhen'))
    await go(pg, '/seguimiento', 600)
    check('«Sigue tu pedido» muestra la etapa del pedido', 'Entregado' in await txt(pg, 'main'))
    check('Sin desborde en el seguimiento del pedido', not await overflow(pg))


async def flow_bulk(pg, ap):
    print('\n· Carga masiva (Excel, CSV y eleventa: existencia, costo, precio y productos nuevos)')
    import urllib.request, zipfile
    await pgo(ap, '/admin/productos', 400)
    await ap.click('#ap-bulk')
    await ap.wait_for_timeout(400)
    check('Productos › «Carga masiva» abre la página', 'Carga masiva' in await txt(ap, 'main h1'))
    async with ap.expect_download() as d:
        await ap.click('[data-dl=xlsx]')
    dl = await d.value
    z = zipfile.ZipFile(await dl.path())
    sheet = z.read('xl/worksheets/sheet1.xml').decode()
    check('La planilla Excel trae Código, Nombre, Cantidad, Precio costo, Precio venta y Departamento', dl.suggested_filename.endswith('.xlsx') and all(h in sheet for h in ['Código', 'Nombre del producto', 'Cantidad', 'Precio costo', 'Precio venta', 'Departamento']) and '>420101<' in sheet, dl.suggested_filename)
    async with ap.expect_download() as d:
        await ap.click('[data-dl=csv]')
    dl = await d.value
    raw = open(await dl.path(), 'rb').read()
    check('La planilla CSV se descarga lista para Excel (con ; y tildes)', raw.startswith('﻿Código;Nombre del producto;Cantidad;Precio costo;Precio venta;Departamento'.encode()), repr(raw[:60]))

    async def upload(path):
        await ap.set_input_files('#cm-file', path)
        await wait_js(ap, "!!document.querySelector('.cm-sum')", timeout=8000)
        await ap.wait_for_timeout(800)  # termina de desplazarse hasta la revisión
    # Excel con títulos en la fila 3, un código que no existe, un decimal y una fila sin cantidad
    await upload(os.path.join(ROOT, 'tests', 'fixtures', 'inventario-excel.xlsx'))
    s = await txt(ap, '.cm-sum')
    check('Excel: lee las filas y marca las que tienen error', '3 productos existentes' in s and '3 con error' in s and '1 sin cambios' in s, s)
    check('Sin elegir dónde ni cómo, no se puede cargar', await ap.is_disabled('#cm-go'))
    check('Si los códigos nuevos no traen precio, no ofrece crearlos', await ap.locator('[data-opt=create]').count() == 0)
    loc = await ap.evaluate("[...document.querySelectorAll('#cm-loc option')].find(o => o.textContent.includes('Las Condes')).value")
    await ap.select_option('#cm-loc', loc)
    await ap.check('input[name=cm-mode][value=set]', force=True)
    await ap.wait_for_timeout(200)
    plan = await txt(ap, '#cm-preview .notice')
    check('Al elegir farmacia y «Reemplazar» muestra qué cambia', 'Las Condes' in plan and 'cambia la existencia' in plan, plan)
    await ap.click('#cm-go')
    await ap.wait_for_selector('.ov--modal.is-open')
    check('Pide confirmar antes de guardar', 'queda igual a la planilla' in await txt(ap, '.ov--modal.is-open .ov__text'))
    await ap.click('.ov--modal.is-open [data-answer=yes]')
    await ap.wait_for_selector('#cm-done', timeout=8000)
    done = await txt(ap, '#cm-done')
    check('Carga lista: informa los productos actualizados', '3 productos' in done and 'Las Condes' in done and 'no se cargaron' in done, done)
    sid = loc.split(':')[1]

    def catalog():
        return json.loads(urllib.request.urlopen(STORE + 'api/catalog').read())

    def stock(pid, store=sid):
        return catalog()['overrides'].get(pid, {}).get('stock', {}).get('s', {}).get(store)
    check('«Reemplazar»: el stock queda igual a la planilla', stock('420101') == 25 and stock('420102') == 1200 and stock('420103') == 7, f"{stock('420101')} {stock('420102')} {stock('420103')}")
    # CSV guardado por Excel en Windows (ANSI, con ;): sumar
    tmp = tempfile.NamedTemporaryFile('wb', suffix='.csv', delete=False)
    tmp.write('Código;Nombre del producto;Cantidad\r\n420101;Paracetamol 500 mg 16 comprimidos;5\r\n'.encode('cp1252'))
    tmp.close()
    await ap.click('#cm-done [data-other]')
    await upload(tmp.name)
    check('CSV: recuerda la farmacia elegida y pide elegir sumar o reemplazar', await ap.input_value('#cm-loc') == loc and await ap.is_disabled('#cm-go'))
    await ap.check('input[name=cm-mode][value=add]', force=True)
    await ap.wait_for_timeout(200)
    row = await txt(ap, '.cm-row')
    check('«Sumar»: la revisión muestra cuánto queda (25 → 30)', '25 → 30' in row.replace('\n', ' '), row)
    await ap.click('#cm-go')
    await ap.wait_for_selector('.ov--modal.is-open')
    await ap.click('.ov--modal.is-open [data-answer=yes]')
    await ap.wait_for_selector('#cm-done', timeout=8000)
    check('«Sumar»: se agregan las unidades al stock', stock('420101') == 30 and '+5 unidades' in await txt(ap, '#cm-done'), str(stock('420101')))
    await ap.click('#cm-done [data-other]')
    await upload(tmp.name)
    await ap.check('input[name=cm-mode][value=add]', force=True)
    await ap.wait_for_timeout(200)
    check('Avisa si se va a sumar dos veces el mismo archivo', 'ya cargaste este mismo archivo' in (await txt(ap, '#cm-preview')).lower())
    os.unlink(tmp.name)
    xls = tempfile.NamedTemporaryFile('wb', suffix='.xls', delete=False)
    xls.write(bytes([0xD0, 0xCF, 0x11, 0xE0]) + b'\0' * 64)
    xls.close()
    await ap.set_input_files('#cm-file', xls.name)
    await ap.wait_for_timeout(500)
    check('Excel antiguo (.xls): explica cómo guardarlo', '.xlsx' in await txt(ap, '#cm-msg'), await txt(ap, '#cm-msg'))
    os.unlink(xls.name)
    # Excel exportado de eleventa: crea productos nuevos con costo, precio y existencia
    price_before = catalog()['overrides'].get('420101', {}).get('price')
    await upload(os.path.join(ROOT, 'tests', 'fixtures', 'inventario-eleventa.xlsx'))
    cols = await txt(ap, '.cm-cols')
    check('eleventa: reconoce costo, precio de venta, existencia y departamento', all(w in cols for w in ['Precio costo', 'Precio venta', 'Departamento']) and await ap.locator('.cm-cols .chip--ok').count() == 5, cols)
    s = await txt(ap, '.cm-sum')
    check('eleventa: 8 productos nuevos (2 sin publicar) y 1 existente', '8 productos nuevos (2 sin publicar)' in s and '1 producto existente' in s, s)
    check('eleventa: muestra los departamentos para elegir categoría y condición', await ap.locator('[data-dept]').count() == 6)
    check('Controlados y Helados se proponen «No publicar»', await ap.input_value('[data-dept="controlados"] [data-dept-rx]') == 'hide' and await ap.input_value('[data-dept="helados"] [data-dept-rx]') == 'hide')
    await ap.select_option('[data-dept="naturales"] [data-dept-rx]', 'hide')
    await ap.wait_for_timeout(300)
    check('Cambiar la condición de un departamento actualiza la revisión', '3 sin publicar' in await txt(ap, '.cm-sum'), await txt(ap, '.cm-sum'))
    await ap.uncheck('[data-opt=hideDemo]')
    await ap.uncheck('[data-opt=price]')
    await ap.wait_for_timeout(200)
    loc2 = await ap.evaluate("[...document.querySelectorAll('#cm-loc option')].find(o => o.textContent.includes('Providencia')).value")
    await ap.select_option('#cm-loc', loc2)
    await ap.check('input[name=cm-mode][value=add]', force=True)
    await ap.wait_for_timeout(300)
    await ap.click('#cm-go')
    await ap.wait_for_selector('.ov--modal.is-open')
    conf = await txt(ap, '.ov--modal.is-open .ov__text')
    check('Confirmación: cuántos se crean y cuántos se actualizan', '8 productos nuevos' in conf and 'se actualizarán 1 productos' in conf, conf)
    await ap.click('.ov--modal.is-open [data-answer=yes]')
    await ap.wait_for_selector('#cm-done', timeout=15000)
    done = await txt(ap, '#cm-done')
    check('eleventa: se crearon los productos', 'Se crearon 8 productos (3 sin publicar' in done and 'costo de 1 productos' in done, done)
    cat = catalog()['overrides']
    los = cat.get('7809990000011', {})
    check('El producto nuevo queda con su categoría, receta y existencia', los.get('def', {}).get('c') == 'medicamentos/cardiovascular' and los.get('def', {}).get('rx') == 'simple' and not los.get('hidden') and los.get('stock', {}).get('s', {}).get(loc2.split(':')[1]) == 12, json.dumps(los)[:300])
    check('«No publicar» crea el producto oculto', cat.get('7809990000042', {}).get('hidden') and cat.get('7809990000059', {}).get('hidden'))
    check('El código con espacio se guarda junto (ABC123)', 'ABC123' in cat)
    check('La tienda nunca recibe el precio costo', all('cost' not in (o or {}) for o in cat.values()))
    check('Sin «Actualizar precio» el precio no cambia', cat.get('420101', {}).get('price') == price_before)
    await store_sync(pg)
    await go(pg, '/buscar?q=losartan%20demo', 500)
    found = await pg.locator('.pcard', has_text='Losartan 50mg').count()
    check('La tienda muestra el producto nuevo en la búsqueda', found >= 1)
    await pgo(ap, '/admin/productos/7809990000011', 600)
    head = await txt(ap, '.aprod-head')
    check('Panel: el producto nuevo muestra su código, el costo y el margen', '7809990000011' in head and 'Margen' in head and 'Desde planilla' in head, head)
    await pgo(ap, '/admin/movimientos', 400)
    check('Movimientos registra la carga masiva', 'Carga masiva' in await txt(ap, 'main') and '8 productos creados' in await txt(ap, 'main'))


async def flow_admin_session(ap):
    print('\n· Panel: sesión vencida')
    await pgo(ap, '/admin/productos', 400)
    await kill_toasts(ap)
    await ap.context.clear_cookies()
    await panel_refresh(ap)
    await ap.wait_for_selector('#al-form', timeout=5000)
    check('Sin sesión válida el panel vuelve al ingreso y lo avisa', 'sesión terminó' in await txt(ap, '#toasts'), await txt(ap, '#toasts'))
    await panel_login(ap)
    check('Al volver a entrar sigue en la misma sección', (await ap.evaluate('location.hash')).startswith('#/admin/productos'))


async def flow_local(browser):
    print('\n· Tienda en un solo archivo (sin servidor)')
    ctx, pg = await new_page(browser, LOCAL, tag='archivo')
    await store_ready(pg)
    check('Sin servidor la tienda usa los datos de ejemplo', await pg.evaluate('window.Piedra.ds.mode') == 'local')
    check('El archivo no tiene enlaces al panel', await pg.locator('a[href*="admin"]').count() == 0)
    check('El código del panel no está en el archivo', 'Ingresar administrador' not in await pg.content())
    await go(pg, '/admin', 300)
    main = await txt(pg, 'main')
    check('/admin no existe en el archivo', '404' in main or 'No encontramos' in main, main[:120])
    check('La portada muestra los banners de ejemplo', await pg.evaluate("(() => { window.Piedra.go('/'); return true; })()") and True)
    await pg.wait_for_timeout(400)
    check('Carrusel con banners de ejemplo', await pg.locator('#hero .hero__slide').count() >= 3)
    await pg.click('.catnav__all')
    await pg.wait_for_timeout(300)
    check('Sin servidor el menú «Categorías» usa las tarjetas de ejemplo', await pg.locator('#mega .mcard').count() == 2)
    await pg.keyboard.press('Escape')
    # Compra de prueba: se guarda en este navegador
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 450)
    await pg.locator('.pdp [data-add-qty]').first.click()
    await pg.wait_for_timeout(250)
    await go(pg, '/checkout', 500)
    f = pg.locator('#f-customer')
    await f.locator('[name=nombre]').fill('Local')
    await f.locator('[name=apellidos]').fill('Prueba')
    await f.locator('[name=rut]').fill('12.345.678-5')
    await f.locator('[name=phone]').fill('912345678')
    await f.locator('[name=email]').fill('local@example.com')
    await f.locator('button[type=submit]').click()
    await pg.wait_for_timeout(450)
    await pg.fill('#f-address [name=calle]', 'Moneda')
    await pg.fill('#f-address [name=numero]', '1100')
    await pg.click('[data-continue="2"]')
    await pg.wait_for_timeout(450)
    await pg.locator('label.radio-card', has=pg.locator('input[name=pay][value=transferencia]')).click()
    await pg.wait_for_timeout(250)
    await pg.check('#co-terms')
    await pg.click('[data-pay]')
    await pg.wait_for_timeout(800)
    r = await route(pg)
    check('Sin servidor la compra de prueba funciona', r.startswith('/pedido/PD'), r)
    info = await pg.evaluate('({ remote: !!window.Piedra.state.orders[0]?.remote, sales: window.Piedra.state.localSales.length })')
    check('El pedido y su stock quedan en este navegador', not info['remote'] and info['sales'] >= 1, str(info))
    await go(pg, '/farmacias', 400)
    check('Sin farmacias: la página lo explica', 'Pronto podrás visitarnos' in await txt(pg, 'main'))
    await go(pg, '/producto/paracetamol-500-mg-16-comprimidos-lab-andino', 400)
    check('Sin farmacias no se ofrece ver stock ni retiro', await pg.locator('[data-stock]').count() == 0 and 'solo con despacho' in await txt(pg, '.avail'))
    await go(pg, '/checkout', 400)
    check('Sin farmacias el pago solo ofrece despacho', await pg.locator('[data-dtype="retiro"]').count() == 0)
    await ctx.close()


async def flow_mobile_panel(browser):
    print('\n· Panel en el celular')
    ctx, ap = await new_page(browser, PANEL, mobile=True, wait='.pbar', tag='panel-celular')
    await ap.wait_for_selector('#al-form', timeout=8000)
    check('Sin desborde en el cuadro de ingreso (celular)', not await overflow(ap))
    await panel_login(ap)
    check('Ingreso de administrador en el celular', await ap.locator('.admin__tabs').count() == 1)
    pos = await ap.evaluate("getComputedStyle(document.querySelector('.pbar__lbl')).position")
    check('En el celular los botones de la barra son solo íconos', pos == 'absolute', pos)
    first_order = await ap.evaluate("(window.PiedraPanel.bo.orders[0] || {}).id || ''")
    for r in ['/admin', '/admin/productos', '/admin/productos/420102', '/admin/productos/nuevo', '/admin/productos/carga-masiva', '/admin/pedidos', '/admin/banners', '/admin/banners/nuevo', '/admin/banners/sol', '/admin/farmacias', '/admin/farmacias/nueva', '/admin/menu', '/admin/menu/nuevo', '/admin/menu/club', '/admin/servicios', '/admin/banners/abajo-bioeq', '/admin/banners/nuevo?lugar=abajo', '/admin/movimientos', '/admin/movimientos?desde=2026-01-01', '/admin/seguridad'] + ([f'/admin/pedidos/{first_order}'] if first_order else []):
        await pgo(ap, r, 400)
        check(f'Sin desborde horizontal en el panel: {r}', not await overflow(ap))
    if first_order:
        check('Celular: contacto con el cliente en el detalle del pedido', await ap.locator('#ccontact #cc-mail').count() == 1)
        await ap.locator('#ccontact').scroll_into_view_if_needed()
        await ap.screenshot(path=f'{SHOTS}/panel_celular_contacto.png')
    await pgo(ap, '/admin/menu', 400)
    await ap.screenshot(path=f'{SHOTS}/panel_celular.png')
    await ctx.close()


def _today_cl():
    from datetime import datetime, timedelta, timezone
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo('America/Santiago')).strftime('%Y-%m-%d')
    except Exception:
        return (datetime.now(timezone.utc) - timedelta(hours=3)).strftime('%Y-%m-%d')


SEED_STORES = [
    {'name': 'Farmacia Piedra Providencia', 'address': 'Av. Providencia 1980', 'region': 'RM', 'comuna': 'Providencia', 'phone': '+56 2 2345 6789', 'recetario': True, 'hours': {'wk': [8, 22], 'sat': [9, 22], 'sun': [10, 21]}},
    {'name': 'Farmacia Piedra Las Condes', 'address': 'Av. Apoquindo 4499', 'region': 'RM', 'comuna': 'Las Condes', 'h24': True, 'hours': {}},
    {'name': 'Farmacia Piedra Santiago Centro', 'address': 'Paseo Ahumada 250', 'region': 'RM', 'comuna': 'Santiago', 'hours': {'wk': [9, 21], 'sat': [10, 14], 'sun': None}, 'turnos': ['TODAY']},
    {'name': 'Farmacia Piedra Temuco', 'address': 'Manuel Montt 800', 'region': 'IX', 'comuna': 'Temuco', 'hours': {'wk': [9, 21], 'sat': [10, 20], 'sun': None}},
    {'name': 'Farmacia Piedra Concepción', 'address': 'Barros Arana 700', 'region': 'VIII', 'comuna': 'Concepción', 'hours': {'wk': [9, 21], 'sat': [10, 20], 'sun': [10, 14]}},
]


def admin_http():
    """Sesión del panel por la API (para preparar datos de prueba)."""
    import urllib.request, urllib.error, http.cookiejar
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

    def call(path, body=None, csrf=None, method='POST'):
        headers = {'Content-Type': 'application/json'}
        if csrf:
            headers['X-CSRF-Token'] = csrf
        req = urllib.request.Request(PANEL + path, data=json.dumps(body or {}).encode(), headers=headers, method=method)
        return json.loads(opener.open(req).read())

    token = re.search(r'clave=([\w-]+)', SETUP_LINK).group(1)
    try:
        r = call('api/setup', {'token': token, 'user': ADMIN['user'], 'password': ADMIN['pw']})
    except urllib.error.HTTPError:
        r = call('api/login', {'user': ADMIN['user'], 'password': ADMIN['pw']})
    return call, r['csrf']


def seed_stores():
    call, csrf = admin_http()
    today = _today_cl()
    for st in SEED_STORES:
        body = dict(st)
        body['turnos'] = [today if d == 'TODAY' else d for d in st.get('turnos', [])]
        call('api/stores', {'store': body, 'initialStock': 20}, csrf)
    print(f'  (farmacias de prueba: {len(SEED_STORES)})')


def setup_admin_http():
    """Crea el administrador por la API (cuando no se corre el flujo de primera vez)."""
    admin_http()


async def main():
    global SETUP_LINK
    mode = sys.argv[1] if len(sys.argv) > 1 else 'all'
    log_path = os.path.join(TMP, 'servidor.log')
    env = {**os.environ, 'PORT': str(PORT), 'HOST': '127.0.0.1', 'DATA_DIR': os.path.join(TMP, 'datos'), 'ADMIN_USER': '', 'ADMIN_PASSWORD': '', 'SETUP_TOKEN': '', 'ADMIN_IPS': '', 'FORCE_HTTPS': ''}
    log = open(log_path, 'w')
    node = subprocess.Popen(['node', '--disable-warning=ExperimentalWarning', 'server/index.mjs'], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    static = subprocess.Popen([sys.executable, '-m', 'http.server', str(DIST_PORT), '--bind', '127.0.0.1', '--directory', DIST], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(100):
            time.sleep(0.1)
            m = re.search(r'(http://\S+primer-acceso\?clave=[\w-]+)', open(log_path).read())
            if m:
                SETUP_LINK = m.group(1)
                break
            if node.poll() is not None:
                break
        if not SETUP_LINK:
            print(open(log_path).read())
            sys.exit('El servidor no inició')
        async with async_playwright() as p:
            b = await p.chromium.launch()
            rx_order = ''

            async def run_steps(steps, shots):
                for name, run in steps:
                    try:
                        await run()
                    except Exception as e:
                        check(f'{name} terminó sin excepción', False, repr(e)[:400])
                        for tag, page in shots:
                            await page.screenshot(path=f'{SHOTS}/{name}_{tag}_error.png')

            panel = mode in ('all', 'panel')
            if panel:
                # El primer administrador se crea con la interfaz (enlace de primera vez)
                tctx, tp = await new_page(b, tag='tienda')
                await store_ready(tp)
                actx, ap = await new_page(b, PANEL, wait='.pbar', tag='panel')
                await run_steps([('flow_admin_access', lambda: flow_admin_access(ap, tp))], [('panel', ap), ('tienda', tp)])
            # Farmacias de prueba (la tienda parte sin farmacias)
            seed_stores()
            if mode in ('all', 'tienda'):
                ctx, pg = await new_page(b)
                await store_ready(pg)
                for fl in (flow_search, flow_cart_checkout, flow_account, flow_pages, flow_listing, flow_header, flow_health):
                    try:
                        out = await fl(pg)
                        if fl is flow_cart_checkout and out:
                            rx_order = out
                    except Exception as e:
                        check(f'{fl.__name__} terminó sin excepción', False, repr(e)[:300])
                        await pg.screenshot(path=f'{SHOTS}/{fl.__name__}_error.png')
                for r in ['/', '/buscar?q=paracetamol', '/carro', '/cuenta', '/farmacias']:
                    await go(pg, r, 300)
                    check(f'Sin desborde horizontal (escritorio) en {r}', not await overflow(pg))
                await ctx.close()
            if panel:
                await store_sync(tp)
                await run_steps([
                    ('flow_farmacias', lambda: flow_farmacias(tp, ap)),
                    ('flow_fotos', lambda: flow_fotos(tp, ap)),
                    ('flow_admin', lambda: flow_admin(tp, ap, rx_order)),
                    ('flow_bulk', lambda: flow_bulk(tp, ap)),
                    ('flow_banners', lambda: flow_banners(tp, ap)),
                    ('flow_promos', lambda: flow_promos(tp, ap)),
                    ('flow_menu', lambda: flow_menu(tp, ap)),
                    ('flow_services', lambda: flow_services(tp, ap)),
                    ('flow_moves_filters', lambda: flow_moves_filters(tp, ap)),
                    ('flow_security', lambda: flow_security(tp, ap)),
                    ('flow_order_stages', lambda: flow_order_stages(tp, ap)),
                    ('flow_admin_session', lambda: flow_admin_session(ap)),
                ], [('panel', ap), ('tienda', tp)])
                await ap.screenshot(path=f'{SHOTS}/panel.png', full_page=True)
                await actx.close()
                await tctx.close()
            if mode == 'all':
                for fl in (flow_local, flow_sandbox):
                    try:
                        await fl(b)
                    except Exception as e:
                        check(f'{fl.__name__} terminó sin excepción', False, repr(e)[:300])
            if mode in ('all', 'celular'):
                ctx, pg = await new_page(b, mobile=True)
                await store_ready(pg)
                try:
                    await flow_mobile(pg)
                except Exception as e:
                    check('flow_mobile terminó sin excepción', False, repr(e)[:300])
                    await pg.screenshot(path=f'{SHOTS}/flow_mobile_error.png')
                await ctx.close()
                try:
                    await flow_mobile_panel(b)
                except Exception as e:
                    check('flow_mobile_panel terminó sin excepción', False, repr(e)[:300])
            await b.close()
    finally:
        node.terminate()
        static.terminate()
        log.close()
    fails = [r for r in results if not r[1]]
    print(f'\n{len(results) - len(fails)} OK, {len(fails)} con error')
    for n, _, d in fails:
        print('  ✗', n, '->', d)
    print('Consola:', console_errors[:20] if console_errors else 'sin errores')
    print('Capturas en', SHOTS, '· registro del servidor en', log_path)
    if fails or console_errors:
        sys.exit(1)


asyncio.run(main())

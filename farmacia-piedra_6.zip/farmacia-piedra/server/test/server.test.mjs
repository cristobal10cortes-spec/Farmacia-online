// Pruebas del servidor: API de la tienda, panel de administración y seguridad.
//   npm run test:server
// Cada grupo levanta un servidor con una base de datos en memoria.

import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, request as httpRequest } from 'node:http';
import { crc32, deflateSync } from 'node:zlib';
import { imageSize } from '../lib/shop.mjs';
import { join } from 'node:path';
import { existsSync } from 'node:fs';
import { openDb, createRepo } from '../lib/db.mjs';
import { makeCipher, parseKey } from '../lib/cifrado.mjs';
import { hotp, totp, base32Encode, base32Decode, verifyTotp, counterAt } from '../lib/totp.mjs';
import { isLocalIp } from '../lib/security.mjs';
import { randomBytes } from 'node:crypto';
import { createApp } from '../app.mjs';
import { ROOT } from '../config.mjs';
import { hashPassword, passwordIssues, verifyPassword, RateLimiter, safeEqual } from '../lib/security.mjs';
import { safeJoin } from '../lib/http.mjs';
import { rateKey } from '../app.mjs';
import { byId } from '../../src/js/engine/catalog.js';
import { stockAt } from '../../src/js/engine/stock.js';
import { proposeProduct } from '../../src/js/engine/importar.js';

const PUBLIC = join(ROOT, 'server/public');
const SETUP = 'clave-de-prueba-1234567890';
const PASS = 'Piedra-Segura-2026';
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const BASE_CONFIG = {
  port: 0, host: '127.0.0.1', dataDir: '', publicDir: PUBLIC, privateDir: join(ROOT, 'server/privado'), adminPath: '/admin',
  trustProxy: false, forceHttps: false, storeOrigins: [], adminIps: [],
  sessionHours: 12, idleMinutes: 120, setupToken: SETUP, adminUser: '', adminPassword: '',
};

async function startApp(extra = {}) {
  const db = openDb(':memory:');
  const repo = createRepo(db, { cipher: makeCipher(randomBytes(32)) });
  const config = { ...BASE_CONFIG, ...extra };
  const app = createApp({ config, repo, log: { info() {}, warn() {} } });
  const first = await app.ensureFirstAdmin();
  const server = createServer((req, res) => { app.handle(req, res); });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    app, repo, db, server, base, first,
    async close() {
      server.closeAllConnections?.();
      await new Promise((r) => server.close(r));
      app.close();
      db.close();
    },
  };
}

/** Cliente HTTP con su propia cookie y ficha anti-CSRF (como un navegador). */
function client(base) {
  const c = {
    cookie: '',
    csrf: '',
    async req(method, path, { body, headers = {}, raw = false } = {}) {
      const h = { accept: 'application/json', ...headers };
      if (c.cookie) h.cookie = c.cookie;
      if (body !== undefined && !raw && !h['content-type']) h['content-type'] = 'application/json';
      if (c.csrf && method !== 'GET' && !('x-csrf-token' in h)) h['x-csrf-token'] = c.csrf;
      const res = await fetch(base + path, { method, headers: h, body: body === undefined ? undefined : raw ? body : JSON.stringify(body), redirect: 'manual' });
      const set = res.headers.get('set-cookie');
      if (set) {
        const m = /^([^=]+)=([^;]*)/.exec(set);
        c.cookie = m && m[2] ? `${m[1]}=${m[2]}` : '';
      }
      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch { json = null; }
      return { status: res.status, headers: res.headers, json, text, setCookie: set };
    },
    get: (p, o) => c.req('GET', p, o),
    post: (p, body, o = {}) => c.req('POST', p, { ...o, body }),
    async login(user = 'admin', password = PASS) {
      const r = await c.post('/admin/api/login', { user, password });
      if (r.status === 200) c.csrf = r.json.csrf;
      return r;
    },
  };
  return c;
}

const customer = { nombre: 'Ana', apellidos: 'Pérez Soto', rut: '11.111.111-1', email: 'ana@example.com', phone: '+56 9 1234 5678' };
const despacho = { type: 'despacho', region: 'RM', comuna: 'Santiago', calle: 'Av. Siempre Viva', numero: '742', depto: '', indicaciones: '', speed: 'estandar' };
const order = (over = {}) => ({
  items: [{ id: '420101', qty: 2 }],
  customer,
  delivery: despacho,
  payment: { method: 'tarjeta', approved: true },
  document: { type: 'boleta' },
  coupon: null,
  ctx: { member: false, treatment: [], ordersCount: 0 },
  rxDeclare: false,
  prescriptions: [],
  ...over,
});

// ── Funciones de seguridad ───────────────────────────────────
test('contraseñas: scrypt con sal, verificación y reglas', async () => {
  const h1 = await hashPassword(PASS);
  const h2 = await hashPassword(PASS);
  assert.match(h1, /^scrypt\$32768\$8\$1\$/);
  assert.notEqual(h1, h2, 'cada resumen lleva una sal distinta');
  assert.ok(!h1.includes(PASS));
  assert.equal(await verifyPassword(PASS, h1), true);
  assert.equal(await verifyPassword('otra-cosa-123', h1), false);
  assert.equal(await verifyPassword(PASS, 'basura'), false);
  assert.deepEqual(passwordIssues(PASS, 'admin'), []);
  assert.ok(passwordIssues('corta1').length);
  assert.ok(passwordIssues('soloLetrasLargas').some((x) => x.includes('número')));
  assert.ok(passwordIssues('admin12345678', 'admin').some((x) => x.includes('usuario')));
  assert.ok(passwordIssues('1111111111').length);
  assert.equal(safeEqual('abc', 'abc'), true);
  assert.equal(safeEqual('abc', 'abd'), false);
  assert.equal(safeEqual(undefined, ''), true);
});

test('límite de intentos: bloquea y libera', () => {
  const rl = new RateLimiter({ limit: 3, windowMs: 1000 });
  const t = 1_000_000;
  assert.equal(rl.hit('x', t), 0);
  assert.equal(rl.hit('x', t), 0);
  assert.equal(rl.blocked('x', t), 0);
  assert.equal(rl.hit('x', t), 0, 'el tercer intento se permite');
  assert.ok(rl.blocked('x', t) > 0, 'después del tercero queda bloqueado');
  assert.ok(rl.hit('x', t) > 0, 'el cuarto intento no se permite');
  assert.ok(rl.blocked('x', t + 10) > 0);
  assert.equal(rl.blocked('x', t + 1001), 0, 'se libera al terminar el bloqueo');
  assert.equal(rl.hit('y', t), 0, 'otras claves no se afectan');
});

test('rutas de archivos: no se puede salir de la carpeta pública', () => {
  assert.equal(safeJoin('/srv/pub', '/../etc/passwd'), null);
  assert.equal(safeJoin('/srv/pub', '/%2e%2e/etc/passwd'), null);
  assert.equal(safeJoin('/srv/pub', '/a/../../x'), null);
  assert.equal(safeJoin('/srv/pub', '/ok%00.js'), null);
  assert.equal(safeJoin('/srv/pub', '/%E0%A4%A'), null);
  assert.equal(safeJoin('/srv/pub', '/assets/tienda.js'), '/srv/pub/assets/tienda.js');
});

// ── Servidor completo ────────────────────────────────────────
let S;
let admin;
let anon;
before(async () => {
  assert.ok(existsSync(join(PUBLIC, 'index.html')), 'Ejecuta primero: npm run build');
  // Límites amplios: aquí todas las pruebas vienen de la misma IP (los límites se prueban aparte)
  S = await startApp({ rateLimits: { orders: 1000, lookup: 1000, loginIp: 1000 } });
  admin = client(S.base);
  anon = client(S.base);
});
after(async () => { await S?.close(); });

test('archivos de la tienda y del panel, con cabeceras de seguridad', async () => {
  const home = await anon.get('/');
  assert.equal(home.status, 200);
  assert.match(home.text, /<meta name="piedra-api" content="\/api">/);
  assert.doesNotMatch(home.text, /panel\.js|Ingresar administrador/i, 'la tienda no enlaza el panel');
  const csp = home.headers.get('content-security-policy');
  assert.match(csp, /script-src 'self'/);
  assert.doesNotMatch(csp, /script-src[^;]*unsafe/);
  assert.equal(home.headers.get('x-content-type-options'), 'nosniff');

  const js = await anon.get('/assets/tienda.js');
  assert.equal(js.status, 200);
  assert.match(js.headers.get('content-type'), /javascript/);
  assert.ok(!js.text.includes('Ingresar administrador'), 'el código del panel no viaja con la tienda');

  const redirect = await anon.get('/admin');
  assert.equal(redirect.status, 301);
  assert.equal(redirect.headers.get('location'), '/admin/');

  const panel = await anon.get('/admin/');
  assert.equal(panel.status, 200);
  assert.match(panel.text, /acceso\.js/);
  assert.doesNotMatch(panel.text, /<script[^>]+panel\.js/, 'sin sesión no se carga el panel');
  const access = await anon.get('/admin/acceso.js');
  assert.equal(access.status, 200);
  assert.ok(!access.text.includes('Productos y stock') && !access.text.includes('/2fa/enable'), 'la pantalla de ingreso no trae el código del panel');
  const hidden = await anon.get('/admin/panel.js');
  assert.equal(hidden.status, 404, 'el código del panel no se entrega sin sesión');
  assert.doesNotMatch(hidden.text, /Productos y stock/);
  assert.equal(panel.headers.get('x-frame-options'), 'DENY');
  assert.match(panel.headers.get('x-robots-tag'), /noindex/);
  assert.equal(panel.headers.get('cache-control'), 'no-store');
  assert.match(panel.headers.get('content-security-policy'), /frame-ancestors 'none'/);

  for (const p of ['/../package.json', '/assets/../../package.json', '/assets/%2e%2e/%2e%2e/package.json', '/admin/..%2f..%2fpackage.json', '/server/app.mjs', '/datos/farmacia.db', '/.env']) {
    const r = await anon.get(p);
    assert.equal(r.status, 404, `${p} no debe entregarse`);
    assert.doesNotMatch(r.text, /"name": "farmacia-piedra"|createApp/);
  }
  const api404 = await anon.get('/api/nada');
  assert.equal(api404.status, 404);
  assert.equal(api404.json.code, 'not_found');
  const wrongMethod = await anon.req('DELETE', '/api/catalog');
  assert.equal(wrongMethod.status, 405);
});

test('catálogo público inicial y respuesta mínima si no cambió', async () => {
  const r = await anon.get('/api/catalog');
  assert.equal(r.status, 200);
  assert.deepEqual(r.json, { version: 0, overrides: {}, banners: [], menu: [], stores: [], services: null });
  const same = await anon.get('/api/catalog?v=0');
  assert.deepEqual(same.json, { version: 0, unchanged: true });
});

test('primer administrador: solo con la clave de configuración', async () => {
  const s0 = await anon.get('/admin/api/session');
  assert.deepEqual(s0.json, { user: null, csrf: null, needsSetup: true, store: '/' });
  assert.equal(S.first.ready, false);

  const bad = await anon.post('/admin/api/setup', { token: 'otra-clave-cualquiera', user: 'admin', password: PASS });
  assert.equal(bad.status, 403);
  const weak = await anon.post('/admin/api/setup', { token: SETUP, user: 'admin', password: 'corta' });
  assert.equal(weak.status, 400);
  const badUser = await anon.post('/admin/api/setup', { token: SETUP, user: 'a b', password: PASS });
  assert.equal(badUser.status, 400);

  const ok = await admin.post('/admin/api/setup', { token: SETUP, user: 'Admin', password: PASS });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.user, 'admin', 'el usuario se guarda en minúsculas');
  assert.ok(ok.json.csrf.length >= 20);
  assert.match(ok.setCookie, /HttpOnly/);
  assert.match(ok.setCookie, /SameSite=Strict/);
  assert.match(ok.setCookie, /Path=\//);
  admin.csrf = ok.json.csrf;

  const again = await anon.post('/admin/api/setup', { token: SETUP, user: 'otro', password: PASS });
  assert.equal(again.status, 409, 'la configuración inicial sirve una sola vez');
  const s1 = await admin.get('/admin/api/session');
  assert.equal(s1.json.user, 'admin');
  assert.equal(s1.json.needsSetup, false);

  // La contraseña no se guarda tal cual
  const row = S.repo.adminByUser('admin');
  assert.ok(row.hash.startsWith('scrypt$'));
  assert.ok(!row.hash.includes(PASS));
});

test('la API del panel exige sesión, ficha anti-CSRF y mismo sitio', async () => {
  for (const [m, p] of [['GET', '/admin/api/data'], ['POST', '/admin/api/stock'], ['POST', '/admin/api/stock/bulk'], ['POST', '/admin/api/price'], ['DELETE', '/admin/api/products/420101'], ['GET', '/admin/api/orders/PD12345678/recetas/1'], ['POST', '/admin/api/menu'], ['DELETE', '/admin/api/menu/club'], ['PUT', '/admin/api/servicios'], ['GET', '/admin/api/movimientos?desde=2026-01-01']]) {
    const r = await anon.req(m, p, m === 'GET' || m === 'DELETE' ? {} : { body: {} });
    assert.equal(r.status, 401, `${m} ${p} sin sesión`);
  }
  const noCsrf = await admin.post('/admin/api/price', { pid: '420101', price: 990, offer: 0 }, { headers: { 'x-csrf-token': '' } });
  assert.equal(noCsrf.status, 403);
  assert.equal(noCsrf.json.code, 'csrf');
  const wrongCsrf = await admin.post('/admin/api/price', { pid: '420101', price: 990, offer: 0 }, { headers: { 'x-csrf-token': 'x'.repeat(32) } });
  assert.equal(wrongCsrf.status, 403);
  const crossSite = await admin.post('/admin/api/price', { pid: '420101', price: 990, offer: 0 }, { headers: { origin: 'https://sitio-malicioso.example', 'sec-fetch-site': 'cross-site' } });
  assert.equal(crossSite.status, 403);
  assert.equal(crossSite.json.code, 'cross_site');
  const otherOrigin = await admin.post('/admin/api/price', { pid: '420101', price: 990, offer: 0 }, { headers: { origin: 'https://sitio-malicioso.example' } });
  assert.equal(otherOrigin.status, 403);
  const forged = await anon.post('/admin/api/price', { pid: '420101', price: 990, offer: 0 }, { headers: { cookie: 'piedra_panel=inventada', 'x-csrf-token': admin.csrf } });
  assert.equal(forged.status, 401, 'una cookie inventada no sirve');
  const notJson = await admin.req('POST', '/admin/api/price', { body: 'pid=420101', raw: true, headers: { 'content-type': 'application/x-www-form-urlencoded' } });
  assert.equal(notJson.status, 415, 'solo se acepta JSON (los formularios de otros sitios no sirven)');
  const data = await admin.get('/admin/api/data');
  assert.equal(data.status, 200);
  assert.equal(data.headers.get('cache-control'), 'no-store');
  assert.deepEqual(Object.keys(data.json).sort(), ['banners', 'menu', 'movements', 'orders', 'overrides', 'services', 'stores', 'version']);
});

let storeA;
let storeB;
const pharmacy = (over = {}) => ({ name: 'Farmacia Piedra Centro', address: 'Huérfanos 1000', region: 'RM', comuna: 'Santiago', phone: '+56 2 2345 6789', h24: false, recetario: true, hours: { wk: [9, 21], sat: [10, 14], sun: null }, turnos: [], ...over });

test('farmacias: la tienda parte sin farmacias y el panel las crea, valida y edita', async () => {
  const empty = (await anon.get('/api/catalog')).json;
  assert.deepEqual(empty.stores, [], 'sin farmacias de ejemplo');
  const noStore = await anon.post('/api/orders', order({ delivery: { type: 'retiro', storeId: 'F001' }, payment: { method: 'farmacia' } }));
  assert.equal(noStore.status, 400, 'sin farmacias no hay retiro');
  for (const bad of [pharmacy({ name: '' }), pharmacy({ comuna: 'Temuco' }), pharmacy({ region: 'ZZ' }), pharmacy({ hours: { wk: [21, 9] } }), pharmacy({ hours: {} }), pharmacy({ phone: '<b>1</b>' })]) {
    const r = await admin.post('/admin/api/stores', { store: bad });
    assert.equal(r.status, 400, JSON.stringify(bad).slice(0, 120));
  }
  const noAuth = await anon.post('/admin/api/stores', { store: pharmacy() });
  assert.equal(noAuth.status, 401);
  const a = await admin.post('/admin/api/stores', { store: pharmacy({ name: '<b>Farmacia</b> Centro', extra: 'x' }), initialStock: 6 });
  assert.equal(a.status, 200, a.text);
  storeA = a.json.result;
  assert.match(storeA, /^F[0-9A-Z]{2,20}$/);
  const b = await admin.post('/admin/api/stores', { store: pharmacy({ name: 'Farmacia Piedra Las Condes', address: 'Apoquindo 4499', comuna: 'Las Condes', h24: true, hours: {} }) });
  assert.equal(b.status, 200, b.text);
  storeB = b.json.result;
  const cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.stores.length, 2);
  const sa = cat.stores.find((x) => x.id === storeA);
  assert.equal(sa.name, '<b>Farmacia</b> Centro', 'se guarda como texto (la tienda lo escapa)');
  assert.equal(sa.extra, undefined);
  assert.deepEqual(sa.services, ['retiro', 'recetario']);
  assert.equal(stockAt(byId.get('420101'), `s:${storeA}`), 6, 'stock inicial en todos los productos');
  assert.equal(stockAt(byId.get('420104'), `s:${storeA}`), 6);
  assert.equal(stockAt(byId.get('420101'), `s:${storeB}`), 0, 'sin stock inicial parte en 0');
  const upd = await admin.req('PUT', `/admin/api/stores/${storeA}`, { body: { store: pharmacy({ name: 'Farmacia Piedra Centro', turnos: ['2099-01-02', '2099-01-01', 'no-es-fecha'] }) } });
  assert.equal(upd.status, 200, upd.text);
  const sa2 = (await anon.get('/api/catalog')).json.stores.find((x) => x.id === storeA);
  assert.equal(sa2.name, 'Farmacia Piedra Centro');
  assert.deepEqual(sa2.turnos, ['2099-01-01', '2099-01-02']);
  assert.equal((await admin.req('PUT', '/admin/api/stores/FNOEXISTE', { body: { store: pharmacy() } })).status, 404);
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.ok(moves.some((m) => m.kind === 'farmacia' && m.note.includes('Farmacia creada')));
});

test('stock: fijar y sumar, con registro de movimientos y versión nueva', async () => {
  const p = byId.get('420101');
  const v0 = (await anon.get('/api/catalog')).json.version;
  const set = await admin.post('/admin/api/stock', { pid: '420101', mode: 'set', changes: [{ loc: 'o:RM', qty: 50 }, { loc: `s:${storeA}`, qty: 7 }, { loc: 'x:nada', qty: 9 }, { loc: 's:F999', qty: 3 }], kind: 'ajuste', note: 'Inventario' });
  assert.equal(set.status, 200);
  assert.equal(set.json.result, 2, 'solo cuentan las ubicaciones válidas');
  assert.ok(set.json.version > v0);
  assert.equal(stockAt(p, 'o:RM'), 50);
  const add = await admin.post('/admin/api/stock', { pid: '420101', mode: 'add', locs: ['o:RM', `s:${storeA}`], qty: 5, note: 'Recepción de proveedor' });
  assert.equal(add.status, 200);
  assert.equal(stockAt(p, 'o:RM'), 55);
  assert.equal(stockAt(p, `s:${storeA}`), 12);
  const cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.overrides['420101'].stock.o.RM, 55);
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.equal(moves[0].kind, 'ingreso');
  assert.equal(moves[0].by, 'admin');
  assert.equal(moves[0].note, 'Recepción de proveedor');
  for (const bad of [{ pid: 'NO-EXISTE', mode: 'set', changes: [{ loc: 'o:RM', qty: 1 }] }, { pid: '420101', mode: 'add', locs: [], qty: 3 }, { pid: '420101', mode: 'add', locs: ['o:RM'], qty: 0 }, { pid: '420101', mode: 'set', changes: [] }, { pid: '../../etc', mode: 'set', changes: [{ loc: 'o:RM', qty: 1 }] }]) {
    const r = await admin.post('/admin/api/stock', bad);
    assert.ok(r.status === 400 || r.status === 404, JSON.stringify(bad));
  }
  const neg = await admin.post('/admin/api/stock', { pid: '420101', mode: 'set', changes: [{ loc: 'o:CENTRO', qty: -40 }] });
  assert.equal(neg.status, 200);
  assert.equal(stockAt(p, 'o:CENTRO'), 0, 'el stock nunca queda negativo');
});

test('carga masiva: sumar o reemplazar desde una planilla; los códigos que no existen se omiten', async () => {
  const p1 = byId.get('420102');
  const p2 = byId.get('420103');
  const loc = `s:${storeA}`;
  const b1 = stockAt(p1, loc);
  const add = await admin.post('/admin/api/stock/bulk', { mode: 'add', loc, file: 'llegada octubre.xlsx', rows: [{ line: 2, code: '420102', qty: 10 }, { line: 3, code: 'NO-EXISTE', qty: 5 }, { line: 4, code: '420102', qty: 2 }, { line: 5, code: '420103', qty: 1.5 }, { line: 6, code: '../x', qty: 1 }] });
  assert.equal(add.status, 200, add.text);
  const r = add.json.result;
  assert.equal(stockAt(p1, loc), b1 + 12, 'los códigos repetidos se suman');
  assert.equal(r.changed, 1);
  assert.equal(r.units, 12);
  assert.equal(r.skippedCount, 3);
  assert.deepEqual(r.skipped.map((x) => x.line), [3, 5, 6]);
  const set = await admin.post('/admin/api/stock/bulk', { mode: 'set', loc: 'o:RM', rows: [{ line: 2, code: '420102', qty: 0 }, { line: 3, code: '420103', qty: 33 }] });
  assert.equal(set.status, 200, set.text);
  assert.equal(stockAt(p1, 'o:RM'), 0, 'reemplazar deja exactamente la cantidad (también 0)');
  assert.equal(stockAt(p2, 'o:RM'), 33);
  const again = await admin.post('/admin/api/stock/bulk', { mode: 'set', loc: 'o:RM', rows: [{ code: '420103', qty: 33 }] });
  assert.equal(again.json.result.changed, 0, 'si ya estaba igual no hay cambio');
  const moves = (await admin.get('/admin/api/data')).json.movements;
  const ing = moves.find((m) => m.pid === '420102' && m.kind === 'ingreso' && m.loc === loc);
  assert.ok(ing && ing.note === 'Carga masiva · llegada octubre.xlsx' && /^CM/.test(ing.ref), JSON.stringify(ing));
  const aj = moves.find((m) => m.pid === '420103' && m.kind === 'ajuste' && m.loc === 'o:RM');
  assert.ok(aj && aj.after === 33);
  for (const bad of [
    { loc, rows: [{ code: '420102', qty: 1 }] },
    { mode: 'add', loc: 's:F999', rows: [{ code: '420102', qty: 1 }] },
    { mode: 'add', loc: 'all', rows: [{ code: '420102', qty: 1 }] },
    { mode: 'set', loc, rows: [] },
    { mode: 'set', loc, rows: [{ code: 'NADA', qty: 1 }, { code: '420102', qty: -1 }] },
    { mode: 'set', loc, rows: Array.from({ length: 5001 }, () => ({ code: '420102', qty: 1 })) },
  ]) {
    const e = await admin.post('/admin/api/stock/bulk', bad);
    assert.equal(e.status, 400, JSON.stringify(bad).slice(0, 100));
  }
  assert.equal((await anon.post('/admin/api/stock/bulk', { mode: 'add', loc, rows: [{ code: '420102', qty: 1 }] })).status, 401);
});

test('carga desde planilla: crea productos, actualiza precio, costo y existencia; el costo no llega a la tienda', async () => {
  const loc = `s:${storeA}`;
  const mk = (code, name, dept) => ({ ...proposeProduct({ code, name, dept, price: 3990 }) });
  const los = mk('7809990000011', 'Losartan 50mg x 30 Com.Rec. Lab Demo', 'BIOEQUIVALENTES');
  const hel = mk('7809990000066', 'Helado Vasito Frutilla 170 ML', 'Helados');
  const p5 = byId.get('420105');
  const r = await admin.post('/admin/api/import', { file: 'eleventa.xlsx', loc, mode: 'set', rows: [
    { line: 2, code: '420105', qty: 9, cost: 1000, price: p5.price + 100 },
    { line: 3, code: '7809990000011', qty: 12, cost: 1250, price: 3990, def: los.def },
    { line: 4, code: '7809990000066', qty: 20, cost: 300, price: 990, def: hel.def, hidden: true },
    { line: 5, code: 'NO-EXISTE', qty: 1 },
    { line: 6, code: 'MALO', qty: 1, price: 990, def: { n: '', b: '', c: 'x/y' } },
    { line: 7, code: 'ab c', qty: 1 },
  ] });
  assert.equal(r.status, 200, r.text);
  const res = r.json.result;
  assert.equal(res.created, 2);
  assert.equal(res.createdHidden, 1);
  assert.equal(res.price, 1);
  assert.equal(res.cost, 1);
  assert.equal(res.skippedCount, 3);
  assert.equal(stockAt(byId.get('7809990000011'), loc), 12, 'el producto nuevo parte con su existencia');
  assert.equal(stockAt(p5, loc), 9);
  const pubRes = await anon.req('GET', '/api/catalog', { headers: { 'accept-encoding': 'gzip' } });
  assert.equal(pubRes.headers.get('content-encoding'), 'gzip', 'el catálogo viaja comprimido');
  const pub = pubRes.json;
  assert.equal(pub.overrides['7809990000011'].def.n, 'Losartan 50mg x 30 Com.Rec. Lab Demo');
  assert.equal(pub.overrides['7809990000011'].def.rx, 'simple');
  assert.ok(pub.overrides['7809990000066'].hidden, '«No publicar» lo crea oculto');
  assert.ok(Object.values(pub.overrides).every((o) => !o || o.cost === undefined), 'la tienda nunca recibe el costo');
  assert.equal(pub.overrides['420105'].price, p5.price);
  const data = (await admin.get('/admin/api/data')).json;
  assert.equal(data.overrides['7809990000011'].cost, 1250, 'el panel sí ve el costo');
  assert.equal(data.overrides['420105'].cost, 1000);
  assert.ok(data.movements.some((m) => m.kind === 'producto' && m.note.includes('2 productos creados')));
  // Otra vez el mismo archivo: los códigos ya existen, no se duplican
  const again = await admin.post('/admin/api/import', { loc, mode: 'add', rows: [{ line: 2, code: '7809990000011', qty: 3, def: los.def, price: 3990 }] });
  assert.equal(again.status, 200, again.text);
  assert.equal(again.json.result.created, 0);
  assert.equal(stockAt(byId.get('7809990000011'), loc), 15);
  // El costo se cambia o borra desde la ficha
  assert.equal((await admin.post('/admin/api/price', { pid: '7809990000011', price: 3990, offer: 0, cost: 1500 })).status, 200);
  assert.equal((await admin.get('/admin/api/data')).json.overrides['7809990000011'].cost, 1500);
  assert.equal((await admin.post('/admin/api/price', { pid: '7809990000011', price: 3990, offer: 0, cost: -3 })).status, 400);
  // Un producto de planilla se puede editar aunque no tenga principio activo
  const noAi = { ...los.def };
  delete noAi.ai;
  assert.equal((await admin.req('PUT', '/admin/api/products/7809990000011', { body: { def: noAi } })).status, 200);
  for (const bad of [{ loc, mode: 'set', rows: [] }, { loc: 'x:y', mode: 'set', rows: [{ code: '420105', qty: 1 }] }, { rows: [{ code: '420105', qty: 1 }] }, { rows: [{ code: 'NADA', price: 100 }] }]) {
    assert.equal((await admin.post('/admin/api/import', bad)).status, 400, JSON.stringify(bad));
  }
  assert.equal((await admin.post('/admin/api/import', { rows: [{ code: '420105', price: p5.price }] })).status, 200, 'solo precio: no pide ubicación');
  assert.equal((await anon.post('/admin/api/import', { rows: [{ code: '420105', price: 1000 }] })).status, 401);
  for (const id of ['7809990000011', '7809990000066']) assert.equal((await admin.req('DELETE', `/admin/api/products/${id}`)).status, 200);
});

test('precio, oferta y visibilidad', async () => {
  const bad = await admin.post('/admin/api/price', { pid: '420102', price: 1000, offer: 1200 });
  assert.equal(bad.status, 400);
  const zero = await admin.post('/admin/api/price', { pid: '420102', price: 0 });
  assert.equal(zero.status, 400);
  const ok = await admin.post('/admin/api/price', { pid: '420102', price: 1500, offer: 1290 });
  assert.equal(ok.status, 200);
  let cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual([cat.overrides['420102'].price, cat.overrides['420102'].offer, cat.overrides['420102'].priceSet], [1500, 1290, true]);
  assert.equal(byId.get('420102').price, 1500);
  // Volver al precio original deja el producto como venía
  await admin.post('/admin/api/price', { pid: '420102', price: 1190, offer: 0 });
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.overrides['420102']?.priceSet, undefined);
  const hide = await admin.post('/admin/api/visibility', { pid: '420104', hidden: true });
  assert.equal(hide.status, 200);
  assert.equal(byId.get('420104').hidden, true);
  const buy = await anon.post('/api/orders', order({ items: [{ id: '420104', qty: 1 }] }));
  assert.equal(buy.status, 409);
  assert.equal(buy.json.code, 'unavailable');
  await admin.post('/admin/api/visibility', { pid: '420104', hidden: false });
  assert.equal(byId.get('420104').hidden, false);
});

let newPid;
test('productos nuevos: validación, creación, edición y eliminación', async () => {
  const bad = await admin.post('/admin/api/products', { def: { n: '', b: 'X', c: 'nada' } });
  assert.equal(bad.status, 400);
  const def = { n: 'Jarabe de prueba 120 ml', b: 'Piedra', c: 'medicamentos/dolor-y-fiebre', ai: ['Paracetamol'], f: 'jarabe', u: 120, un: 'ml', p: 3990, o: 0, rx: 'directa', d: 'Producto creado en las pruebas.' };
  const r = await admin.post('/admin/api/products', { def, stock: { o: { RM: 20 }, s: { [storeA]: 4, F999: 9 } } });
  assert.equal(r.status, 200, r.text);
  newPid = r.json.result;
  assert.match(newPid, /^N[0-9A-Z]+$/);
  const p = byId.get(newPid);
  assert.ok(p && p.custom);
  assert.equal(stockAt(p, 'o:RM'), 20);
  assert.equal(stockAt(p, 'o:NORTE'), 0, 'un producto nuevo parte sin stock donde no se indicó');
  const cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.overrides[newPid].def.n, def.n);
  const upd = await admin.req('PUT', `/admin/api/products/${newPid}`, { body: { def: { ...def, n: 'Jarabe de prueba 150 ml' } } });
  assert.equal(upd.status, 200, upd.text);
  assert.equal(byId.get(newPid).name, 'Jarabe de prueba 150 ml');
  const notCustom = await admin.req('PUT', '/admin/api/products/420101', { body: { def } });
  assert.equal(notCustom.status, 400, 'los productos del catálogo base no se reescriben');
  const delBase = await admin.req('DELETE', '/admin/api/products/420101');
  assert.equal(delBase.status, 400);
});

let orderId;
test('pedido desde la tienda: el servidor calcula el total y descuenta el stock', async () => {
  const p = byId.get('420101');
  const before = stockAt(p, 'o:RM');
  const wrongTotal = await anon.post('/api/orders', order({ expectTotal: 1 }));
  assert.equal(wrongTotal.status, 409);
  assert.equal(wrongTotal.json.code, 'price_changed');
  assert.ok(wrongTotal.json.total > 0, 'informa el total correcto');
  const r = await anon.post('/api/orders', order({ expectTotal: wrongTotal.json.total, userEmail: 'ana@example.com' }));
  assert.equal(r.status, 201, r.text);
  const o = r.json.order;
  orderId = o.id;
  assert.match(o.id, /^PD\d{8}$/);
  assert.equal(o.totals.total, wrongTotal.json.total);
  assert.equal(o.items[0].unit, 790, 'usa el precio de oferta del servidor');
  assert.equal(o.payment.simulated, true);
  assert.equal(o.stockMoves, undefined, 'el cliente no ve datos internos');
  assert.equal(o.claims, undefined);
  assert.equal(stockAt(p, 'o:RM'), before - 2);
  const data = (await admin.get('/admin/api/data')).json;
  const saved = data.orders.find((x) => x.id === o.id);
  assert.ok(saved);
  assert.deepEqual(saved.stockMoves, [{ pid: '420101', loc: 'o:RM', qty: 2 }]);
  assert.equal(data.movements[0].kind, 'venta');
  assert.equal(data.movements[0].ref, o.id);
});

test('pedido: validación de datos, stock, recetas y precios manipulados', async () => {
  const cases = [
    [order({ items: [] }), 400],
    [order({ items: [{ id: '420101', qty: 99 }] }), 400],
    [order({ items: [{ id: '420101', qty: 1 }, { id: '420101', qty: 1 }] }), 400],
    [order({ items: [{ id: 'NOEXISTE', qty: 1 }] }), 409],
    [order({ customer: { ...customer, rut: '11.111.111-2' } }), 400],
    [order({ customer: { ...customer, email: 'no-es-correo' } }), 400],
    [order({ delivery: { ...despacho, comuna: 'Comuna Falsa' } }), 400],
    [order({ delivery: { ...despacho, calle: '' } }), 400],
    [order({ delivery: { type: 'retiro', storeId: 'F999' } }), 400],
    [order({ payment: { method: 'bitcoin' } }), 400],
    [order({ payment: { method: 'farmacia' } }), 400],
    [order({ document: { type: 'factura', rut: '1-9', razon: '', giro: '' } }), 400],
    [order({ items: [{ id: '420108', qty: 1 }] }), 400], // con receta: falta declaración y archivo
    [order({ items: [{ id: '420108', qty: 1 }], rxDeclare: true, prescriptions: [] }), 400],
    [order({ items: [{ id: '420108', qty: 1 }], rxDeclare: true, prescriptions: [{ productId: '420108', fileName: 'r.png', file: 'data:text/html;base64,PHNjcmlwdD4=' }] }), 400],
  ];
  for (const [body, status] of cases) {
    const r = await anon.post('/api/orders', body);
    assert.equal(r.status, status, `${JSON.stringify(body).slice(0, 160)} → ${r.text}`);
    assert.ok(r.json?.error, 'siempre hay un mensaje para el cliente');
  }
  // Sin stock suficiente en la zona
  await admin.post('/admin/api/stock', { pid: '420103', mode: 'set', changes: [{ loc: 'o:RM', qty: 1 }] });
  const noStock = await anon.post('/api/orders', order({ items: [{ id: '420103', qty: 3 }] }));
  assert.equal(noStock.status, 409);
  assert.equal(noStock.json.code, 'stock');
  assert.equal(noStock.json.items[0].id, '420103');
  // Precio inventado por el cliente: no tiene efecto
  const cheat = await anon.post('/api/orders', order({ items: [{ id: '420101', qty: 1, price: 1 }], totals: { total: 1 } }));
  assert.equal(cheat.status, 201);
  assert.equal(cheat.json.order.items[0].unit, 790);
});

let rxOrder;
test('recetas: se guardan y solo el administrador puede verlas', async () => {
  const r = await anon.post('/api/orders', order({
    items: [{ id: '420108', qty: 1 }],
    rxDeclare: true,
    prescriptions: [{ productId: '420108', fileName: 'receta.png', file: PNG }],
  }));
  assert.equal(r.status, 201, r.text);
  rxOrder = r.json.order;
  assert.equal(rxOrder.hasRx, true);
  assert.deepEqual(rxOrder.prescriptions, [{ productId: '420108', fileName: 'receta.png', hasFile: true }]);
  const data = (await admin.get('/admin/api/data')).json;
  const o = data.orders.find((x) => x.id === rxOrder.id);
  assert.equal(o.files.length, 1);
  const url = `/admin/api/orders/${rxOrder.id}/recetas/${o.files[0].id}`;
  const file = await fetch(S.base + url, { headers: { cookie: admin.cookie } });
  assert.equal(file.status, 200);
  assert.equal(file.headers.get('content-type'), 'image/png');
  assert.match(file.headers.get('content-security-policy'), /sandbox/);
  assert.equal(Buffer.from(await file.arrayBuffer()).subarray(1, 4).toString(), 'PNG');
  const noAuth = await anon.get(url);
  assert.equal(noAuth.status, 401);
  const otherOrder = await admin.get(`/admin/api/orders/${orderId}/recetas/${o.files[0].id}`);
  assert.equal(otherOrder.status, 404, 'la receta solo se entrega con su pedido');
});

test('retiro en farmacia: descuenta el stock de esa farmacia', async () => {
  const p = byId.get('420102');
  const before = stockAt(p, `s:${storeA}`);
  const r = await anon.post('/api/orders', order({ items: [{ id: '420102', qty: 2 }], delivery: { type: 'retiro', storeId: storeA, pickupBy: 'yo' }, payment: { method: 'farmacia' } }));
  assert.equal(r.status, 201, r.text);
  assert.equal(r.json.order.delivery.storeName, 'Farmacia Piedra Centro');
  assert.equal(stockAt(p, `s:${storeA}`), before - 2);
  const far = await anon.post('/api/orders', order({ items: [{ id: '420102', qty: 1 }], delivery: { type: 'retiro', storeId: 'F999' }, payment: { method: 'farmacia' } }));
  assert.equal(far.status, 400);
});

// PNG válido de w × h (gris) para las pruebas de fotos
function pngDataUrl(w, h) {
  const row = Buffer.concat([Buffer.from([0]), Buffer.alloc(w * 3, 200)]);
  const raw = Buffer.concat(Array.from({ length: h }, () => row));
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type, 'latin1'), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
  return `data:image/png;base64,${png.toString('base64')}`;
}

test('fotos de productos: subir, ver con caché, validar y quitar', async () => {
  const noAuth = await anon.req('PUT', '/admin/api/products/420101/foto', { body: { image: pngDataUrl(400, 400) } });
  assert.equal(noAuth.status, 401);
  const tiny = await admin.req('PUT', '/admin/api/products/420101/foto', { body: { image: pngDataUrl(120, 120) } });
  assert.equal(tiny.status, 400);
  assert.match(tiny.json.error, /120 × 120/);
  const svg = await admin.req('PUT', '/admin/api/products/420101/foto', { body: { image: 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=' } });
  assert.equal(svg.status, 400);
  const fake = await admin.req('PUT', '/admin/api/products/420101/foto', { body: { image: 'data:image/png;base64,' + Buffer.from('<html>no soy una foto</html>').toString('base64') } });
  assert.equal(fake.status, 400);
  const missing = await admin.req('PUT', '/admin/api/products/NOEXISTE/foto', { body: { image: pngDataUrl(400, 400) } });
  assert.equal(missing.status, 404);
  const ok = await admin.req('PUT', '/admin/api/products/420101/foto', { body: { image: pngDataUrl(800, 600) } });
  assert.equal(ok.status, 200, ok.text);
  assert.deepEqual([ok.json.result.w, ok.json.result.h], [800, 600]);
  const meta = (await anon.get('/api/catalog')).json.overrides['420101'].photo;
  assert.equal(meta.v, ok.json.result.v);
  assert.equal(byId.get('420101').photo?.v, meta.v, 'el motor del servidor también la conoce');
  const img = await fetch(`${S.base}/api/fotos/420101?v=${meta.v}`);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.match(img.headers.get('cache-control'), /immutable/);
  assert.match(img.headers.get('content-security-policy'), /sandbox/);
  assert.equal(Buffer.from(await img.arrayBuffer()).subarray(1, 4).toString(), 'PNG');
  const old = await fetch(`${S.base}/api/fotos/420101?v=vieja`);
  assert.doesNotMatch(old.headers.get('cache-control'), /immutable/, 'una versión vieja no se guarda para siempre');
  assert.equal((await fetch(`${S.base}/admin/api/fotos/420101?v=${meta.v}`)).status, 200, 'también desde la dirección del panel');
  assert.equal((await fetch(`${S.base}/api/fotos/420102`)).status, 404, 'sin foto: 404');
  assert.equal((await fetch(`${S.base}/api/fotos/..%2f..%2fpackage.json`)).status, 404);
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.ok(moves.some((m) => m.pid === '420101' && /Foto actualizada \(800 × 600 px\)/.test(m.note)));
  // El precio u otros cambios no borran la foto
  await admin.post('/admin/api/price', { pid: '420101', price: 990, offer: 790 });
  assert.ok((await anon.get('/api/catalog')).json.overrides['420101'].photo);
  const del = await admin.req('DELETE', '/admin/api/products/420101/foto');
  assert.equal(del.status, 200);
  assert.equal((await anon.get('/api/catalog')).json.overrides['420101'].photo, undefined);
  assert.equal((await fetch(`${S.base}/api/fotos/420101`)).status, 404);
  assert.equal((await admin.req('DELETE', '/admin/api/products/420101/foto')).status, 404);
  assert.equal(imageSize('image/png', Buffer.from(pngDataUrl(321, 456).split(',')[1], 'base64')).w, 321);
});

test('farmacias: eliminar una borra su stock y deja de ofrecer retiro ahí', async () => {
  const del = await admin.req('DELETE', `/admin/api/stores/${storeB}`);
  assert.equal(del.status, 200, del.text);
  const cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(cat.stores.map((x) => x.id), [storeA]);
  assert.ok(Object.values(cat.overrides).every((o) => !o.stock?.s || !(storeB in o.stock.s)), 'sin restos de su stock');
  const r = await anon.post('/api/orders', order({ delivery: { type: 'retiro', storeId: storeB }, payment: { method: 'farmacia' } }));
  assert.equal(r.status, 400);
  assert.equal((await admin.req('DELETE', `/admin/api/stores/${storeB}`)).status, 404);
});

test('seguimiento y anulación por el cliente (con el correo del pedido)', async () => {
  const wrong = await anon.get(`/api/orders/${orderId}?email=otro@example.com`);
  assert.equal(wrong.status, 404);
  const ok = await anon.get(`/api/orders/${orderId.toLowerCase()}?email=ANA@example.com`);
  assert.equal(ok.status, 200);
  assert.equal(ok.json.order.id, orderId);
  assert.equal(ok.json.order.stockMoves, undefined);
  const p = byId.get('420101');
  const before = stockAt(p, 'o:RM');
  const badCancel = await anon.post(`/api/orders/${orderId}/cancel`, { email: 'otro@example.com' });
  assert.equal(badCancel.status, 404);
  const cancel = await anon.post(`/api/orders/${orderId}/cancel`, { email: 'ana@example.com' });
  assert.equal(cancel.status, 200, cancel.text);
  assert.equal(cancel.json.order.cancelled, true);
  assert.equal(stockAt(p, 'o:RM'), before + 2, 'el stock vuelve');
  const twice = await anon.post(`/api/orders/${orderId}/cancel`, { email: 'ana@example.com' });
  assert.equal(twice.status, 409);
  // Cuando la farmacia ya confirmó el pedido, el cliente ya no puede anularlo
  assert.equal((await admin.post(`/admin/api/orders/${rxOrder.id}/status`, { status: 'embalaje' })).status, 200);
  const tooLate = await anon.post(`/api/orders/${rxOrder.id}/cancel`, { email: 'ana@example.com' });
  assert.equal(tooLate.status, 409);
  assert.equal(tooLate.json.code, 'too_late');
  // El administrador sí puede anular
  const byAdmin = await admin.post(`/admin/api/orders/${rxOrder.id}/cancel`, {});
  assert.equal(byAdmin.status, 200);
  assert.equal(S.repo.getOrder(rxOrder.id).cancelledBy, 'admin');
});

test('etapas del pedido, fecha de entrega y mensajes que ve el cliente', async () => {
  // El cliente elige el día de entrega (si no es uno de los disponibles, se usa el primero)
  const bad = await anon.post('/api/orders', order({ delivery: { ...despacho, date: '2000-01-01' } }));
  assert.equal(bad.status, 201, bad.text);
  const first = bad.json.order.delivery.date;
  assert.match(first, /^\d{4}-\d{2}-\d{2}$/);
  const { deliveryDates } = await import('../../src/js/engine/orderflow.js');
  const { deliveryInfo } = await import('../../src/js/engine/inventory.js');
  const options = deliveryDates(deliveryInfo({ region: 'RM', comuna: 'Santiago' }).home.date);
  assert.equal(first, options[0]);
  const chosen = options[3];
  const r = await anon.post('/api/orders', order({ customer: { ...customer, email: 'flujo@example.com' }, delivery: { ...despacho, date: chosen } }));
  assert.equal(r.status, 201, r.text);
  const id = r.json.order.id;
  assert.equal(r.json.order.delivery.date, chosen, 'se guarda el día que eligió el cliente');
  assert.equal(r.json.order.status, 'recibido');
  assert.equal(r.json.order.messages.length, 1);
  assert.equal(r.json.order.history[0].by, undefined, 'el cliente no ve quién hizo cada cambio');
  // Etapas: solo las marca el administrador
  assert.equal((await anon.post(`/admin/api/orders/${id}/status`, { status: 'embalaje' })).status, 401);
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'listo' })).status, 400, 'listo es solo para retiro');
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'recibido' })).status, 409, 'ya está en esa etapa');
  const s1 = await admin.post(`/admin/api/orders/${id}/status`, { status: 'embalaje', note: 'Tu receta está <b>correcta</b>.' });
  assert.equal(s1.status, 200, s1.text);
  let seen = (await anon.get(`/api/orders/${id}?email=flujo@example.com`)).json.order;
  assert.equal(seen.status, 'embalaje');
  assert.equal(seen.messages.at(-1).title, 'Pedido confirmado');
  assert.match(seen.messages.at(-1).text, /embalando.*Tu receta está <b>correcta<\/b>\./, 'la nota va como texto (la tienda la escapa)');
  assert.equal((await anon.post(`/api/orders/${id}/cancel`, { email: 'flujo@example.com' })).json.code, 'too_late', 'confirmado, el cliente ya no lo anula');
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'camino' })).status, 200);
  // Volver una etapa (por error): sin mensaje nuevo
  const before = (await anon.get(`/api/orders/${id}?email=flujo@example.com`)).json.order.messages.length;
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'embalaje' })).status, 200);
  seen = (await anon.get(`/api/orders/${id}?email=flujo@example.com`)).json.order;
  assert.equal(seen.status, 'embalaje');
  assert.equal(seen.messages.length, before);
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'recibido' })).status, 200);
  assert.equal((await admin.post(`/admin/api/orders/${id}/status`, { status: 'entregado' })).status, 200, 'puede saltar etapas hacia adelante');
  // Fecha: el administrador la cambia y el cliente recibe el aviso
  const id2 = (await anon.post('/api/orders', order({ customer: { ...customer, email: 'fecha@example.com' } }))).json.order.id;
  assert.equal((await admin.post(`/admin/api/orders/${id2}/date`, { date: '2001-01-01' })).status, 400, 'no antes de hoy');
  assert.equal((await admin.post(`/admin/api/orders/${id2}/date`, { date: '2026-02-30' })).status, 400, 'fecha inexistente');
  assert.equal((await admin.post(`/admin/api/orders/${id2}/date`, { date: 'mañana' })).status, 400);
  const newDate = options[5];
  const d1 = await admin.post(`/admin/api/orders/${id2}/date`, { date: newDate });
  assert.equal(d1.status, 200, d1.text);
  seen = (await anon.get(`/api/orders/${id2}?email=fecha@example.com`)).json.order;
  assert.equal(seen.delivery.date, newDate);
  assert.equal(seen.messages.at(-1).kind, 'fecha');
  assert.match(seen.messages.at(-1).text, /nueva fecha de entrega/);
  // Anulado: ya no cambia
  await admin.post(`/admin/api/orders/${id2}/cancel`, {});
  assert.equal((await admin.post(`/admin/api/orders/${id2}/status`, { status: 'embalaje' })).json.code, 'cancelled');
  assert.equal((await admin.post(`/admin/api/orders/${id2}/date`, { date: options[1] })).json.code, 'cancelled');
  seen = (await anon.get(`/api/orders/${id2}?email=fecha@example.com`)).json.order;
  assert.equal(seen.messages.at(-1).title, 'Pedido anulado');
});

test('banners: crear, validar, ordenar, pausar y eliminar', async () => {
  const evil = await admin.post('/admin/api/banners', { banner: { title: 'Hola', to: '//sitio-malicioso.example' } });
  assert.equal(evil.status, 400);
  const js = await admin.post('/admin/api/banners', { banner: { title: 'Hola', to: 'javascript:alert(1)' } });
  assert.equal(js.status, 400);
  const badImg = await admin.post('/admin/api/banners', { banner: { title: 'Foto', to: '/ofertas', visual: 'photo', image: 'data:image/svg+xml;base64,PHN2Zz4=' } });
  assert.equal(badImg.status, 400);
  const tiny = await admin.post('/admin/api/banners', { banner: { title: 'Foto', to: '/ofertas', visual: 'photo', image: PNG } });
  assert.equal(tiny.status, 400, 'una foto de 1 × 1 px no sirve');
  assert.match(tiny.json.error, /pequeña/);
  const fake = await admin.post('/admin/api/banners', { banner: { title: 'Foto', to: '/ofertas', visual: 'photo', image: `data:image/png;base64,${Buffer.from('no soy una foto de verdad').toString('base64')}` } });
  assert.equal(fake.status, 400, 'el contenido debe ser una foto de verdad');
  const stolen = await admin.post('/admin/api/banners', { banner: { title: 'Foto', to: '/ofertas', visual: 'photo', image: 'media:bn-club?v=abc' } });
  assert.equal(stolen.status, 400, 'no se puede usar la foto guardada de otro banner');
  const photo = pngDataUrl(400, 108);
  const photoM = pngDataUrl(200, 200);
  const r = await admin.post('/admin/api/banners', { banner: { title: '<b>Cyber</b> Piedra', text: 'Hasta 40% dcto.', to: '/ofertas', tone: 'pyrite', visual: 'photo', image: photo, imageM: photoM, photoOnly: true, extra: 'campo desconocido' } });
  assert.equal(r.status, 200, r.text);
  const id = r.json.result;
  let cat = (await anon.get('/api/catalog')).json;
  const heroes = () => cat.banners.filter((x) => (x.place || 'hero') === 'hero');
  assert.ok(heroes().length >= 5, 'los banners de ejemplo pasan a ser editables');
  assert.equal(cat.banners.some((x) => x.place === 'promo'), false, 'los de más abajo siguen siendo de ejemplo');
  const b = cat.banners.find((x) => x.id === id);
  assert.equal(b.title, '<b>Cyber</b> Piedra', 'se guarda como texto (la tienda lo escapa al mostrarlo)');
  assert.equal(b.extra, undefined, 'los campos desconocidos se descartan');
  assert.equal(b.order, heroes().length - 1, 'queda al final');
  assert.equal(b.photoOnly, true);
  // La foto va aparte: el catálogo solo lleva su referencia (así la tienda carga rápido)
  assert.match(b.image, /^media:bn-[A-Za-z0-9]+\?v=[a-z0-9]+$/);
  assert.match(b.imageM, /^media:bn-[A-Za-z0-9]+-m\?v=[a-z0-9]+$/);
  assert.ok(!JSON.stringify(cat).includes('data:image'), 'el catálogo no lleva fotos dentro');
  const [, key, v] = /^media:([^?]+)\?v=(.+)$/.exec(b.image);
  const img = await anon.req('GET', `/api/imagenes/${key}?v=${v}`, { raw: true });
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.match(img.headers.get('cache-control'), /immutable/);
  assert.equal(img.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await anon.req('GET', `/api/imagenes/${key}`, { raw: true })).headers.get('cache-control'), 'public, max-age=300');
  assert.equal((await admin.req('GET', `/admin/api/imagenes/${key}?v=${v}`, { raw: true })).status, 200, 'también desde la dirección del panel');
  assert.equal((await anon.req('GET', '/api/imagenes/no-existe', { raw: true })).status, 404);
  // Guardar sin cambiar la foto la mantiene; cambiarla le da otra versión
  const keep = await admin.post('/admin/api/banners', { banner: { ...b, title: 'Cyber Piedra' } });
  assert.equal(keep.status, 200, keep.text);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.banners.find((x) => x.id === id).image, b.image);
  await admin.post('/admin/api/banners', { banner: { ...b, image: pngDataUrl(320, 86), imageM: '' } });
  cat = (await anon.get('/api/catalog')).json;
  const b2 = cat.banners.find((x) => x.id === id);
  assert.notEqual(b2.image, b.image);
  assert.equal(b2.imageM, '', 'se puede quitar la foto para celular');
  const [, keyM, vM] = /^media:([^?]+)\?v=(.+)$/.exec(b.imageM);
  assert.equal((await anon.req('GET', `/api/imagenes/${keyM}?v=${vM}`, { raw: true })).status, 404, 'la foto quitada ya no existe');
  const up = await admin.post(`/admin/api/banners/${id}/move`, { dir: -1 });
  assert.equal(up.status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(heroes().findIndex((x) => x.id === id), heroes().length - 2);
  const pause = await admin.req('PATCH', `/admin/api/banners/${id}`, { body: { active: false } });
  assert.equal(pause.status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.banners.find((x) => x.id === id).active, false);
  const del = await admin.req('DELETE', `/admin/api/banners/${id}`);
  assert.equal(del.status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.banners.some((x) => x.id === id), false);
  const [, key2, v2] = /^media:([^?]+)\?v=(.+)$/.exec(b2.image);
  assert.equal((await anon.req('GET', `/api/imagenes/${key2}?v=${v2}`, { raw: true })).status, 404, 'al eliminar el banner se borra su foto');
  const gone = await admin.req('DELETE', `/admin/api/banners/${id}`);
  assert.equal(gone.status, 404);
  const heavy = await admin.post('/admin/api/banners', { banner: { title: 'x', to: '/', visual: 'photo', image: `data:image/png;base64,${'A'.repeat(1.5 * 1024 * 1024)}` } });
  assert.equal(heavy.status, 400, 'foto demasiado pesada');
  const big = await admin.post('/admin/api/banners', { banner: { title: 'x', visual: 'photo', image: `data:image/png;base64,${'A'.repeat(4.2 * 1024 * 1024)}` } });
  assert.equal(big.status, 413, 'cuerpo demasiado grande');
});

test('banners de más abajo: ejemplos, foto, lugar fijo, máximo y siempre queda uno', async () => {
  let cat = (await anon.get('/api/catalog')).json;
  const promos = () => cat.banners.filter((x) => x.place === 'promo');
  assert.equal(promos().length, 0);
  // Editar uno de ejemplo los guarda a todos como reales
  const r = await admin.post('/admin/api/banners', { banner: { id: 'abajo-receta', place: 'hero', title: 'Cotiza tu receta', to: '/cotizar-receta', visual: 'photo', image: pngDataUrl(300, 135), photoOnly: false, imageM: pngDataUrl(100, 100) } });
  assert.equal(r.status, 200, r.text);
  cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(promos().map((x) => x.id), ['abajo-bioeq', 'abajo-receta']);
  const p = promos()[1];
  assert.equal(p.place, 'promo', 'un banner de abajo no se puede mover al carrusel');
  assert.match(p.image, /^media:bn-abajo-receta\?v=/);
  assert.equal(p.imageM, '', 'los de abajo no llevan foto para celular');
  assert.equal(p.dynamic, '');
  // Uno nuevo de ilustración pasa a «solo color» (abajo no hay ilustraciones)
  const n = await admin.post('/admin/api/banners', { banner: { place: 'promo', title: 'Vacunatorio', to: '/ofertas', visual: 'art', art: 'sun' } });
  assert.equal(n.status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(promos().find((x) => x.id === n.json.result).visual, 'none');
  // Máximo de banners de abajo
  const made = [n.json.result];
  for (let i = 0; i < 10; i++) {
    const x = await admin.post('/admin/api/banners', { banner: { place: 'promo', title: `Abajo ${i}`, to: '/' } });
    if (x.status !== 200) { assert.equal(x.json.code, 'too_many'); break; }
    made.push(x.json.result);
  }
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(promos().length, 8, 'se guardan hasta 8');
  for (const id of made) assert.equal((await admin.req('DELETE', `/admin/api/banners/${id}`)).status, 200);
  assert.equal((await admin.req('DELETE', '/admin/api/banners/abajo-bioeq')).status, 200);
  const last = await admin.req('DELETE', '/admin/api/banners/abajo-receta');
  assert.equal(last.status, 400, 'siempre queda al menos uno (para no mostrarlo se pausa)');
  assert.equal(last.json.code, 'last_one');
  assert.equal((await admin.req('PATCH', '/admin/api/banners/abajo-receta', { body: { active: false } })).status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(promos().map((x) => [x.id, x.active]), [['abajo-receta', false]]);
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.ok(moves.some((m) => m.kind === 'banner' && m.note === 'Banner de abajo actualizado'));
});

test('menú «Categorías»: tarjetas creadas, validadas, ordenadas, pausadas y eliminadas', async () => {
  const noCsrf = await admin.post('/admin/api/menu', { card: { title: 'x', to: '/' } }, { headers: { 'x-csrf-token': '' } });
  assert.equal(noCsrf.status, 403);
  for (const to of ['//sitio-malicioso.example', 'javascript:alert(1)', 'https://otro.example']) {
    const r = await admin.post('/admin/api/menu', { card: { title: 'Hola', to } });
    assert.equal(r.status, 400, `no acepta ${to}`);
  }
  const noTitle = await admin.post('/admin/api/menu', { card: { title: '  ', to: '/' } });
  assert.equal(noTitle.status, 400);
  const r = await admin.post('/admin/api/menu', { card: { kicker: 'Verano', title: '<b>Protectores</b> -30%', text: 'Solo esta semana.', to: '/buscar?q=protector', tone: 'coral', icon: 'sun', extra: 'campo desconocido', dynamic: 'club' } });
  assert.equal(r.status, 200, r.text);
  const id = r.json.result;
  let cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(cat.menu.map((c) => c.id), ['club', 'bioeq', id], 'las tarjetas de ejemplo pasan a ser editables y la nueva queda al final');
  const c = cat.menu.find((x) => x.id === id);
  assert.equal(c.title, '<b>Protectores</b> -30%', 'se guarda como texto (la tienda lo escapa)');
  assert.equal(c.extra, undefined);
  assert.equal(c.dynamic, '', 'una tarjeta nueva no puede hacerse pasar por la del Club');
  assert.equal(c.tone, 'coral');
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.ok(moves.some((m) => m.kind === 'menu' && m.note === 'Tarjeta creada' && m.by === 'admin'));
  assert.equal((await admin.post(`/admin/api/menu/${id}/move`, { dir: -1 })).status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(cat.menu.map((x) => x.id), ['club', id, 'bioeq']);
  // Editar el texto de la tarjeta del Club la deja fija
  const club = cat.menu.find((x) => x.id === 'club');
  assert.equal(club.dynamic, 'club');
  assert.equal((await admin.post('/admin/api/menu', { card: { ...club, title: 'Socios: 2x1 en vitaminas' } })).status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.menu.find((x) => x.id === 'club').dynamic, '');
  assert.equal(cat.menu.find((x) => x.id === 'club').order, 0, 'editar no cambia el orden');
  assert.equal((await admin.req('PATCH', `/admin/api/menu/${id}`, { body: { active: false } })).status, 200);
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.menu.find((x) => x.id === id).active, false);
  const ghost = await admin.post('/admin/api/menu', { card: { id: 'NOEXISTE', title: 'x', to: '/' } });
  assert.equal(ghost.status, 404);
  // Máximo de tarjetas guardadas
  const made = [];
  for (let i = 0; i < 20; i++) {
    const x = await admin.post('/admin/api/menu', { card: { title: `Tarjeta ${i}`, to: '/' } });
    if (x.status !== 200) { assert.equal(x.status, 400); assert.equal(x.json.code, 'too_many'); break; }
    made.push(x.json.result);
  }
  cat = (await anon.get('/api/catalog')).json;
  assert.equal(cat.menu.length, 12, 'se guardan hasta 12');
  for (const m of [...made, id]) assert.equal((await admin.req('DELETE', `/admin/api/menu/${m}`)).status, 200);
  assert.equal((await admin.req('DELETE', `/admin/api/menu/${id}`)).status, 404);
  cat = (await anon.get('/api/catalog')).json;
  assert.deepEqual(cat.menu.map((x) => x.id), ['club', 'bioeq']);
  // Imagen de fondo (opcional)
  const withImg = await admin.post('/admin/api/menu', { card: { title: 'Con foto', to: '/ofertas', image: pngDataUrl(300, 150) } });
  assert.equal(withImg.status, 200, withImg.text);
  cat = (await anon.get('/api/catalog')).json;
  const ci = cat.menu.find((x) => x.id === withImg.json.result);
  assert.match(ci.image, /^media:mc-[A-Za-z0-9]+\?v=/);
  const [, mkey, mv] = /^media:([^?]+)\?v=(.+)$/.exec(ci.image);
  assert.equal((await anon.req('GET', `/api/imagenes/${mkey}?v=${mv}`, { raw: true })).status, 200);
  assert.equal((await admin.post('/admin/api/menu', { card: { title: 'x', to: '/', image: 'data:image/svg+xml;base64,PHN2Zz4=' } })).status, 400);
  assert.equal((await admin.req('DELETE', `/admin/api/menu/${withImg.json.result}`)).status, 200);
  assert.equal((await anon.req('GET', `/api/imagenes/${mkey}?v=${mv}`, { raw: true })).status, 404, 'al eliminar la tarjeta se borra su imagen');
  const big = await admin.post('/admin/api/menu', { card: { title: 'x', to: '/', text: 'A'.repeat(2.2 * 1024 * 1024) } });
  assert.equal(big.status, 413, 'cuerpo demasiado grande');
});

test('Servicios Piedra: ejemplo, guardar, validar y lo que ve la tienda', async () => {
  assert.equal((await anon.get('/api/catalog')).json.services, null, 'sin guardar se usan los de ejemplo');
  const noCsrf = await admin.req('PUT', '/admin/api/servicios', { body: { section: { title: 'x', items: [] } }, headers: { 'x-csrf-token': '' } });
  assert.equal(noCsrf.status, 403);
  for (const items of [[{ title: '', to: '/' }], [{ title: 'Hola', to: 'https://otro.example' }], [{ title: 'Hola', to: '//otro.example' }], Array.from({ length: 13 }, (_, i) => ({ title: `S${i}`, to: '/' }))]) {
    const r = await admin.req('PUT', '/admin/api/servicios', { body: { section: { title: 'Servicios', items } } });
    assert.equal(r.status, 400, JSON.stringify(items).slice(0, 60));
  }
  const ok = await admin.req('PUT', '/admin/api/servicios', { body: { section: { title: '  Nuestros servicios  ', items: [
    { id: 's1', icon: 'moon', title: 'Farmacia de turno', text: 'Abierta hoy hasta las 23:00.', to: '/farmacias?turno=1', active: true },
    { icon: '__proto__', title: '<b>Vacunatorio</b>', text: '', to: '/buscar?q=vacuna', active: false, hack: 1 },
  ] } } });
  assert.equal(ok.status, 200, ok.text);
  const s = (await anon.get('/api/catalog')).json.services;
  assert.equal(s.title, 'Nuestros servicios');
  assert.equal(s.items.length, 2);
  assert.deepEqual(s.items[0], { id: 's1', icon: 'moon', title: 'Farmacia de turno', text: 'Abierta hoy hasta las 23:00.', to: '/farmacias?turno=1', active: true });
  assert.equal(s.items[1].icon, 'star', 'un ícono desconocido queda como estrella');
  assert.equal(s.items[1].title, '<b>Vacunatorio</b>', 'se guarda como texto (la tienda lo escapa)');
  assert.equal(s.items[1].hack, undefined);
  assert.equal(s.items[1].active, false);
  assert.match(s.items[1].id, /^[A-Za-z0-9_-]+$/);
  const moves = (await admin.get('/admin/api/data')).json.movements;
  assert.ok(moves.some((m) => m.kind === 'servicios' && /1 de 2/.test(m.note)));
});

test('movimientos: filtro por fechas, farmacia, tipo y texto en todo el historial', async () => {
  const day = (d) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const now = Date.now();
  // Movimientos antiguos escritos directo en la base (fuera de los 400 más recientes)
  const old = now - 40 * 86400000;
  S.repo.addMovement({ at: old, pid: '420101', name: 'Producto antiguo', kind: 'ingreso', loc: 's:ANTIGUA', delta: 7, after: 7, note: 'Ingreso viejo', ref: 'REF-VIEJA', by: 'admin' });
  S.repo.addMovement({ at: old + 1000, pid: '420101', name: 'Producto antiguo', kind: 'venta', loc: 's:ANTIGUA', delta: -2, after: 5, note: 'Venta vieja', ref: 'PD00000001', by: 'admin' });
  S.repo.addMovement({ at: old + 2000, pid: '420102', name: 'Otro producto', kind: 'ingreso', loc: 's:OTRA', delta: 3, after: 3, note: '', ref: '', by: 'admin' });
  const d = day(new Date(old));
  let r = await admin.get(`/admin/api/movimientos?desde=${d}&hasta=${d}`);
  assert.equal(r.status, 200);
  assert.equal(r.json.total, 3);
  assert.deepEqual(r.json.movements.map((m) => m.note), ['', 'Venta vieja', 'Ingreso viejo'], 'del más nuevo al más antiguo');
  r = await admin.get(`/admin/api/movimientos?desde=${d}&hasta=${d}&local=s:ANTIGUA`);
  assert.equal(r.json.total, 2);
  assert.equal(r.json.unitsIn, 7);
  assert.equal(r.json.unitsOut, 2);
  r = await admin.get(`/admin/api/movimientos?local=s:ANTIGUA&tipo=venta`);
  assert.equal(r.json.total, 1);
  r = await admin.get(`/admin/api/movimientos?desde=${d}&q=ref-vieja`);
  assert.equal(r.json.total, 1, 'busca también por referencia, sin importar mayúsculas');
  const next = day(new Date(old + 86400000 * 2));
  r = await admin.get(`/admin/api/movimientos?desde=${next}&hasta=${next}&local=s:ANTIGUA`);
  assert.equal(r.json.total, 0);
  r = await admin.get('/admin/api/movimientos?desde=ayer&local=<script>');
  assert.equal(r.status, 200, 'los filtros inválidos se ignoran');
  assert.deepEqual(r.json.filters, { from: '', until: '', loc: '', kind: '', q: '' });
});

test('cuerpos inválidos y demasiado grandes', async () => {
  const notJson = await anon.req('POST', '/api/orders', { body: 'hola', raw: true, headers: { 'content-type': 'text/plain' } });
  assert.equal(notJson.status, 415);
  const broken = await anon.req('POST', '/api/orders', { body: '{"items": [', raw: true, headers: { 'content-type': 'application/json' } });
  assert.equal(broken.status, 400);
  const arr = await anon.req('POST', '/api/orders', { body: '[1,2]', raw: true, headers: { 'content-type': 'application/json' } });
  assert.equal(arr.status, 400);
  const huge = await anon.req('POST', '/admin/api/login', { body: JSON.stringify({ user: 'admin', password: 'x'.repeat(20000) }), raw: true, headers: { 'content-type': 'application/json' } });
  assert.equal(huge.status, 413);
});

test('ingreso: errores genéricos, bloqueo por intentos y cierre de sesión', async () => {
  S.repo.createAdmin('bodega', await hashPassword(PASS));
  const u = client(S.base);
  const noUser = await u.login('no-existe', PASS);
  const badPass = await u.login('bodega', 'mala-contraseña-1');
  assert.equal(noUser.status, 401);
  assert.equal(badPass.status, 401);
  assert.equal(noUser.json.error, badPass.json.error, 'no revela si el usuario existe');
  for (let i = 0; i < 3; i++) await u.login('bodega', `mala-contraseña-${i}`);
  assert.equal((await u.login('bodega', 'mala-contraseña-x')).status, 401, 'el 5.º intento fallido todavía responde normal');
  const locked = await u.login('bodega', PASS);
  assert.equal(locked.status, 429, 'tras varios intentos fallidos se bloquea, aunque la contraseña sea correcta');
  assert.ok(Number(locked.headers.get('retry-after')) > 0);

  const other = client(S.base);
  assert.equal((await other.login('admin', PASS)).status, 200, 'el bloqueo es solo para ese usuario');
  const out = await other.post('/admin/api/logout', {});
  assert.equal(out.status, 200);
  assert.match(out.setCookie, /Max-Age=0/);
  const after = await other.get('/admin/api/data');
  assert.equal(after.status, 401);
});

test('sesión: vence por inactividad y la revisión automática no la extiende', async () => {
  const c = client(S.base);
  await c.login();
  const token = decodeURIComponent(c.cookie.split('=')[1]);
  const { createHash } = await import('node:crypto');
  const hash = createHash('sha256').update(token).digest('hex');
  const old = Date.now() - 30 * 60000;
  S.repo.touchSession(hash, old);
  await c.get('/admin/api/data', { headers: { 'x-panel-activity': '0' } });
  assert.equal(S.repo.session(hash).last_seen, old, 'la revisión automática no cuenta como uso');
  await c.get('/admin/api/data', { headers: { 'x-panel-activity': '1' } });
  assert.ok(S.repo.session(hash).last_seen > old, 'el uso real sí la mantiene abierta');
  S.repo.touchSession(hash, Date.now() - 3 * 3600000);
  const expired = await c.get('/admin/api/data');
  assert.equal(expired.status, 401);
  assert.equal(S.repo.session(hash), null, 'la sesión vencida se borra');
});

test('cambio de contraseña: cierra las demás sesiones', async () => {
  const a = client(S.base);
  const b = client(S.base);
  await a.login();
  await b.login();
  const wrong = await a.post('/admin/api/password', { current: 'no-es-esta-123', next: 'Nueva-Clave-2027' });
  assert.equal(wrong.status, 400);
  const weak = await a.post('/admin/api/password', { current: PASS, next: 'corta' });
  assert.equal(weak.status, 400);
  const ok = await a.post('/admin/api/password', { current: PASS, next: 'Nueva-Clave-2027' });
  assert.equal(ok.status, 200);
  a.csrf = ok.json.csrf;
  assert.equal((await a.get('/admin/api/data')).status, 200, 'quien la cambió sigue dentro');
  assert.equal((await b.get('/admin/api/data')).status, 401, 'las otras sesiones se cierran');
  assert.equal((await client(S.base).login('admin', PASS)).status, 401);
  assert.equal((await client(S.base).login('admin', 'Nueva-Clave-2027')).status, 200);
  // Para las pruebas siguientes
  await a.post('/admin/api/password', { current: 'Nueva-Clave-2027', next: PASS });
  admin = client(S.base);
  await admin.login();
});

test('ingreso: muchos intentos al mismo tiempo no se saltan el límite', async () => {
  S.repo.createAdmin('paralelo', await hashPassword(PASS));
  const c = client(S.base);
  const tries = Array.from({ length: 30 }, (_, i) => c.post('/admin/api/login', { user: 'paralelo', password: i === 29 ? PASS : `mala-${i}-contraseña` }));
  const res = await Promise.all(tries);
  const checked = res.filter((r) => r.status === 401 || r.status === 200).length;
  assert.ok(checked <= 5, `se revisaron ${checked} contraseñas (máximo 5)`);
  assert.ok(res.filter((r) => r.status === 429).length >= 25, 'el resto queda bloqueado');
  assert.equal(res[29].status === 200 && checked > 5, false);
  const after = await c.post('/admin/api/login', { user: 'paralelo', password: PASS });
  assert.equal(after.status, 429, 'después del bloqueo, ni la contraseña correcta entra');
});

test('pedido: límites de tamaño, medio de pago y archivos falsos', async () => {
  const many = Array.from({ length: 26 }, (_, i) => ({ id: String(420101 + i), qty: 1 }));
  assert.equal((await anon.post('/api/orders', order({ items: many }))).status, 400);
  const units = ['420101', '420102', '420103', '420104', '420105', '420106', '420107'].map((id) => ({ id, qty: 9 }));
  const big = await anon.post('/api/orders', order({ items: units }));
  assert.equal(big.status, 400, 'más de 60 unidades en total');
  for (const method of ['toString', 'constructor', '__proto__', 'hasOwnProperty']) {
    const r = await anon.post('/api/orders', order({ payment: { method } }));
    assert.equal(r.status, 400, `medio de pago "${method}"`);
  }
  const fake = 'data:image/png;base64,' + Buffer.from('<html><script>alert(1)</script></html>').toString('base64');
  const r = await anon.post('/api/orders', order({ items: [{ id: '420108', qty: 1 }], rxDeclare: true, prescriptions: [{ productId: '420108', fileName: 'receta.png', file: fake }] }));
  assert.equal(r.status, 400, 'un archivo que no es imagen se rechaza aunque diga image/png');
  const pdf = 'data:application/pdf;base64,' + Buffer.from('%PDF-1.4\n%prueba\n').toString('base64');
  const ok = await anon.post('/api/orders', order({ items: [{ id: '420108', qty: 1 }], rxDeclare: true, prescriptions: [{ productId: '420108', fileName: 'receta.pdf', file: pdf }] }));
  assert.equal(ok.status, 201, ok.text);
});

test('seguimiento: RUT y celular se muestran a medias', async () => {
  const created = await anon.post('/api/orders', order());
  assert.equal(created.status, 201);
  assert.equal(created.json.order.customer.rut, '11.111.111-1', 'quien compra recibe sus datos completos');
  const r = await anon.get(`/api/orders/${created.json.order.id}?email=ana@example.com`);
  assert.equal(r.json.order.customer.rut, '••.•••.111-1');
  assert.equal(r.json.order.customer.phone, '+56 9 •••• 5678');
  assert.equal(r.json.order.customer.email, 'ana@example.com');
});

test('archivos: /assets no deja leer el panel', async () => {
  for (const p of ['/assets/..%2fadmin%2fpanel.js', '/assets/%2e%2e%2fadmin%2findex.html', '/assets/..%5cadmin%5cpanel.js', '/robots.txt%2f..%2fadmin%2fpanel.js']) {
    const r = await anon.get(p);
    assert.equal(r.status, 404, p);
  }
  assert.equal((await anon.get('/assets/tienda.css')).status, 200);
});

// ── Cifrado de datos y verificación en dos pasos ────────────
test('cifrado: llaves, ida y vuelta, y un dato no sirve en otro lugar', () => {
  const key = randomBytes(32);
  assert.deepEqual(parseKey(key.toString('hex')), key);
  assert.deepEqual(parseKey(key.toString('base64')), key);
  assert.equal(parseKey('corta'), null);
  const c = makeCipher(key);
  const box = c.encText('Ana Pérez · 11.111.111-1', 'pedido:PD1');
  assert.match(box, /^enc1:/);
  assert.ok(!box.includes('Ana'));
  assert.equal(c.decText(box, 'pedido:PD1'), 'Ana Pérez · 11.111.111-1');
  assert.notEqual(c.encText('x', 'a'), c.encText('x', 'a'), 'cada cifrado es distinto (vector aleatorio)');
  assert.throws(() => c.decText(box, 'pedido:PD2'), 'copiado a otro pedido no se puede abrir');
  const tampered = box.slice(0, -4) + (box.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  assert.throws(() => c.decText(tampered, 'pedido:PD1'), 'si alguien lo modifica, se detecta');
  assert.throws(() => makeCipher(randomBytes(32)).decText(box, 'pedido:PD1'), 'con otra llave no se puede leer');
  const file = Buffer.from('%PDF-1.4 receta');
  const fb = c.encBuf(file, 'receta:x');
  assert.ok(c.isBuf(fb) && !fb.includes(Buffer.from('receta')));
  assert.deepEqual(c.decBuf(fb, 'receta:x'), file);
  assert.equal(c.decText('texto de antes', 'x'), 'texto de antes', 'los datos sin cifrar de antes se siguen leyendo');
});

test('verificación en dos pasos: códigos TOTP según el estándar (RFC 6238)', () => {
  const secret = Buffer.from('12345678901234567890');
  assert.equal(hotp(secret, 0), '755224', 'RFC 4226');
  assert.equal(hotp(secret, 9), '520489');
  assert.equal(totp(secret, 59 * 1000), '287082', 'RFC 6238, T=59');
  assert.equal(totp(secret, 1111111109 * 1000), '081804');
  assert.deepEqual(base32Decode(base32Encode(secret)), secret);
  const b32 = base32Encode(secret);
  const now = 1_800_000_000_000;
  const code = totp(b32, now);
  assert.equal(verifyTotp(b32, code, { now }), counterAt(now));
  assert.equal(verifyTotp(b32, totp(b32, now - 30000), { now }), counterAt(now) - 1, 'acepta el código anterior (reloj corrido)');
  assert.equal(verifyTotp(b32, totp(b32, now - 90000), { now }), -1, 'un código viejo no sirve');
  assert.equal(verifyTotp(b32, code, { now, last: counterAt(now) }), -1, 'un código ya usado no sirve de nuevo');
  assert.equal(verifyTotp(b32, '12345', { now }), -1);
  assert.equal(verifyTotp(b32, 'abcdef', { now }), -1);
});

test('direcciones locales: este equipo y la red de la casa u oficina', () => {
  for (const ip of ['127.0.0.1', '::1', '::ffff:192.168.1.5', '10.0.0.8', '172.16.4.2', 'fd00::1']) assert.equal(isLocalIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '203.0.113.7', '172.32.0.1', '2001:db8::1', '']) assert.equal(isLocalIp(ip), false, ip);
});

test('base de datos: los datos de clientes y las recetas se guardan cifrados', async () => {
  const pdf = 'data:application/pdf;base64,' + Buffer.from('%PDF-1.4\n%receta de Ana\n').toString('base64');
  const r = await anon.post('/api/orders', order({ customer: { ...customer, nombre: 'Clotilde', email: 'clotilde@example.com' }, items: [{ id: '420108', qty: 1 }], rxDeclare: true, prescriptions: [{ productId: '420108', fileName: 'receta-clotilde.pdf', file: pdf }] }));
  assert.equal(r.status, 201, r.text);
  const id = r.json.order.id;
  const row = S.db.prepare('SELECT email, data FROM orders WHERE id = ?').get(id);
  assert.match(row.data, /^enc1:/);
  for (const secret of ['Clotilde', 'clotilde@example.com', '11.111.111-1', 'Siempre Viva', '+56', '912345678']) assert.ok(!row.data.includes(secret) && !row.email.includes(secret), `"${secret}" no queda a la vista`);
  const rx = S.db.prepare('SELECT file_name, data FROM prescriptions WHERE order_id = ?').get(id);
  assert.ok(Buffer.from(rx.data).subarray(0, 5).toString() === 'PENC1' && !Buffer.from(rx.data).includes(Buffer.from('receta de Ana')));
  assert.match(rx.file_name, /^enc1:/);
  // El panel y el cliente los siguen viendo normalmente
  const o = (await admin.get('/admin/api/data')).json.orders.find((x) => x.id === id);
  assert.equal(o.customer.nombre, 'Clotilde');
  assert.equal(o.files[0].fileName, 'receta-clotilde.pdf');
  const f = await admin.get(`/admin/api/orders/${id}/recetas/${o.files[0].id}`);
  assert.equal(f.status, 200);
  assert.match(f.text, /receta de Ana/);
  assert.equal((await anon.get(`/api/orders/${id}?email=clotilde@example.com`)).status, 200, 'el seguimiento con el correo sigue funcionando');
  // Pedidos guardados antes del cifrado: se cifran al iniciar
  S.db.prepare('INSERT INTO orders (id, email, data, created_at, cancelled) VALUES (?, ?, ?, ?, 0)').run('PD99999999', 'viejo@example.com', JSON.stringify({ id: 'PD99999999', customer: { email: 'viejo@example.com', nombre: 'Viejo' }, items: [], createdAt: 1 }), 1);
  // Una receta de antes cuyo nombre (lo escribe el cliente) "parece" cifrado igual se cifra
  S.db.prepare('INSERT INTO prescriptions (order_id, product_id, file_name, mime, data, created_at) VALUES (?, ?, ?, ?, ?, 1)').run('PD99999999', '420108', 'enc1:truco.pdf', 'application/pdf', Buffer.from('%PDF-1.4 vieja'));
  const moved = S.repo.encryptExisting();
  assert.ok(moved.orders >= 1 && moved.files === 1, JSON.stringify(moved));
  const old = S.db.prepare('SELECT email, data FROM orders WHERE id = ?').get('PD99999999');
  assert.ok(old.data.startsWith('enc1:') && !old.email.includes('@'));
  assert.equal(S.repo.getOrder('PD99999999').customer.nombre, 'Viejo');
  assert.equal(S.repo.prescriptions('PD99999999')[0].fileName, 'enc1:truco.pdf');
  assert.match(Buffer.from(S.db.prepare("SELECT data FROM prescriptions WHERE order_id = 'PD99999999'").get().data).subarray(0, 5).toString(), /PENC1/);
  assert.deepEqual(S.repo.encryptExisting(), { orders: 0, files: 0 }, 'se hace una sola vez');
  // Desde ahora, un dato sin cifrar puesto a mano en la base se rechaza, sin botar el panel
  S.db.prepare('UPDATE orders SET data = ? WHERE id = ?').run(JSON.stringify({ id: 'PD99999999', customer: { nombre: 'Falso' }, items: [] }), 'PD99999999');
  assert.equal(S.repo.getOrder('PD99999999'), null);
  assert.equal((await admin.get('/admin/api/data')).status, 200);
  S.db.prepare("DELETE FROM prescriptions WHERE order_id = 'PD99999999'").run();
  assert.equal(S.repo.hasEncrypted(), true);
  assert.equal(S.repo.keyMatches(), true);
  assert.equal(createRepo(S.db, { cipher: makeCipher(randomBytes(32)) }).keyMatches(), false, 'otra llave no corresponde');
  S.db.prepare('DELETE FROM orders WHERE id = ?').run('PD99999999');
});

test('el código del panel solo se entrega con la sesión iniciada', async () => {
  const none = await anon.get('/admin/panel.js');
  assert.equal(none.status, 404);
  const fake = await anon.get('/admin/panel.js', { headers: { cookie: 'piedra_panel=inventada' } });
  assert.equal(fake.status, 404);
  const ok = await admin.get('/admin/panel.js');
  assert.equal(ok.status, 200);
  assert.match(ok.headers.get('content-type'), /javascript/);
  assert.match(ok.headers.get('cache-control'), /no-store/);
  assert.ok(ok.text.includes('Productos y stock'));
  for (const p of ['/admin/../privado/panel.js', '/admin/%2e%2e/%2e%2e/privado/panel.js', '/privado/panel.js', '/server/privado/panel.js']) {
    assert.equal((await anon.get(p)).status, 404, `${p} no debe entregarse`);
  }
});

let tfaSecret = '';
test('verificación en dos pasos: activar, ingresar con código o código de respaldo, y desactivar', async () => {
  S.repo.createAdmin('seguro', await hashPassword(PASS));
  const a = client(S.base);
  assert.equal((await a.login('seguro')).status, 200);
  const other = client(S.base);
  assert.equal((await other.login('seguro')).status, 200);
  // Activar
  assert.equal((await anon.post('/admin/api/2fa/start', {})).status, 401);
  assert.equal((await a.post('/admin/api/2fa/start', {}, { headers: { 'x-csrf-token': '' } })).status, 403);
  const st = await a.post('/admin/api/2fa/start', {});
  assert.equal(st.status, 200);
  assert.match(st.json.secret, /^[A-Z2-7]{32}$/);
  assert.match(st.json.uri, /^otpauth:\/\/totp\/Farmacias%20Piedra%3Aseguro\?secret=[A-Z2-7]{32}&issuer=Farmacias%20Piedra/);
  tfaSecret = st.json.secret;
  const badPw = await a.post('/admin/api/2fa/enable', { password: 'otra-clave-123', code: totp(tfaSecret) });
  assert.equal(badPw.status, 400);
  assert.equal(badPw.json.code, 'bad_credentials');
  const badCode = await a.post('/admin/api/2fa/enable', { password: PASS, code: '000000' === totp(tfaSecret) ? '111111' : '000000' });
  assert.equal(badCode.json.code, 'bad_code');
  const en = await a.post('/admin/api/2fa/enable', { password: PASS, code: totp(tfaSecret) });
  assert.equal(en.status, 200, en.text);
  assert.equal(en.json.recovery.length, 10);
  assert.match(en.json.recovery[0], /^[a-z2-9]{4}-[a-z2-9]{4}$/);
  assert.equal(en.json.closedSessions, 1, 'se cierran las otras sesiones');
  assert.equal((await other.get('/admin/api/data')).status, 401);
  const raw = S.db.prepare("SELECT totp_secret, recovery FROM admins WHERE username = 'seguro'").get();
  assert.ok(raw.totp_secret.startsWith('enc1:') && !raw.totp_secret.includes(tfaSecret), 'la clave se guarda cifrada');
  assert.ok(!raw.recovery.includes(en.json.recovery[0]), 'de los códigos de respaldo solo se guarda un resumen');
  const sec = await a.get('/admin/api/security');
  assert.equal(sec.json.twoFactor, true);
  assert.equal(sec.json.recoveryLeft, 10);
  assert.ok(sec.json.log.some((l) => l.event === '2fa_on' && l.user === 'seguro'));
  // Ingresar: la contraseña sola ya no basta
  const c = client(S.base);
  const step1 = await c.login('seguro');
  assert.equal(step1.status, 200);
  assert.equal(step1.json.needCode, true);
  assert.ok(step1.json.ticket && !step1.json.csrf && !step1.setCookie, 'sin código no hay sesión');
  assert.equal((await c.get('/admin/api/data')).status, 401);
  assert.equal((await c.get('/admin/panel.js')).status, 404);
  const wrong = await c.post('/admin/api/login/2fa', { ticket: step1.json.ticket, code: '12345' });
  assert.equal(wrong.json.code, 'bad_code');
  assert.equal((await c.post('/admin/api/login/2fa', { ticket: 'inventado', code: totp(tfaSecret) })).json.code, 'ticket');
  // El código de la activación ya se usó: hay que esperar el siguiente (o usar uno de respaldo)
  const used = await c.post('/admin/api/login/2fa', { ticket: step1.json.ticket, code: totp(tfaSecret) });
  assert.equal(used.json.code, 'bad_code', 'un código ya usado no sirve de nuevo');
  const rc = en.json.recovery[0];
  const viaRc = await c.post('/admin/api/login/2fa', { ticket: step1.json.ticket, code: rc.toUpperCase() });
  assert.equal(viaRc.status, 200, viaRc.text);
  assert.equal(viaRc.json.recoveryLeft, 9);
  assert.match(viaRc.setCookie, /HttpOnly/);
  c.csrf = viaRc.json.csrf;
  assert.equal((await c.get('/admin/api/data')).status, 200);
  assert.equal((await c.post('/admin/api/login/2fa', { ticket: step1.json.ticket, code: en.json.recovery[1] })).json.code, 'ticket', 'el ticket sirve una sola vez');
  const again = client(S.base);
  const t2 = (await again.login('seguro')).json.ticket;
  assert.equal((await again.post('/admin/api/login/2fa', { ticket: t2, code: rc })).json.code, 'bad_code', 'un código de respaldo sirve una sola vez');
  // Fuerza bruta del código: se bloquea
  const statuses = [];
  for (let i = 0; i < 6; i++) {
    const t = await again.login('seguro');
    if (t.status !== 200) { statuses.push(t.status); continue; }
    statuses.push((await again.post('/admin/api/login/2fa', { ticket: t.json.ticket, code: String(100000 + i) })).status);
  }
  assert.ok(statuses.slice(0, 3).every((x) => x === 400) && statuses.at(-1) === 429, `tras varios códigos incorrectos se bloquea (${statuses})`);
  const locked = await again.login('seguro');
  assert.ok(locked.json.needCode && locked.json.totpLocked > 0, 'avisa que el código del celular está bloqueado');
  const blockedTry = await again.post('/admin/api/login/2fa', { ticket: locked.json.ticket, code: totp(tfaSecret, 1) });
  assert.equal(blockedTry.status, 429, 'mientras dura el bloqueo, ni el código correcto del celular sirve');
  assert.equal(blockedTry.json.totpLocked, true);
  // …pero el dueño no queda afuera: con un código de respaldo entra igual
  const owner = client(S.base);
  const ot = (await owner.login('seguro')).json.ticket;
  const viaBackup = await owner.post('/admin/api/login/2fa', { ticket: ot, code: en.json.recovery[1] });
  assert.equal(viaBackup.status, 200, viaBackup.text);
  assert.ok(viaBackup.json.alerts?.failedCodes >= 5, 'y se le avisa que alguien falló el código varias veces');
  // Desactivar: pide contraseña y código
  const noCode = await c.post('/admin/api/2fa/disable', { password: PASS, code: '000001' });
  assert.ok(noCode.status === 400 || noCode.status === 429);
  const log = (await c.get('/admin/api/security')).json.log;
  assert.ok(log.some((l) => l.event === 'login_recovery') && log.some((l) => l.event === '2fa_fail'));
});

test('verificación en dos pasos: códigos de respaldo nuevos y desactivar', async () => {
  S.repo.createAdmin('seguro3', await hashPassword(PASS));
  const a = client(S.base);
  await a.login('seguro3');
  const st = await a.post('/admin/api/2fa/start', {});
  const en = await a.post('/admin/api/2fa/enable', { password: PASS, code: totp(st.json.secret) });
  assert.equal(en.status, 200);
  assert.equal((await a.post('/admin/api/2fa/start', {})).status, 409, 'no se puede activar dos veces');
  const fresh = await a.post('/admin/api/2fa/recovery', { password: PASS, code: en.json.recovery[0] });
  assert.equal(fresh.status, 200, fresh.text);
  assert.equal(fresh.json.recovery.length, 10);
  const oldCode = await a.post('/admin/api/2fa/disable', { password: PASS, code: en.json.recovery[1] });
  assert.equal(oldCode.json.code, 'bad_code', 'los códigos anteriores dejan de servir');
  const noPw = await a.post('/admin/api/2fa/disable', { password: 'otra-clave-123', code: fresh.json.recovery[0] });
  assert.equal(noPw.json.code, 'bad_credentials', 'desactivar pide la contraseña');
  const off = await a.post('/admin/api/2fa/disable', { password: PASS, code: fresh.json.recovery[0] });
  assert.equal(off.status, 200, off.text);
  const direct = await client(S.base).login('seguro3');
  assert.equal(direct.status, 200);
  assert.ok(direct.json.csrf && !direct.json.needCode, 'sin la verificación, basta la contraseña');
  assert.equal(S.db.prepare("SELECT totp_secret FROM admins WHERE username = 'seguro3'").get().totp_secret, null, 'la clave se borra');
});

test('sesiones: cerrar las demás y registro de ingresos fallidos', async () => {
  const a = client(S.base);
  const b = client(S.base);
  await a.login();
  await b.login();
  const bad = await client(S.base).login('admin', 'clave-equivocada-1');
  assert.equal(bad.status, 401);
  const sec = await a.get('/admin/api/security');
  assert.ok(sec.json.sessions.length >= 2 && sec.json.sessions.filter((x) => x.current).length === 1);
  assert.ok(sec.json.log.some((l) => l.event === 'login_fail' && l.user === 'admin' && l.ip));
  const r = await a.post('/admin/api/sessions/close-others', {});
  assert.equal(r.status, 200);
  assert.ok(r.json.closed >= 1);
  assert.equal((await b.get('/admin/api/data')).status, 401);
  assert.equal((await a.get('/admin/api/data')).status, 200);
  admin = client(S.base);
  await admin.login();
});

test('registro del servidor: el usuario no puede inventar líneas', async () => {
  const lines = [];
  // Un servidor aparte que guarda lo que escribe en el registro
  await S.close();
  const db = openDb(':memory:');
  const app = createApp({ config: { ...BASE_CONFIG, rateLimits: { loginIp: 1000 } }, repo: createRepo(db), log: { info: (m) => lines.push(m), warn: (m) => lines.push(m) } });
  await app.ensureFirstAdmin();
  const server = createServer((req, res) => { app.handle(req, res); });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const c = client(`http://127.0.0.1:${server.address().port}`);
  await c.post('/admin/api/login', { user: 'x\n[panel] «admin» ingresó desde 1.2.3.4', password: 'mala-contraseña-1' });
  server.closeAllConnections?.();
  await new Promise((r) => server.close(r));
  app.close();
  db.close();
  assert.ok(lines.length >= 1 && lines.every((l) => !l.includes('\n')), JSON.stringify(lines));
  S = await startApp();
});

test('IPv6: los límites agrupan cada red /64', () => {
  assert.equal(rateKey('2001:db8:1:2:aaaa::1'), '2001:db8:1:2::/64');
  assert.equal(rateKey('2001:db8:1:2:ffff:ffff:ffff:ffff'), '2001:db8:1:2::/64');
  assert.equal(rateKey('2001:db8::1'), '2001:db8:0:0::/64');
  assert.equal(rateKey('::ffff:203.0.113.5'), '203.0.113.5');
  assert.equal(rateKey('198.51.100.7'), '198.51.100.7');
  assert.equal(rateKey('fe80::1%eth0'), 'fe80:0:0:0::/64');
});

// ── Configuraciones especiales ───────────────────────────────
test('límites por IP: pedidos e ingresos fallidos', async () => {
  await S.close();
  S = await startApp();
  const c = client(S.base);
  let last;
  let n = 0;
  for (; n < 30; n++) {
    last = await c.post('/api/orders', { items: [] });
    if (last.status === 429) break;
  }
  assert.equal(last.status, 429);
  assert.equal(n, 10, 'se permiten 10 intentos de pedido cada 10 minutos por IP');
  assert.ok(Number(last.headers.get('retry-after')) > 0);
  S.repo.createAdmin('caja', await hashPassword(PASS));
  for (let i = 0; i < 10; i++) await c.post('/admin/api/login', { user: `usuario${i}`, password: 'mala-contraseña-1' });
  const blocked = await c.post('/admin/api/login', { user: 'caja', password: PASS });
  assert.equal(blocked.status, 429, 'muchos intentos fallidos desde una IP la bloquean');
});

test('IP detrás de un proxy: se usa la que agrega el proxy, no la que manda el visitante', async () => {
  const { clientIp, isSecure } = await import('../lib/http.mjs');
  const req = (xff, proto) => ({ headers: { 'x-forwarded-for': xff, 'x-forwarded-proto': proto }, socket: { remoteAddress: '10.0.0.1' } });
  assert.equal(clientIp(req('1.1.1.1, 203.0.113.9'), 1), '203.0.113.9');
  assert.equal(clientIp(req('1.1.1.1, 203.0.113.9, 10.0.0.5'), 2), '203.0.113.9');
  assert.equal(clientIp(req('1.1.1.1'), 0), '10.0.0.1', 'sin proxy de confianza se ignora la cabecera');
  assert.equal(clientIp(req(''), 1), '10.0.0.1');
  assert.equal(isSecure(req('', 'http, https'), 1), true);
  assert.equal(isSecure(req('', 'https'), 0), false);
});

test('ADMIN_IPS: el panel no existe para otras direcciones', async () => {
  await S.close();
  S = await startApp({ adminIps: ['10.9.9.9'] });
  const c = client(S.base);
  assert.equal((await c.get('/admin/')).status, 404);
  assert.equal((await c.get('/admin/api/session')).status, 404);
  assert.equal((await c.get('/')).status, 200, 'la tienda sigue abierta');
});

test('FORCE_HTTPS y proxy de confianza: cookie segura y HSTS', async () => {
  await S.close();
  S = await startApp({ forceHttps: true, trustProxy: true, adminUser: 'dueno', adminPassword: PASS });
  assert.equal(S.first.ready, true, 'ADMIN_USER/ADMIN_PASSWORD crean el primer administrador');
  const c = client(S.base);
  const http = await c.get('/');
  assert.equal(http.status, 308);
  assert.match(http.headers.get('location'), /^https:\/\//);
  const https = { 'x-forwarded-proto': 'https', 'x-forwarded-for': '203.0.113.7' };
  const home = await c.get('/', { headers: https });
  assert.equal(home.status, 200);
  assert.match(home.headers.get('strict-transport-security'), /max-age=31536000/);
  const login = await c.post('/admin/api/login', { user: 'dueno', password: PASS }, { headers: https });
  assert.equal(login.status, 200);
  assert.match(login.setCookie, /^__Host-piedra_panel=/);
  assert.match(login.setCookie, /Secure/);
});

// fetch no deja cambiar la cabecera Host: se usa node:http directamente
function hostGet(base, path, host) {
  const u = new URL(base);
  return new Promise((resolve, reject) => {
    const req = httpRequest({ host: u.hostname, port: u.port, path, method: 'GET', headers: { host } }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => { let json = null; try { json = JSON.parse(body); } catch { json = null; } resolve({ status: res.statusCode, headers: res.headers, json }); });
    });
    req.on('error', reject);
    req.end();
  });
}

test('ADMIN_HOST: el panel vive solo en su subdominio', async () => {
  await S.close();
  S = await startApp({ adminHost: 'panel.piedra.test', storeUrl: 'https://piedra.test/' });
  const get = (path, host) => hostGet(S.base, path, host);
  assert.equal((await get('/admin/', 'piedra.test')).status, 404, 'en la tienda el panel no existe');
  assert.equal((await get('/admin/api/session', 'piedra.test')).status, 404);
  assert.equal((await get('/', 'piedra.test')).status, 200);
  assert.equal((await get('/api/catalog', 'piedra.test')).status, 200);
  const root = await get('/', 'panel.piedra.test');
  assert.equal(root.status, 302);
  assert.equal(root.headers.location, '/admin/');
  assert.equal((await get('/api/catalog', 'panel.piedra.test')).status, 404, 'en el subdominio del panel no está la tienda');
  assert.equal((await get('/admin/', 'PANEL.piedra.test:443')).status, 200, 'sin distinguir mayúsculas ni puerto');
  const sess = await get('/admin/api/session', 'panel.piedra.test');
  assert.equal(sess.json.store, 'https://piedra.test/', 'el panel sabe dónde está la tienda');
});

test('sin ADMIN_PASSWORD válido no se crea un administrador débil', async () => {
  await S.close();
  S = await startApp({ adminUser: 'dueno', adminPassword: '123', setupToken: '' });
  assert.equal(S.first.ready, false);
  assert.ok(S.first.setupToken.length >= 20, 'se genera una clave de configuración aleatoria');
  assert.equal(S.repo.adminCount(), 0);
});

test('desde internet, el panel solo funciona con https', async () => {
  await S.close();
  S = await startApp({ trustProxy: true, adminUser: 'dueno', adminPassword: PASS });
  const c = client(S.base);
  const internet = { 'x-forwarded-for': '203.0.113.7' };
  const page = await c.get('/admin/', { headers: internet });
  assert.equal(page.status, 403);
  assert.match(page.text, /https/);
  const api = await c.post('/admin/api/login', { user: 'dueno', password: PASS }, { headers: internet });
  assert.equal(api.status, 403);
  assert.equal(api.json.code, 'https_required');
  assert.equal((await c.get('/', { headers: internet })).status, 200, 'la tienda sigue funcionando');
  assert.equal((await c.get('/admin/', { headers: { ...internet, 'x-forwarded-proto': 'https' } })).status, 200, 'con https sí');
  assert.equal((await c.get('/admin/', { headers: { 'x-forwarded-for': '192.168.1.20' } })).status, 200, 'en la red local se permite');
  // Detrás de un proxy sin TRUST_PROXY, todas las visitas parecen "de este equipo": no cuenta como local
  await S.close();
  S = await startApp();
  assert.equal((await client(S.base).get('/admin/', { headers: { 'x-forwarded-for': '203.0.113.7', 'x-forwarded-proto': 'http' } })).status, 403);
  assert.equal((await client(S.base).get('/admin/')).status, 200, 'directo en este equipo sí');
  await S.close();
  S = await startApp({ trustProxy: true, allowHttpPanel: true });
  assert.equal((await client(S.base).get('/admin/', { headers: internet })).status, 200, 'ALLOW_HTTP_PANEL lo permite (no recomendado)');
});

test('carga desde planilla: ocultar los productos de ejemplo', async () => {
  const T = await startApp();
  try {
    const a = client(T.base);
    await a.post('/admin/api/setup', { token: SETUP, user: 'admin', password: PASS }).then((r) => { a.csrf = r.json?.csrf || ''; });
    const def = proposeProduct({ code: '7801', name: 'Crema Dental Menta 90gr Sonrisa', dept: 'Perfumeria', price: 1990 }).def;
    const r = await a.post('/admin/api/import', { file: 'x.xlsx', hideDemo: true, rows: [{ line: 2, code: '7801', price: 1990, def }] });
    assert.equal(r.status, 200, r.text);
    assert.ok(r.json.result.hiddenDemo > 200, String(r.json.result.hiddenDemo));
    const pub = (await client(T.base).get('/api/catalog')).json;
    assert.ok(pub.overrides['420101'].hidden && !pub.overrides['7801'].hidden);
  } finally {
    await T.close();
  }
});

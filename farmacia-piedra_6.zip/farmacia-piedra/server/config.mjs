// Configuración del servidor (todo se puede cambiar con variables de entorno).

import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, readFileSync } from 'node:fs';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

// Variables de un archivo .env en la carpeta del proyecto (opcional)
function loadDotEnv() {
  const file = join(ROOT, '.env');
  if (!existsSync(file)) return;
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m || line.trim().startsWith('#')) continue;
    if (process.env[m[1]] == null) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}

const bool = (v, d = false) => (v == null || v === '' ? d : /^(1|true|si|sí|yes|on)$/i.test(String(v)));
// TRUST_PROXY: cuántos proxys de confianza hay delante (true = 1). Se usa la IP
// que agregó el último proxy, no la que podría inventar el visitante.
const hops = (v) => (/^\d+$/.test(String(v || '').trim()) ? Math.min(5, Number(v)) : bool(v) ? 1 : 0);
const list = (v) => String(v || '').split(',').map((s) => s.trim()).filter(Boolean);

function adminPathOf(v) {
  const p = `/${String(v || 'admin').trim().replace(/^\/+|\/+$/g, '')}`;
  if (!/^\/[A-Za-z0-9_-]{3,60}$/.test(p) || p === '/api' || p === '/assets') return '/admin';
  return p;
}

export function loadConfig(overrides = {}) {
  // Los servicios de hosting definen PORT en el entorno (no en .env)
  const hosted = !!process.env.PORT;
  loadDotEnv();
  const env = { ...process.env, ...overrides };
  return {
    port: Number(env.PORT) || 3000,
    // Con PORT definido (hosting) escucha en todas las interfaces; si no, solo en este equipo
    host: env.HOST || (hosted ? '0.0.0.0' : '127.0.0.1'),
    dataDir: resolve(ROOT, env.DATA_DIR || 'datos'),
    publicDir: resolve(ROOT, env.PUBLIC_DIR || 'server/public'),
    // Código del panel que solo se entrega con la sesión iniciada (nunca desde public/)
    privateDir: resolve(ROOT, env.PRIVATE_DIR || 'server/privado'),
    // Llave de cifrado de los datos (si no está, se usa datos/clave-cifrado.key)
    dataKey: String(env.DATA_KEY || '').trim(),
    // https directo en este servidor (certificado y llave en formato PEM)
    tlsCert: env.TLS_CERT ? resolve(ROOT, env.TLS_CERT) : '',
    tlsKey: env.TLS_KEY ? resolve(ROOT, env.TLS_KEY) : '',
    httpRedirectPort: Number(env.HTTP_REDIRECT_PORT) || 0,
    // Desde internet, el panel solo funciona con https (salvo que se permita aquí, no recomendado)
    allowHttpPanel: bool(env.ALLOW_HTTP_PANEL),
    adminPath: adminPathOf(env.ADMIN_PATH),
    trustProxy: hops(env.TRUST_PROXY),
    forceHttps: bool(env.FORCE_HTTPS),
    storeOrigins: list(env.STORE_ORIGINS),
    adminIps: list(env.ADMIN_IPS),
    // Panel en su propio subdominio (por ejemplo panel.tudominio.cl) y dirección de la tienda
    adminHost: String(env.ADMIN_HOST || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/[/:].*$/, ''),
    storeUrl: /^https?:\/\/[\w.-]+(:\d+)?\/?$/i.test(String(env.STORE_URL || '').trim()) ? String(env.STORE_URL).trim().replace(/\/?$/, '/') : '',
    sessionHours: Math.min(72, Number(env.SESSION_HOURS) || 12),
    idleMinutes: Math.min(24 * 60, Number(env.IDLE_MINUTES) || 120),
    setupToken: env.SETUP_TOKEN || '',
    adminUser: env.ADMIN_USER || '',
    adminPassword: env.ADMIN_PASSWORD || '',
    rateLimits: overrides.rateLimits || {},
  };
}

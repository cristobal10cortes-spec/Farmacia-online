// Respaldo de la base de datos (pedidos, stock, productos, banners, recetas y administradores).
// Los datos de clientes y recetas quedan cifrados en el respaldo: guarda aparte la llave
// (datos/clave-cifrado.key), que no se copia aquí.
//   npm run respaldar      (o doble clic en "respaldar-datos.bat")
// Se puede hacer con el servidor funcionando: la copia queda completa y consistente.
// Guarda los respaldos en la carpeta "respaldos" (o la que indiques: npm run respaldar -- D:\mis-respaldos).

import { mkdirSync, existsSync, statSync, readdirSync, unlinkSync, chmodSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { loadConfig, ROOT } from '../config.mjs';

// Los respaldos solo los puede leer el usuario que los crea
try { process.umask(0o077); } catch { /* Windows */ }
const config = loadConfig();
const source = join(config.dataDir, 'farmacia.db');
if (!existsSync(source)) {
  console.error(`\nNo hay datos para respaldar todavía (${source}). Inicia el servidor al menos una vez.\n`);
  process.exit(1);
}
const dir = resolve(ROOT, process.argv[2] || 'respaldos');
mkdirSync(dir, { recursive: true });
const d = new Date();
const p2 = (n) => String(n).padStart(2, '0');
const name = `farmacia-${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}.db`;
const target = join(dir, name);

const db = new DatabaseSync(source);
db.exec('PRAGMA busy_timeout = 10000');
db.prepare('VACUUM INTO ?').run(target);
db.close();
try { chmodSync(dir, 0o700); chmodSync(target, 0o600); } catch { /* Windows */ }

// Se guardan los 30 respaldos más recientes
const old = readdirSync(dir).filter((f) => /^farmacia-[\d-]+\.db$/.test(f)).sort().reverse().slice(30);
for (const f of old) { try { unlinkSync(join(dir, f)); } catch { /* en uso */ } }

const kb = (statSync(target).size / 1024).toFixed(0);
console.log(`\nListo: respaldo guardado en ${target} (${kb} KB).`);
console.log('Guarda una copia fuera de este computador (pendrive o nube).');
console.log('');
console.log('Los datos de clientes y recetas del respaldo están CIFRADOS. Para poder usarlo necesitas');
console.log(`también la llave: ${join(config.dataDir, 'clave-cifrado.key')} (guárdala aparte, en un lugar`);
console.log('seguro, y no la subas a internet junto con los respaldos).');
console.log('Para restaurarlo: detén el servidor, borra datos/farmacia.db-wal y datos/farmacia.db-shm (si existen)');
console.log('y reemplaza datos/farmacia.db por el respaldo (con ese mismo nombre).\n');

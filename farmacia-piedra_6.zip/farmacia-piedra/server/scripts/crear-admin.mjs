// Crea un administrador del panel, cambia su contraseña (si olvidaste la tuya)
// o desactiva su verificación en dos pasos (si perdiste el celular).
//   npm run crear-admin      (o doble clic en "crear-administrador.bat")
// Solo funciona en el computador donde está el servidor (con acceso a la carpeta
// de datos). Cierra las sesiones abiertas de ese usuario. Se puede usar con el
// servidor funcionando.

import { createInterface } from 'node:readline';
import { join } from 'node:path';
import { loadConfig } from '../config.mjs';
import { openDb, createRepo } from '../lib/db.mjs';
import { hashPassword, normUser, userIssues, passwordIssues } from '../lib/security.mjs';

const tty = !!process.stdin.isTTY;

// Sin pantalla interactiva (por ejemplo, respuestas desde un script): se leen todas las líneas
const piped = tty ? null : (await new Promise((resolve) => {
  let data = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (c) => { data += c; });
  process.stdin.on('end', () => resolve(data));
})).split(/\r?\n/);

function ask(question, { hidden = false } = {}) {
  if (piped) {
    process.stdout.write(`${question}\n`);
    const answer = piped.shift();
    if (answer == null) { console.log('\nCancelado: faltan respuestas.'); process.exit(1); }
    return Promise.resolve(answer);
  }
  return new Promise((resolve) => {
    const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    // La contraseña no se muestra mientras se escribe (ni al borrar)
    if (hidden) rl._writeToOutput = (s) => { rl.output.write(s.includes(question) ? question : s.replace(/[^\r\n]/g, '')); };
    rl.question(question, (answer) => { rl.close(); resolve(answer); });
  });
}

const config = loadConfig();
const db = openDb(join(config.dataDir, 'farmacia.db'));
const repo = createRepo(db);

console.log('\nAdministrador del panel de Farmacias Piedra\n');
let user = '';
for (;;) {
  user = normUser(await ask('Usuario: '));
  const issues = userIssues(user);
  if (!issues.length) break;
  console.log(`  ${issues[0]}`);
}
const existing = repo.adminByUser(user);
const yes = (a) => /^\s*(s|si|sí|y|yes)\s*$/i.test(a || '');
if (existing && existing.totp_on) {
  console.log(`  «${user}» tiene activa la verificación en dos pasos (código del celular).`);
  if (yes(await ask('¿Desactivarla? Úsalo si perdiste el celular y los códigos de respaldo (s/n): '))) {
    repo.setTotp(existing.id, { on: false });
    repo.deleteSessionsOf(existing.id);
    repo.logAccess({ user, event: '2fa_reset' });
    console.log('  Listo: la verificación en dos pasos quedó desactivada. Al entrar al panel puedes volver a activarla.');
  }
  if (!yes(await ask('¿Cambiar también la contraseña? (s/n): '))) {
    console.log('');
    db.close();
    process.exit(0);
  }
}
console.log(existing ? `  El usuario «${user}» ya existe: vas a cambiar su contraseña.` : `  Se creará el usuario «${user}».`);
let password = '';
for (;;) {
  password = await ask('Contraseña (al menos 10 caracteres, con letras y números): ', { hidden: true });
  const issues = passwordIssues(password, user);
  if (issues.length) { console.log(`  La contraseña necesita ${issues.join(', ')}.`); continue; }
  const again = await ask('Repite la contraseña: ', { hidden: true });
  if (again !== password) { console.log('  No coinciden. Inténtalo de nuevo.'); continue; }
  break;
}
const hash = await hashPassword(password);
if (existing) {
  repo.setAdminHash(existing.id, hash);
  repo.deleteSessionsOf(existing.id);
  repo.logAccess({ user, event: 'password_reset' });
  console.log(`\nListo: cambiaste la contraseña de «${user}». Sus sesiones abiertas se cerraron.\n`);
} else {
  repo.createAdmin(user, hash);
  console.log(`\nListo: creaste el administrador «${user}». Entra al panel en ${config.adminPath}/\n`);
}
db.close();

// Servidor HTTP de Farmacias Piedra: tienda pública, API y panel de
// administración (en su propia dirección, con ingreso seguro).
//
//   /                     tienda (solo lectura de datos + envío de pedidos)
//   /api/...              API pública de la tienda
//   <ADMIN_PATH>/         panel de administración (por defecto /admin/): sin sesión
//                         solo se entrega la pantalla de ingreso
//   <ADMIN_PATH>/panel.js código del panel: SOLO con la sesión iniciada
//   <ADMIN_PATH>/api/...  API del panel: requiere sesión y ficha anti-CSRF
//
// Con ADMIN_HOST (por ejemplo panel.tudominio.cl) el panel solo existe en ese
// subdominio y la tienda no lo ve: quedan en orígenes distintos.

import { join } from 'node:path';
import { HttpError, sendJson, sendJsonGz, sendError, readJson, parseCookies, cookie, clientIp, requestHost, isSecure, safeJoin, serveFile } from './lib/http.mjs';
import { hashPassword, verifyPassword, dummyVerify, normUser, userIssues, passwordIssues, randomToken, sha256, safeEqual, RateLimiter, securityHeaders, isLocalIp } from './lib/security.mjs';
import { newSecret, verifyTotp, otpauthUri, newRecoveryCodes, normRecovery, looksLikeRecovery } from './lib/totp.mjs';
import { createShop } from './lib/shop.mjs';

const MB = 1024 * 1024;

/** Clave para los límites de intentos: la IP (IPv6 agrupada por /64, como la entregan los proveedores). */
export function rateKey(ip) {
  const v = String(ip || '').replace(/^::ffff:/i, '').replace(/%.*$/, '').toLowerCase();
  if (!v.includes(':')) return v;
  const [head, tail] = v.split('::');
  const h = head ? head.split(':') : [];
  const t = tail === undefined ? [] : tail ? tail.split(':') : [];
  const full = tail === undefined ? h : [...h, ...Array(Math.max(0, 8 - h.length - t.length)).fill('0'), ...t];
  return `${full.slice(0, 4).map((x) => x.replace(/^0+(?=.)/, '')).join(':')}::/64`;
}

// Texto seguro para el registro (sin saltos de línea ni caracteres de control)
const logText = (s, max = 60) => String(s ?? '').replace(/[\u0000-\u001f\u007f-\u009f]/g, '?').slice(0, max);

export function createApp({ config, repo, log = console }) {
  const shop = createShop(repo);
  const adminPath = config.adminPath;
  const apiAdmin = `${adminPath}/api`;
  const idleMs = config.idleMinutes * 60000;
  const sessionMs = config.sessionHours * 3600000;
  let setupToken = '';

  // ── Límites de intentos ────────────────────────────────────
  const RATE = {
    global: 900, // solicitudes por minuto por IP
    loginIp: 10, // intentos de ingreso por IP cada 15 minutos (los correctos se descuentan)
    loginUser: 5, // intentos de ingreso por usuario cada 15 minutos (al entrar se reinicia)
    orders: 10, // pedidos por IP cada 10 minutos
    lookup: 60, // consultas de seguimiento por IP cada 10 minutos
    twoFa: 5, // códigos de verificación incorrectos por usuario cada 15 minutos
    ...config.rateLimits,
  };
  const limits = {
    global: new RateLimiter({ limit: RATE.global, windowMs: 60000 }),
    loginIp: new RateLimiter({ limit: RATE.loginIp, windowMs: 15 * 60000 }),
    loginUser: new RateLimiter({ limit: RATE.loginUser, windowMs: 15 * 60000 }),
    orders: new RateLimiter({ limit: RATE.orders, windowMs: 10 * 60000 }),
    lookup: new RateLimiter({ limit: RATE.lookup, windowMs: 10 * 60000 }),
    twoFa: new RateLimiter({ limit: RATE.twoFa, windowMs: 15 * 60000 }),
    // Códigos de respaldo: por usuario Y conexión, así quien tenga la contraseña no
    // puede dejar afuera al dueño (que siempre puede entrar con un código de respaldo)
    recovery: new RateLimiter({ limit: RATE.twoFa, windowMs: 15 * 60000 }),
  };
  // Ingresos a medio camino (contraseña correcta, falta el código) y activaciones pendientes
  const pendingLogins = new Map();
  const pendingSetups = new Map();
  const sweep = setInterval(() => {
    for (const l of Object.values(limits)) l.sweep();
    repo.purgeSessions(Date.now(), idleMs);
    const now = Date.now();
    for (const m of [pendingLogins, pendingSetups]) for (const [k, v] of m) if (v.exp < now) m.delete(k);
  }, 5 * 60000);
  sweep.unref?.();

  // Revisar una contraseña (scrypt) usa memoria y procesador: pocas a la vez
  // (las demás esperan su turno) para que la tienda siga respondiendo rápido.
  const MAX_SLOW = 2;
  const MAX_QUEUE = 20;
  let slowActive = 0;
  const slowQueue = [];
  async function slow(fn) {
    if (slowActive >= MAX_SLOW) {
      if (slowQueue.length >= MAX_QUEUE) throw new HttpError(503, 'El servidor está ocupado. Inténtalo de nuevo en unos segundos.', 'busy', { retryAfter: 5 });
      await new Promise((resolve) => slowQueue.push(resolve));
    } else {
      slowActive++;
    }
    try {
      return await fn();
    } finally {
      const next = slowQueue.shift();
      if (next) next(); else slowActive--;
    }
  }

  // ── Primer administrador ───────────────────────────────────
  async function ensureFirstAdmin() {
    if (repo.adminCount() > 0) return { ready: true };
    if (config.adminUser && config.adminPassword) {
      const user = normUser(config.adminUser);
      const issues = [...userIssues(user), ...passwordIssues(config.adminPassword, user)];
      if (!issues.length) {
        repo.createAdmin(user, await hashPassword(config.adminPassword));
        log.info?.(`[panel] Se creó el administrador «${user}» (ADMIN_USER).`);
        return { ready: true, created: user };
      }
      log.warn?.(`[panel] ADMIN_USER/ADMIN_PASSWORD no se usaron: ${issues.join('; ')}.`);
    }
    setupToken = config.setupToken || randomToken(18);
    return { ready: false, setupToken };
  }

  // ── Sesiones del panel ─────────────────────────────────────
  const cookieNames = (secure) => (secure ? '__Host-piedra_panel' : 'piedra_panel');

  // passive: revisión automática del panel (no cuenta como uso para el cierre por inactividad)
  function readSession(req, { passive = false } = {}) {
    const c = parseCookies(req.headers.cookie);
    const token = c['__Host-piedra_panel'] || c.piedra_panel;
    if (!token || token.length > 100) return null;
    const hash = sha256(token);
    const s = repo.session(hash);
    const now = Date.now();
    if (!s) return null;
    if (s.expires_at < now || s.last_seen < now - idleMs) { repo.deleteSession(hash); return null; }
    if (!passive && now - s.last_seen > 60000) repo.touchSession(hash, now);
    return { hash, adminId: s.admin_id, user: s.username, csrf: s.csrf };
  }

  function startSession(req, res, admin, secure) {
    const token = randomToken(32);
    const now = Date.now();
    const csrf = randomToken(24);
    repo.createSession({ tokenHash: sha256(token), adminId: admin.id, csrf, createdAt: now, lastSeen: now, expiresAt: now + sessionMs, ip: clientIp(req, config.trustProxy), ua: String(req.headers['user-agent'] || '').slice(0, 200) });
    repo.touchLogin(admin.id);
    res.setHeader('Set-Cookie', cookie(cookieNames(secure), token, { maxAge: sessionMs / 1000, secure }));
    return { user: admin.username, csrf, twoFactor: !!admin.totp_on };
  }

  function clearCookie(res, secure) {
    res.setHeader('Set-Cookie', cookie(cookieNames(secure), '', { maxAge: 0, secure }));
  }

  // Registro de ingresos (lo ve el administrador en Seguridad)
  const audit = (ctx, user, event) => repo.logAccess({ user, event, ip: ctx.ip, ua: String(ctx.req.headers['user-agent'] || '') });

  /** Revisa la contraseña de quien ya tiene sesión (para cambios delicados). */
  async function confirmPassword(admin, password) {
    const wait = limits.loginUser.blocked(admin.username);
    if (wait) throw lockedOut(wait);
    limits.loginUser.hit(admin.username);
    let ok;
    try {
      ok = await slow(() => verifyPassword(String(password || ''), admin.hash));
    } catch (e) {
      limits.loginUser.refund(admin.username);
      throw e;
    }
    if (!ok) throw new HttpError(400, 'La contraseña actual no es correcta.', 'bad_credentials');
    limits.loginUser.refund(admin.username);
  }

  /** Código de la app del celular o código de respaldo. Devuelve 'totp' | 'recovery' | ''. */
  function checkSecondFactor(adminId, code) {
    const t = repo.adminTotp(adminId);
    if (!t?.on || !t.secret) return '';
    if (looksLikeRecovery(code)) {
      const h = repo.recoveryHash(adminId, normRecovery(code));
      let idx = -1;
      t.recovery.forEach((x, i) => { if (safeEqual(x, h) && idx < 0) idx = i; });
      if (idx < 0) return '';
      repo.setRecovery(adminId, t.recovery.filter((_, i) => i !== idx));
      return 'recovery';
    }
    const n = verifyTotp(t.secret, code, { last: t.last });
    return n >= 0 && repo.useTotpCounter(adminId, n) ? 'totp' : '';
  }

  const badCode = () => new HttpError(400, 'El código no es correcto. Revisa que sea el que muestra ahora la app de tu celular.', 'bad_code');

  /** Revisa el segundo paso con su límite de intentos. Devuelve 'totp' | 'recovery' | '' (incorrecto). */
  function secondFactor(ctx, admin, code) {
    const recovery = looksLikeRecovery(code);
    const lim = recovery ? limits.recovery : limits.twoFa;
    const key = recovery ? `${admin.username}|${ctx.rk}` : admin.username;
    const wait = lim.blocked(key);
    if (wait) {
      const mins = Math.ceil(wait / 60);
      throw new HttpError(429, recovery
        ? `Demasiados códigos de respaldo incorrectos. Espera ${mins} minutos e inténtalo de nuevo.`
        : `Demasiados códigos incorrectos: el código del celular quedó bloqueado por ${mins} minutos. Puedes entrar con un código de respaldo.`, 'rate_limited', { retryAfter: wait, totpLocked: !recovery });
    }
    lim.hit(key);
    const how = checkSecondFactor(admin.id, code);
    if (how) { lim.reset(key); limits.twoFa.reset(admin.username); }
    return how;
  }

  /** Intentos fallidos desde el último ingreso (para avisarle al dueño). */
  const alertsFor = (user) => {
    const f = repo.failuresSince(user);
    return f.password || f.code ? { failedPasswords: f.password, failedCodes: f.code } : undefined;
  };

  // Desde internet el panel solo funciona con https. "Local" es este equipo o la red de la
  // casa/oficina; si las visitas llegan por un proxy sin TRUST_PROXY, nada cuenta como local.
  const viaProxyUntrusted = (req) => !config.trustProxy && !!(req.headers['x-forwarded-for'] || req.headers['x-forwarded-proto'] || req.headers.forwarded);
  const localClient = (req, ip) => !viaProxyUntrusted(req) && isLocalIp(ip);

  // Peticiones que cambian algo: deben venir del mismo sitio
  function checkSameOrigin(req) {
    const site = req.headers['sec-fetch-site'];
    if (site && site !== 'same-origin' && site !== 'none') throw new HttpError(403, 'Petición no permitida.', 'cross_site');
    const origin = req.headers.origin;
    if (origin) {
      let oh = '';
      try { oh = new URL(origin).host.toLowerCase(); } catch { oh = ''; }
      if (!oh || oh !== requestHost(req, config.trustProxy, { keepPort: true })) throw new HttpError(403, 'Petición no permitida.', 'cross_site');
    }
  }

  function requireAdmin(req, { write = false } = {}) {
    const s = readSession(req, { passive: !write && req.headers['x-panel-activity'] === '0' });
    if (!s) throw new HttpError(401, 'Tu sesión terminó. Vuelve a ingresar.', 'auth');
    if (write) {
      checkSameOrigin(req);
      if (!safeEqual(req.headers['x-csrf-token'], s.csrf)) throw new HttpError(403, 'La página del panel está desactualizada. Recárgala e inténtalo de nuevo.', 'csrf');
    }
    return s;
  }

  function limited(limiter, key, msg) {
    const wait = limiter.hit(key);
    if (wait) throw new HttpError(429, msg || `Demasiados intentos. Espera ${Math.ceil(wait / 60)} minuto${wait > 60 ? 's' : ''} e inténtalo de nuevo.`, 'rate_limited', { retryAfter: wait });
  }

  const lockedOut = (wait) => new HttpError(429, `Demasiados intentos fallidos. Espera ${Math.ceil(wait / 60)} minutos e inténtalo de nuevo.`, 'rate_limited', { retryAfter: wait });

  // ── Rutas de la API ────────────────────────────────────────
  const routes = [];
  const on = (method, pattern, kind, handler) => routes.push({ method, pattern, kind, handler });

  // API pública (tienda)
  let catalogCache = { version: null, json: null, gz: null };
  on('GET', /^\/api\/catalog$/, 'public', (ctx) => {
    const snap = shop.catalogSnapshot();
    const etag = `W/"v${snap.version}"`;
    if (ctx.req.headers['if-none-match'] === etag) {
      ctx.res.writeHead(304, { ETag: etag, 'Cache-Control': 'no-cache' });
      ctx.res.end();
      return;
    }
    // La tienda pregunta con ?v=<versión que tiene>: si no cambió nada, la respuesta es mínima
    if (ctx.url.searchParams.get('v') === String(snap.version)) { sendJson(ctx.res, 200, { version: snap.version, unchanged: true }, { 'Cache-Control': 'no-store' }); return; }
    if (catalogCache.version !== snap.version) catalogCache = { version: snap.version, json: null, gz: null };
    sendJsonGz(ctx.req, ctx.res, 200, snap, { ETag: etag, 'Cache-Control': 'no-cache' }, catalogCache);
  });

  on('POST', /^\/api\/orders$/, 'public', async (ctx) => {
    limited(limits.orders, ctx.rk, 'Hiciste muchos pedidos seguidos. Espera unos minutos e inténtalo de nuevo.');
    const body = await readJson(ctx.req, 16 * MB).catch((e) => {
      if (e.code === 'too_large') throw new HttpError(413, 'Las recetas adjuntas pesan demasiado. Prueba con fotos o archivos más livianos.', 'too_large');
      throw e;
    });
    const order = shop.createOrder(body);
    log.info?.(`[pedido] ${order.id} · ${order.items.length} productos · $${order.totals.total}`);
    sendJson(ctx.res, 201, { order: shop.publicOrder(order) });
  });

  // Fotos de productos: la dirección cambia con cada foto nueva (?v=…), así que se guardan en caché
  function sendPhoto(ctx, pid) {
    const f = shop.photoFile(pid);
    if (!f) throw new HttpError(404, 'Este producto no tiene foto.', 'not_found');
    const fresh = ctx.url.searchParams.get('v') === f.v;
    ctx.res.writeHead(200, {
      'Content-Type': f.mime,
      'Content-Length': f.data.length,
      'Cache-Control': fresh ? 'public, max-age=31536000, immutable' : 'public, max-age=300',
      'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
      'X-Content-Type-Options': 'nosniff',
    });
    ctx.res.end(ctx.req.method === 'HEAD' ? undefined : f.data);
  }
  on('GET', /^\/api\/fotos\/([A-Za-z0-9_-]{1,40})$/, 'public', (ctx, m) => sendPhoto(ctx, m[1]));

  // Fotos de banners y tarjetas del menú (misma idea: la dirección cambia con cada foto nueva)
  function sendMedia(ctx, key) {
    const f = shop.mediaFile(key);
    if (!f) throw new HttpError(404, 'Esta imagen ya no existe.', 'not_found');
    const fresh = ctx.url.searchParams.get('v') === f.v;
    ctx.res.writeHead(200, {
      'Content-Type': f.mime,
      'Content-Length': f.data.length,
      'Cache-Control': fresh ? 'public, max-age=31536000, immutable' : 'public, max-age=300',
      'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
      'X-Content-Type-Options': 'nosniff',
    });
    ctx.res.end(ctx.req.method === 'HEAD' ? undefined : f.data);
  }
  on('GET', /^\/api\/imagenes\/([A-Za-z0-9_-]{1,60})$/, 'public', (ctx, m) => sendMedia(ctx, m[1]));

  // Seguimiento con número y correo: los datos personales se muestran en parte
  on('GET', /^\/api\/orders\/([A-Za-z0-9]{1,20})$/, 'public', (ctx, m) => {
    limited(limits.lookup, ctx.rk, 'Hiciste muchas búsquedas seguidas. Espera unos minutos e inténtalo de nuevo.');
    const o = shop.findOrderFor(m[1], ctx.url.searchParams.get('email'));
    sendJson(ctx.res, 200, { order: shop.publicOrder(o, { mask: true }) });
  });

  on('POST', /^\/api\/orders\/([A-Za-z0-9]{1,20})\/cancel$/, 'public', async (ctx, m) => {
    limited(limits.lookup, ctx.rk, 'Hiciste muchas solicitudes seguidas. Espera unos minutos e inténtalo de nuevo.');
    const body = await readJson(ctx.req, 4096);
    shop.findOrderFor(m[1], body.email);
    const o = shop.cancelOrder(m[1], { by: 'cliente', email: body.email });
    sendJson(ctx.res, 200, { order: shop.publicOrder(o, { mask: true }) });
  });

  // API del panel
  const A = (re) => new RegExp(`^${apiAdmin.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&')}${re}$`);

  on('GET', A('/session'), 'admin', (ctx) => {
    const s = readSession(ctx.req);
    const out = { user: s?.user || null, csrf: s?.csrf || null, needsSetup: repo.adminCount() === 0, store: config.storeUrl || '/' };
    if (s) out.twoFactor = !!repo.adminById(s.adminId)?.totp_on;
    sendJson(ctx.res, 200, out);
  });

  on('POST', A('/setup'), 'admin', async (ctx) => {
    checkSameOrigin(ctx.req);
    if (repo.adminCount() > 0) throw new HttpError(409, 'El administrador ya fue creado. Ingresa con tu usuario y contraseña.', 'already');
    limited(limits.loginIp, ctx.rk);
    const body = await readJson(ctx.req, 8192);
    if (!setupToken || !safeEqual(body.token, setupToken)) throw new HttpError(403, 'El enlace de primera configuración no es válido. Usa el que muestra el servidor al iniciar.', 'setup_token');
    const user = normUser(body.user);
    const issues = [...userIssues(user), ...passwordIssues(body.password, user).map((x) => `La contraseña necesita ${x}.`)];
    if (issues.length) throw new HttpError(400, issues.join(' '), 'weak');
    const hash = await slow(() => hashPassword(body.password));
    if (repo.adminCount() > 0 || !setupToken) throw new HttpError(409, 'El administrador ya fue creado. Ingresa con tu usuario y contraseña.', 'already');
    const id = repo.createAdmin(user, hash);
    setupToken = '';
    log.info?.(`[panel] Se creó el administrador «${user}».`);
    audit(ctx, user, 'setup');
    sendJson(ctx.res, 200, startSession(ctx.req, ctx.res, repo.adminById(id), ctx.secure));
  });

  on('POST', A('/login'), 'admin', async (ctx) => {
    checkSameOrigin(ctx.req);
    const body = await readJson(ctx.req, 8192);
    const user = normUser(body.user).slice(0, 60);
    const wait = limits.loginIp.blocked(ctx.rk) || limits.loginUser.blocked(user);
    if (wait) throw lockedOut(wait);
    // El intento se cuenta ANTES de revisar la contraseña: así muchos intentos
    // enviados al mismo tiempo no se saltan el límite.
    limits.loginIp.hit(ctx.rk);
    limits.loginUser.hit(user);
    const admin = repo.adminByUser(user);
    let ok;
    try {
      ok = await slow(() => (admin ? verifyPassword(String(body.password || ''), admin.hash) : dummyVerify(String(body.password || ''))));
    } catch (e) {
      limits.loginIp.refund(ctx.rk);
      limits.loginUser.refund(user);
      throw e;
    }
    // Mientras se revisaba la contraseña pudo cambiar (o activarse la verificación):
    // se usan los datos de AHORA, no los de antes de revisar
    const fresh = admin ? repo.adminById(admin.id) : null;
    if (!ok || !fresh || fresh.hash !== admin.hash) {
      // Del usuario solo se anota si existe (a veces se escribe la contraseña en ese campo)
      log.warn?.(`[panel] Ingreso fallido${admin ? ` para «${logText(user)}»` : ' (usuario desconocido)'} desde ${logText(ctx.ip)}`);
      audit(ctx, admin ? admin.username : '', 'login_fail');
      throw new HttpError(401, 'Usuario o contraseña incorrectos.', 'bad_credentials');
    }
    limits.loginUser.reset(user);
    limits.loginIp.refund(ctx.rk);
    // Con verificación en dos pasos: falta el código del celular
    if (fresh.totp_on) {
      const ticket = randomToken(24);
      pendingLogins.set(sha256(ticket), { adminId: fresh.id, hash: fresh.hash, rk: ctx.rk, exp: Date.now() + 5 * 60000, tries: 0 });
      const locked = limits.twoFa.blocked(fresh.username);
      sendJson(ctx.res, 200, { needCode: true, ticket, ...(locked ? { totpLocked: locked } : {}) });
      return;
    }
    log.info?.(`[panel] «${fresh.username}» ingresó desde ${logText(ctx.ip)}`);
    const alerts = alertsFor(fresh.username);
    audit(ctx, fresh.username, 'login');
    sendJson(ctx.res, 200, { ...startSession(ctx.req, ctx.res, fresh, ctx.secure), alerts });
  });

  on('POST', A('/login/2fa'), 'admin', async (ctx) => {
    checkSameOrigin(ctx.req);
    const body = await readJson(ctx.req, 4096);
    const key = sha256(String(body.ticket || '').slice(0, 100));
    const p = pendingLogins.get(key);
    const expired = () => new HttpError(401, 'El ingreso venció. Vuelve a escribir tu usuario y contraseña.', 'ticket');
    if (!p || p.exp < Date.now() || p.rk !== ctx.rk) { pendingLogins.delete(key); throw expired(); }
    const admin = repo.adminById(p.adminId);
    // Si mientras tanto cambió la contraseña o se desactivó la verificación, hay que empezar de nuevo
    if (!admin || !admin.totp_on || admin.hash !== p.hash) { pendingLogins.delete(key); throw expired(); }
    const ipWait = limits.loginIp.blocked(ctx.rk);
    if (ipWait) { pendingLogins.delete(key); throw lockedOut(ipWait); }
    limits.loginIp.hit(ctx.rk);
    const how = secondFactor(ctx, admin, body.code);
    if (!how) {
      p.tries++;
      if (p.tries >= 5) pendingLogins.delete(key);
      log.warn?.(`[panel] Código de verificación incorrecto para «${logText(admin.username)}» desde ${logText(ctx.ip)}`);
      audit(ctx, admin.username, '2fa_fail');
      throw badCode();
    }
    pendingLogins.delete(key);
    limits.loginIp.refund(ctx.rk);
    log.info?.(`[panel] «${admin.username}» ingresó (con verificación en dos pasos) desde ${logText(ctx.ip)}`);
    const alerts = alertsFor(admin.username);
    audit(ctx, admin.username, how === 'recovery' ? 'login_recovery' : 'login');
    const out = { ...startSession(ctx.req, ctx.res, admin, ctx.secure), alerts };
    if (how === 'recovery') out.recoveryLeft = repo.adminTotp(admin.id).recovery.length;
    sendJson(ctx.res, 200, out);
  });

  on('POST', A('/logout'), 'admin', (ctx) => {
    checkSameOrigin(ctx.req);
    const s = readSession(ctx.req);
    if (s) { repo.deleteSession(s.hash); audit(ctx, s.user, 'logout'); }
    clearCookie(ctx.res, ctx.secure);
    sendJson(ctx.res, 200, { ok: true });
  });

  on('POST', A('/password'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    const body = await readJson(ctx.req, 8192);
    const admin = repo.adminById(s.adminId);
    await confirmPassword(admin, body.current);
    const issues = passwordIssues(body.next, admin.username);
    if (issues.length) throw new HttpError(400, `La contraseña nueva necesita ${issues.join(', ')}.`, 'weak');
    repo.setAdminHash(admin.id, await slow(() => hashPassword(body.next)));
    repo.deleteSessionsOf(admin.id); // cierra las otras sesiones abiertas
    audit(ctx, admin.username, 'password');
    sendJson(ctx.res, 200, startSession(ctx.req, ctx.res, admin, ctx.secure));
  });

  // ── Seguridad de la cuenta ─────────────────────────────────
  on('GET', A('/security'), 'admin', (ctx) => {
    const s = requireAdmin(ctx.req);
    const t = repo.adminTotp(s.adminId);
    const sessions = repo.sessionsOf(s.adminId).map((x) => ({ current: x.token_hash === s.hash, createdAt: x.created_at, lastSeen: x.last_seen, ip: x.ip || '', ua: x.ua || '' }));
    sendJson(ctx.res, 200, {
      user: s.user,
      twoFactor: !!t?.on,
      recoveryLeft: t?.on ? t.recovery.length : 0,
      sessions,
      log: repo.accessLog(60),
      checks: {
        https: ctx.secure,
        local: localClient(ctx.req, ctx.ip),
        proxyWithoutTrust: viaProxyUntrusted(ctx.req),
        adminPath: adminPath !== '/admin',
        adminHost: !!config.adminHost,
        adminIps: config.adminIps.length > 0,
        encrypted: true,
      },
    });
  });

  on('POST', A('/2fa/start'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    await readJson(ctx.req, 1024);
    if (repo.adminTotp(s.adminId)?.on) throw new HttpError(409, 'La verificación en dos pasos ya está activa.', 'already');
    const secret = newSecret();
    pendingSetups.set(s.hash, { adminId: s.adminId, secret, exp: Date.now() + 15 * 60000, tries: 0 });
    sendJson(ctx.res, 200, { secret, uri: otpauthUri({ secret, user: s.user }) });
  });

  on('POST', A('/2fa/enable'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    const body = await readJson(ctx.req, 4096);
    const admin = repo.adminById(s.adminId);
    const p = pendingSetups.get(s.hash);
    if (!p || p.exp < Date.now() || p.adminId !== s.adminId) { pendingSetups.delete(s.hash); throw new HttpError(400, 'Pasó mucho rato. Vuelve a empezar la activación.', 'setup_expired'); }
    await confirmPassword(admin, body.password);
    if (repo.adminTotp(admin.id)?.on) throw new HttpError(409, 'La verificación en dos pasos ya está activa.', 'already');
    const n = verifyTotp(p.secret, body.code);
    if (n < 0) {
      if (++p.tries >= 5) pendingSetups.delete(s.hash);
      throw badCode();
    }
    const codes = newRecoveryCodes();
    repo.setTotp(admin.id, { on: true, secret: p.secret, last: n, recovery: codes.map((c) => repo.recoveryHash(admin.id, normRecovery(c))) });
    pendingSetups.delete(s.hash);
    const closed = repo.deleteOtherSessions(admin.id, s.hash);
    audit(ctx, admin.username, '2fa_on');
    log.info?.(`[panel] «${admin.username}» activó la verificación en dos pasos.`);
    sendJson(ctx.res, 200, { ok: true, recovery: codes, closedSessions: closed });
  });

  on('POST', A('/2fa/disable'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    const body = await readJson(ctx.req, 4096);
    const admin = repo.adminById(s.adminId);
    if (!repo.adminTotp(admin.id)?.on) throw new HttpError(409, 'La verificación en dos pasos no está activa.', 'not_active');
    await confirmPassword(admin, body.password);
    if (!secondFactor(ctx, admin, body.code)) { audit(ctx, admin.username, '2fa_fail'); throw badCode(); }
    repo.setTotp(admin.id, { on: false });
    audit(ctx, admin.username, '2fa_off');
    log.info?.(`[panel] «${admin.username}» desactivó la verificación en dos pasos.`);
    sendJson(ctx.res, 200, { ok: true });
  });

  on('POST', A('/2fa/recovery'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    const body = await readJson(ctx.req, 4096);
    const admin = repo.adminById(s.adminId);
    if (!repo.adminTotp(admin.id)?.on) throw new HttpError(409, 'La verificación en dos pasos no está activa.', 'not_active');
    await confirmPassword(admin, body.password);
    if (!secondFactor(ctx, admin, body.code)) { audit(ctx, admin.username, '2fa_fail'); throw badCode(); }
    const codes = newRecoveryCodes();
    repo.setRecovery(admin.id, codes.map((c) => repo.recoveryHash(admin.id, normRecovery(c))));
    audit(ctx, admin.username, 'recovery_new');
    sendJson(ctx.res, 200, { ok: true, recovery: codes });
  });

  on('POST', A('/sessions/close-others'), 'admin', async (ctx) => {
    const s = requireAdmin(ctx.req, { write: true });
    await readJson(ctx.req, 1024);
    const closed = repo.deleteOtherSessions(s.adminId, s.hash);
    audit(ctx, s.user, 'close_sessions');
    sendJson(ctx.res, 200, { ok: true, closed });
  });

  on('GET', A('/data'), 'admin', (ctx) => {
    requireAdmin(ctx.req);
    const v = ctx.url.searchParams.get('v');
    if (v != null && v === String(repo.version())) { sendJson(ctx.res, 200, { version: repo.version(), unchanged: true }); return; }
    sendJsonGz(ctx.req, ctx.res, 200, shop.adminSnapshot());
  });

  // Movimientos con filtros (fechas, farmacia, tipo y texto) en todo el historial
  on('GET', A('/movimientos'), 'admin', (ctx) => {
    requireAdmin(ctx.req);
    const p = ctx.url.searchParams;
    sendJsonGz(ctx.req, ctx.res, 200, shop.findMovements({ from: p.get('desde'), until: p.get('hasta'), loc: p.get('local'), kind: p.get('tipo'), q: p.get('q') }));
  });

  const write = (method, re, fn, limit = MB) => on(method, A(re), 'admin', async (ctx, m) => {
    const s = requireAdmin(ctx.req, { write: true });
    const body = method === 'DELETE' ? {} : await readJson(ctx.req, limit);
    const result = await fn(body, s.user, m);
    sendJson(ctx.res, 200, { ok: true, result: result ?? null, version: repo.version() });
  });

  // Las fotos también se ven desde la dirección del panel (por si está en su propio subdominio)
  on('GET', A('/fotos/([A-Za-z0-9_-]{1,40})'), 'admin', (ctx, m) => sendPhoto(ctx, m[1]));
  on('GET', A('/imagenes/([A-Za-z0-9_-]{1,60})'), 'admin', (ctx, m) => sendMedia(ctx, m[1]));

  write('POST', '/stock', (b, by) => shop.changeStock(b, by));
  write('POST', '/stock/bulk', (b, by) => shop.bulkStock(b, by), 2 * MB);
  write('POST', '/import', (b, by) => shop.importPlanilla(b, by), 8 * MB);
  write('POST', '/price', (b, by) => shop.setPrice(b, by));
  write('POST', '/visibility', (b, by) => shop.setHidden(b, by));
  write('POST', '/products', (b, by) => shop.createProduct(b, by));
  write('PUT', '/products/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.updateProductDef({ pid: m[1], def: b.def }, by));
  write('DELETE', '/products/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.deleteProduct({ pid: m[1] }, by));
  write('PUT', '/products/([A-Za-z0-9_-]{1,40})/foto', (b, by, m) => shop.setPhoto({ pid: m[1], image: b.image }, by), 3 * MB);
  write('DELETE', '/products/([A-Za-z0-9_-]{1,40})/foto', (b, by, m) => shop.removePhoto({ pid: m[1] }, by));
  write('POST', '/stores', (b, by) => shop.createStore({ store: b.store, initialStock: b.initialStock }, by));
  write('PUT', '/stores/(F[0-9A-Z]{2,20})', (b, by, m) => shop.updateStore({ id: m[1], store: b.store }, by));
  write('DELETE', '/stores/(F[0-9A-Z]{2,20})', (b, by, m) => shop.deleteStore({ id: m[1] }, by));
  write('POST', '/banners', (b, by) => shop.saveBanner(b.banner || {}, by), 4 * MB);
  write('PATCH', '/banners/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.setBannerActive({ id: m[1], active: !!b.active }, by));
  write('POST', '/banners/([A-Za-z0-9_-]{1,40})/move', (b, by, m) => shop.moveBanner({ id: m[1], dir: b.dir }, by));
  write('DELETE', '/banners/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.deleteBanner({ id: m[1] }, by));
  write('POST', '/menu', (b, by) => shop.saveMenuCard(b.card || {}, by), 2 * MB);
  write('PATCH', '/menu/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.setMenuCardActive({ id: m[1], active: !!b.active }, by));
  write('POST', '/menu/([A-Za-z0-9_-]{1,40})/move', (b, by, m) => shop.moveMenuCard({ id: m[1], dir: b.dir }, by));
  write('DELETE', '/menu/([A-Za-z0-9_-]{1,40})', (b, by, m) => shop.deleteMenuCard({ id: m[1] }, by));
  write('PUT', '/servicios', (b, by) => shop.saveServices(b.section || {}, by), 64 * 1024);
  write('POST', '/orders/([A-Za-z0-9]{1,20})/cancel', (b, by, m) => { shop.cancelOrder(m[1], { by }); return true; });
  write('POST', '/orders/([A-Za-z0-9]{1,20})/status', (b, by, m) => { shop.setOrderStatus(m[1], { status: b.status, note: b.note }, by); return true; }, 8192);
  write('POST', '/orders/([A-Za-z0-9]{1,20})/date', (b, by, m) => { shop.setDeliveryDate(m[1], { date: b.date, note: b.note }, by); return true; }, 8192);

  on('GET', A('/orders/([A-Za-z0-9]{1,20})/recetas/(\\d{1,10})'), 'admin', (ctx, m) => {
    requireAdmin(ctx.req);
    const f = repo.prescription(String(m[1]).toUpperCase(), Number(m[2]));
    if (!f || !f.data) throw new HttpError(404, 'Receta no encontrada.', 'not_found');
    const data = Buffer.from(f.data);
    const safeName = String(f.file_name).replace(/[^\w.\- ]+/g, '_').slice(0, 80) || 'receta';
    ctx.res.writeHead(200, {
      'Content-Type': f.mime || 'application/octet-stream',
      'Content-Length': data.length,
      'Content-Disposition': `${f.mime === 'application/pdf' ? 'attachment' : 'inline'}; filename="${safeName}"`,
      'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
    });
    ctx.res.end(data);
  });

  // ── Archivos de la tienda y del panel ──────────────────────
  const storeDir = config.publicDir;
  const assetsDir = join(config.publicDir, 'assets');
  const adminDir = join(config.publicDir, 'admin');

  function serveAdminFiles(ctx) {
    const { req, res, path } = ctx;
    if (path === adminPath) { res.writeHead(301, { Location: `${adminPath}/` }); res.end(); return true; }
    const rel = path === `${adminPath}/` ? '/index.html' : path.slice(adminPath.length);
    if (rel.startsWith('/api/')) return false;
    // El código del panel solo se entrega con la sesión iniciada (sin ella, "no existe")
    if (rel === '/panel.js') {
      if (!readSession(req, { passive: true })) return false;
      return serveFile(req, res, join(config.privateDir, 'panel.js'), { ...securityHeaders('admin', { secure: ctx.secure }), 'Cache-Control': 'private, no-store' });
    }
    const file = safeJoin(adminDir, rel);
    const head = { ...securityHeaders('admin', { secure: ctx.secure }) };
    if (!rel.endsWith('.html')) head['Cache-Control'] = 'no-cache';
    return !!file && serveFile(req, res, file, head);
  }

  function serveStoreFiles(ctx) {
    const { req, res, path } = ctx;
    const head = securityHeaders('store', { secure: ctx.secure });
    if (path === '/' || path === '/index.html') return serveFile(req, res, join(storeDir, 'index.html'), { ...head, 'Cache-Control': 'no-cache' });
    if (path === '/favicon.svg' || path === '/robots.txt') return serveFile(req, res, join(storeDir, path.slice(1)), { ...head, 'Cache-Control': 'public, max-age=86400' });
    if (path.startsWith('/assets/')) {
      // Solo la carpeta de la tienda (nunca la del panel)
      const file = safeJoin(assetsDir, path.slice('/assets'.length));
      return !!file && serveFile(req, res, file, { ...head, 'Cache-Control': 'public, max-age=3600' });
    }
    return false;
  }

  // CORS solo para la API pública, y solo para los orígenes configurados
  function cors(ctx) {
    const origin = ctx.req.headers.origin;
    if (!origin || !config.storeOrigins.includes(origin) || !ctx.path.startsWith('/api/')) return false;
    ctx.res.setHeader('Access-Control-Allow-Origin', origin);
    ctx.res.setHeader('Vary', 'Origin');
    if (ctx.req.method === 'OPTIONS') {
      ctx.res.writeHead(204, { 'Access-Control-Allow-Methods': 'GET, POST', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '600' });
      ctx.res.end();
      return true;
    }
    return false;
  }

  function adminAllowed(ip) {
    if (!config.adminIps.length) return true;
    const clean = ip.replace(/^::ffff:/, '');
    return config.adminIps.includes(clean) || config.adminIps.includes(ip);
  }

  function httpsRequired(ctx) {
    if (ctx.path.startsWith(`${apiAdmin}/`)) throw new HttpError(403, 'El panel solo funciona con conexión segura (https).', 'https_required');
    ctx.res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8', ...securityHeaders('admin', { secure: false }) });
    ctx.res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Conexión no segura</title><div style="font-family:sans-serif;max-width:560px;margin:48px auto;padding:0 20px;line-height:1.5"><h1 style="font-size:22px">El panel necesita una conexión segura</h1><p>Por seguridad, el panel de administración solo se abre con <b>https://</b> (la dirección con candado). Así tu contraseña y los datos de los clientes viajan cifrados.</p><p>Escribe la dirección comenzando con <b>https://</b>. Si eres quien administra el servidor, revisa la sección «Publicarlo en internet» del README.</p></div>');
  }

  const notFound = (res, secure) => {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', ...securityHeaders('store', { secure }) });
    res.end('<!doctype html><meta charset="utf-8"><title>No encontrado</title><p style="font-family:sans-serif;padding:24px">Página no encontrada.</p>');
  };

  async function handle(req, res) {
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { res.writeHead(400); res.end(); return; }
    const path = url.pathname.replace(/\/{2,}/g, '/');
    const ip = clientIp(req, config.trustProxy);
    const secure = isSecure(req, config.trustProxy);
    const ctx = { req, res, url, path, ip, rk: rateKey(ip), secure };
    try {
      if (config.forceHttps && !secure) {
        const host = String(req.headers.host || '').replace(/[^\w.:-]/g, '');
        res.writeHead(308, { Location: `https://${host}${req.url}` });
        res.end();
        return;
      }
      if (limits.global.hit(ctx.rk)) throw new HttpError(429, 'Demasiadas solicitudes. Espera un momento.', 'rate_limited', { retryAfter: 60 });
      const isAdmin = path === adminPath || path.startsWith(`${adminPath}/`);
      // Panel en su propio subdominio: ahí solo existe el panel, y en la tienda no existe
      if (config.adminHost) {
        const onPanelHost = requestHost(req, config.trustProxy) === config.adminHost;
        if (onPanelHost && !isAdmin) {
          if (path === '/') { res.writeHead(302, { Location: `${adminPath}/` }); res.end(); return; }
          notFound(res, secure);
          return;
        }
        if (!onPanelHost && isAdmin) { notFound(res, secure); return; }
      }
      if (isAdmin && !adminAllowed(ip)) { notFound(res, secure); return; }
      // Desde internet, el panel solo funciona con conexión cifrada (https): así la
      // contraseña y los datos nunca viajan a la vista. En este computador o en la
      // red de la casa/oficina se permite http.
      if (isAdmin && !secure && !config.allowHttpPanel && !localClient(req, ip)) { httpsRequired(ctx); return; }
      if (cors(ctx)) return;
      for (const r of routes) {
        const m = r.pattern.exec(path);
        if (!m) continue;
        if (r.method !== req.method) continue;
        const head = r.kind === 'admin' ? securityHeaders('admin', { secure }) : { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin' };
        for (const [k, v] of Object.entries(head)) res.setHeader(k, v);
        await r.handler(ctx, m);
        return;
      }
      if (routes.some((r) => r.pattern.test(path))) throw new HttpError(405, 'Método no permitido.', 'method');
      if (path.startsWith('/api/') || path.startsWith(`${apiAdmin}/`)) throw new HttpError(404, 'No encontrado.', 'not_found');
      if (req.method === 'GET' || req.method === 'HEAD') {
        if (isAdmin ? serveAdminFiles(ctx) : serveStoreFiles(ctx)) return;
      }
      notFound(res, secure);
    } catch (err) {
      if (!res.headersSent) sendError(res, err);
      else res.end();
    }
  }

  return { handle, ensureFirstAdmin, shop, get setupToken() { return setupToken; }, close: () => clearInterval(sweep) };
}

// Inicia el servidor de Farmacias Piedra.
//   npm start            (o doble clic en "iniciar-servidor.bat" en Windows)
// Requiere Node.js 22.13 o más reciente (trae SQLite incluido).

import { createServer } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import { spawn } from 'node:child_process';
import { existsSync, readFileSync, chmodSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { loadConfig, ROOT } from './config.mjs';
import { openDb, createRepo } from './lib/db.mjs';
import { createApp } from './app.mjs';
import { loadKey, createKeyFile, makeCipher, KEY_FILE } from './lib/cifrado.mjs';

const VERSION = (() => { try { return JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8')).version; } catch { return ''; } })();

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`Necesitas Node.js 22.13 o más reciente (tienes ${process.versions.node}). Descárgalo en https://nodejs.org`);
  process.exit(1);
}

const config = loadConfig();
if (!existsSync(join(config.publicDir, 'index.html')) || !existsSync(join(config.publicDir, 'admin', 'index.html')) || !existsSync(join(config.privateDir, 'panel.js'))) {
  console.error('Faltan los archivos de la tienda y del panel. Ejecuta primero:  npm run build');
  process.exit(1);
}

// Los archivos que crea el servidor (base de datos, llave, respaldos) solo los
// puede leer el usuario que lo ejecuta
try { process.umask(0o077); } catch { /* Windows */ }
mkdirSync(config.dataDir, { recursive: true });
try { chmodSync(config.dataDir, 0o700); } catch { /* Windows */ }

const dbFile = join(config.dataDir, 'farmacia.db');
const db = openDb(dbFile);
try { chmodSync(dbFile, 0o600); } catch { /* Windows */ }

// ── Llave de cifrado de los datos delicados ──────────────────
let keyInfo;
let newKey = false;
try {
  keyInfo = loadKey(config.dataDir, config.dataKey);
} catch (e) {
  console.error(`\n  ${e.message}\n`);
  process.exit(1);
}
const plainRepo = createRepo(db);
if (!keyInfo) {
  if (plainRepo.hasEncrypted()) {
    console.error('');
    console.error(`  Falta la llave de cifrado (${join(config.dataDir, KEY_FILE)}).`);
    console.error('  Los pedidos, recetas y claves guardados están cifrados y sin esa llave no se pueden leer.');
    console.error('  Copia de vuelta el archivo clave-cifrado.key desde tu respaldo (o define DATA_KEY) y vuelve a iniciar.');
    console.error('');
    process.exit(1);
  }
  keyInfo = createKeyFile(config.dataDir);
  newKey = true;
}
const repo = createRepo(db, { cipher: makeCipher(keyInfo.key) });
if (!repo.keyMatches()) {
  console.error('');
  console.error('  La llave de cifrado no corresponde a estos datos (¿copiaste la llave de otra instalación?).');
  console.error(`  Revisa ${keyInfo.source === 'env' ? 'la variable DATA_KEY' : keyInfo.source}.`);
  console.error('');
  process.exit(1);
}
const moved = repo.encryptExisting();
const app = createApp({ config, repo, log: { info: (m) => console.log(m), warn: (m) => console.warn(m) } });
const first = await app.ensureFirstAdmin();

// https directo (si se indicó el certificado); si no, http (detrás de un proxy con https o en este equipo)
const tls = config.tlsCert && config.tlsKey;
let server;
try {
  server = tls
    ? createHttpsServer({ cert: readFileSync(config.tlsCert), key: readFileSync(config.tlsKey), minVersion: 'TLSv1.2' }, (req, res) => { app.handle(req, res); })
    : createServer((req, res) => { app.handle(req, res); });
} catch (e) {
  console.error(`\n  No se pudo leer el certificado https (TLS_CERT / TLS_KEY): ${e.message}\n`);
  process.exit(1);
}
server.headersTimeout = 30000;
server.requestTimeout = 60000;
server.keepAliveTimeout = 5000;

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    const shown = config.host === '0.0.0.0' ? 'localhost' : config.host;
    console.error(`\n  NO SE PUDO ABRIR esta versión (${VERSION}): el puerto ${config.port} ya está ocupado.`);
    console.error('  Ya hay otro servidor de Farmacias Piedra abierto, y puede ser una COPIA ANTERIOR del programa.');
    console.error('  Qué hacer:');
    console.error('    1. Cierra la otra ventana negra de "Farmacias Piedra - Servidor".');
    console.error('    2. Vuelve a abrir iniciar-servidor de ESTA carpeta:');
    console.error(`       ${ROOT}`);
    console.error(`  (Si quieres usar las dos a la vez, cambia el puerto con PORT en el archivo .env)\n`);
  } else {
    console.error('\n  No se pudo iniciar el servidor:', err.message, '\n');
  }
  try { db.close(); } catch { /* ya cerrada */ }
  setTimeout(() => process.exit(1), 300);
});

// Con https directo, el puerto http (por ejemplo 80) solo redirige a https
if (tls && config.httpRedirectPort) {
  const redirect = createServer((req, res) => {
    const host = String(req.headers.host || '').replace(/:\d+$/, '').replace(/[^\w.-]/g, '');
    res.writeHead(308, { Location: `https://${host}${config.port === 443 ? '' : `:${config.port}`}${req.url}` });
    res.end();
  });
  redirect.on('error', (e) => console.warn(`  No se pudo abrir el puerto ${config.httpRedirectPort} para redirigir a https: ${e.message}`));
  redirect.listen(config.httpRedirectPort, config.host);
}

server.listen(config.port, config.host, () => {
  const shown = config.host === '0.0.0.0' ? 'localhost' : config.host;
  const base = `${tls ? 'https' : 'http'}://${shown}:${config.port}`;
  const panelBase = config.adminHost ? `https://${config.adminHost}` : base;
  console.log('');
  console.log(`  Farmacias Piedra está funcionando · versión ${VERSION}`);
  console.log(`    Carpeta: ${ROOT}`);
  console.log(`    Tienda:  ${config.storeUrl || `${base}/`}`);
  console.log(`    Panel:   ${panelBase}${config.adminPath}/`);
  console.log(`    Datos:   ${dbFile} (datos de clientes y recetas cifrados)`);
  if (moved.orders || moved.files) {
    console.log(`    Se cifraron ${moved.orders} pedidos y ${moved.files} recetas que estaban guardados de antes.`);
    console.log('    Ojo: los respaldos hechos ANTES de esta versión (carpeta respaldos/) no están cifrados.');
    console.log('    Haz un respaldo nuevo (respaldar-datos) y borra los antiguos que tengas fuera del computador.');
  }
  if (newKey) {
    console.log('');
    console.log('  IMPORTANTE: se creó la llave de cifrado de tus datos:');
    console.log(`    ${keyInfo.source}`);
    console.log('  Guarda una copia de ese archivo en un lugar seguro (por ejemplo un pendrive).');
    console.log('  Sin ella, los respaldos no se pueden leer. No la compartas ni la subas a internet.');
  }
  if (!first.ready) {
    console.log('');
    console.log('  Primera vez: crea tu usuario de administrador en este enlace');
    console.log('  (solo funciona hasta que crees el primero; no lo compartas):');
    console.log(`    ${panelBase}${config.adminPath}/#/primer-acceso?clave=${first.setupToken}`);
    if (process.env.PORT && !config.adminHost) console.log('    (en un hosting, cambia el comienzo por la dirección de tu sitio)');
  }
  console.log('');
  console.log('  Para detenerlo, cierra esta ventana o presiona Ctrl + C.');
  console.log('');
  // Al iniciar con doble clic (iniciar-servidor.bat) se abre el navegador
  if (process.env.OPEN_BROWSER === '1') openBrowser(first.ready ? `${base}${config.adminPath}/` : `${base}${config.adminPath}/#/primer-acceso?clave=${first.setupToken}`);
});

function openBrowser(url) {
  if (!/^https?:\/\/[\w.:-]+\/[\w\-/#?=.]*$/.test(url)) return;
  const [cmd, args] = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]]
    : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try {
    const child = spawn(cmd, args, { stdio: 'ignore', detached: true, windowsHide: true });
    child.on('error', () => {});
    child.unref();
  } catch { /* sin navegador: se usa la dirección que aparece arriba */ }
}

function shutdown() {
  server.close(() => {
    app.close();
    try { db.close(); } catch { /* ya cerrada */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

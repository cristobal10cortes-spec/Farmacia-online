// ─────────────────────────────────────────────────────────────
//  CONFIGURACIÓN CENTRAL — Farmacias Piedra
//  Todo lo que es "de la marca" o "del negocio" está aquí.
//  Cambia nombre, contacto, reglas de despacho, cupones y
//  campañas sin tocar el resto del código.
// ─────────────────────────────────────────────────────────────

export const BRAND = {
  name: 'Piedra',
  fullName: 'Farmacias Piedra',
  tagline: 'Tu farmacia, firme y cerca',
  // Sitio de demostración: se muestra un aviso discreto en el sitio.
  demo: true,
  demoNote: 'Sitio de demostración: precios, stock, farmacias y pedidos son de ejemplo.',
  // Datos de contacto (reemplazar por los reales)
  phone: '600 000 0000',
  phoneMobile: '*0000 desde celulares',
  whatsapp: '+56 9 0000 0000',
  email: 'contacto@farmaciaspiedra.cl',
  hours: 'Lunes a domingo, 8:00 a 22:00',
  techDirector: 'Q.F. por definir',
  legalName: 'Farmacias Piedra SpA',
  year: 2026,
};

// Zonas de despacho (cada región pertenece a una zona; ver data/regions.js)
export const ZONES = {
  RM: { name: 'Región Metropolitana', shipping: 2990, freeFrom: 29990, days: 1 },
  CENTRO: { name: 'Zona centro', shipping: 3990, freeFrom: 49990, days: 2 },
  NORTE: { name: 'Zona norte', shipping: 4990, freeFrom: 49990, days: 3 },
  SUR: { name: 'Zona sur', shipping: 4990, freeFrom: 49990, days: 3 },
  AUSTRAL: { name: 'Zona austral', shipping: 6990, freeFrom: 59990, days: 5 },
};

export const RULES = {
  maxQty: 10, // unidades máximas por producto
  maxQtyRx: 6, // unidades máximas por producto con receta
  expressCost: 4990, // despacho express (3 horas), solo comunas habilitadas
  expressCutoffHour: 18, // hasta esta hora se puede pedir express para hoy
  pickupReadyHours: 2, // tiempo de preparación para retiro en farmacia
  stockLagMinutes: 30, // desfase informado del stock por farmacia
  // Comunas con despacho express
  expressComunas: [
    'Santiago', 'Providencia', 'Las Condes', 'Vitacura', 'Ñuñoa', 'La Reina', 'Lo Barnechea',
    'San Miguel', 'Macul', 'Peñalolén', 'La Florida', 'Maipú', 'Estación Central',
    'Independencia', 'Recoleta', 'Huechuraba', 'Quinta Normal', 'San Joaquín',
  ],
  // Comunas sin cobertura de despacho a domicilio (solo retiro, si hay farmacia)
  noDeliveryComunas: [
    'Isla de Pascua', 'Juan Fernández', 'Antártica', 'General Lagos', 'Ollagüe', 'Colchane',
    'Camarones', 'Putre', 'Tortel', "O'Higgins", 'Lago Verde', 'Guaitecas', 'Cabo de Hornos',
    'Timaukel', 'Laguna Blanca', 'Río Verde', 'Primavera', 'San Gregorio',
  ],
  // Productos refrigerados: solo despacho a domicilio en estas zonas
  coldChainZones: ['RM'],
  defaultLocation: { region: 'RM', comuna: 'Santiago' },
};

// Condición de venta (normativa chilena)
export const RX = {
  directa: { label: 'Venta directa', short: 'Venta directa', tone: 'ok',
    info: 'Producto disponible para venta sin receta.' },
  simple: { label: 'Receta médica', short: 'Receta', tone: 'warn',
    info: 'Requiere receta médica. Deberás adjuntar una foto o PDF de tu receta al comprar.' },
  retenida: { label: 'Receta retenida', short: 'Receta retenida', tone: 'danger',
    info: 'Requiere receta médica retenida: adjunta tu receta al comprar y entrega el original al recibir o retirar.' },
  cheque: { label: 'Receta cheque', short: 'Receta cheque', tone: 'danger',
    info: 'Venta solo presencial en farmacia, con receta cheque.' },
};

// Club Piedra: beneficios por día de la semana (0 = domingo … 6 = sábado)
export const CLUB = {
  name: 'Club Piedra',
  treatmentPct: 15, // Programa Mi Tratamiento: descuento permanente en productos inscritos
  treatmentMax: 5, // máximo de productos inscritos
  campaigns: [
    { id: 'martes-vital', days: [2], pct: 15, cats: ['vitaminas-y-suplementos'],
      title: 'Martes Vital', text: '15% Club en vitaminas y suplementos' },
    { id: 'jueves-dermo', days: [4], pct: 20, cats: ['dermocosmetica'],
      title: 'Jueves Dermo', text: '20% Club en toda la dermocosmética' },
    { id: 'sabado-familia', days: [6], pct: 15, cats: ['infantil-y-mama'],
      title: 'Sábado en Familia', text: '15% Club en infantil y mamá' },
    { id: 'lunes-cuidado', days: [1], pct: 10, cats: ['cuidado-personal', 'belleza'],
      title: 'Lunes de Cuidado', text: '10% Club en cuidado personal y belleza' },
  ],
};

// Cupones de descuento
export const COUPONS = [
  { code: 'BIENVENIDA10', type: 'pct', value: 10, max: 5000, minAmount: 0, firstOrder: true,
    excludeRx: true, text: '10% en tu primera compra (tope $5.000, no aplica a medicamentos con receta).' },
  { code: 'PIEDRA5000', type: 'amount', value: 5000, minAmount: 40000, excludeRx: true,
    text: '$5.000 de descuento en compras sobre $40.000 (no aplica a medicamentos con receta).' },
  { code: 'DESPACHOGRATIS', type: 'shipping', minAmount: 15000,
    text: 'Despacho gratis en compras sobre $15.000.' },
];

// Mensajes de la barra superior (rotan)
// Asistente de ayuda: la ventanita de la esquina inferior derecha
export const HELPBOT = {
  name: 'Asistente Piedra',
  // Frases que va diciendo, una tras otra (la de la página actual se suma sola)
  teasers: [
    '¿Necesitas ayuda?',
    '¿Lo puedo asesorar en algo?',
    '¿Tienes algún síntoma? Te puedo orientar.',
    '¿Buscas un remedio? Escríbelo aunque no sepas cómo se escribe.',
    '¿Quieres saber dónde está tu pedido?',
    '¿Necesitas una farmacia de turno?',
  ],
  every: 5500, // milisegundos que se queda cada frase
};

export const TOPBAR_MESSAGES = [
  { text: 'Despacho gratis en la RM sobre $29.990', to: '/ayuda/despacho' },
  { text: 'Retira en tu farmacia en 2 horas, sin costo', to: '/farmacias' },
  { text: 'Bioequivalentes: el mismo efecto, a menor precio', to: '/bioequivalentes' },
  { text: 'Únete al Club Piedra y ahorra todas las semanas', to: '/club' },
];

// Búsquedas populares (se muestran al enfocar el buscador)
export const POPULAR_SEARCHES = [
  'paracetamol', 'protector solar', 'loratadina', 'vitamina c', 'pañales', 'omeprazol', 'ibuprofeno', 'magnesio',
];

// Enrutador con rutas en el "hash" (#/producto/…). Funciona abriendo el archivo
// directamente, en cualquier hosting estático y dentro de un visor embebido
// (si el historial no está disponible, la navegación sigue en memoria).

const routes = [];
let current = '/';
let renderFn = null;

export function route(pattern, handler) {
  const keys = [];
  const src = pattern.replace(/\/:([a-zA-Z]+)(\?)?/g, (_, k, opt) => {
    keys.push(k);
    return opt ? '(?:/([^/]+))?' : '/([^/]+)';
  });
  routes.push({ re: new RegExp(`^${src}/?$`), keys, handler });
}

export function parse(to) {
  const i = to.indexOf('?');
  const path = (i >= 0 ? to.slice(0, i) : to) || '/';
  const qs = i >= 0 ? to.slice(i + 1) : '';
  const query = {};
  for (const [k, v] of new URLSearchParams(qs)) query[k] = v;
  return { path, query };
}

export function match(path) {
  for (const r of routes) {
    const m = path.match(r.re);
    if (m) {
      const params = {};
      r.keys.forEach((k, i) => { params[k] = m[i + 1] ? decodeURIComponent(m[i + 1]) : undefined; });
      return { handler: r.handler, params };
    }
  }
  return null;
}

// Construye una ruta con parámetros (omite vacíos)
export function href(path, query = {}) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (v === undefined || v === null || v === '' || v === false || (Array.isArray(v) && !v.length)) continue;
    qs.set(k, Array.isArray(v) ? v.join('|') : String(v));
  }
  const s = qs.toString();
  return s ? `${path}?${s}` : path;
}

function fromHash() {
  let h = '';
  try { h = decodeURIComponent((window.location.hash || '').slice(1)); } catch { h = (window.location.hash || '').slice(1); }
  if (h.startsWith('/')) return h;
  if (h && /^[a-z0-9._~-]+$/i.test(h) && h !== 'main') return `/${h}`;
  return '/';
}

export function go(to, { replace = false, scroll = true } = {}) {
  const next = to.startsWith('/') ? to : `/${to}`;
  const same = next === current;
  current = next;
  try {
    window.history[replace || same ? 'replaceState' : 'pushState']({ to: current }, '', `#${current}`);
  } catch {
    /* sin historial (visor embebido): seguimos en memoria */
  }
  renderFn?.(current, { scroll, replace });
}

export const currentRoute = () => current;

export function start(render) {
  renderFn = render;
  current = fromHash();
  window.addEventListener('popstate', (e) => {
    current = e.state?.to || fromHash();
    render(current, { scroll: false, pop: true });
  });
  window.addEventListener('hashchange', () => {
    const h = fromHash();
    if (h !== current) {
      current = h;
      render(current, { scroll: true });
    }
  });
  render(current, { scroll: false, initial: true });
}

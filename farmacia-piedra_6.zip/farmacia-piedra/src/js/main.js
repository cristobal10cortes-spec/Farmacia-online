// Punto de entrada de la TIENDA pública: arma la página, registra las rutas y
// conecta los eventos. El panel de administración es otra aplicación
// (src/js/admin/main.js) que vive en el servidor, separada de la tienda.

import { route, start, go, parse, match } from './router.js';
import { headerHtml, mountHeader, updateHeader, setActiveNav, openLocation, openMobileMenu, openCart, refreshCartDrawer, toggleMega, closeMega, closeAc, setSearchValue } from './ui/header.js';
import { footerHtml, mountFooter, updatePromises } from './ui/footer.js';
import { mountHelpbot, openHelpbot, helpbotRoute } from './ui/helpbot.js';
import { homePage } from './pages/home.js';
import { listingPage } from './pages/listing.js';
import { productPage } from './pages/product.js';
import { cartPage } from './pages/cart.js';
import { checkoutPage } from './pages/checkout.js';
import { orderPage, trackingPage } from './pages/order.js';
import { loginPage, registerPage, accountPage } from './pages/account.js';
import { storesPage } from './pages/stores.js';
import { quotePage } from './pages/quote.js';
import { clubPage, bioPage, brandsPage, helpPage, legalPage, notFoundPage } from './pages/info.js';
import { on, state, emit } from './engine/state.js';
import { addToCart, setQty, qtyOf, toggleFav, isFav, maxQty } from './engine/shop.js';
import { byId, productIndex } from './engine/catalog.js';
import { initDataSource, ds } from './engine/datasource.js';
import { cartControl } from './ui/components.js';
import { installFormSubmit } from './ui/forms.js';
import { toast, closeAll } from './ui/overlay.js';
import { esc } from './ui/dom.js';
import { icon } from './ui/icons.js';
import { BRAND } from './config.js';

// ── Rutas ────────────────────────────────────────────────────
route('/', () => homePage());
route('/buscar', (p, q) => listingPage({ kind: 'search', query: q, basePath: '/buscar' }));
route('/categoria/:cat/:sub?', (p, q) => listingPage({ kind: 'category', params: p, query: q, basePath: `/categoria/${p.cat}${p.sub ? `/${p.sub}` : ''}` }));
route('/ofertas', (p, q) => listingPage({ kind: 'ofertas', query: q, basePath: '/ofertas' }));
route('/bioequivalentes/todos', (p, q) => listingPage({ kind: 'bioequivalentes', query: q, basePath: '/bioequivalentes/todos' }));
route('/bioequivalentes', bioPage);
route('/producto/:slug', productPage);
route('/carro', cartPage);
route('/checkout', checkoutPage);
route('/pedido/:id', orderPage);
route('/seguimiento', trackingPage);
route('/ingresar', loginPage);
route('/registro', registerPage);
route('/cuenta/:tab?', accountPage);
route('/farmacias', storesPage);
route('/club', clubPage);
route('/cotizar-receta', quotePage);
route('/marcas', brandsPage);
route('/ayuda/:section?', helpPage);
route('/legal/:doc', legalPage);

// ── Armado de la página ──────────────────────────────────────
const app = document.getElementById('app');
app.innerHTML = `${headerHtml()}<main id="main" tabindex="-1"></main>${footerHtml()}<div id="overlays"></div><div id="toasts" aria-live="polite"></div>`;
mountHeader();
mountFooter();
mountHelpbot();

let current = null;

function render(to, opts = {}) {
  const { path, query } = parse(to);
  const m = match(path);
  let page = null;
  try {
    page = m ? m.handler(m.params, query, to) : null;
  } catch (err) {
    console.error(err);
    page = null;
  }
  if (page && page.redirect) { go(page.redirect, { replace: true }); return; }
  if (!page) page = notFoundPage();
  try { current?.cleanup?.(); } catch (e) { console.error(e); }
  if (!opts.rerender) { closeAll(); closeMega(); closeAc(); }
  // Cada vista se monta en un <main> nuevo: así los eventos de la vista anterior
  // desaparecen con su elemento y nunca se acumulan.
  const old = document.getElementById('main');
  const main = old.cloneNode(false);
  main.innerHTML = page.html;
  old.replaceWith(main);
  document.title = `${page.title} | ${BRAND.fullName}`;
  setActiveNav(path);
  helpbotRoute(path);
  if (!opts.rerender) setSearchValue(page.searchValue ?? '');
  let cleanup = null;
  try { cleanup = page.mount?.(main) || null; } catch (e) { console.error(e); }
  current = { page, cleanup, to, path };
  if (opts.scroll !== false && !opts.rerender) window.scrollTo(0, 0);
  if (!opts.initial && !opts.pop && !opts.rerender && opts.scroll !== false) main.focus({ preventScroll: true });
}

function rerenderCurrent() {
  if (!current) return;
  const y = window.scrollY;
  render(current.to, { scroll: false, rerender: true });
  window.scrollTo(0, y);
}

// ── Actualizaciones parciales ────────────────────────────────
function updateCartSlots(changedId) {
  const active = document.activeElement;
  const slotEl = active?.closest?.('[data-cart-slot]');
  const focusId = slotEl?.dataset.cartSlot;
  const focusAction = active?.dataset?.action;
  document.querySelectorAll('[data-cart-slot]').forEach((el) => {
    if (changedId && el.dataset.cartSlot !== changedId) return;
    const p = byId.get(el.dataset.cartSlot);
    if (!p) return;
    const html = cartControl(p);
    if (el.innerHTML !== html) el.innerHTML = html;
  });
  if (focusId && !document.activeElement?.closest?.('[data-cart-slot]')) {
    const slot = document.querySelector(`[data-cart-slot="${focusId}"]`);
    const target = slot?.querySelector(focusAction === 'qty-dec' && qtyOf(focusId) ? '[data-action="qty-dec"]' : '[data-action="qty-inc"], [data-action="add"]');
    target?.focus({ preventScroll: true });
  }
}

function updateFavButtons() {
  document.querySelectorAll('.fav[data-id]').forEach((b) => {
    const onState = isFav(b.dataset.id);
    b.classList.toggle('is-on', onState);
    b.setAttribute('aria-pressed', String(onState));
    b.setAttribute('aria-label', onState ? 'Quitar de favoritos' : 'Guardar en favoritos');
  });
}

on('*', (evt, data) => {
  updateHeader();
  if (evt === 'cart') { updateCartSlots(data?.id); refreshCartDrawer(); }
  if (evt === 'favorites') updateFavButtons();
  if (evt === 'location' || evt === 'user' || evt === 'catalog') { updateCartSlots(); refreshCartDrawer(); }
  if (evt === 'catalog') updatePromises();
  const page = current?.page;
  if (!page) return;
  if (page.onState?.(evt)) return;
  const triggers = page.rerender || ['user', 'location', 'catalog'];
  if (triggers.includes(evt)) rerenderCurrent();
});

// ── Clics globales ───────────────────────────────────────────
document.addEventListener('click', (e) => {
  if (e.defaultPrevented) return;
  const t = e.target;
  if (t.closest('[data-skip]')) {
    e.preventDefault();
    document.getElementById('main').focus();
    return;
  }
  const a = t.closest('a[href^="#/"]');
  if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && a.target !== '_blank') {
    e.preventDefault();
    go(a.getAttribute('href').slice(1));
    return;
  }
  const act = t.closest('[data-action]');
  if (!act) return;
  const id = act.dataset.id;
  switch (act.dataset.action) {
    case 'add': {
      const p = byId.get(id);
      if (!p) return;
      if (p.rx === 'cheque') { toast('Este medicamento es de receta cheque: solo se vende en farmacia.', { tone: 'warn' }); break; }
      if (p.hidden) { toast('Este producto no está disponible por ahora.', { tone: 'warn' }); break; }
      const before = qtyOf(id);
      const after = addToCart(id, 1);
      if (after > before) toast(`Agregaste <b>${esc(p.name)}</b> al carro`, { actionText: 'Ver carro', onAction: () => go('/carro') });
      else toast(`Puedes llevar hasta ${maxQty(p)} unidades de este producto.`, { tone: 'warn' });
      break;
    }
    case 'qty-inc': {
      const p = byId.get(id);
      if (qtyOf(id) >= maxQty(p)) { toast(`Puedes llevar hasta ${maxQty(p)} unidades de este producto.`, { tone: 'warn' }); break; }
      setQty(id, qtyOf(id) + 1);
      break;
    }
    case 'qty-dec': setQty(id, qtyOf(id) - 1); break;
    case 'fav': {
      const onState = toggleFav(id);
      toast(onState ? 'Guardado en favoritos' : 'Quitado de favoritos', { tone: onState ? 'ok' : 'info', actionText: onState ? 'Ver favoritos' : '', onAction: () => go('/cuenta/favoritos') });
      break;
    }
    case 'open-cart': openCart(); break;
    case 'open-location': openLocation(); break;
    case 'open-menu': openMobileMenu(); break;
    case 'toggle-mega': toggleMega(); break;
    case 'open-assistant': openHelpbot(); break;
    case 'rail-prev':
    case 'rail-next': {
      const tr = document.getElementById(act.dataset.rail);
      if (tr) tr.scrollBy({ left: (act.dataset.action === 'rail-next' ? 1 : -1) * tr.clientWidth * 0.9, behavior: 'smooth' });
      break;
    }
    default:
  }
});

// ── Envío de formularios (también dentro de visores que lo bloquean) ──
installFormSubmit();

// Atajo de teclado: "/" enfoca el buscador
document.addEventListener('keydown', (e) => {
  if (e.key === '/' && !e.target.closest?.('input, textarea, select, [contenteditable]')) {
    e.preventDefault();
    document.getElementById('q')?.focus();
  }
});

start(render);

// Stock, precios, productos nuevos y banners que administra el dueño (solo lectura)
initDataSource();

// Primera visita: avisamos qué comuna se está usando (sin bloquear la página)
if (!state.seenLocation) {
  setTimeout(() => {
    state.seenLocation = true;
    emit('seen');
    toast(`Te mostramos stock y entregas para <b>${esc(state.location.comuna)}</b>.`, { tone: 'info', actionText: 'Cambiar comuna', onAction: () => openLocation({ first: true }), timeout: 7000 });
  }, 1400);
}

// Acceso para pruebas y depuración desde la consola
window.Piedra = { state, go, icon, ds, get productIndex() { return productIndex; } };

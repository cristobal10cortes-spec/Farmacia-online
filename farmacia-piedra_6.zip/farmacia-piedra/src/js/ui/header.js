// Encabezado: barra superior, logo, buscador con autocompletar, ubicación,
// cuenta, carro, menú de categorías (escritorio) y menú lateral (celular).

import { $, $$, esc, debounce } from './dom.js';
import { icon } from './icons.js';
import { logo } from './logo.js';
import { productImg } from './art.js';
import { highlight } from '../engine/text.js';
import { subsOf } from '../engine/catalog.js';
import { BRAND, TOPBAR_MESSAGES, POPULAR_SEARCHES, RULES } from '../config.js';
import { CATEGORIES, categoryById } from '../data/categories.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { STORES } from '../data/stores.js';
import { state, currentUser, on } from '../engine/state.js';
import { cartCount, totals, addRecent, clearRecent, setLocation, cartItems, setQty } from '../engine/shop.js';
import { clp } from '../engine/format.js';
import { freeShippingFrom, PROMO_LABEL } from '../engine/pricing.js';
import { liveMenu } from '../engine/datasource.js';
import { menuCardsHtml } from './megacards.js';
import { zoneOf } from '../engine/inventory.js';
import { suggest, noteHtml } from './searchui.js';
import { openModal, openDrawer, toast } from './overlay.js';
import { go } from '../router.js';
import { stepper } from './components.js';

const CAT_LINKS = [
  ['medicamentos', 'Medicamentos'],
  ['dermocosmetica', 'Dermocosmética'],
  ['vitaminas-y-suplementos', 'Vitaminas'],
  ['infantil-y-mama', 'Infantil y mamá'],
  ['cuidado-personal', 'Cuidado personal'],
];

export function headerHtml() {
  const msg = TOPBAR_MESSAGES[0];
  return `<a class="skip" href="#main" data-skip>Saltar al contenido</a>
  <div class="topbar"><div class="wrap topbar__inner">
    <div class="topbar__msg" id="topmsg">${icon('sparkle')}<a href="#${msg.to}" data-link>${esc(msg.text)}</a></div>
    <div class="topbar__links">
      <a href="#/seguimiento" data-link>${icon('box')}Sigue tu pedido</a>
      <a href="#/cotizar-receta" data-link>${icon('file')}Cotiza tu receta</a>
      <a href="#/farmacias" data-link>${icon('store')}Farmacias</a>
      <a href="#/ayuda/contacto" data-link>${icon('phone')}Venta telefónica</a>
      ${BRAND.demo ? `<span class="demo-pill" title="${esc(BRAND.demoNote)}">${icon('info')}Sitio de demostración</span>` : ''}
    </div>
  </div></div>
  <header class="hdr" id="hdr">
    <div class="wrap hdr__row">
      <button type="button" class="icon-btn hdr__menu" data-action="open-menu" aria-label="Abrir menú">${icon('menu')}</button>
      <a class="hdr__logo" href="#/" data-link aria-label="${esc(BRAND.fullName)}, ir al inicio">${logo()}</a>
      <form class="search" id="search" role="search" autocomplete="off" novalidate>
        <label class="visually-hidden" for="q">Buscar productos</label>
        <div class="search__box">
          ${icon('search', 'search__ico')}
          <input id="q" name="q" type="search" placeholder="Busca productos, marcas o síntomas" role="combobox" aria-autocomplete="list" aria-controls="ac" aria-expanded="false" enterkeyhint="search" spellcheck="false" autocapitalize="off">
          <button type="button" class="icon-btn search__clear" data-action="clear-search" aria-label="Borrar búsqueda" hidden>${icon('x')}</button>
          <button type="submit" class="btn btn--primary search__go">Buscar</button>
        </div>
        <div class="ac" id="ac" role="listbox" aria-label="Sugerencias de búsqueda" hidden></div>
      </form>
      <div class="hdr__actions">
        <button type="button" class="hdr-act hdr-act--loc" data-action="open-location" aria-label="Cambiar comuna">${icon('pin')}<span class="hdr-act__txt"><small>Stock y entrega en</small><b class="js-loc">${esc(state.location.comuna)}</b></span></button>
        <a class="hdr-act" id="acct-link" href="#/cuenta" data-link>${icon('user')}<span class="hdr-act__txt"><small id="acct-small">Hola,</small><b id="acct-label">Ingresa</b></span></a>
        <a class="hdr-act hdr-act--fav" href="#/cuenta/favoritos" data-link aria-label="Favoritos">${icon('heart')}<span class="hdr-act__txt"><small>Tus</small><b>Favoritos</b></span></a>
        <button type="button" class="hdr-act hdr-cart" data-action="open-cart" aria-label="Abrir carro">${icon('bag')}<span class="hdr-cart__count" id="cart-count" data-n="0">0</span><span class="hdr-act__txt"><small>Tu carro</small><b id="cart-total">$0</b></span></button>
      </div>
    </div>
    <button type="button" class="hdr__loc-m" data-action="open-location">${icon('pin')}<span>Stock y entrega en <b class="js-loc">${esc(state.location.comuna)}</b></span>${icon('chevronRight')}</button>
  </header>
  <nav class="catnav" id="catnav" aria-label="Categorías">
    <div class="wrap catnav__inner">
      <button type="button" class="catnav__all" data-action="toggle-mega" aria-expanded="false" aria-controls="mega">${icon('menu')}Categorías</button>
      <a href="#/ofertas" data-link class="catnav__sale" data-nav="/ofertas">${icon('percent')}Ofertas</a>
      ${CAT_LINKS.map(([id, name]) => `<a href="#/categoria/${id}" data-link data-nav="/categoria/${id}">${esc(name)}</a>`).join('')}
      <a href="#/bioequivalentes" data-link data-nav="/bioequivalentes" class="hide-lg">Bioequivalentes</a>
      <span class="catnav__spacer"></span>
      <a href="#/club" data-link class="catnav__club" data-nav="/club">${icon('star')}Club Piedra</a>
      <a href="#/farmacias?turno=1" data-link data-nav="/farmacias">${icon('clock')}Farmacias de turno</a>
      <a href="#/cotizar-receta" data-link data-nav="/cotizar-receta" class="hide-xl">${icon('file')}Cotiza tu receta</a>
    </div>
    <div class="mega" id="mega" hidden>${megaHtml(CATEGORIES[0].id)}</div>
  </nav>`;
}

function megaSubsHtml(c) {
  return `<h3>${esc(c.name)}</h3>
      <div class="mega__grid">${subsOf(c).map((s) => `<a href="#/categoria/${c.id}/${s.id}" data-link>${esc(s.name)}</a>`).join('')}</div>
      <a class="link-more" href="#/categoria/${c.id}" data-link>Ver todo en ${esc(c.name)} ${icon('arrowRight')}</a>`;
}

function megaHtml(active) {
  const c = categoryById(active);
  return `<div class="wrap mega__inner">
    <ul class="mega__cats">${CATEGORIES.map((x) => `<li><a class="mega__cat${x.id === active ? ' is-on' : ''}" href="#/categoria/${x.id}" data-link data-mega-cat="${x.id}">${icon(x.icon)}<span>${esc(x.name)}</span>${icon('chevronRight')}</a></li>`).join('')}</ul>
    <div class="mega__subs">${megaSubsHtml(c)}</div>
    <div class="mega__promo" aria-label="Destacados">${menuCardsHtml(liveMenu())}</div>
  </div>`;
}

/** Tarjetas de color del menú: se arman de nuevo al abrirlo y cuando el dueño las cambia. */
function renderMegaPromo() {
  const box = $('#mega .mega__promo');
  if (box) box.innerHTML = menuCardsHtml(liveMenu());
}

// ── Actualizaciones del encabezado ───────────────────────────
export function updateHeader() {
  const n = cartCount();
  const c = $('#cart-count');
  if (c) {
    if (String(n) !== c.dataset.n && n > Number(c.dataset.n || 0)) {
      const btn = c.closest('.hdr-cart');
      btn.classList.remove('bump');
      void btn.offsetWidth;
      btn.classList.add('bump');
    }
    c.textContent = n > 99 ? '99+' : String(n);
    c.dataset.n = String(n);
  }
  const t = $('#cart-total');
  if (t) t.textContent = clp(totals().total);
  const u = currentUser();
  const small = $('#acct-small');
  const label = $('#acct-label');
  if (small && label) {
    small.textContent = u ? 'Hola,' : 'Hola,';
    label.textContent = u ? u.nombre.split(' ')[0] : 'Ingresa';
  }
  $$('.js-loc').forEach((el) => { el.textContent = state.location.comuna; });
}

export function setActiveNav(path) {
  $$('.catnav [data-nav]').forEach((a) => {
    const nav = a.dataset.nav;
    a.classList.toggle('is-active', path === nav || path.startsWith(`${nav}/`));
  });
}

// ── Montaje ──────────────────────────────────────────────────
export function mountHeader() {
  rotateTopbar();
  mountSearch();
  mountMega();
  const hdr = $('#hdr');
  const onScroll = () => hdr.classList.toggle('is-scrolled', window.scrollY > 8);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  updateHeader();
}

function rotateTopbar() {
  const box = $('#topmsg');
  if (!box || TOPBAR_MESSAGES.length < 2) return;
  let i = 0;
  setInterval(() => {
    if (document.hidden) return;
    i = (i + 1) % TOPBAR_MESSAGES.length;
    const m = TOPBAR_MESSAGES[i];
    const a = $('a', box);
    a.style.opacity = '0';
    setTimeout(() => {
      a.textContent = m.text;
      a.setAttribute('href', `#${m.to}`);
      a.style.opacity = '1';
    }, 220);
  }, 6000);
  $('a', box).style.transition = 'opacity .2s';
}

// ── Menú grande de categorías ────────────────────────────────
let megaOpen = false;
function mountMega() {
  const mega = $('#mega');
  const btn = $('[data-action="toggle-mega"]');
  if (!mega || !btn) return;
  on('menu', renderMegaPromo);
  let leaveT;
  // Al pasar sobre una categoría solo cambia la columna de subcategorías
  // (la lista de la izquierda no se reemplaza, así el clic siempre funciona).
  const showCat = (a) => {
    if (!a || a.classList.contains('is-on')) return;
    mega.querySelectorAll('[data-mega-cat]').forEach((x) => x.classList.toggle('is-on', x === a));
    const subs = mega.querySelector('.mega__subs');
    if (subs) subs.innerHTML = megaSubsHtml(categoryById(a.dataset.megaCat));
  };
  mega.addEventListener('mouseover', (e) => showCat(e.target.closest('[data-mega-cat]')));
  mega.addEventListener('focusin', (e) => showCat(e.target.closest('[data-mega-cat]')));
  const nav = $('#catnav');
  nav.addEventListener('mouseleave', () => { leaveT = setTimeout(closeMega, 260); });
  nav.addEventListener('mouseenter', () => clearTimeout(leaveT));
  btn.addEventListener('mouseenter', () => {
    if (!window.matchMedia('(hover: hover)').matches || megaOpen) return;
    openMega();
    hoverOpenedAt = Date.now();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && megaOpen) { closeMega(); btn.focus(); } });
  document.addEventListener('click', (e) => { if (megaOpen && !e.target.closest('#catnav')) closeMega(); });
}

// Si el menú se acaba de abrir al pasar el mouse, el clic no lo vuelve a cerrar.
let hoverOpenedAt = 0;
export function toggleMega() {
  if (megaOpen && Date.now() - hoverOpenedAt < 900) return;
  (megaOpen ? closeMega : openMega)();
}
function openMega() {
  const mega = $('#mega');
  if (!mega) return;
  if (mega.hidden) {
    renderMegaPromo(); // la campaña del Club cambia cada día
    // Las subcategorías dependen de los productos a la venta (pueden haber cambiado)
    const cur = mega.querySelector('[data-mega-cat].is-on');
    const subs = mega.querySelector('.mega__subs');
    if (cur && subs) subs.innerHTML = megaSubsHtml(categoryById(cur.dataset.megaCat));
  }
  mega.hidden = false;
  megaOpen = true;
  $('[data-action="toggle-mega"]')?.setAttribute('aria-expanded', 'true');
}
export function closeMega() {
  const mega = $('#mega');
  if (!mega) return;
  mega.hidden = true;
  megaOpen = false;
  $('[data-action="toggle-mega"]')?.setAttribute('aria-expanded', 'false');
}

// ── Buscador con autocompletar ───────────────────────────────
let acIndex = -1;

function mountSearch() {
  const form = $('#search');
  const input = $('#q');
  const ac = $('#ac');
  const clearBtn = $('.search__clear', form);

  const show = (html) => {
    ac.innerHTML = html;
    ac.hidden = !html;
    input.setAttribute('aria-expanded', String(!ac.hidden));
    acIndex = -1;
  };
  const update = () => {
    const v = input.value;
    clearBtn.hidden = !v;
    show(v.trim().length >= 2 ? resultsPanel(v) : idlePanel());
  };
  const run = debounce(update, 90);

  input.addEventListener('input', run);
  input.addEventListener('focus', update);
  input.addEventListener('keydown', (e) => {
    const opts = $$('[data-opt]', ac);
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (ac.hidden) { update(); return; }
      e.preventDefault();
      if (!opts.length) return;
      acIndex = e.key === 'ArrowDown' ? (acIndex + 1) % opts.length : (acIndex - 1 + opts.length) % opts.length;
      opts.forEach((o, i) => o.classList.toggle('is-active', i === acIndex));
      opts[acIndex].scrollIntoView({ block: 'nearest' });
      input.setAttribute('aria-activedescendant', opts[acIndex].id);
    } else if (e.key === 'Escape') {
      if (!ac.hidden) { e.stopPropagation(); closeAc(); }
    } else if (e.key === 'Enter' && acIndex >= 0 && opts[acIndex]) {
      e.preventDefault();
      opts[acIndex].click();
    }
  });
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const v = input.value.trim();
    if (!v) { input.focus(); return; }
    addRecent(v);
    closeAc();
    input.blur();
    go(`/buscar?q=${encodeURIComponent(v)}`);
  });
  clearBtn.addEventListener('click', () => {
    input.value = '';
    clearBtn.hidden = true;
    input.focus();
    update();
  });
  ac.addEventListener('click', (e) => {
    const rec = e.target.closest('[data-recent-clear]');
    if (rec) { e.preventDefault(); clearRecent(); update(); return; }
    const a = e.target.closest('a[href^="#/"], [data-q]');
    if (!a) return;
    if (a.dataset.q) {
      e.preventDefault();
      input.value = a.dataset.q;
      addRecent(a.dataset.q);
      closeAc();
      go(`/buscar?q=${encodeURIComponent(a.dataset.q)}`);
      return;
    }
    const v = input.value.trim();
    if (v) addRecent(v);
    closeAc();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#search')) closeAc(); });
}

export function closeAc() {
  const ac = $('#ac');
  if (!ac) return;
  ac.hidden = true;
  $('#q')?.setAttribute('aria-expanded', 'false');
  $('#q')?.removeAttribute('aria-activedescendant');
}

export function setSearchValue(v) {
  const input = $('#q');
  if (input && document.activeElement !== input) {
    input.value = v || '';
    const c = $('.search__clear');
    if (c) c.hidden = !input.value;
  }
}

let optN = 0;
const optId = () => `aco${++optN}`;

function idlePanel() {
  const recent = state.recent.slice(0, 6);
  return `<div class="ac__col">
    ${recent.length ? `<div class="ac__row"><p class="ac__h">Búsquedas recientes</p><button type="button" class="btn btn--link btn--sm" data-recent-clear>Borrar</button></div>
      ${recent.map((r) => `<a class="ac__opt" role="option" id="${optId()}" data-opt data-q="${esc(r)}" href="#/buscar?q=${encodeURIComponent(r)}">${icon('clock')}<span>${esc(r)}</span></a>`).join('')}` : ''}
    <p class="ac__h">Lo más buscado</p>
    <div class="ac__chips">${POPULAR_SEARCHES.map((s) => `<a class="chip" role="option" id="${optId()}" data-opt data-q="${esc(s)}" href="#/buscar?q=${encodeURIComponent(s)}">${icon('search')}${esc(s)}</a>`).join('')}</div>
    <p class="ac__empty">Puedes buscar por nombre, marca, principio activo o síntoma. Entendemos errores de tipeo: prueba con "paqazetami".</p>
  </div>`;
}

function resultsPanel(v) {
  const { r, products, words, brands, cats } = suggest(v);
  const terms = r.terms;
  if (!products.length && !cats.length) {
    return `<div class="ac__empty">No encontramos productos para "<b>${esc(v)}</b>". Revisa la ortografía o prueba con el nombre del principio activo.</div>`;
  }
  const fix = r.corrected
    ? `<p class="ac__fix">${icon('sparkle')}<span>Mostrando resultados para <a href="#/buscar?q=${encodeURIComponent(r.corrected)}" data-link data-opt role="option" id="${optId()}">${esc(r.corrected)}</a></span></p>`
    : '';
  const notes = r.notes.length ? `<p class="ac__fix">${icon('info')}<span>${noteHtml(r.notes[0])}</span></p>` : '';
  const hl = (t) => highlight(t, terms, esc);
  return `${fix}${notes}<div class="ac__cols">
    <div class="ac__col">
      ${words.length ? `<p class="ac__h">Sugerencias</p>${words.map((w) => `<a class="ac__opt" role="option" id="${optId()}" data-opt data-q="${esc(w)}" href="#/buscar?q=${encodeURIComponent(w)}">${icon('search')}<span>${hl(w)}</span></a>`).join('')}` : ''}
      ${cats.length ? `<p class="ac__h">Categorías</p>${cats.map((c) => `<a class="ac__opt" role="option" id="${optId()}" data-opt href="#${c.path}" data-link>${icon('chevronRight')}<span>${hl(c.name)}</span>${c.parent ? `<small>${esc(c.parent)}</small>` : ''}</a>`).join('')}` : ''}
      ${brands.length ? `<p class="ac__h">Marcas</p>${brands.map((b) => `<a class="ac__opt" role="option" id="${optId()}" data-opt data-q="${esc(b)}" href="#/buscar?q=${encodeURIComponent(b)}">${icon('tag')}<span>${hl(b)}</span></a>`).join('')}` : ''}
    </div>
    <div class="ac__col">
      ${products.length ? `<p class="ac__h">Productos</p>${products.map((p) => `<a class="ac__opt ac__prod" role="option" id="${optId()}" data-opt href="#/producto/${p.slug}" data-link>
        <img src="${productImg(p)}" alt="" width="46" height="46">
        <span class="ac__prod-main"><em>${esc(p.brand)}</em><span>${hl(p.name)}</span></span>
        <span class="ac__prod-price"><b>${clp(p.offer || p.price)}</b>${p.offer ? `<s>${clp(p.price)}</s>` : ''}</span>
      </a>`).join('')}
      <a class="ac__all" role="option" id="${optId()}" data-opt href="#/buscar?q=${encodeURIComponent(r.corrected || v)}" data-link>Ver los ${r.total} resultados ${icon('arrowRight')}</a>` : ''}
    </div>
  </div>`;
}

// ── Ubicación ────────────────────────────────────────────────
export function openLocation({ first = false } = {}) {
  const loc = state.location;
  const regionOpts = REGIONS.map((r) => `<option value="${r.id}"${r.id === loc.region ? ' selected' : ''}>${esc(regionLabel(r))}</option>`).join('');
  const comunaOpts = (rid, sel) => (regionById(rid)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es'))
    .map((c) => `<option${c === sel ? ' selected' : ''}>${esc(c)}</option>`).join('');
  openModal({
    title: `${icon('pin')} ${first ? '¿Dónde quieres recibir o retirar?' : 'Elige tu comuna'}`,
    size: 'sm',
    html: `<p class="ov__text">Así te mostramos el stock de las farmacias y los tiempos de entrega de tu comuna.</p>
      <form id="loc-form" class="form-grid" style="margin-top:16px" novalidate>
        <div class="field field--full"><label for="loc-region">Región</label><select id="loc-region" name="region">${regionOpts}</select></div>
        <div class="field field--full"><label for="loc-comuna">Comuna</label><select id="loc-comuna" name="comuna">${comunaOpts(loc.region, loc.comuna)}</select></div>
        <div class="full"><button type="submit" class="btn btn--primary btn--block btn--lg">Guardar ubicación</button></div>
      </form>`,
    onMount(api) {
      const f = $('#loc-form', api.el);
      f.region.addEventListener('change', () => { f.comuna.innerHTML = comunaOpts(f.region.value, ''); });
      f.addEventListener('submit', (e) => {
        e.preventDefault();
        setLocation(f.region.value, f.comuna.value);
        api.close();
        const z = zoneOf(state.location);
        const free = freeShippingFrom(z);
        const noDel = RULES.noDeliveryComunas.includes(state.location.comuna);
        toast(noDel ? `Listo: <b>${esc(state.location.comuna)}</b>. Por ahora no despachamos a esa comuna${STORES.length ? ': puedes retirar en farmacia' : ''}.` : `Listo: stock y entregas para <b>${esc(state.location.comuna)}</b>. Despacho gratis sobre ${clp(free)}.`);
      });
    },
  });
}

// ── Menú lateral (celular) ───────────────────────────────────
export function openMobileMenu() {
  const main = () => `<nav class="mmenu" aria-label="Menú principal">
      <a class="mmenu__item" href="#/ofertas" data-link>${icon('percent')}Ofertas</a>
      ${CATEGORIES.map((c) => `<button type="button" class="mmenu__item" data-mm-cat="${c.id}">${icon(c.icon)}${esc(c.name)}${icon('chevronRight')}</button>`).join('')}
      <div class="mmenu__sep"></div>
      <a class="mmenu__item" href="#/bioequivalentes" data-link>${icon('scale')}Bioequivalentes</a>
      <a class="mmenu__item" href="#/club" data-link>${icon('star')}Club Piedra</a>
      <a class="mmenu__item" href="#/cotizar-receta" data-link>${icon('file')}Cotiza tu receta</a>
      <a class="mmenu__item" href="#/farmacias" data-link>${icon('store')}Farmacias y turnos</a>
      <a class="mmenu__item" href="#/seguimiento" data-link>${icon('box')}Sigue tu pedido</a>
      <a class="mmenu__item" href="#/cuenta" data-link>${icon('user')}${currentUser() ? 'Mi cuenta' : 'Ingresar o crear cuenta'}</a>
      <a class="mmenu__item" href="#/ayuda" data-link>${icon('help')}Ayuda</a>
    </nav>${(() => { const cards = menuCardsHtml(liveMenu()); return cards ? `<div class="mmenu__cards" aria-label="Destacados">${cards}</div>` : ''; })()}`;
  const sub = (id) => {
    const c = categoryById(id);
    return `<button type="button" class="mmenu__back" data-mm-back>${icon('chevronLeft')}Menú principal</button>
      <h3 class="mmenu__title">${esc(c.name)}</h3>
      <nav class="mmenu"><a class="mmenu__item" href="#/categoria/${c.id}" data-link>${icon(c.icon)}Ver todo</a>
      ${subsOf(c).map((s) => `<a class="mmenu__item" href="#/categoria/${c.id}/${s.id}" data-link>${esc(s.name)}${icon('chevronRight')}</a>`).join('')}</nav>`;
  };
  openDrawer({
    side: 'left',
    title: logo({ compact: true }),
    html: main(),
    onMount(api) {
      api.el.addEventListener('click', (e) => {
        const cat = e.target.closest('[data-mm-cat]');
        if (cat) { api.setBody(sub(cat.dataset.mmCat)); api.body.scrollTop = 0; return; }
        if (e.target.closest('[data-mm-back]')) { api.setBody(main()); return; }
        if (e.target.closest('a[href^="#/"]')) api.close();
      });
    },
  });
}

// ── Carro lateral ────────────────────────────────────────────
let cartDrawer = null;

function miniCartHtml() {
  const items = cartItems();
  if (!items.length) {
    return `<div class="empty" style="padding:28px 8px">${icon('bag')}<h2 class="empty__title">Tu carro está vacío</h2><p class="empty__text">Busca tus productos o revisa las ofertas de la semana.</p><div class="empty__actions"><a class="btn btn--primary" href="#/ofertas" data-link>Ver ofertas</a></div></div>`;
  }
  const t = totals();
  const zone = zoneOf(state.location);
  const free = freeShippingFrom(zone);
  const left = Math.max(0, free - t.total);
  const pct = Math.min(100, Math.round((t.total / free) * 100));
  return `<div class="mini">
    <div class="ship-bar">${left ? `<span>Te faltan <b>${clp(left)}</b> para el despacho gratis.</span>` : `<span><b>¡Tienes despacho gratis!</b> (${esc(state.location.comuna)})</span>`}
      <div class="ship-bar__track"><div class="ship-bar__fill" style="width:${pct}%"></div></div></div>
    <div class="mini__lines">${t.lines.map((l) => `<div class="mini__line">
      <img src="${productImg(l.product)}" alt="" width="58" height="58">
      <div><a href="#/producto/${l.product.slug}" data-link>${esc(l.product.name)}</a><small>${clp(l.info.sale)} c/u${l.promoOff ? ` · ${esc(PROMO_LABEL[l.product.promo] || 'Promoción')}` : ''}</small>
        <div style="margin-top:6px">${stepper(l.product, l.qty, { size: 'sm' }).replace('class="stepper stepper--sm"', 'class="stepper stepper--inline"')}</div></div>
      <b>${clp(l.total)}</b></div>`).join('')}</div>
    <div class="mini__foot">
      <div class="summary__rows">
        ${t.offerOff + t.promoOff + t.clubOff ? `<div class="summary__row save"><span>Ahorro</span><span>-${clp(t.offerOff + t.promoOff + t.clubOff)}</span></div>` : ''}
        <div class="summary__row"><span>Subtotal (${t.count} ${t.count === 1 ? 'producto' : 'productos'})</span><span><b>${clp(t.subtotal)}</b></span></div>
      </div>
      <p class="field__hint">El costo de despacho se calcula al pagar.</p>
      <a class="btn btn--primary btn--lg btn--block" href="#/carro" data-link>Ir al carro</a>
      <button type="button" class="btn btn--ghost btn--block" data-ov-close>Seguir comprando</button>
    </div>
  </div>`;
}

export function openCart() {
  if (cartDrawer) return;
  cartDrawer = openDrawer({
    side: 'right',
    title: `${icon('bag')} Tu carro`,
    html: miniCartHtml(),
    onMount(api) {
      api.el.addEventListener('click', (e) => { if (e.target.closest('a[href^="#/"]')) api.close(); });
    },
    onClose() { cartDrawer = null; },
  });
}

export function refreshCartDrawer() {
  if (cartDrawer) cartDrawer.setBody(miniCartHtml());
}

export { setQty };

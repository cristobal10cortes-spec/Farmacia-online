// Ventanas modales, paneles laterales y avisos breves (toasts).

import { $, esc } from './dom.js';
import { icon } from './icons.js';

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
const stack = [];

function host() {
  let h = $('#overlays');
  if (!h) {
    h = document.createElement('div');
    h.id = 'overlays';
    document.body.appendChild(h);
  }
  return h;
}

function trap(e, el) {
  if (e.key !== 'Tab') return;
  const f = [...el.querySelectorAll(FOCUSABLE)].filter((x) => x.offsetParent !== null);
  if (!f.length) return;
  const first = f[0];
  const last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}

function mount(kind, { title = '', html = '', size = 'md', side = 'right', onMount, onClose, className = '' }) {
  const prevFocus = document.activeElement;
  const wrap = document.createElement('div');
  const tid = `ov-${Date.now()}-${stack.length}`;
  wrap.className = `ov ov--${kind}${kind === 'drawer' ? ` ov--${side}` : ''} ${className}`;
  wrap.innerHTML = `<div class="ov__backdrop" data-ov-close></div>
    <div class="ov__panel ov__panel--${size}" role="dialog" aria-modal="true" aria-labelledby="${tid}">
      <div class="ov__head">
        <h2 class="ov__title" id="${tid}">${title}</h2>
        <button type="button" class="icon-btn" data-ov-close aria-label="Cerrar">${icon('x')}</button>
      </div>
      <div class="ov__body">${html}</div>
    </div>`;
  host().appendChild(wrap);
  document.documentElement.classList.add('has-overlay');
  const api = {
    el: wrap,
    body: $('.ov__body', wrap),
    close(result) {
      if (!wrap.isConnected) return;
      wrap.classList.remove('is-open');
      const i = stack.indexOf(api);
      if (i >= 0) stack.splice(i, 1);
      setTimeout(() => wrap.remove(), 180);
      if (!stack.length) document.documentElement.classList.remove('has-overlay');
      document.removeEventListener('keydown', onKey);
      if (prevFocus && prevFocus.focus && document.contains(prevFocus)) prevFocus.focus({ preventScroll: true });
      onClose?.(result);
    },
    setBody(h) { api.body.innerHTML = h; },
  };
  const onKey = (e) => {
    if (stack[stack.length - 1] !== api) return;
    if (e.key === 'Escape') { e.preventDefault(); api.close(); }
    trap(e, wrap);
  };
  document.addEventListener('keydown', onKey);
  wrap.addEventListener('click', (e) => { if (e.target.closest('[data-ov-close]')) api.close(); });
  stack.push(api);
  requestAnimationFrame(() => {
    wrap.classList.add('is-open');
    const first = $('.ov__body', wrap).querySelector(FOCUSABLE) || $('[data-ov-close].icon-btn', wrap);
    first?.focus({ preventScroll: true });
  });
  onMount?.(api);
  return api;
}

export const openModal = (opts) => mount('modal', opts);
export const openDrawer = (opts) => mount('drawer', opts);
export const closeAll = () => [...stack].forEach((o) => o.close());
export const topOverlay = () => stack[stack.length - 1] || null;

export function confirmDialog({ title, text, confirmText = 'Confirmar', cancelText = 'Cancelar', danger = false }) {
  return new Promise((resolve) => {
    let answered = false;
    openModal({
      title: esc(title),
      size: 'sm',
      html: `<p class="ov__text">${text}</p>
        <div class="ov__actions">
          <button type="button" class="btn btn--ghost" data-answer="no">${esc(cancelText)}</button>
          <button type="button" class="btn ${danger ? 'btn--danger' : 'btn--primary'}" data-answer="yes">${esc(confirmText)}</button>
        </div>`,
      onMount(api) {
        api.el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-answer]');
          if (!b) return;
          answered = true;
          api.close(b.dataset.answer === 'yes');
        });
      },
      onClose(r) { resolve(answered ? !!r : false); },
    });
  });
}

export function toast(html, { actionText = '', onAction = null, tone = 'ok', timeout = 3800 } = {}) {
  let box = $('#toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.setAttribute('aria-live', 'polite');
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = `toast toast--${tone}`;
  t.innerHTML = `${icon(tone === 'ok' ? 'checkCircle' : tone === 'warn' ? 'alert' : 'info')}<div class="toast__msg">${html}</div>${actionText ? `<button type="button" class="toast__act">${esc(actionText)}</button>` : ''}<button type="button" class="toast__x" aria-label="Cerrar aviso">${icon('x')}</button>`;
  box.appendChild(t);
  requestAnimationFrame(() => t.classList.add('is-in'));
  const kill = () => { t.classList.remove('is-in'); setTimeout(() => t.remove(), 200); };
  t.querySelector('.toast__x').onclick = kill;
  if (actionText) t.querySelector('.toast__act').onclick = () => { kill(); onAction?.(); };
  let timer = setTimeout(kill, timeout);
  t.addEventListener('mouseenter', () => clearTimeout(timer));
  t.addEventListener('mouseleave', () => { timer = setTimeout(kill, 1800); });
  while (box.children.length > 3) box.firstChild.remove();
}

export function clearToasts() {
  document.querySelectorAll('#toasts .toast').forEach((t) => t.remove());
}

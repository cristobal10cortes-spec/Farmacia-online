// Envío de formularios hecho por el propio sitio.
//
// Algunos visores muestran la página dentro de un marco que bloquea el envío
// de formularios: Enter y los botones "Enviar" no hacían nada (no llega el
// evento "submit"). Como todos los formularios se manejan con JavaScript, el
// envío lo hace el sitio y funciona en cualquier visor.

function sendForm(form, submitter) {
  if (!form.noValidate && !submitter?.formNoValidate && !form.reportValidity()) return;
  let ev;
  try {
    ev = new SubmitEvent('submit', { bubbles: true, cancelable: true, submitter: submitter || null });
  } catch {
    ev = new Event('submit', { bubbles: true, cancelable: true });
  }
  form.dispatchEvent(ev);
}

export function installFormSubmit() {
  document.addEventListener('click', (e) => {
    if (e.defaultPrevented) return;
    const btn = e.target.closest?.('button, input[type="submit"]');
    if (!btn || btn.type !== 'submit' || !btn.form || btn.disabled) return;
    e.preventDefault();
    sendForm(btn.form, btn);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.defaultPrevented || e.isComposing) return;
    const el = e.target;
    if (!(el instanceof HTMLInputElement) || !el.form) return;
    if (/^(button|submit|reset|checkbox|radio|file|image|color|range)$/.test(el.type)) return;
    // Si el formulario tiene botón de envío, el navegador "hace clic" en él y lo maneja el bloque anterior
    if ([...el.form.elements].some((x) => x.type === 'submit')) return;
    e.preventDefault();
    sendForm(el.form, null);
  });
}

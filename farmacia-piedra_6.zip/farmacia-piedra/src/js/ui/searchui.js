// Piezas de interfaz del buscador compartidas (autocompletar, listado, cotizador).

import { esc } from './dom.js';
import { fold } from '../engine/text.js';
import { productIndex, categoryIndex, byId } from '../engine/catalog.js';

const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

export function noteHtml(n) {
  if (n.kind === 'marca') return `<b>${esc(cap(n.from))}</b> es una marca comercial. Te mostramos productos con su mismo principio activo: <b>${esc(n.to)}</b>.`;
  if (n.kind === 'nombre') return `<b>${esc(cap(n.from))}</b> es otro nombre de <b>${esc(n.to)}</b>.`;
  return `Para "<b>${esc(n.from)}</b>" te mostramos productos relacionados. Si tienes dudas, consulta a un químico farmacéutico.`;
}

// Nombre corto para sugerencias: "Paracetamol 500 mg", "Pañales Premium talla G"
export function shortName(p) {
  return p.name
    .replace(/\s\d+\s(comprimidos|cápsulas|sobres|unidades?|ampollas|óvulos|supositorios|parches|gasas|pañales|tiras|lancetas)\b.*$/i, '')
    .replace(/\s\d+([.,]\d+)?\s?(ml|g)$/i, '')
    .trim();
}

/** Sugerencias para el autocompletar */
export function suggest(query, { maxProducts = 6 } = {}) {
  const r = productIndex.search(query, { prefix: true });
  const products = r.items.slice(0, maxProducts).map((it) => byId.get(it.id));
  const seen = new Set();
  const words = [];
  const push = (s) => {
    const k = fold(s);
    if (!k || seen.has(k)) return;
    seen.add(k);
    words.push(s);
  };
  if (r.completion && r.items.length) push(r.completion);
  for (const it of r.items.slice(0, 14)) {
    const p = byId.get(it.id);
    const sn = shortName(p);
    const firstWordHit = r.terms.some((t) => fold(sn).includes(t));
    if (firstWordHit) push(sn.length > 46 ? `${sn.slice(0, 44)}…` : sn);
    if (words.length >= 6) break;
  }
  const qf = fold(query).split(' ')[0];
  const brands = [];
  for (const it of r.items.slice(0, 30)) {
    const b = byId.get(it.id).brand;
    if (qf.length >= 2 && fold(b).split(' ').some((w) => w.startsWith(qf.slice(0, 3))) && !brands.includes(b)) brands.push(b);
  }
  const cats = categoryIndex.search(query, { prefix: true }).items.slice(0, 3).map((it) => categoryIndex.byId.get(it.id));
  return { r, products, words: words.slice(0, 6), brands: brands.slice(0, 4), cats };
}

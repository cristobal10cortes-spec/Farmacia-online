// Banners de la portada: dibujo de cada diapositiva y comportamiento del
// carrusel (lo usan la portada y la vista previa del panel).

import { $, $$, esc } from './dom.js';
import { icon } from './icons.js';
import { productImg } from './art.js';
import { byId } from '../engine/catalog.js';
import { imageSrc } from '../engine/bannerlist.js';
import { pebbles } from './components.js';
import { activeCampaigns } from '../engine/pricing.js';
import { DAYS, santiago } from '../engine/format.js';

// Ilustraciones incluidas (sin fotos con derechos de autor)
export const ART = {
  be: `<svg viewBox="0 0 320 220" aria-hidden="true">
    <g transform="translate(18 40)"><path d="M0 26 L18 12 L118 12 L100 26 Z" fill="#9DB6EE"/><path d="M100 26 L118 12 L118 132 L100 146 Z" fill="#163070"/><rect x="0" y="26" width="100" height="120" rx="3" fill="#fff"/><path d="M0 108 C30 98 70 118 100 104 L100 146 L0 146 Z" fill="#24479B"/><rect x="12" y="44" width="58" height="9" rx="4" fill="#15202B"/><rect x="12" y="60" width="38" height="7" rx="3.5" fill="#24479B"/><circle cx="84" cy="44" r="11" fill="#F2C200"/><text x="84" y="48" text-anchor="middle" font-family="Arial" font-weight="800" font-size="10" fill="#3A2E00">BE</text></g>
    <g transform="translate(140 96)" fill="#F3DC8E"><rect x="0" y="0" width="38" height="8" rx="4"/><rect x="0" y="16" width="38" height="8" rx="4"/></g>
    <g transform="translate(192 40)"><path d="M0 26 L18 12 L118 12 L100 26 Z" fill="#F0C9C2"/><path d="M100 26 L118 12 L118 132 L100 146 Z" fill="#8E2C1C"/><rect x="0" y="26" width="100" height="120" rx="3" fill="#fff"/><path d="M0 108 C30 98 70 118 100 104 L100 146 L0 146 Z" fill="#C8432B"/><rect x="12" y="44" width="58" height="9" rx="4" fill="#15202B"/><rect x="12" y="60" width="38" height="7" rx="3.5" fill="#C8432B"/></g>
  </svg>`,
  club: `<svg viewBox="0 0 320 220" aria-hidden="true">
    <rect x="40" y="38" width="240" height="148" rx="18" fill="#F3DC8E"/><rect x="40" y="38" width="240" height="148" rx="18" fill="url(#cg)"/>
    <defs><linearGradient id="cg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
    <path d="M62 86c0-14 11-24 26-24 14 0 23 9 23 20 0 13-10 20-25 20-14 0-24-5-24-16Z" fill="#24479B"/><circle cx="96" cy="88" r="2.4" fill="#F3DC8E"/><circle cx="101" cy="80" r="1.6" fill="#F3DC8E"/>
    <text x="124" y="92" font-family="Arial" font-weight="800" font-size="22" fill="#2A1E05">Club Piedra</text>
    <rect x="62" y="132" width="120" height="10" rx="5" fill="#2A1E05" opacity=".35"/><rect x="62" y="150" width="80" height="10" rx="5" fill="#2A1E05" opacity=".25"/>
    <text x="258" y="166" text-anchor="end" font-family="Arial" font-weight="800" font-size="30" fill="#2A1E05">-20%</text>
  </svg>`,
  sun: `<svg viewBox="0 0 320 220" aria-hidden="true">
    <circle cx="214" cy="78" r="40" fill="#F3DC8E"/><g stroke="#F3DC8E" stroke-width="6" stroke-linecap="round"><path d="M214 18v12M214 126v12M154 78h12M262 78h12M172 36l8 8M248 112l8 8M256 36l-8 8M180 112l-8 8"/></g>
    <g transform="rotate(-12 110 120)"><rect x="70" y="58" width="76" height="12" rx="3" fill="#DCE3EC"/><path d="M72 70 H144 L134 186 Q133 192 126 192 H90 Q83 192 82 186 Z" fill="#fff"/><path d="M72 70 H144 L141 100 H75 Z" fill="#1B6E96"/><rect x="93" y="192" width="30" height="20" rx="4" fill="#0F4C6E"/><text x="108" y="132" text-anchor="middle" font-family="Arial" font-weight="800" font-size="16" fill="#0F4C6E">FPS</text><text x="108" y="154" text-anchor="middle" font-family="Arial" font-weight="800" font-size="22" fill="#0F4C6E">50+</text></g>
  </svg>`,
  rx: `<svg viewBox="0 0 320 220" aria-hidden="true">
    <g transform="rotate(-6 160 110)"><rect x="70" y="24" width="180" height="176" rx="10" fill="#fff"/><text x="92" y="66" font-family="Georgia, serif" font-weight="700" font-size="30" fill="#24479B">Rx</text>
    <rect x="92" y="84" width="130" height="8" rx="4" fill="#C4CCD8"/><rect x="92" y="102" width="110" height="8" rx="4" fill="#C4CCD8"/><rect x="92" y="120" width="120" height="8" rx="4" fill="#C4CCD8"/><rect x="92" y="138" width="80" height="8" rx="4" fill="#C4CCD8"/>
    <path d="M150 176c10-14 20-14 26-4s14 8 22-6" fill="none" stroke="#15202B" stroke-width="3" stroke-linecap="round"/></g>
    <g transform="translate(228 132)"><circle r="36" fill="#F3DC8E"/><path d="M-14 0 l9 9 l19 -20" fill="none" stroke="#2A1E05" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></g>
  </svg>`,
};

export const ART_LABELS = { be: 'Bioequivalentes', club: 'Club (tarjeta)', sun: 'Protección solar', rx: 'Receta médica' };
export const TONES = { lapis: 'Azul lapislázuli', pyrite: 'Dorado pirita', sky: 'Celeste', basalt: 'Grafito', custom: 'Otro color' };

const HEX = /^#[0-9a-f]{6}$/i;

// ¿El color es claro? (entonces el texto va oscuro para que se lea)
export function isLight(hex) {
  if (!HEX.test(hex || '')) return false;
  const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2] > 0.42;
}

function visual(b) {
  if (b.visual === 'product') {
    const p = byId.get(b.productId);
    return p ? `<div class="hero__art hero__art--product"><img src="${productImg(p)}" alt="" width="260" height="260"></div>` : '';
  }
  if (b.visual === 'art' || (!b.visual && b.art)) return `<div class="hero__art">${ART[b.art] || ''}</div>`;
  return '';
}

/** Fotos del banner listas para mostrar: { src, srcM } (vacías si no tiene foto). */
function photosOf(b) {
  if (b.visual !== 'photo') return { src: '', srcM: '' };
  const src = imageSrc(b.image);
  return { src, srcM: src ? imageSrc(b.imageM) : '' };
}
const cssUrl = (src) => `url('${src}')`;

// Fondo claro elegido por el administrador → texto, puntos y flechas oscuros
const lightSlide = (b) => b.tone === 'custom' && HEX.test(b.color || '') && !photosOf(b).src && isLight(b.color);

/** El banner del Club muestra la campaña del día mientras no se edite su texto. */
export function withLiveText(b) {
  if (!b || b.dynamic !== 'club') return b;
  const camp = activeCampaigns()[0];
  if (!camp) return b;
  return { ...b, eyebrow: `Hoy ${DAYS[santiago().weekday]} en el Club`, title: `${camp.title}: ${camp.pct}% para socios`, text: `${camp.text}. Inscríbete gratis y paga precio Club desde hoy.` };
}

/** Una diapositiva del carrusel. */
export function bannerSlideHtml(b, i = 0, total = 1) {
  const tone = TONES[b.tone] ? b.tone : 'lapis';
  const custom = tone === 'custom' && HEX.test(b.color || '');
  const { src, srcM } = photosOf(b);
  const only = !!src && b.photoOnly === true;
  const light = lightSlide(b);
  const cls = ['hero__slide', `hero__slide--${custom ? 'custom' : tone === 'custom' ? 'lapis' : tone}`, src ? 'hero__slide--photo' : '', only ? 'hero__slide--only' : '', srcM ? 'has-m' : '', light ? 'hero__slide--light' : '', i === 0 ? 'is-on' : ''].filter(Boolean).join(' ');
  const style = [custom ? `--banner-bg:${b.color}` : '', src ? `--img:${cssUrl(src)}` : '', srcM ? `--img-m:${cssUrl(srcM)}` : ''].filter(Boolean).join(';');
  const to = String(b.to || '/').startsWith('/') ? b.to : '/';
  const head = `<div class="${cls}"${style ? ` style="${style}"` : ''} role="group" aria-roledescription="diapositiva" aria-label="${i + 1} de ${total}"${i ? ' aria-hidden="true"' : ''}>`;
  // Foto que ya trae su propio texto: toda la diapositiva es el enlace
  if (only) {
    return `${head}
    <h2 class="visually-hidden">${esc(b.title || 'Banner')}</h2>
    <a class="hero__fill" href="#${esc(to)}" data-link aria-label="${esc(`${b.title || 'Banner'}: ${b.cta || 'Ver más'}`)}"${i ? ' tabindex="-1"' : ''}></a>
  </div>`;
  }
  return `${head}
    <div class="hero__copy">
      ${b.eyebrow ? `<span class="hero__eyebrow">${esc(b.eyebrow)}</span>` : ''}
      <h2 class="hero__title">${esc(b.title || 'Título del banner')}</h2>
      ${b.text ? `<p class="hero__text">${esc(b.text)}</p>` : ''}
      <a class="btn btn--lg hero__cta" href="#${esc(to)}" data-link${i ? ' tabindex="-1"' : ''}>${esc(b.cta || 'Ver más')} ${icon('arrowRight')}</a>
    </div>
    ${src ? '' : visual(b)}
  </div>`;
}

/** Un banner de más abajo (recuadro grande). `tag: 'div'` lo dibuja sin enlace (vista previa del panel). */
export function promoCardHtml(b, { tag = 'a' } = {}) {
  const tone = TONES[b.tone] ? b.tone : 'lapis';
  const custom = tone === 'custom' && HEX.test(b.color || '');
  const { src } = photosOf(b);
  const only = !!src && b.photoOnly === true;
  const light = custom && !src && isLight(b.color);
  const to = String(b.to || '/').startsWith('/') ? b.to : '/';
  const cls = ['promo-card', `promo-card--${custom ? 'custom' : tone === 'custom' ? 'lapis' : tone}`, src ? 'promo-card--photo' : '', only ? 'promo-card--only' : '', light ? 'promo-card--light' : ''].filter(Boolean).join(' ');
  const style = [custom ? `--banner-bg:${b.color}` : '', src ? `--img:${cssUrl(src)}` : ''].filter(Boolean).join(';');
  const attrs = `class="${cls}"${tag === 'a' ? ` href="#${esc(to)}" data-link` : ''}${style ? ` style="${style}"` : ''}`;
  if (only) return `<${tag} ${attrs} aria-label="${esc(`${b.title || 'Banner'}: ${b.cta || 'Ver más'}`)}"><span class="visually-hidden">${esc(b.title || 'Banner')}</span></${tag}>`;
  return `<${tag} ${attrs}>
    ${b.eyebrow ? `<small>${esc(b.eyebrow)}</small>` : ''}<h3>${esc(b.title || 'Título del banner')}</h3>
    ${b.text ? `<p>${esc(b.text)}</p>` : ''}
    <span class="btn">${esc(b.cta || 'Ver más')} ${icon('arrowRight')}</span>${src ? '' : pebbles()}
  </${tag}>`;
}

/** Los banners de más abajo (nada si no hay activos). */
export function promoGridHtml(list, opts) {
  if (!list.length) return '';
  return `<div class="split">${list.map((b) => promoCardHtml(b, opts)).join('')}</div>`;
}

/** El carrusel completo (o nada si no hay banners activos). */
export function heroCarouselHtml(banners, { id = 'hero', label = 'Destacados' } = {}) {
  if (!banners.length) return '';
  const many = banners.length > 1;
  const light = lightSlide(banners[0]);
  return `<section class="hero${light ? ' hero--light' : ''}" id="${id}" aria-roledescription="carrusel" aria-label="${esc(label)}">
    <div class="hero__track">${banners.map((b, i) => bannerSlideHtml(b, i, banners.length)).join('')}</div>
    ${many ? `<div class="hero__dots" role="group" aria-label="Elegir banner">${banners.map((b, i) => `<button type="button" class="hero__dot${i === 0 ? ' is-on' : ''}" data-slide="${i}" aria-label="Ir a ${esc(b.eyebrow || b.title || `banner ${i + 1}`)}"${i === 0 ? ' aria-current="true"' : ''}></button>`).join('')}</div>
    <div class="hero__nav">
      <button type="button" data-hero="prev" aria-label="Anterior">${icon('chevronLeft')}</button>
      <button type="button" data-hero="next" aria-label="Siguiente">${icon('chevronRight')}</button>
    </div>` : ''}
  </section>`;
}

/** Hace avanzar el carrusel solo (se pausa al pasar el mouse o con el foco). */
export function mountHeroCarousel(hero, { interval = 6500 } = {}) {
  if (!hero) return null;
  const slidesEl = $$('.hero__slide', hero);
  const dots = $$('.hero__dot', hero);
  if (slidesEl.length < 2) return null;
  let i = 0;
  const show = (n) => {
    i = (n + slidesEl.length) % slidesEl.length;
    slidesEl.forEach((s, k) => {
      s.classList.toggle('is-on', k === i);
      s.setAttribute('aria-hidden', String(k !== i));
      const cta = $('.hero__cta, .hero__fill', s);
      if (cta) cta.tabIndex = k === i ? 0 : -1;
    });
    dots.forEach((d, k) => {
      d.classList.toggle('is-on', k === i);
      if (k === i) d.setAttribute('aria-current', 'true');
      else d.removeAttribute('aria-current');
    });
    hero.classList.toggle('hero--light', slidesEl[i].classList.contains('hero__slide--light'));
  };
  let timer = null;
  let paused = false;
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const tick = () => { if (!paused && !document.hidden) show(i + 1); };
  const restart = () => { clearInterval(timer); if (!reduce) timer = setInterval(tick, interval); };
  hero.addEventListener('click', (e) => {
    const d = e.target.closest('[data-slide]');
    if (d) { show(+d.dataset.slide); restart(); }
    const n = e.target.closest('[data-hero]');
    if (n) { show(i + (n.dataset.hero === 'next' ? 1 : -1)); restart(); }
  });
  hero.addEventListener('mouseenter', () => { paused = true; });
  hero.addEventListener('mouseleave', () => { paused = false; });
  hero.addEventListener('focusin', () => { paused = true; });
  hero.addEventListener('focusout', () => { paused = false; });
  restart();
  return () => clearInterval(timer);
}

/**
 * Achica una foto subida para que pese poco (JPEG, máx. `maxW` px de ancho).
 * Devuelve { url, width, height, srcW, srcH } (srcW × srcH = medida original).
 */
export function compressPhoto(file, { maxW = 1400, maxChars = 190000 } = {}) {
  return new Promise((resolve, reject) => {
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { reject(new Error('Sube una imagen JPG, PNG o WebP.')); return; }
    if (file.size > 15 * 1024 * 1024) { reject(new Error('La imagen pesa más de 15 MB.')); return; }
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('No pudimos leer la imagen.'));
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('No pudimos abrir la imagen. Prueba con otra.'));
      img.onload = () => {
        let w = Math.min(maxW, img.width);
        for (let round = 0; round < 6; round++) {
          const h = Math.round(img.height * (w / img.width));
          const c = document.createElement('canvas');
          c.width = w;
          c.height = h;
          const ctx = c.getContext('2d');
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          for (const q of [0.82, 0.74, 0.66, 0.58]) {
            const url = c.toDataURL('image/jpeg', q);
            if (url.length <= maxChars) { resolve({ url, width: w, height: h, srcW: img.width, srcH: img.height }); return; }
          }
          w = Math.round(w * 0.8);
        }
        reject(new Error('La imagen es muy pesada. Prueba con una más liviana.'));
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

// Pie de página y asistente de ayuda.

import { $, esc } from './dom.js';
import { icon } from './icons.js';
import { logo } from './logo.js';
import { BRAND } from '../config.js';
import { PROMISES, LEGAL_LINKS } from '../data/content.js';
import { toast } from './overlay.js';
import { helpbotHtml, openHelpbot } from './helpbot.js';
import { state, emit } from '../engine/state.js';
import { validEmail } from '../engine/rut.js';
import { STORES } from '../data/stores.js';

// Sin farmacias no se ofrece retiro en farmacia
const promisesHtml = () => PROMISES.filter((p) => p.icon !== 'store' || STORES.length)
  .map((p) => `<div class="promise">${icon(p.icon)}<div><b>${esc(p.title)}</b><span>${esc(p.text)}</span></div></div>`).join('');

/** Actualiza las promesas del pie (cuando cambian las farmacias). */
export function updatePromises() {
  const grid = document.getElementById('promises-grid');
  const html = promisesHtml();
  if (grid && grid.dataset.sig !== html) { grid.innerHTML = html; grid.dataset.sig = html; }
}

export function footerHtml() {
  return `<section class="promises" aria-label="Nuestros servicios"><div class="wrap promises__grid" id="promises-grid">
    ${promisesHtml()}
  </div></section>
  <footer class="foot">
    <div class="wrap">
      <div class="foot__news">
        <div><h2>Ofertas y consejos de salud en tu correo</h2><p>Una vez por semana, sin spam. Puedes darte de baja cuando quieras.</p></div>
        <form class="foot__form" id="news-form" novalidate>
          <label class="visually-hidden" for="news-email">Correo electrónico</label>
          <input id="news-email" name="email" type="email" placeholder="tu@correo.cl" autocomplete="email">
          <button class="btn" type="submit">Suscribirme</button>
        </form>
      </div>
      <div class="foot__cols">
        <div class="foot__brand">
          ${logo()}
          <div class="foot__contact">
            <span>${icon('phone')}Venta telefónica: <b>${esc(BRAND.phone)}</b></span>
            <span>${icon('chat')}WhatsApp: <b>${esc(BRAND.whatsapp)}</b></span>
            <span>${icon('mail')}${esc(BRAND.email)}</span>
            <span>${icon('clock')}${esc(BRAND.hours)}</span>
          </div>
        </div>
        <details class="foot__col" open><summary><h3>Farmacias Piedra</h3>${icon('chevronDown')}</summary><ul>
          <li><a href="#/legal/quienes-somos" data-link>Quiénes somos</a></li>
          <li><a href="#/farmacias" data-link>Farmacias y horarios</a></li>
          <li><a href="#/farmacias?turno=1" data-link>Farmacias de turno</a></li>
          <li><a href="#/marcas" data-link>Marcas</a></li>
          <li><a href="#/legal/trabaja-con-nosotros" data-link>Trabaja con nosotros</a></li>
        </ul></details>
        <details class="foot__col" open><summary><h3>Servicio al cliente</h3>${icon('chevronDown')}</summary><ul>
          <li><a href="#/ayuda" data-link>Preguntas frecuentes</a></li>
          <li><a href="#/seguimiento" data-link>Sigue tu pedido</a></li>
          <li><a href="#/cotizar-receta" data-link>Cotiza tu receta</a></li>
          <li><a href="#/ayuda/contacto" data-link>Contacto</a></li>
          <li><a href="#/ayuda/reclamos" data-link>Libro de reclamos</a></li>
        </ul></details>
        <details class="foot__col" open><summary><h3>Información legal</h3>${icon('chevronDown')}</summary><ul>
          ${LEGAL_LINKS.map(([id, t]) => `<li><a href="#/legal/${id}" data-link>${esc(t)}</a></li>`).join('')}
          <li><a href="#/bioequivalentes" data-link>Medicamentos bioequivalentes</a></li>
        </ul></details>
        <details class="foot__col" open><summary><h3>Club Piedra</h3>${icon('chevronDown')}</summary><ul>
          <li><a href="#/club" data-link>Beneficios</a></li>
          <li><a href="#/registro" data-link>Inscríbete gratis</a></li>
          <li><a href="#/club?ver=tratamiento" data-link>Programa Mi Tratamiento</a></li>
          <li><a href="#/cuenta" data-link>Mi cuenta</a></li>
        </ul></details>
      </div>
      <div class="foot__bottom">
        <span>© ${BRAND.year} ${esc(BRAND.fullName)} · Dirección técnica: ${esc(BRAND.techDirector)}${BRAND.demo ? ` · ${esc(BRAND.demoNote)}` : ''}</span>
        <span class="foot__pay" aria-label="Medios de pago"><span>Débito</span><span>Crédito</span><span>Prepago</span><span>Transferencia</span></span>
      </div>
    </div>
  </footer>
  ${helpbotHtml()}`;
}

export function mountFooter() {
  // En pantallas angostas las columnas de enlaces se vuelven acordeones.
  const mq = window.matchMedia?.('(max-width: 480px)');
  const syncCols = () => document.querySelectorAll('.foot__col').forEach((d) => { d.open = !mq?.matches; });
  syncCols();
  mq?.addEventListener?.('change', syncCols);
  document.querySelectorAll('.foot__col > summary').forEach((sm) => sm.addEventListener('click', (e) => { if (!mq?.matches) e.preventDefault(); }));
  const f = $('#news-form');
  f?.addEventListener('submit', (e) => {
    e.preventDefault();
    const v = f.email.value.trim();
    if (!validEmail(v)) {
      toast('Escribe un correo válido para suscribirte.', { tone: 'warn' });
      f.email.focus();
      return;
    }
    if (!state.newsletter.includes(v)) state.newsletter.push(v);
    emit('newsletter');
    f.reset();
    toast(`Listo, te suscribiste con <b>${esc(v)}</b>.`);
  });
}

// El asistente de ayuda vive en ui/helpbot.js (ventanita de la esquina)
export { faqSearch } from '../engine/assistant.js';
export const openAssistant = (question) => openHelpbot(question);

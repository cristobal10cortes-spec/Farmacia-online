// Componentes reutilizables (devuelven HTML como texto).

import { esc, cls } from './dom.js';
import { icon } from './icons.js';
import { productImg } from './art.js';
import { clp } from '../engine/format.js';
import { RX } from '../config.js';
import { priceInfo, PROMO_LABEL } from '../engine/pricing.js';
import { priceCtx, qtyOf, maxQty, isFav } from '../engine/shop.js';
import { productAvailability } from '../engine/inventory.js';
import { state } from '../engine/state.js';

export const link = (path) => `#${path}`;
export const productPath = (p) => `/producto/${p.slug}`;

export function rxChip(p, { long = false } = {}) {
  const r = RX[p.rx] || RX.directa;
  return `<span class="rx rx--${r.tone}">${p.rx !== 'directa' ? icon('file') : ''}${esc(long ? r.label : r.short)}</span>`;
}

export const beSeal = (big = false) => `<span class="be${big ? ' be--lg' : ''}" title="Bioequivalente"><b>BE</b>${big ? '<span>Bioequivalente</span>' : ''}</span>`;

export function promoBadge(p) {
  return p.promo ? `<span class="badge badge--promo">${esc(PROMO_LABEL[p.promo])}</span>` : '';
}

export function priceBlock(p, { size = 'md', info = priceInfo(p, priceCtx()), align = size !== 'lg' } = {}) {
  const member = !!priceCtx().member;
  const club = info.clubPrice && info.clubPrice < info.sale;
  return `<div class="price price--${size}">
    <div class="price__row">
      <span class="price__now">${clp(info.sale)}</span>
      ${info.offPct ? `<span class="badge badge--sale">-${info.offPct}%</span>` : ''}
    </div>
    ${info.offPct ? `<span class="price__was">Normal <s>${clp(info.list)}</s></span>` : align ? '<span class="price__was price__was--empty" aria-hidden="true">&nbsp;</span>' : ''}
    ${club ? `<span class="price__club${member ? ' is-member' : ''}" title="${esc(info.clubLabel)}"><b>Club</b> ${clp(info.clubPrice)}</span>` : ''}
  </div>`;
}

export function unitPriceText(p, info = priceInfo(p, priceCtx())) {
  if (p.units <= 1) return '';
  const un = p.unitName === 'ml' || p.unitName === 'g' ? p.unitName : p.unitName;
  const per = info.sale / p.units;
  const shown = per < 10 ? per.toLocaleString('es-CL', { maximumFractionDigits: 1 }) : Math.round(per).toLocaleString('es-CL');
  return `$${shown} por ${un}`;
}

export function stepper(p, qty, { size = 'md' } = {}) {
  const max = maxQty(p);
  return `<div class="stepper stepper--${size}" role="group" aria-label="Cantidad de ${esc(p.name)}">
    <button type="button" class="stepper__btn" data-action="qty-dec" data-id="${p.id}" aria-label="${qty <= 1 ? 'Quitar del carro' : 'Quitar una unidad'}">${icon(qty <= 1 ? 'trash' : 'minus')}</button>
    <span class="stepper__val" aria-live="polite">${qty}</span>
    <button type="button" class="stepper__btn" data-action="qty-inc" data-id="${p.id}" aria-label="Agregar una unidad" ${qty >= max ? 'disabled' : ''}>${icon('plus')}</button>
  </div>`;
}

// Botón "Agregar" o selector de cantidad según el estado del carro
export function cartControl(p, avail = productAvailability(p, state.location), { size = 'md' } = {}) {
  if (p.rx === 'cheque') return `<span class="btn btn--block btn--disabled" aria-disabled="true">${icon('store')} Solo en farmacia</span>`;
  const q = qtyOf(p.id);
  if (q) return stepper(p, q, { size });
  if (!avail.delivery.ok && !avail.pickup.ok) {
    return `<a class="btn btn--block btn--ghost" href="${link(productPath(p))}" data-link>Ver disponibilidad</a>`;
  }
  return `<button type="button" class="btn btn--primary btn--block" data-action="add" data-id="${p.id}">${icon('bag')}<span>Agregar</span></button>`;
}

export function favButton(p) {
  const on = isFav(p.id);
  return `<button type="button" class="fav${on ? ' is-on' : ''}" data-action="fav" data-id="${p.id}" aria-pressed="${on}" aria-label="${on ? 'Quitar de favoritos' : 'Guardar en favoritos'}">${icon('heart')}</button>`;
}

export function productCard(p, { compact = false } = {}) {
  const info = priceInfo(p, priceCtx());
  const avail = productAvailability(p, state.location);
  const unit = unitPriceText(p, info);
  return `<article class="pcard${compact ? ' pcard--compact' : ''}" data-pid="${p.id}">
    <a class="pcard__media" href="${link(productPath(p))}" data-link tabindex="-1" aria-hidden="true">
      <img src="${productImg(p)}" alt="" width="200" height="200" loading="lazy" decoding="async">
    </a>
    <div class="pcard__flags">${promoBadge(p)}${p.cold ? `<span class="badge badge--cold" title="Requiere cadena de frío">${icon('snow')}Frío</span>` : ''}</div>
    ${favButton(p)}
    <div class="pcard__body">
      <p class="pcard__brand">${esc(p.brand)}</p>
      <h3 class="pcard__name"><a href="${link(productPath(p))}" data-link>${esc(p.name)}</a></h3>
      ${p.isMedicine || p.rx !== 'directa' || p.be ? `<div class="pcard__chips">${p.isMedicine || p.rx !== 'directa' ? rxChip(p) : ''}${p.be ? '<span class="be-chip" title="Bioequivalente"><b>BE</b>Bioequivalente</span>' : ''}</div>` : ''}
      ${priceBlock(p, { info, size: compact ? 'sm' : 'md' })}
      ${unit ? `<p class="pcard__unit">${esc(unit)}</p>` : ''}
      <p class="pcard__avail">
        <span class="${avail.delivery.ok ? 'ok' : 'no'}" title="${esc(avail.delivery.text)}">${icon('truck')}Despacho</span>
        ${avail.noStores ? '' : `<span class="${avail.pickup.ok ? 'ok' : 'no'}" title="${esc(avail.pickup.text)}">${icon('store')}Retiro</span>`}
      </p>
    </div>
    <div class="pcard__cta" data-cart-slot="${p.id}">${cartControl(p, avail)}</div>
  </article>`;
}

export function productGrid(list, opts) {
  return `<div class="pgrid">${list.map((p) => productCard(p, opts)).join('')}</div>`;
}

let railN = 0;
export function rail(title, products, { href = '', sub = '', id = '' } = {}) {
  if (!products.length) return '';
  railN += 1;
  const rid = id || `rail${railN}`;
  return `<section class="rail" aria-labelledby="${rid}-t">
    <div class="sec-head">
      <div><h2 class="sec-title" id="${rid}-t">${esc(title)}</h2>${sub ? `<p class="sec-sub">${esc(sub)}</p>` : ''}</div>
      <div class="sec-head__actions">
        ${href ? `<a class="link-more" href="${link(href)}" data-link>Ver todo ${icon('arrowRight')}</a>` : ''}
        <button type="button" class="icon-btn icon-btn--line" data-action="rail-prev" data-rail="${rid}" aria-label="Anteriores">${icon('chevronLeft')}</button>
        <button type="button" class="icon-btn icon-btn--line" data-action="rail-next" data-rail="${rid}" aria-label="Siguientes">${icon('chevronRight')}</button>
      </div>
    </div>
    <div class="rail__track" id="${rid}" tabindex="0" aria-label="${esc(title)}">${products.map((p) => productCard(p, { compact: true })).join('')}</div>
  </section>`;
}

export function breadcrumbs(items) {
  return `<nav class="crumbs" aria-label="Ruta de navegación"><ol>${items.map((it, i) => {
    const last = i === items.length - 1;
    return `<li>${last || !it.href ? `<span${last ? ' aria-current="page"' : ''}>${esc(it.label)}</span>` : `<a href="${link(it.href)}" data-link>${esc(it.label)}</a>`}</li>`;
  }).join('')}</ol></nav>`;
}

export function pagination(page, pages, hrefFor) {
  if (pages <= 1) return '';
  const nums = [];
  for (let i = 1; i <= pages; i++) {
    if (i === 1 || i === pages || Math.abs(i - page) <= 1) nums.push(i);
    else if (nums[nums.length - 1] !== '…') nums.push('…');
  }
  return `<nav class="pager" aria-label="Paginación">
    ${page > 1 ? `<a class="pager__btn" href="${link(hrefFor(page - 1))}" data-link aria-label="Página anterior">${icon('chevronLeft')}</a>` : `<span class="pager__btn is-disabled">${icon('chevronLeft')}</span>`}
    ${nums.map((n) => (n === '…' ? '<span class="pager__gap">…</span>' : n === page ? `<span class="pager__num is-current" aria-current="page">${n}</span>` : `<a class="pager__num" href="${link(hrefFor(n))}" data-link>${n}</a>`)).join('')}
    ${page < pages ? `<a class="pager__btn" href="${link(hrefFor(page + 1))}" data-link aria-label="Página siguiente">${icon('chevronRight')}</a>` : `<span class="pager__btn is-disabled">${icon('chevronRight')}</span>`}
  </nav>`;
}

export function emptyState({ icon: ic = 'stone', title, text = '', actions = '' }) {
  return `<div class="empty">
    <div class="empty__art" aria-hidden="true">${pebbles()}${icon(ic)}</div>
    <h2 class="empty__title">${esc(title)}</h2>
    ${text ? `<p class="empty__text">${esc(text)}</p>` : ''}
    ${actions ? `<div class="empty__actions">${actions}</div>` : ''}
  </div>`;
}

export function pebbles() {
  return `<svg class="pebbles" viewBox="0 0 120 60" aria-hidden="true"><path d="M8 44c0-8 7-14 16-14 8 0 13 5 13 11 0 7-6 11-15 11C14 52 8 50 8 44Z" fill="currentColor" opacity=".18"/><path d="M40 40c0-11 9-19 22-19 11 0 19 7 19 16 0 10-9 15-21 15C49 52 40 48 40 40Z" fill="currentColor" opacity=".28"/><path d="M84 46c0-6 5-10 12-10 6 0 10 4 10 8 0 5-5 8-11 8-6 0-11-2-11-6Z" fill="currentColor" opacity=".14"/></svg>`;
}

export function notice(tone, html, ic) {
  const icons = { info: 'info', ok: 'checkCircle', warn: 'alert', danger: 'alert', club: 'star' };
  return `<div class="notice notice--${tone}" role="${tone === 'danger' ? 'alert' : 'status'}">${icon(ic || icons[tone] || 'info')}<div>${html}</div></div>`;
}

export function field({ label, name, type = 'text', value = '', hint = '', required = false, autocomplete = '', inputmode = '', placeholder = '', options = null, attrs = '', full = false }) {
  const id = `f-${name}`;
  let control;
  if (options) {
    control = `<select id="${id}" name="${name}" ${required ? 'required' : ''} ${attrs}>${options.map((o) => {
      const v = typeof o === 'string' ? o : o.value;
      const l = typeof o === 'string' ? o : o.label;
      return `<option value="${esc(v)}"${String(v) === String(value) ? ' selected' : ''}>${esc(l)}</option>`;
    }).join('')}</select>`;
  } else if (type === 'textarea') {
    control = `<textarea id="${id}" name="${name}" rows="3" ${required ? 'required' : ''} placeholder="${esc(placeholder)}" ${attrs}>${esc(value)}</textarea>`;
  } else {
    control = `<input id="${id}" name="${name}" type="${type}" value="${esc(value)}" ${required ? 'required' : ''} ${autocomplete ? `autocomplete="${autocomplete}"` : ''} ${inputmode ? `inputmode="${inputmode}"` : ''} placeholder="${esc(placeholder)}" ${attrs}>`;
  }
  return `<div class="field${full ? ' field--full' : ''}">
    <label for="${id}">${esc(label)}${required ? '' : ' <span class="field__opt">(opcional)</span>'}</label>
    ${control}
    ${hint ? `<p class="field__hint">${hint}</p>` : ''}
    <p class="field__error" aria-live="polite"></p>
  </div>`;
}

export function checkbox({ name, label, checked = false, required = false }) {
  return `<div class="field field--check"><label class="check"><input type="checkbox" name="${name}" ${checked ? 'checked' : ''} ${required ? 'required' : ''}><span>${label}</span></label><p class="field__error" aria-live="polite"></p></div>`;
}

export function sectionHead(title, { href = '', linkText = 'Ver todo', sub = '' } = {}) {
  return `<div class="sec-head"><div><h2 class="sec-title">${esc(title)}</h2>${sub ? `<p class="sec-sub">${esc(sub)}</p>` : ''}</div>${href ? `<a class="link-more" href="${link(href)}" data-link>${esc(linkText)} ${icon('arrowRight')}</a>` : ''}</div>`;
}

export function chip(text, tone = '') {
  return `<span class="${cls('chip', tone && `chip--${tone}`)}">${text}</span>`;
}

// Asistente de ayuda: ventanita fija en la esquina inferior derecha que va
// diciendo frases ("¿Necesitas ayuda?", "¿Lo puedo asesorar en algo?") y se
// abre como chat. Las respuestas las arma engine/assistant.js.
//
// Estados: 'mini' (ventanita; en el celular, globo con la frase),
//          'min'  (achicada: botón con la frase; en el celular, solo el ícono),
//          'chat' (conversación abierta; en el celular, pantalla completa).

import { $, $$, esc } from './dom.js';
import { icon } from './icons.js';
import { markSvg } from './logo.js';
import { productImg } from './art.js';
import { clp } from '../engine/format.js';
import { salePrice } from '../engine/catalog.js';
import { HELPBOT, RX } from '../config.js';
import { botReply, greeting, teasersFor } from '../engine/assistant.js';

const KEY = 'piedra:ayuda';
// Botones de la ventanita: texto corto → pregunta que se envía
const QUICK = [
  ['Tengo un síntoma', 'Tengo un síntoma'],
  ['Buscar un remedio', 'Buscar un remedio'],
  ['Mi pedido', '¿Dónde está mi pedido?'],
  ['Farmacias de turno', 'Farmacias de turno'],
];

const ui = {
  root: null,
  mode: 'mini',
  hidden: false,
  compact: false, // carro y pago: empieza achicada
  started: false, // ya se mostró el saludo en el chat
  queue: Promise.resolve(), // las preguntas se responden en orden
  lines: teasersFor('/'),
  li: 0,
  timer: null,
  hover: false,
};

const reduceMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const isPhone = () => window.matchMedia?.('(max-width: 600px)').matches;
const stored = () => { try { return window.sessionStorage.getItem(KEY); } catch { return null; } };
const store = (v) => { try { if (v) window.sessionStorage.setItem(KEY, v); else window.sessionStorage.removeItem(KEY); } catch { /* sin almacenamiento */ } };
const wait = (ms) => new Promise((r) => setTimeout(r, reduceMotion() ? Math.min(ms, 120) : ms));

export function helpbotHtml() {
  return `<aside class="hb" id="hb" aria-label="Asistente de ayuda" hidden>
    <section class="hb__card" aria-labelledby="hb-name">
      <header class="hb__head">
        <span class="hb__avatar" aria-hidden="true">${markSvg(30)}<i class="hb__online"></i></span>
        <span class="hb__who"><b id="hb-name">${esc(HELPBOT.name)}</b><small>Orientación de salud · en línea</small></span>
        <button type="button" class="hb__btn" data-hb="shrink" aria-label="Achicar el asistente">${icon('minus')}</button>
      </header>
      <div class="hb__body">
        <div class="hb__teaser" aria-hidden="true"><p class="hb__bubble"><span class="hb__typing"><i></i><i></i><i></i></span><span class="hb__say"></span></p></div>
        <div class="hb__log" id="hb-log" role="log" aria-live="polite" aria-label="Conversación con el asistente"></div>
        <p class="hb__hint">Elige una opción o escríbeme tu duda:</p>
        <div class="hb__quick">${QUICK.map(([label, q]) => `<button type="button" class="hb__chip" data-ask="${esc(q)}">${esc(label)}</button>`).join('')}</div>
      </div>
      <form class="hb__form" id="hb-form" novalidate>
        <label class="visually-hidden" for="hb-q">Escribe tu pregunta</label>
        <input id="hb-q" name="q" placeholder="Escribe tu pregunta…" maxlength="300" autocomplete="off" enterkeyhint="send">
        <button type="submit" class="hb__send" aria-label="Enviar pregunta">${icon('send')}</button>
      </form>
    </section>
    <button type="button" class="hb__pill" data-hb="open" aria-label="Abrir el asistente de ayuda">
      <span class="hb__avatar hb__avatar--sm" aria-hidden="true">${markSvg(24)}<i class="hb__online"></i></span>
      <span class="hb__pill-say" aria-hidden="true"></span>
    </button>
    <button type="button" class="hb__x" data-hb="min" aria-label="Achicar el aviso de ayuda">${icon('x')}</button>
  </aside>`;
}

// ── Dibujo de los mensajes ───────────────────────────────────
const li = (t) => `<li>${esc(t)}</li>`;
const telHref = (tel) => `tel:${String(tel).replace(/[^\d+*#]/g, '').replace(/#/g, '%23')}`;
const callHtml = (c) => (c.tel
  ? `<a class="hbcall" href="${telHref(c.tel)}"><b>${esc(c.label)}</b><small>${esc(c.sub)}</small></a>`
  : `<div class="hbcall"><b>${esc(c.label)}</b><small>${esc(c.sub)}</small></div>`);

const linksHtml = (links = []) => (links.length ? `<span class="hbm__links">${links.map((l) => `<a href="#${esc(l.to)}" data-link>${esc(l.label)} ${icon('arrowRight')}</a>`).join('')}</span>` : '');

function msgHtml(m) {
  switch (m.type) {
    case 'text':
      if (!m.text) return `<div class="hbm hbm--bot hbm--bare">${linksHtml(m.links)}</div>`;
      return `<div class="hbm hbm--bot"><p>${esc(m.text)}</p>${linksHtml(m.links)}</div>`;
    case 'faq':
      return `<div class="hbm hbm--bot hbm--faq"><b>${esc(m.q)}</b><p>${esc(m.a)}</p>${linksHtml([{ label: `Más sobre ${m.group.toLowerCase()}`, to: m.to }])}</div>`;
    case 'note':
      return `<div class="hbm hbm--bot hbm--note">${icon('info')}<p>${esc(m.text)}</p></div>`;
    case 'products':
      return `<div class="hbm hbm--bot hbm--list"><p class="hbm__title">${esc(m.title)}</p>${m.items.map((p) => {
        const rx = RX[p.rx] && (p.rx !== 'directa' || m.rxAll) ? `<small class="hbp__rx${p.rx === 'directa' ? ' is-ok' : ''}">${p.rx === 'directa' ? '' : icon('file')}${esc(RX[p.rx].short)}</small>` : '';
        const price = salePrice(p);
        return `<a class="hbp" href="#/producto/${esc(p.slug)}" data-link><img src="${productImg(p)}" alt="" width="44" height="44"><span class="hbp__main"><small>${esc(p.brand)}</small><span class="hbp__name">${esc(p.name)}</span>${rx}</span><span class="hbp__price"><b>${clp(price)}</b>${price < p.price ? `<s>${clp(p.price)}</s>` : ''}</span></a>`;
      }).join('')}${m.more ? linksHtml([m.more]) : ''}</div>`;
    case 'stores':
      return `<div class="hbm hbm--bot hbm--list">${m.items.map((s) => `<div class="hbs">${icon(s.turno || s.h24 ? 'moon' : 'store')}<span><b>${esc(s.name)}</b><small>${esc(s.address)}, ${esc(s.comuna)}</small><em class="${s.turno || s.h24 ? 'is-night' : ''}">${esc(s.label)}</em></span></div>`).join('')}</div>`;
    case 'orders':
      return `<div class="hbm hbm--bot hbm--list">${m.items.map((o) => `<a class="hbs hbs--order" href="#/pedido/${esc(o.id)}" data-link>${icon('box')}<span><b>${esc(o.id)} · ${clp(o.total)}</b><em class="is-${esc(o.status.tone)}">${esc(o.status.text)}</em></span></a>`).join('')}</div>`;
    case 'contact':
      return `<div class="hbm hbm--bot hbm--list">${m.items.map((c) => (c.tel
        ? `<a class="hbs hbs--call" href="${telHref(c.tel)}">${icon(c.icon)}<span><b>${esc(c.label)}</b><small>${esc(c.sub)}</small></span></a>`
        : `<div class="hbs">${icon(c.icon)}<span><b>${esc(c.label)}</b><small>${esc(c.sub)}</small></span></div>`)).join('')}</div>`;
    case 'health':
      return `<div class="hbm hbm--bot hbm--health">
        <p class="hbh__tag">${icon('heart')}Orientación de salud</p>
        <b class="hbh__title">${esc(m.title)}</b>
        ${m.notes.map((n) => `<p class="hbh__note">${icon('info')}<span>${esc(n)}</span></p>`).join('')}
        <p class="hbh__h">Qué puedes hacer</p><ul>${m.tips.map(li).join('')}</ul>
        <p class="hbh__h">En la farmacia</p><p>${esc(m.pharmacy)}</p>
        <p class="hbh__h">Consulta a un médico si…</p><ul>${m.doctor.map(li).join('')}</ul>
        ${m.urgent.length ? `<div class="hbh__urgent"><p class="hbh__h">${icon('alert')}Llama al SAMU 131 o ve a urgencias si…</p><ul>${m.urgent.map(li).join('')}</ul></div>` : ''}
        ${linksHtml([m.more])}
        <p class="hbh__foot">Información general: no reemplaza una consulta médica ni indica dosis.</p>
      </div>`;
    case 'alert':
      return `<div class="hbm hbm--bot hbm--alert${m.tone === 'care' ? ' hbm--care' : ''}" role="alert">
        <b class="hbh__title">${icon(m.tone === 'care' ? 'heart' : 'alert')}${esc(m.title)}</b>
        <p>${esc(m.text)}</p>
        ${m.points?.length ? `<ul>${m.points.map(li).join('')}</ul>` : ''}
        <div class="hbm__calls">${m.lines.map(callHtml).join('')}</div>
        ${m.foot ? `<p class="hbh__foot">${esc(m.foot)}</p>` : ''}
      </div>`;
    case 'chips':
      return `<div class="hbm__chips">${m.items.map((q) => `<button type="button" class="hb__chip" data-ask="${esc(q)}">${esc(q)}</button>`).join('')}</div>`;
    default:
      return '';
  }
}

function logEl() { return $('#hb-log', ui.root); }

function scrollDown() {
  const log = logEl();
  if (log) log.scrollTop = log.scrollHeight;
}

function push(html) {
  logEl().insertAdjacentHTML('beforeend', html);
  scrollDown();
}

async function botSays(msgs) {
  for (const m of msgs) {
    push(msgHtml(m));
    await wait(160);
  }
}

async function typing(ms) {
  push('<div class="hbm hbm--bot hbm--typing" aria-label="El asistente está escribiendo"><span class="hb__typing"><i></i><i></i><i></i></span></div>');
  await wait(ms);
  $$('.hbm--typing', ui.root).forEach((t) => t.remove());
}

function ask(text) {
  const q = String(text || '').trim();
  if (!q) return ui.queue;
  ui.queue = ui.queue.then(async () => {
    // Los botones de la respuesta anterior ya cumplieron su función
    $$('.hbm__chips', ui.root).forEach((c) => c.remove());
    push(`<div class="hbm hbm--user"><p>${esc(q)}</p></div>`);
    const reply = botReply(q);
    await typing(Math.min(1100, 420 + q.length * 12));
    await botSays(reply);
  }).catch((e) => console.error(e));
  return ui.queue;
}

// ── Estados ──────────────────────────────────────────────────
function apply() {
  const r = ui.root;
  if (!r) return;
  r.hidden = ui.hidden;
  r.classList.toggle('is-chat', ui.mode === 'chat');
  r.classList.toggle('is-min', ui.mode === 'min');
  document.body.classList.toggle('hb-full', ui.mode === 'chat' && isPhone() && !ui.hidden);
}

function setMode(mode, { remember = true } = {}) {
  ui.mode = mode;
  if (remember) store(mode === 'min' ? 'min' : '');
  apply();
}

export async function openHelpbot(question) {
  if (!ui.root) return;
  ui.hidden = false;
  setMode('chat');
  if (!ui.started) {
    ui.started = true;
    ui.queue = ui.queue.then(() => botSays(greeting()));
  }
  if (question) await ask(question);
  else if (!isPhone()) $('#hb-q', ui.root)?.focus({ preventScroll: true });
  scrollDown();
}

function closeChat() {
  setMode(!isPhone() && ui.compact ? 'min' : 'mini', { remember: false });
}

// ── Frases que va diciendo ───────────────────────────────────
function showLine(text, animate = true) {
  const r = ui.root;
  const say = $('.hb__say', r);
  const pill = $('.hb__pill-say', r);
  const put = () => {
    say.textContent = text;
    pill.textContent = text;
    r.classList.remove('is-typing');
    r.classList.remove('is-new');
    void r.offsetWidth;
    r.classList.add('is-new');
  };
  if (!animate || reduceMotion()) { put(); return; }
  r.classList.add('is-typing');
  setTimeout(put, 850);
}

function tick() {
  const r = ui.root;
  const paused = ui.mode === 'chat' || ui.hover || ui.hidden || document.hidden || r.contains(document.activeElement);
  if (!paused) {
    ui.li = (ui.li + 1) % ui.lines.length;
    showLine(ui.lines[ui.li]);
  }
}

function startCycle() {
  clearInterval(ui.timer);
  ui.timer = setInterval(tick, Math.max(2500, HELPBOT.every || 5500));
}

/** La página cambió: frases propias de la página, y se oculta en el panel. */
export function helpbotRoute(path = '/') {
  if (!ui.root) return;
  ui.hidden = false;
  // La ventanita completa se muestra en la portada y en Ayuda; en el resto de las
  // páginas queda el botón con la frase, para no tapar productos, botones ni el pago
  const compact = !(path === '/' || path === '/ayuda' || path.startsWith('/ayuda/'));
  if (compact && !ui.compact && ui.mode === 'mini' && !isPhone()) setMode('min', { remember: false });
  if (!compact && ui.compact && ui.mode === 'min' && stored() !== 'min') setMode('mini', { remember: false });
  ui.compact = compact;
  const lines = teasersFor(path);
  if (lines.join('|') !== ui.lines.join('|')) {
    ui.lines = lines;
    ui.li = Math.min(ui.li, lines.length - 1);
  }
  apply();
}

export function mountHelpbot() {
  const r = document.getElementById('hb');
  if (!r) return;
  ui.root = r;
  ui.mode = stored() === 'min' ? 'min' : 'mini';
  apply();
  showLine(ui.lines[0], false);
  // Aparece con un pequeño retraso para no competir con la carga de la página
  setTimeout(() => {
    r.classList.add('is-in');
    if (!reduceMotion()) { r.classList.add('is-typing'); setTimeout(() => r.classList.remove('is-typing'), 900); }
  }, 700);
  startCycle();

  r.addEventListener('mouseenter', () => { ui.hover = true; });
  r.addEventListener('mouseleave', () => { ui.hover = false; });
  r.addEventListener('click', (e) => {
    const chip = e.target.closest('[data-ask]');
    if (chip) {
      e.preventDefault();
      if (ui.mode !== 'chat') openHelpbot(chip.dataset.ask);
      else ask(chip.dataset.ask);
      return;
    }
    const act = e.target.closest('[data-hb]')?.dataset.hb;
    if (act === 'open') { openHelpbot(); return; }
    if (act === 'min') { setMode('min'); return; }
    if (act === 'shrink') {
      if (ui.mode === 'chat') closeChat();
      else setMode('min');
      return;
    }
    // Al seguir un enlace en el celular, se cierra la conversación para ver la página
    if (e.target.closest('a[href^="#/"]') && isPhone() && ui.mode === 'chat') setMode('mini', { remember: false });
  });
  $('#hb-form', r).addEventListener('submit', (e) => {
    e.preventDefault();
    const input = $('#hb-q', r);
    const q = input.value.trim();
    if (!q) { input.focus(); return; }
    input.value = '';
    if (ui.mode !== 'chat') openHelpbot(q);
    else ask(q);
  });
  r.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && ui.mode === 'chat') {
      e.stopPropagation();
      closeChat();
      (ui.mode === 'mini' && !isPhone() ? $('#hb-q', r) : $('.hb__pill', r))?.focus({ preventScroll: true });
    }
  });
  window.matchMedia?.('(max-width: 600px)').addEventListener?.('change', apply);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) startCycle(); });
}

// Ilustraciones de envases generadas en SVG (sin fotos con derechos de autor).
// Cada producto tiene su "envase" según su formato y colores derivados de su marca.

import { esc } from './dom.js';

const cache = new Map();

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const MED_HUES = [214, 188, 356, 22, 148, 266, 42, 200, 330, 172];
const CAT_HUE = { medicamentos: 214, dermocosmetica: 196, 'vitaminas-y-suplementos': 32, 'infantil-y-mama': 205, 'cuidado-personal': 170, belleza: 320, mascotas: 24 };
const BRAND_HSL = {
  Piedra: [222, 62, 38],
  'Piedra Vital': [36, 82, 44],
  'Piedra Salud': [212, 58, 40],
  'Piedra Bebé': [198, 62, 52],
  'Piedra Sport': [222, 28, 24],
};

const hsl = (h, s, l) => `hsl(${h}, ${s}%, ${l}%)`;

function palette(p) {
  let h;
  let s = 62;
  let l = 44;
  if (BRAND_HSL[p.brand]) [h, s, l] = BRAND_HSL[p.brand];
  else if (p.isMedicine) h = MED_HUES[hash(p.brand + p.ingredients.join('+')) % MED_HUES.length];
  else h = ((CAT_HUE[p.cat] ?? 210) + (hash(p.brand + p.name) % 70) - 35 + 360) % 360;
  return {
    h,
    main: hsl(h, s, l),
    dark: hsl(h, s, Math.max(14, l - 16)),
    mid: hsl(h, Math.min(85, s + 6), Math.min(82, l + 26)),
    light: hsl(h, Math.min(90, s + 12), 94),
    soft: hsl(h, 40, 88),
  };
}

const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

function labelText(p) {
  // Monodroga o asociación de 2: se rotula por principio activo; si son más, por nombre.
  if (p.isMedicine && p.ingredients.length && p.ingredients.length <= 2) return p.ingredients.map(cap).join(' + ');
  return p.name
    .replace(/\s\d+([.,]\d+)?\s?(ml|g|kg|m|cm|mg|mcg|ui|gr|unidades|unidad|comprimidos|cápsulas|sobres|ampollas|parches|dosis|x)(\s|$).*$/i, '')
    .replace(/\spack\s.*$/i, '')
    .replace(/\stalla\s.*$/i, '')
    .trim();
}

const SHORT = { comprimidos: 'comp.', 'comprimidos efervescentes': 'comp.', 'comprimidos masticables': 'comp.', 'comprimidos bucodispersables': 'comp.', 'cápsulas': 'cáps.', 'cápsulas blandas': 'cáps.' };
function qtyText(p, short = false) {
  if (p.unitName === 'g' || p.unitName === 'ml') return `${p.units} ${p.unitName}`;
  if (p.units <= 1) return p.form && p.form !== 'unidad' ? cap(p.form) : '';
  if (short) return `${p.units} ${SHORT[p.form] || p.form || p.unitName}`.slice(0, 14);
  return `${p.units} ${p.form || p.unitName}`.slice(0, 26);
}

// Divide en líneas de hasta `max` caracteres (máx. `lines` líneas)
function wrap(text, max, lines) {
  const words = String(text).split(/\s+/).filter(Boolean);
  const out = [];
  let cur = '';
  for (const w of words) {
    if (!cur) cur = w;
    else if ((cur + ' ' + w).length <= max) cur += ` ${w}`;
    else { out.push(cur); cur = w; }
  }
  if (cur) out.push(cur);
  if (out.length > lines) {
    const kept = out.slice(0, lines);
    kept[lines - 1] = `${kept[lines - 1].replace(/[,+]$/, '')}…`;
    return kept;
  }
  return out;
}

const T = (x, y, size, weight, fill, content, anchor = 'start', extra = '') =>
  `<text x="${x}" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="${size}" font-weight="${weight}" fill="${fill}" text-anchor="${anchor}" ${extra}>${esc(content)}</text>`;

function textBlock({ x, y, width, lines, maxSize, fill = '#15202B', anchor = 'start', weight = 800, lh = 1.12, min = 7.5 }) {
  const longest = Math.max(1, ...lines.map((l) => l.length));
  const size = Math.max(min, Math.min(maxSize, width / (0.6 * longest)));
  const out = lines.map((l, i) => T(x, (y + i * size * lh).toFixed(1), size.toFixed(1), weight, fill, l, anchor)).join('');
  return { svg: out, bottom: y + (lines.length - 1) * size * lh, size };
}

const SHADOW = (cx, cy, rx) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="6.5" fill="#0B1320" opacity=".10"/>`;
const BE = (x, y, r = 9) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#F2C200"/><circle cx="${x}" cy="${y}" r="${r - 1.6}" fill="none" stroke="#3A2E00" stroke-width=".8" opacity=".35"/>${T(x, y + r * 0.33, r * 0.82, 800, '#3A2E00', 'BE', 'middle')}`;

// ── Formas de envase ──────────────────────────────────────────
function box(p, c, o = {}) {
  const rawBrand = (p.brand || '').toUpperCase();
  const brand = p.be && rawBrand.length > 17 ? `${rawBrand.slice(0, 16)}…` : rawBrand.slice(0, 24);
  const nameLines = wrap(labelText(p), 13, o.glyph ? 2 : 3);
  const nb = textBlock({ x: 44, y: 84, width: 96, lines: nameLines, maxSize: o.glyph ? 13 : 15 });
  let body = `${SHADOW(102, 179, 76)}
    <path d="M150 50 L170 36 L170 158 L150 172 Z" fill="${c.dark}"/>
    <path d="M34 50 L54 36 L170 36 L150 50 Z" fill="${c.mid}"/>
    <rect x="34" y="50" width="116" height="122" rx="2" fill="#FFFFFF"/>
    <path d="M34 136 C66 124 108 148 150 130 L150 172 L34 172 Z" fill="${c.main}"/>
    <rect x="34.5" y="50.5" width="115" height="121" rx="2" fill="none" stroke="#0B1320" stroke-opacity=".07"/>
    ${T(44, 67, 7.5, 700, '#6B7685', brand, 'start', 'letter-spacing=".6"')}
    ${nb.svg}`;
  if (o.glyph) body += o.glyph;
  else if (p.strength) body += T(44, Math.min(128, nb.bottom + 15), 11, 700, c.main, p.strength.slice(0, 18));
  const q = qtyText(p);
  if (q) body += T(44, 163, 9.5, 700, '#FFFFFF', q);
  if (p.rx !== 'directa' && p.isMedicine) body += T(44, 151, 6.5, 700, '#FFFFFF', 'VENTA BAJO RECETA MÉDICA', 'start', 'opacity=".88" letter-spacing=".3"');
  if (p.be) body += BE(139, 63, 8);
  return body;
}

function bottle(p, c) {
  const amber = p.isMedicine;
  const bodyFill = amber ? 'url(#amb)' : c.mid;
  const lines = wrap(labelText(p), 11, 2);
  const nb = textBlock({ x: 100, y: 116, width: 60, lines, maxSize: 11, anchor: 'middle' });
  return `<defs><linearGradient id="amb" x1="0" x2="1"><stop offset="0" stop-color="#B0662A"/><stop offset=".55" stop-color="#8A4516"/><stop offset="1" stop-color="#5E2C0C"/></linearGradient></defs>
    ${SHADOW(100, 181, 44)}
    <rect x="80" y="22" width="40" height="22" rx="4" fill="${c.dark}"/>
    <path d="M86 26v14M92 26v14M98 26v14M104 26v14M110 26v14M116 26v14" stroke="#FFFFFF" stroke-opacity=".18" stroke-width="2"/>
    <rect x="86" y="42" width="28" height="12" fill="${amber ? '#4A2209' : c.dark}"/>
    <path d="M64 68 Q64 54 78 54 L122 54 Q136 54 136 68 L136 168 Q136 179 125 179 L75 179 Q64 179 64 168 Z" fill="${bodyFill}"/>
    <rect x="71" y="62" width="6" height="104" rx="3" fill="#FFFFFF" opacity=".16"/>
    <rect x="64" y="94" width="72" height="64" fill="#FFFFFF"/>
    <rect x="64" y="94" width="72" height="9" fill="${c.main}"/>
    ${nb.svg}
    ${p.strength ? T(100, Math.min(146, nb.bottom + 12), 8.5, 700, c.main, p.strength.slice(0, 16), 'middle') : ''}
    ${T(100, 154, 7.5, 700, '#6B7685', qtyText(p), 'middle')}
    ${p.be ? BE(122, 76, 7) : ''}`;
}

function dropper(p, c) {
  const lines = wrap(labelText(p), 10, 2);
  const nb = textBlock({ x: 100, y: 118, width: 50, lines, maxSize: 10, anchor: 'middle' });
  const glass = p.isMedicine ? '#8A4516' : c.mid;
  return `${SHADOW(100, 181, 38)}
    <rect x="89" y="22" width="22" height="30" rx="11" fill="#2B2F36"/>
    <rect x="83" y="48" width="34" height="16" rx="3" fill="${c.dark}"/>
    <rect x="70" y="64" width="60" height="114" rx="12" fill="${glass}"/>
    <rect x="77" y="72" width="5" height="96" rx="2.5" fill="#FFFFFF" opacity=".2"/>
    <rect x="70" y="98" width="60" height="58" fill="#FFFFFF"/>
    <rect x="70" y="98" width="60" height="8" fill="${c.main}"/>
    ${nb.svg}
    ${T(100, 151, 7.5, 700, '#6B7685', qtyText(p), 'middle')}
    ${p.be ? BE(120, 114, 6.5) : ''}`;
}

function tube(p, c) {
  const lines = wrap(labelText(p), 12, 3);
  const nb = textBlock({ x: 100, y: 90, width: 66, lines, maxSize: 12, anchor: 'middle', min: 7 });
  return `${SHADOW(100, 183, 40)}
    <rect x="58" y="24" width="84" height="11" rx="2" fill="#D9DFE7"/>
    <path d="M66 26v7M74 26v7M82 26v7M90 26v7M98 26v7M106 26v7M114 26v7M122 26v7M130 26v7" stroke="#FFFFFF" stroke-width="1.5" opacity=".7"/>
    <path d="M60 35 L140 35 L129 152 Q128 158 121 158 L79 158 Q72 158 71 152 Z" fill="#FFFFFF"/>
    <path d="M60 35 L140 35 L137 66 L63 66 Z" fill="${c.main}"/>
    <path d="M60.5 35.5 L139.5 35.5 L128.6 151.5 Q127.5 157.5 121 157.5 L79 157.5 Q72.5 157.5 71.4 151.5 Z" fill="none" stroke="#0B1320" stroke-opacity=".07"/>
    ${T(100, 55, 6.5, 700, '#FFFFFF', (p.brand || '').toUpperCase().slice(0, 16), 'middle', 'letter-spacing=".4"')}
    ${nb.svg}
    ${p.strength ? T(100, Math.min(140, nb.bottom + 14), 9.5, 700, c.main, p.strength.slice(0, 14), 'middle') : ''}
    ${T(100, 150, 7.5, 700, '#6B7685', qtyText(p), 'middle')}
    <rect x="82" y="157" width="36" height="24" rx="4" fill="${c.dark}"/>
    ${p.be ? BE(124, 80, 7) : ''}`;
}

function spray(p, c) {
  const lines = wrap(labelText(p), 10, 3);
  const nb = textBlock({ x: 100, y: 112, width: 48, lines, maxSize: 10, anchor: 'middle' });
  return `${SHADOW(100, 183, 38)}
    <path d="M94 22 L106 22 L108 50 L92 50 Z" fill="#E7ECF2"/>
    <rect x="86" y="48" width="28" height="16" rx="4" fill="${c.dark}"/>
    <rect x="72" y="62" width="56" height="118" rx="14" fill="${p.isMedicine ? '#FFFFFF' : c.mid}"/>
    <rect x="72" y="92" width="56" height="70" fill="#FFFFFF"/>
    <rect x="72" y="92" width="56" height="10" fill="${c.main}"/>
    <rect x="72.5" y="62.5" width="55" height="117" rx="13.5" fill="none" stroke="#0B1320" stroke-opacity=".08"/>
    ${nb.svg}
    ${T(100, 156, 7, 700, '#6B7685', qtyText(p), 'middle')}`;
}

function pump(p, c) {
  const lines = wrap(labelText(p), 11, 3);
  const nb = textBlock({ x: 100, y: 108, width: 56, lines, maxSize: 11, anchor: 'middle' });
  return `${SHADOW(100, 183, 46)}
    <path d="M96 22 H128 Q134 22 134 28 V30 H104 V44 H96 Z" fill="${c.dark}"/>
    <rect x="88" y="42" width="24" height="16" rx="3" fill="${c.dark}"/>
    <rect x="64" y="56" width="72" height="124" rx="18" fill="${c.mid}"/>
    <rect x="72" y="66" width="6" height="104" rx="3" fill="#FFFFFF" opacity=".25"/>
    <rect x="64" y="84" width="72" height="76" fill="#FFFFFF"/>
    <rect x="64" y="84" width="72" height="9" fill="${c.main}"/>
    ${T(100, 91, 6, 700, '#FFFFFF', (p.brand || '').toUpperCase().slice(0, 16), 'middle', 'letter-spacing=".3"')}
    ${nb.svg}
    ${T(100, 154, 7.5, 700, '#6B7685', qtyText(p), 'middle')}`;
}

function jar(p, c) {
  const lines = wrap(labelText(p), 15, 2);
  const nb = textBlock({ x: 100, y: 116, width: 80, lines, maxSize: 12, anchor: 'middle' });
  return `${SHADOW(100, 182, 52)}
    <rect x="50" y="56" width="100" height="28" rx="7" fill="${c.dark}"/>
    <path d="M58 60v20M66 60v20M74 60v20M82 60v20M90 60v20M98 60v20M106 60v20M114 60v20M122 60v20M130 60v20M138 60v20" stroke="#FFFFFF" stroke-opacity=".15" stroke-width="2"/>
    <rect x="54" y="82" width="92" height="98" rx="14" fill="${c.light}"/>
    <rect x="54" y="96" width="92" height="62" fill="#FFFFFF"/>
    <rect x="54" y="96" width="92" height="8" fill="${c.main}"/>
    ${nb.svg}
    ${T(100, 152, 8, 700, '#6B7685', qtyText(p), 'middle')}
    ${p.be ? BE(134, 116, 7) : ''}`;
}

function tubeEff(p, c) {
  const lines = wrap(labelText(p), 10, 3);
  const nb = textBlock({ x: 100, y: 94, width: 54, lines, maxSize: 10, anchor: 'middle', fill: '#FFFFFF', min: 6.5 });
  return `${SHADOW(100, 183, 38)}
    <rect x="64" y="20" width="72" height="22" rx="6" fill="${c.dark}"/>
    <rect x="68" y="40" width="64" height="140" rx="6" fill="#F4F6F9"/>
    <rect x="68" y="74" width="64" height="84" fill="${c.main}"/>
    <rect x="73" y="46" width="5" height="128" rx="2.5" fill="#FFFFFF" opacity=".5"/>
    ${nb.svg}
    ${T(100, 150, 7.5, 700, '#FFFFFF', qtyText(p, true), 'middle')}`;
}

function pack(p, c) {
  const lines = wrap(labelText(p), 16, 2);
  const nb = textBlock({ x: 100, y: 108, width: 100, lines, maxSize: 14, anchor: 'middle' });
  const big = p.variant ? `<circle cx="146" cy="72" r="15" fill="#FFFFFF"/>${T(146, 77, p.variant.length > 2 ? 10 : 13, 800, c.dark, p.variant, 'middle')}` : '';
  return `${SHADOW(100, 183, 74)}
    <path d="M30 66 Q30 44 52 44 L148 44 Q170 44 170 66 L173 158 Q173 179 150 179 L50 179 Q27 179 27 158 Z" fill="${c.light}"/>
    <path d="M30 66 Q30 44 52 44 L148 44 Q170 44 170 66 L171 88 Q100 104 29 88 Z" fill="${c.main}"/>
    <path d="M84 52 Q100 44 116 52" fill="none" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round" opacity=".85"/>
    ${T(100, 74, 8, 700, '#FFFFFF', (p.brand || '').toUpperCase().slice(0, 22), 'middle', 'letter-spacing=".6"')}
    ${nb.svg}
    ${T(100, 160, 9, 700, c.dark, qtyText(p), 'middle')}
    ${big}`;
}

function inhaler(p, c) {
  return `${SHADOW(100, 182, 46)}
    <rect x="84" y="20" width="34" height="78" rx="9" fill="#C7CFDA"/>
    <rect x="84" y="20" width="34" height="14" rx="7" fill="#AEB8C6"/>
    <path d="M72 70 H130 Q138 70 138 78 V156 Q138 172 122 172 H96 V182 H66 Q60 182 60 176 V160 H72 Z" fill="${c.main}"/>
    <rect x="80" y="104" width="48" height="40" rx="5" fill="#FFFFFF"/>
    ${textBlock({ x: 104, y: 120, width: 42, lines: wrap(labelText(p), 10, 2), maxSize: 9, anchor: 'middle' }).svg}
    ${T(104, 139, 6.5, 700, '#6B7685', p.strength.slice(0, 14), 'middle')}`;
}

function pen(p, c) {
  return `${SHADOW(100, 180, 70)}
    <g transform="rotate(-28 100 104)">
      <rect x="22" y="92" width="156" height="26" rx="13" fill="#E9EDF2"/>
      <rect x="22" y="92" width="52" height="26" rx="13" fill="${c.main}"/>
      <rect x="150" y="96" width="34" height="18" rx="6" fill="${c.dark}"/>
      <rect x="96" y="97" width="30" height="16" rx="3" fill="#FFFFFF" stroke="#0B1320" stroke-opacity=".12"/>
      ${T(111, 108.5, 8, 800, '#15202B', '100 UI', 'middle')}
    </g>
    ${T(100, 168, 10, 800, '#15202B', labelText(p).slice(0, 22), 'middle')}
    <circle cx="160" cy="44" r="13" fill="#E3F1FF"/>${T(160, 48.5, 12, 800, '#2B6CB0', '❄', 'middle')}`;
}

const GLYPHS = {
  thermo: (c) => `<rect x="86" y="104" width="12" height="38" rx="6" fill="none" stroke="${c.main}" stroke-width="3"/><circle cx="92" cy="146" r="8" fill="${c.main}"/><rect x="89.5" y="118" width="5" height="26" fill="${c.main}"/>`,
  cuff: (c) => `<rect x="66" y="104" width="44" height="30" rx="5" fill="none" stroke="${c.main}" stroke-width="3"/>${T(88, 124, 11, 800, c.main, '120', 'middle')}<path d="M110 120 C124 120 124 138 136 138" fill="none" stroke="${c.main}" stroke-width="3"/>`,
  pulse: (c) => `<path d="M62 124 H80 L86 108 L94 140 L100 118 L106 124 H128" fill="none" stroke="${c.main}" stroke-width="3.2" stroke-linejoin="round"/>`,
  neb: (c) => `<rect x="64" y="110" width="44" height="28" rx="6" fill="none" stroke="${c.main}" stroke-width="3"/><path d="M108 120 C122 112 126 100 136 104" fill="none" stroke="${c.main}" stroke-width="3"/>`,
  drop: (c) => `<path d="M92 102 C92 102 108 120 108 130 A16 16 0 0 1 76 130 C76 120 92 102 92 102Z" fill="${c.main}"/>`,
  baby: (c) => `<circle cx="92" cy="124" r="16" fill="none" stroke="${c.main}" stroke-width="3"/><circle cx="86" cy="122" r="1.8" fill="${c.main}"/><circle cx="98" cy="122" r="1.8" fill="${c.main}"/><path d="M86 130 Q92 135 98 130" fill="none" stroke="${c.main}" stroke-width="2.4" stroke-linecap="round"/>`,
  brush: (c) => `<rect x="70" y="118" width="58" height="10" rx="5" fill="${c.main}"/><rect x="118" y="108" width="14" height="12" rx="3" fill="#C7CFDA"/>`,
};

function device(p, c, kind) {
  const g = `<g transform="translate(0 11)">${(GLYPHS[kind] || GLYPHS.pulse)(c)}</g>`;
  return box(p, c, { glyph: g });
}

function soap(p, c) {
  return `${SHADOW(100, 168, 66)}
    <rect x="36" y="78" width="128" height="80" rx="26" fill="${c.light}"/>
    <rect x="36" y="96" width="128" height="44" fill="${c.main}"/>
    ${T(100, 115, 9, 700, '#FFFFFF', (p.brand || '').toUpperCase(), 'middle', 'letter-spacing=".8"')}
    ${T(100, 131, 11, 800, '#FFFFFF', labelText(p).slice(0, 20), 'middle')}`;
}

function stick(p, c) {
  const lines = wrap(labelText(p), 8, 4);
  const nb = textBlock({ x: 100, y: 104, width: 30, lines, maxSize: 8, anchor: 'middle' });
  return `${SHADOW(100, 182, 26)}
    <rect x="82" y="22" width="36" height="58" rx="8" fill="${c.dark}"/>
    <rect x="82" y="78" width="36" height="102" rx="6" fill="#FFFFFF"/>
    <rect x="82" y="78" width="36" height="10" fill="${c.main}"/>
    <rect x="82.5" y="78.5" width="35" height="101" rx="5.5" fill="none" stroke="#0B1320" stroke-opacity=".1"/>
    ${nb.svg}`;
}

function polish(p, c) {
  return `${SHADOW(100, 180, 34)}
    <rect x="88" y="26" width="24" height="64" rx="4" fill="#23272E"/>
    <rect x="72" y="88" width="56" height="90" rx="14" fill="${c.main}"/>
    <rect x="80" y="96" width="6" height="72" rx="3" fill="#FFFFFF" opacity=".3"/>
    <rect x="80" y="122" width="40" height="30" rx="4" fill="#FFFFFF"/>
    ${textBlock({ x: 100, y: 134, width: 36, lines: wrap(labelText(p), 9, 2), maxSize: 8, anchor: 'middle' }).svg}`;
}

function babybottle(p, c) {
  return `${SHADOW(100, 182, 34)}
    <path d="M92 20 Q100 12 108 20 L110 40 H90 Z" fill="#F2C9A0"/>
    <rect x="80" y="38" width="40" height="16" rx="4" fill="${c.main}"/>
    <rect x="76" y="54" width="48" height="126" rx="14" fill="#EAF2FB" stroke="#0B1320" stroke-opacity=".08"/>
    <path d="M86 78h10M86 98h14M86 118h10M86 138h14M86 158h10" stroke="${c.main}" stroke-width="2"/>
    ${T(112, 172, 7, 700, c.dark, '260 ml', 'middle')}`;
}

const SHAPES = { box, bottle, dropper, tube, spray, pump, jar, tubeEff, pack, inhaler, pen, soap, stick, polish, babybottle };

export function productSvg(p) {
  const c = palette(p);
  const [shape, kind] = String(p.art || 'box').split(':');
  const inner = shape === 'device' ? device(p, c, kind) : (SHAPES[shape] || box)(p, c);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" role="img">${inner}</svg>`;
}

// Fotos que sube el administrador: las entrega el servidor (sin servidor no hay fotos)
let photoBase = '';
/** Dirección desde donde se cargan las fotos ('' = solo dibujos). */
export function setPhotoBase(base) { photoBase = String(base || ''); }

export function productImg(p) {
  if (photoBase && p.photo?.v) return `${photoBase}${encodeURIComponent(p.id)}?v=${encodeURIComponent(p.photo.v)}`;
  // Los productos creados en el panel se identifican también por su contenido
  // (si se editan, su dibujo se vuelve a generar).
  const key = p._sig || p.id;
  if (!cache.has(key)) cache.set(key, `data:image/svg+xml;charset=utf-8,${encodeURIComponent(productSvg(p))}`);
  return cache.get(key);
}

/** Dibujo sin caché (vista previa de un producto que aún no existe). */
export const previewImg = (p) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(productSvg(p))}`;

export function artHue(p) {
  return palette(p).h;
}

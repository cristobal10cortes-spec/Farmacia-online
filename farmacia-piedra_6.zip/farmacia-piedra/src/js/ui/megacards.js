// Tarjetas de color del menú «Categorías». La tienda y el panel (vista previa)
// las dibujan con la misma función, así se ven idénticas.

import { esc } from './dom.js';
import { icon } from './icons.js';
import { activeCampaigns } from '../engine/pricing.js';
import { MENU_TONES, MENU_ICONS } from '../engine/menucards.js';
import { imageSrc } from '../engine/bannerlist.js';

const PATH = /^\/(?!\/)[\w\-/?=&%.~+]*$/;

/** La tarjeta del Club muestra la campaña del día mientras no se edite su texto. */
export function withLiveMenuText(c) {
  if (!c || c.dynamic !== 'club') return c;
  const camp = activeCampaigns()[0];
  if (!camp) return c;
  return { ...c, kicker: 'Hoy en el Club', title: camp.title, text: camp.text };
}

/** Una tarjeta. `tag: 'div'` la dibuja sin enlace (vista previa del panel). */
export function menuCardHtml(c, { tag = 'a', extra = '' } = {}) {
  const tone = Object.hasOwn(MENU_TONES, c.tone) ? c.tone : 'lapis';
  const ic = Object.hasOwn(MENU_ICONS, c.icon) ? c.icon : '';
  const to = PATH.test(String(c.to || '')) ? c.to : '/';
  const src = imageSrc(c.image);
  const attrs = (tag === 'a' ? ` href="#${esc(to)}" data-link` : '') + (src ? ` style="--img:url('${src}')"` : '');
  return `<${tag} class="mcard mcard--${tone}${src ? ' mcard--photo' : ''}${extra ? ` ${extra}` : ''}"${attrs}>
    <span class="mcard__top">${ic ? `<span class="mcard__ico" aria-hidden="true">${icon(ic)}</span>` : ''}${c.kicker ? `<small class="mcard__kicker">${esc(c.kicker)}</small>` : ''}</span>
    <b class="mcard__title">${esc(c.title)}</b>
    <span class="mcard__foot">${c.text ? `<span class="mcard__text">${esc(c.text)}</span>` : '<span></span>'}<span class="mcard__go" aria-hidden="true">${icon('arrowRight')}</span></span>
  </${tag}>`;
}

/** Columna de tarjetas del menú grande (vacía si el dueño no tiene ninguna activa). */
export function menuCardsHtml(list) {
  return list.map((c) => menuCardHtml(withLiveMenuText(c))).join('');
}

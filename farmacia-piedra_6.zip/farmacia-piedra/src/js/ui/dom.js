// Utilidades de DOM pequeñas y sin dependencias.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

export function delegate(root, type, selector, handler, opts) {
  root.addEventListener(type, (e) => {
    const t = e.target.closest?.(selector);
    if (t && root.contains(t)) handler(e, t);
  }, opts);
}

export function debounce(fn, ms = 120) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

export const cls = (...xs) => xs.filter(Boolean).join(' ');

export function formData(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') out[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) out[el.name] = el.value; }
    else out[el.name] = el.value;
  }
  return out;
}

export function setErrors(form, errors = {}) {
  $$('.field', form).forEach((f) => {
    f.classList.remove('is-invalid');
    const m = $('.field__error', f);
    if (m) m.textContent = '';
  });
  let first = null;
  for (const [name, msg] of Object.entries(errors)) {
    const input = form.elements[name];
    const field = (input?.length && !input.tagName ? input[0] : input)?.closest?.('.field');
    if (!field) continue;
    field.classList.add('is-invalid');
    const m = $('.field__error', field);
    if (m) m.textContent = msg;
    if (!first) first = input?.length && !input.tagName ? input[0] : input;
  }
  if (first) first.focus({ preventScroll: false });
  return !Object.keys(errors).length;
}

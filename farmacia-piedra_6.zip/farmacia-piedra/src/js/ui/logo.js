// Logo provisorio: una piedra de lapislázuli (piedra nacional de Chile) con
// destellos de pirita. Para cambiar el logo, reemplaza markSvg() o pon tu
// propia imagen en logo().

import { BRAND } from '../config.js';

let n = 0;

export function markSvg(size = 40) {
  n += 1;
  const id = `pg${n}`;
  return `<svg class="logo__mark" width="${size}" height="${size}" viewBox="0 0 48 48" aria-hidden="true" focusable="false">
    <defs>
      <linearGradient id="${id}" x1="0.15" y1="0.1" x2="0.85" y2="0.95">
        <stop offset="0" stop-color="#4A72CF"/>
        <stop offset="0.55" stop-color="#24479B"/>
        <stop offset="1" stop-color="#162E66"/>
      </linearGradient>
    </defs>
    <path d="M6.5 27.5C6.5 17.3 14.6 9.5 25.1 9.5 35.2 9.5 42 15.9 42 24.8 42 34.4 34.3 40.5 23.8 40.5 13.6 40.5 6.5 35.6 6.5 27.5Z" fill="url(#${id})"/>
    <path d="M14 21.5c2.4-5 7.2-7.6 12.4-7.8" fill="none" stroke="#FFFFFF" stroke-opacity=".38" stroke-width="2.6" stroke-linecap="round"/>
    <circle cx="30.5" cy="30" r="1.7" fill="#E5C55A"/>
    <circle cx="35" cy="24.6" r="1.15" fill="#E5C55A"/>
    <circle cx="24.6" cy="33.6" r="1" fill="#E5C55A"/>
  </svg>`;
}

export function logo({ compact = false } = {}) {
  return `<span class="logo${compact ? ' logo--compact' : ''}">${markSvg(compact ? 34 : 40)}<span class="logo__text"><span class="logo__sub">farmacias</span><span class="logo__word">${BRAND.name.toLowerCase()}</span></span></span>`;
}

// Ícono para la pestaña del navegador (versión independiente)
export function faviconDataUri() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><path d="M6.5 27.5C6.5 17.3 14.6 9.5 25.1 9.5 35.2 9.5 42 15.9 42 24.8 42 34.4 34.3 40.5 23.8 40.5 13.6 40.5 6.5 35.6 6.5 27.5Z" fill="#24479B"/><circle cx="30.5" cy="30" r="2" fill="#E5C55A"/><circle cx="35" cy="24.6" r="1.4" fill="#E5C55A"/></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

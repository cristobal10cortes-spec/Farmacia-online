// Gráfico de línea en SVG: ejes con números, línea principal con área suave,
// línea de comparación opcional, cruz de lectura con tooltip (mouse, dedo y
// teclado) y redibujo al cambiar el tamaño.

const NS = 'http://www.w3.org/2000/svg';

/** Divisiones "redondas" para el eje Y (0, 250.000, 500.000…). */
export function niceTicks(max, target = 5) {
  if (!(max > 0)) return [0, 1];
  const raw = max / target;
  const pow = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * pow).find((s) => s >= raw) || 10 * pow;
  const top = Math.ceil(max / step) * step;
  const ticks = [];
  for (let v = 0; v <= top + step / 2; v += step) ticks.push(Math.round(v * 100) / 100);
  return ticks;
}

function el(tag, attrs = {}, parent) {
  const n = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== undefined && v !== null) n.setAttribute(k, String(v));
  if (parent) parent.appendChild(n);
  return n;
}

/**
 * opts:
 *  count      cantidad de posiciones del eje X
 *  series     [{ label, values: number[] (pueden ser menos que count), tone: 'main'|'muted' }]
 *  xTick(i)   texto corto bajo el eje (o '' para no rotular esa posición)
 *  yTick(v)   texto del eje Y
 *  tooltip(i) → { title, rows: [{ label, value, tone }] }
 *  label      descripción para lectores de pantalla
 */
export function mountLineChart(host, opts) {
  host.classList.add('lchart');
  host.innerHTML = '';
  host.tabIndex = 0;
  host.setAttribute('role', 'group');
  host.setAttribute('aria-label', opts.label || 'Gráfico');
  const svg = el('svg', { class: 'lchart__svg', 'aria-hidden': 'true' }, host);
  const tip = document.createElement('div');
  tip.className = 'lchart__tip';
  tip.hidden = true;
  host.appendChild(tip);
  const live = document.createElement('p');
  live.className = 'visually-hidden';
  live.setAttribute('aria-live', 'polite');
  host.appendChild(live);

  const H = opts.height || 300;
  const AXIS = 30;
  let geo = null;
  let active = -1;

  const lastIndex = () => Math.max(0, ...opts.series.filter((s) => s.tone !== 'muted').map((s) => s.values.length - 1));

  function draw() {
    const W = Math.max(280, Math.round(host.clientWidth || 600));
    const all = opts.series.flatMap((s) => s.values).filter((v) => Number.isFinite(v));
    const ticks = niceTicks(Math.max(0, ...all));
    const yMax = ticks[ticks.length - 1] || 1;
    const longest = Math.max(...ticks.map((t) => opts.yTick(t).length));
    const L = Math.min(96, 14 + longest * 7.2);
    const R = 18;
    const T = 14;
    const plotW = W - L - R;
    const plotH = H - T - AXIS;
    const n = Math.max(1, opts.count);
    const x = (i) => L + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW);
    const y = (v) => T + plotH - (v / yMax) * plotH;
    geo = { W, L, R, T, plotW, plotH, n, x, y };

    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('width', W);
    svg.setAttribute('height', H);
    svg.innerHTML = '';
    // Grilla y eje Y
    const grid = el('g', { class: 'lchart__grid' }, svg);
    for (const t of ticks) {
      const yy = Math.round(y(t)) + 0.5;
      el('line', { x1: L, x2: W - R, y1: yy, y2: yy, class: t === 0 ? 'is-base' : '' }, grid);
      const lab = el('text', { x: L - 10, y: yy + 4, 'text-anchor': 'end', class: 'lchart__ytick' }, grid);
      lab.textContent = opts.yTick(t);
    }
    // Eje X
    const xa = el('g', { class: 'lchart__xaxis' }, svg);
    let lastRight = -Infinity;
    for (let i = 0; i < n; i++) {
      const txt = opts.xTick(i);
      if (!txt) continue;
      const cx = x(i);
      const w = txt.length * 6.6;
      const anchor = i === 0 && n > 1 ? 'start' : i === n - 1 && n > 1 ? 'end' : 'middle';
      const left = anchor === 'start' ? cx : anchor === 'end' ? cx - w : cx - w / 2;
      if (left < lastRight + 8) continue; // sin rótulos encimados
      lastRight = left + w;
      el('line', { x1: Math.round(cx) + 0.5, x2: Math.round(cx) + 0.5, y1: T + plotH, y2: T + plotH + 5, class: 'lchart__tick' }, xa);
      const lab = el('text', { x: cx, y: T + plotH + 20, 'text-anchor': anchor, class: 'lchart__xtick' }, xa);
      lab.textContent = txt;
    }
    // Series: primero las de comparación (atrás), después la principal con su área
    const ordered = [...opts.series].sort((a, b) => (a.tone === 'muted' ? -1 : 1) - (b.tone === 'muted' ? -1 : 1));
    for (const s of ordered) {
      const pts = s.values.slice(0, n).map((v, i) => [x(i), y(v)]);
      if (!pts.length) continue;
      const d = pts.map(([px, py], i) => `${i ? 'L' : 'M'}${px.toFixed(1)} ${py.toFixed(1)}`).join(' ');
      if (s.tone !== 'muted' && pts.length > 1) {
        el('path', { d: `${d} L${pts[pts.length - 1][0].toFixed(1)} ${y(0)} L${pts[0][0].toFixed(1)} ${y(0)} Z`, class: 'lchart__area' }, svg);
      }
      el('path', { d, class: `lchart__line lchart__line--${s.tone || 'main'}` }, svg);
      if (s.tone !== 'muted') {
        const [ex, ey] = pts[pts.length - 1];
        el('circle', { cx: ex, cy: ey, r: 4.5, class: 'lchart__end' }, svg);
      }
    }
    // Capa de lectura
    el('line', { class: 'lchart__cross', x1: 0, x2: 0, y1: T, y2: T + plotH, visibility: 'hidden' }, svg);
    for (const s of opts.series) el('circle', { class: `lchart__dot lchart__dot--${s.tone || 'main'}`, r: 5, cx: 0, cy: 0, visibility: 'hidden' }, svg);
    el('rect', { class: 'lchart__hit', x: L, y: 0, width: plotW, height: H, fill: 'transparent' }, svg);
    if (active >= 0) show(active);
  }

  function show(i) {
    if (!geo) return;
    const idx = Math.max(0, Math.min(geo.n - 1, i));
    active = idx;
    const cx = geo.x(idx);
    const cross = svg.querySelector('.lchart__cross');
    cross.setAttribute('x1', cx);
    cross.setAttribute('x2', cx);
    cross.setAttribute('visibility', 'visible');
    const dots = svg.querySelectorAll('.lchart__dot');
    opts.series.forEach((s, k) => {
      const v = s.values[idx];
      const dot = dots[k];
      if (!dot) return;
      if (Number.isFinite(v)) {
        dot.setAttribute('cx', cx);
        dot.setAttribute('cy', geo.y(v));
        dot.setAttribute('visibility', 'visible');
      } else dot.setAttribute('visibility', 'hidden');
    });
    const info = opts.tooltip(idx);
    tip.textContent = '';
    const h = document.createElement('p');
    h.className = 'lchart__tip-title';
    h.textContent = info.title;
    tip.appendChild(h);
    for (const r of info.rows) {
      const row = document.createElement('p');
      row.className = `lchart__tip-row${r.tone ? ` is-${r.tone}` : ''}`;
      const key = document.createElement('i');
      key.setAttribute('aria-hidden', 'true');
      const val = document.createElement('b');
      val.textContent = r.value;
      const lab = document.createElement('span');
      lab.textContent = r.label;
      row.append(key, val, lab);
      tip.appendChild(row);
    }
    tip.hidden = false;
    const tw = tip.offsetWidth;
    const hostW = host.clientWidth;
    let left = cx + 14;
    if (left + tw > hostW - 4) left = cx - tw - 14;
    tip.style.left = `${Math.max(4, left)}px`;
    tip.style.top = `${geo.T + 4}px`;
    live.textContent = `${info.title}: ${info.rows.map((r) => `${r.label} ${r.value}`).join(', ')}`;
  }

  function hide() {
    active = -1;
    tip.hidden = true;
    svg.querySelector('.lchart__cross')?.setAttribute('visibility', 'hidden');
    svg.querySelectorAll('.lchart__dot').forEach((d) => d.setAttribute('visibility', 'hidden'));
  }

  const indexAt = (clientX) => {
    const r = svg.getBoundingClientRect();
    const scale = r.width ? geo.W / r.width : 1;
    const px = (clientX - r.left) * scale;
    if (geo.n === 1) return 0;
    return Math.round(((px - geo.L) / geo.plotW) * (geo.n - 1));
  };
  svg.addEventListener('pointermove', (e) => { if (geo) show(indexAt(e.clientX)); });
  svg.addEventListener('pointerdown', (e) => { if (geo) show(indexAt(e.clientX)); });
  svg.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') hide(); });
  host.addEventListener('focus', () => show(active >= 0 ? active : lastIndex()));
  host.addEventListener('blur', hide);
  host.addEventListener('keydown', (e) => {
    const k = e.key;
    if (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'Home' || k === 'End') {
      e.preventDefault();
      const cur = active >= 0 ? active : lastIndex();
      show(k === 'Home' ? 0 : k === 'End' ? lastIndex() : cur + (k === 'ArrowRight' ? 1 : -1));
    } else if (k === 'Escape') hide();
  });

  draw();
  let raf = 0;
  const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(draw);
  }) : null;
  ro?.observe(host);
  return () => { ro?.disconnect(); cancelAnimationFrame(raf); };
}

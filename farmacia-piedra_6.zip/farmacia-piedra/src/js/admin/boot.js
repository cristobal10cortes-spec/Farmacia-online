// Se carga antes que todo lo demás en el panel: el panel guarda sus
// preferencias con una clave propia, separada del carro y la cuenta de la tienda.
globalThis.PIEDRA_STATE_KEY = 'piedra:panel:v1';

// Conexión mínima con la API del panel. La usan la pantalla de ingreso (que
// es lo único que se entrega sin sesión) y el panel completo.

export const API = 'api'; // relativo a la dirección del panel (por ejemplo /admin/api)

/** Llama a la API del panel. Devuelve los datos o lanza un error con .code y .status. */
export async function request(path, { method = 'GET', body, csrf = '', activity } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET' && csrf) headers['X-CSRF-Token'] = csrf;
  if (activity != null) headers['X-Panel-Activity'] = activity ? '1' : '0';
  let res;
  try {
    res = await fetch(`${API}${path}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: 'same-origin', cache: 'no-store' });
  } catch {
    const e = new Error('No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo.');
    e.code = 'network';
    throw e;
  }
  if (res.status === 304) return { notModified: true };
  let data = null;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) {
    const e = new Error(data?.error || 'No se pudo completar la operación. Inténtalo de nuevo.');
    e.code = data?.code || `http_${res.status}`;
    e.status = res.status;
    e.data = data;
    throw e;
  }
  return data;
}

/** Acciones de ingreso (sin sesión). Devuelven { ok, ... } o { ok:false, error, code }. */
const wrap = (p) => p.then((r) => ({ ok: true, ...r }), (e) => ({ ok: false, error: e.message, code: e.code, totpLocked: !!e.data?.totpLocked }));
export const loginRequest = (user, password) => wrap(request('/login', { method: 'POST', body: { user, password } }));
export const codeRequest = (ticket, code) => wrap(request('/login/2fa', { method: 'POST', body: { ticket, code } }));
export const setupRequest = (token, user, password) => wrap(request('/setup', { method: 'POST', body: { token, user, password } }));

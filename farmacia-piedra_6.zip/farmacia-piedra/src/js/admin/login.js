// Pantalla de ingreso del panel: primer administrador, usuario y contraseña, y
// (si está activa) la verificación en dos pasos. Es la ÚNICA parte del panel
// que se entrega sin sesión: el resto del código llega recién al ingresar.
// No importa nada del panel para que este archivo quede pequeño.

import { $, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { openModal } from '../ui/overlay.js';

// ── Ayudas (también las usa el cambio de contraseña) ────────
export const pwIssues = (pw, user = '') => {
  const out = [];
  if (String(pw).length < 10) out.push('al menos 10 caracteres');
  if (!/[a-záéíóúñ]/i.test(pw)) out.push('al menos una letra');
  if (!/\d/.test(pw)) out.push('al menos un número');
  if (user && String(pw).toLowerCase().includes(String(user).trim().toLowerCase())) out.push('que no contenga el usuario');
  return out;
};
const userOk = (u) => /^[a-z0-9._-]{3,30}$/.test(String(u || '').trim().toLowerCase());

export function passField(name, label, autocomplete, hint = '') {
  return `<div class="field"><label for="f-${name}">${esc(label)}</label>
    <div class="pass"><input id="f-${name}" name="${name}" type="password" autocomplete="${autocomplete}" required maxlength="200"><button type="button" class="pass__eye" data-eye="f-${name}" aria-label="Mostrar contraseña" aria-pressed="false">${icon('eye')}</button></div>
    ${hint ? `<p class="field__hint">${hint}</p>` : ''}<p class="field__error" aria-live="polite"></p></div>`;
}

function textField({ label, name, autocomplete = '', placeholder = '', attrs = '' }) {
  return `<div class="field"><label for="f-${name}">${esc(label)}</label>
    <input id="f-${name}" name="${name}" type="text" required ${autocomplete ? `autocomplete="${autocomplete}"` : ''} placeholder="${esc(placeholder)}" ${attrs}>
    <p class="field__error" aria-live="polite"></p></div>`;
}

export function toggleEye(eye) {
  const input = document.getElementById(eye.dataset.eye);
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  eye.innerHTML = icon(show ? 'eyeOff' : 'eye');
  eye.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña');
  eye.setAttribute('aria-pressed', String(show));
}

export function setupTokenFromHash() {
  const m = /[?&]clave=([A-Za-z0-9_-]{10,100})/.exec(location.hash || '');
  return m ? m[1] : '';
}

function forgotHelp() {
  openModal({
    title: `${icon('lock')} ¿Olvidaste tu contraseña o perdiste el celular?`,
    size: 'sm',
    html: '<p>Por seguridad, eso se resuelve en el computador donde funciona el servidor: abre <b>crear-administrador</b> (o ejecuta <code>npm run crear-admin</code>) y escribe tu usuario. Ahí puedes poner una contraseña nueva o desactivar la verificación en dos pasos. Las sesiones abiertas se cierran.</p><p>Si tienes tus <b>códigos de respaldo</b>, también puedes usar uno en lugar del código del celular.</p>',
  });
}

// ── Pasos ─────────────────────────────────────────────────────
function passwordStep({ setup, noAdmin, notice = '' }) {
  return `<span class="admin-login__badge" aria-hidden="true">${icon('shield')}</span>
    <h1 class="admin-login__title" id="al-title">Ingresar administrador</h1>
    ${notice ? `<p class="admin-login__notice" role="status">${notice}</p>` : ''}
    <p class="admin-login__text">${setup
      ? 'Primera configuración: <b>crea el usuario y la contraseña</b> del administrador. Guárdalos en un lugar seguro.'
      : noAdmin
        ? 'Todavía no hay un administrador. Abre el enlace de <b>primera configuración</b> que aparece en la ventana del servidor, o crea uno con <b>crear-administrador</b>.'
        : 'Escribe tu usuario y contraseña para administrar el stock, los precios, los pedidos y los banners.'}</p>
    ${noAdmin ? '' : `<form id="al-form" class="admin-login__form" novalidate>
      ${textField({ label: 'Usuario', name: 'user', autocomplete: 'username', placeholder: setup ? 'Ej: admin' : '', attrs: 'autocapitalize="off" spellcheck="false" maxlength="60"' })}
      ${passField('pass', 'Contraseña', setup ? 'new-password' : 'current-password', setup ? 'Al menos 10 caracteres, con letras y números.' : '')}
      ${setup ? passField('pass2', 'Repite la contraseña', 'new-password') : ''}
      <p class="admin-login__error" id="al-error" role="alert" aria-live="assertive"></p>
      <button class="btn btn--primary btn--lg btn--block" type="submit">${icon('lock')} ${setup ? 'Crear administrador e ingresar' : 'Ingresar'}</button>
    </form>`}
    <div class="admin-login__links">
      ${setup || noAdmin ? '' : '<button type="button" class="btn btn--link btn--sm" data-forgot>¿Olvidaste tu contraseña?</button>'}
    </div>`;
}

function codeStep(recovery = false, warn = '') {
  return `<span class="admin-login__badge" aria-hidden="true">${icon('shield')}</span>
    <h1 class="admin-login__title" id="al-title">Verificación en dos pasos</h1>
    ${warn ? `<p class="admin-login__warn" role="alert">${esc(warn)}</p>` : ''}
    <p class="admin-login__text">${recovery
      ? 'Escribe uno de tus <b>códigos de respaldo</b> (por ejemplo <b>abcd-efgh</b>). Cada código sirve una sola vez.'
      : 'Abre la app de verificación de tu celular (Google Authenticator, Microsoft Authenticator u otra) y escribe el <b>código de 6 números</b> de «Farmacias Piedra».'}</p>
    <form id="tf-form" class="admin-login__form" novalidate>
      ${textField(recovery
        ? { label: 'Código de respaldo', name: 'code', autocomplete: 'off', placeholder: 'abcd-efgh', attrs: 'autocapitalize="off" spellcheck="false" maxlength="12"' }
        : { label: 'Código de 6 números', name: 'code', autocomplete: 'one-time-code', placeholder: '123456', attrs: 'inputmode="numeric" pattern="[0-9 ]*" maxlength="9"' })}
      <p class="admin-login__error" id="tf-error" role="alert" aria-live="assertive"></p>
      <button class="btn btn--primary btn--lg btn--block" type="submit">${icon('checkCircle')} Verificar e ingresar</button>
    </form>
    <div class="admin-login__links">
      <button type="button" class="btn btn--link btn--sm" data-recovery="${recovery ? '0' : '1'}">${recovery ? 'Usar el código del celular' : '¿No tienes el celular? Usa un código de respaldo'}</button>
      <button type="button" class="btn btn--link btn--sm" data-back>Volver</button>
    </div>`;
}

/**
 * Pantalla de ingreso.
 *  actions: { login(user, pass), code(ticket, code), setup(token, user, pass) } → { ok, error, needCode, ticket }
 *  onDone(kind, result): después de entrar ('login' | 'setup')
 */
export function loginView({ needsSetup, actions, onDone, notice = '' }) {
  const token = setupTokenFromHash();
  const setup = needsSetup && !!token;
  const noAdmin = needsSetup && !token;
  return {
    title: 'Ingresar administrador',
    setup,
    noAdmin,
    html: `<div class="wrap page"><div class="admin-login">
      <section class="admin-login__card" id="al-card" aria-labelledby="al-title">${passwordStep({ setup, noAdmin, notice })}</section></div></div>`,
    mount(root) {
      const card = $('#al-card', root);
      let ticket = '';
      let lastUser = '';

      const showPassword = (msg = '') => {
        card.innerHTML = passwordStep({ setup: false, noAdmin: false });
        wirePassword(false);
        if (msg) $('#al-error', card).textContent = msg;
      };

      const showCode = (recovery = false, warn = '') => {
        card.innerHTML = codeStep(recovery, warn);
        const f = $('#tf-form', card);
        const err = $('#tf-error', card);
        f.addEventListener('submit', async (e) => {
          e.preventDefault();
          err.textContent = '';
          const v = formData(f);
          const code = v.code.trim();
          const okFormat = recovery ? code.replace(/[^a-z0-9]/gi, '').length === 8 : /^\d{6}$/.test(code.replace(/\s/g, ''));
          if (!setErrors(f, okFormat ? {} : { code: recovery ? 'El código de respaldo tiene 8 letras y números (por ejemplo abcd-efgh).' : 'Escribe los 6 números que muestra la app.' })) return;
          const btn = $('button[type=submit]', f);
          btn.disabled = true;
          const r = await actions.code(ticket, code);
          btn.disabled = false;
          if (r.ok) { onDone?.('login', { ...r, user: r.user || lastUser }); return; }
          // Código del celular bloqueado por intentos: se puede seguir con un código de respaldo
          if (r.totpLocked) { showCode(true, r.error); return; }
          if (r.code === 'ticket' || r.code === 'rate_limited') { showPassword(r.error); return; }
          err.textContent = r.error;
          f.code.value = '';
          f.code.focus();
        });
        requestAnimationFrame(() => f.code.focus({ preventScroll: true }));
      };

      function wirePassword(isSetup) {
        const f = $('#al-form', card);
        if (!f) return;
        const err = $('#al-error', card);
        if (isSetup) {
          f.pass.addEventListener('input', () => {
            const hint = f.pass.closest('.field').querySelector('.field__hint');
            const issues = pwIssues(f.pass.value, f.user.value);
            hint.textContent = issues.length ? `Falta: ${issues.join(', ')}.` : 'Contraseña segura.';
            hint.style.color = issues.length ? '' : 'var(--ok)';
          });
        }
        f.addEventListener('submit', async (e) => {
          e.preventDefault();
          err.textContent = '';
          const v = formData(f);
          const errors = {};
          if (isSetup) {
            if (!userOk(v.user)) errors.user = 'El usuario debe tener entre 3 y 30 letras, números, punto, guion o guion bajo (sin espacios).';
            const issues = pwIssues(v.pass, v.user);
            if (issues.length) errors.pass = `La contraseña necesita ${issues.join(', ')}.`;
            if (v.pass !== v.pass2) errors.pass2 = 'Las contraseñas no coinciden.';
          } else {
            if (!v.user.trim()) errors.user = 'Escribe tu usuario.';
            if (!v.pass) errors.pass = 'Escribe tu contraseña.';
          }
          if (!setErrors(f, errors)) return;
          const btn = $('button[type=submit]', f);
          btn.disabled = true;
          const r = isSetup ? await actions.setup(token, v.user, v.pass) : await actions.login(v.user, v.pass);
          btn.disabled = false;
          if (!r.ok) {
            err.textContent = r.error;
            f.pass.value = '';
            f.pass.focus();
            return;
          }
          lastUser = v.user.trim().toLowerCase();
          if (r.needCode) {
            ticket = r.ticket;
            if (r.totpLocked) showCode(true, `Por muchos códigos incorrectos, el código del celular está bloqueado por ${Math.ceil(r.totpLocked / 60)} minutos. Puedes entrar con un código de respaldo.`);
            else showCode(false);
            return;
          }
          if (isSetup) history.replaceState(null, '', `${location.pathname}#/admin`);
          onDone?.(isSetup ? 'setup' : 'login', { ...r, user: r.user || lastUser });
        });
        requestAnimationFrame(() => f.user.focus({ preventScroll: true }));
      }

      root.addEventListener('click', (e) => {
        const eye = e.target.closest('[data-eye]');
        if (eye) { toggleEye(eye); return; }
        if (e.target.closest('[data-forgot]')) { forgotHelp(); return; }
        const rc = e.target.closest('[data-recovery]');
        if (rc) { showCode(rc.dataset.recovery === '1'); return; }
        if (e.target.closest('[data-back]')) { ticket = ''; showPassword(); }
      });
      wirePassword(setup);
      return null;
    },
  };
}

// Panel: cuadro «Carga la imagen aquí» (medida ideal, revisión de la foto
// subida y botón para quitarla) y vistas previas a tamaño real achicadas.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { compressPhoto } from '../ui/banners.js';
import { photoFit, imageSrc } from '../engine/bannerlist.js';

const fmt = (n) => Number(n).toLocaleString('es-CL');
const shape = (s) => (s.w > s.h * 1.15 ? 'horizontal' : s.h > s.w * 1.15 ? 'vertical' : 'cuadrada');

/** Texto de la medida ideal: «1.600 × 430 px». */
export const sizeText = (s) => `${fmt(s.w)} × ${fmt(s.h)} px`;

/**
 * Cuadro para subir una foto. `size` = medida ideal ({ w, h }).
 * El cuadro se activa con mountImageDrop().
 */
export function imageDropHtml({ name, title = 'Carga la imagen aquí', size, image = '', note = '', optional = false }) {
  const src = imageSrc(image);
  return `<div class="idrop${src ? ' has-img' : ''}" data-idrop="${esc(name)}">
    <p class="idrop__title">${esc(title)}${optional ? ' <span class="field__opt">(opcional)</span>' : ''}</p>
    <label class="idrop__zone">
      <span class="idrop__thumb" style="aspect-ratio:${size.w} / ${size.h}">${src ? `<img src="${esc(src)}" alt="">` : icon('upload')}</span>
      <span class="idrop__txt"><b>${src ? 'Cambiar imagen' : 'Elegir imagen'}</b><small>o arrástrala aquí · JPG o PNG</small></span>
      <input type="file" name="${esc(name)}" accept="image/jpeg,image/png,image/webp">
    </label>
    <p class="idrop__size">${icon('image')}<span>Medida ideal: <b>${sizeText(size)}</b> (${shape(size)})</span></p>
    ${note ? `<p class="idrop__note">${note}</p>` : ''}
    <p class="idrop__fit" aria-live="polite"></p>
    <p class="idrop__err" aria-live="polite"></p>
    <button type="button" class="btn btn--ghost btn--sm idrop__del"${src ? '' : ' hidden'}>${icon('trash')} Quitar imagen</button>
  </div>`;
}

/**
 * Activa un cuadro de foto. onChange(url, info) recibe la foto ya achicada
 * (data URL) o '' si se quitó. Devuelve { setError(msg) }.
 */
export function mountImageDrop(box, { size, maxW = 1400, maxChars = 600000, onChange }) {
  const input = $('input[type=file]', box);
  const zone = $('.idrop__zone', box);
  const thumb = $('.idrop__thumb', box);
  const label = $('.idrop__txt b', box);
  const fit = $('.idrop__fit', box);
  const err = $('.idrop__err', box);
  const del = $('.idrop__del', box);
  const setError = (msg) => {
    err.textContent = msg || '';
    box.classList.toggle('is-invalid', !!msg);
  };
  const show = (url) => {
    thumb.innerHTML = url ? `<img src="${esc(url)}" alt="">` : icon('upload');
    label.textContent = url ? 'Cambiar imagen' : 'Elegir imagen';
    del.hidden = !url;
    box.classList.toggle('has-img', !!url);
  };
  async function take(file) {
    if (!file) return;
    setError('');
    fit.className = 'idrop__fit';
    fit.textContent = 'Preparando la foto…';
    box.classList.add('is-busy');
    try {
      const r = await compressPhoto(file, { maxW, maxChars });
      const f = photoFit(r.srcW, r.srcH, size);
      fit.className = `idrop__fit idrop__fit--${f.tone}`;
      fit.innerHTML = `${icon(f.tone === 'ok' ? 'checkCircle' : 'alert')}<span>${esc(f.text)}</span>`;
      show(r.url);
      onChange(r.url, { ...r, fit: f, name: file.name });
    } catch (ex) {
      fit.textContent = '';
      setError(ex.message);
    } finally {
      box.classList.remove('is-busy');
      input.value = '';
    }
  }
  input.addEventListener('change', () => take(input.files?.[0]));
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('is-over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('is-over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('is-over');
    take(e.dataTransfer?.files?.[0]);
  });
  del.addEventListener('click', () => {
    show('');
    fit.textContent = '';
    setError('');
    onChange('', null);
  });
  return { setError };
}

/**
 * Vista previa a tamaño real, achicada para que quepa: el contenido se dibuja
 * con el ancho que tiene en la tienda (`width` px) y se escala al cuadro.
 */
export function stageHtml(inner, { width, id = '', cls = '' } = {}) {
  return `<div class="pstage${cls ? ` ${cls}` : ''}"${id ? ` id="${esc(id)}"` : ''} data-stage="${Number(width) || 1232}"><div class="pstage__in" style="width:${Number(width) || 1232}px">${inner}</div></div>`;
}

/** Ajusta la escala de las vistas previas de `root` (y la vuelve a ajustar si cambian). */
export function mountStages(root) {
  const frames = [...root.querySelectorAll('[data-stage]')];
  if (!frames.length) return () => {};
  const apply = (frame) => {
    const stage = frame.firstElementChild;
    const w = Number(frame.dataset.stage) || 1232;
    const s = Math.min(1, (frame.clientWidth || w) / w);
    stage.style.transform = s < 1 ? `scale(${s})` : '';
    frame.style.height = `${Math.ceil(stage.offsetHeight * s)}px`;
  };
  if (typeof ResizeObserver === 'undefined') {
    frames.forEach(apply);
    return () => {};
  }
  // Se ajusta en el cuadro siguiente (así no se encadenan avisos de cambio de tamaño)
  const pending = new Set();
  let raf = 0;
  const ro = new ResizeObserver((entries) => {
    for (const e of entries) pending.add(e.target.matches('[data-stage]') ? e.target : e.target.parentElement);
    if (!raf) {
      raf = requestAnimationFrame(() => {
        raf = 0;
        for (const f of pending) if (f?.isConnected) apply(f);
        pending.clear();
      });
    }
  });
  frames.forEach((f) => { ro.observe(f); ro.observe(f.firstElementChild); apply(f); });
  return () => { ro.disconnect(); if (raf) cancelAnimationFrame(raf); };
}

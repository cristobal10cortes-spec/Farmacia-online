// Punto de entrada del PANEL DE ADMINISTRACIÓN (aplicación aparte de la tienda).
// El servidor entrega este código SOLO a quien ya ingresó (sin sesión, la
// dirección del panel muestra únicamente la pantalla de ingreso: admin/acceso.js).
// Todo lo que hace pasa por la API del panel, que exige sesión y ficha anti-CSRF.

import './boot.js'; // primero: clave propia para guardar las preferencias del panel
import { route, start, go, parse, match } from '../router.js';
import { adminProductsPage, adminNewProductPage, adminEditProductPage, adminProductPage, adminOrdersPage, adminOrderPage, adminMovesPage, adminGuard, adminShell, welcomeText } from '../pages/admin.js';
import { adminSecurityPage } from '../pages/admin-security.js';
import { adminBulkPage } from '../pages/admin-carga.js';
import { adminDashboardPage } from '../pages/admin-dashboard.js';
import { adminBannersPage, adminBannerPage } from '../pages/admin-banners.js';
import { adminStoresPage, adminStorePage } from '../pages/admin-stores.js';
import { adminMenuPage, adminMenuCardPage } from '../pages/admin-menu.js';
import { adminServicesPage } from '../pages/admin-services.js';
import { setPhotoBase } from '../ui/art.js';
import { setMediaBase } from '../engine/bannerlist.js';
import { bo, initAdmin, logout, refresh } from './api.js';
import { on } from '../engine/state.js';
import { logo } from '../ui/logo.js';
import { icon } from '../ui/icons.js';
import { esc } from '../ui/dom.js';
import { emptyState } from '../ui/components.js';
import { toast, closeAll } from '../ui/overlay.js';
import { installFormSubmit } from '../ui/forms.js';

// Versión del programa (la pone build.mjs desde package.json)
// eslint-disable-next-line no-undef
const APP_VERSION = typeof __APP_VERSION__ === 'string' ? __APP_VERSION__ : '';
import { BRAND } from '../config.js';

// ── Rutas ────────────────────────────────────────────────────
route('/', () => ({ redirect: '/admin' }));
route('/primer-acceso', () => adminGuard() || { redirect: '/admin' });
route('/admin', adminDashboardPage);
route('/admin/productos', adminProductsPage);
route('/admin/productos/nuevo', adminNewProductPage);
route('/admin/productos/carga-masiva', adminBulkPage);
route('/admin/productos/:id/editar', adminEditProductPage);
route('/admin/productos/:id', adminProductPage);
route('/admin/pedidos', adminOrdersPage);
route('/admin/pedidos/:id', adminOrderPage);
route('/admin/banners', adminBannersPage);
route('/admin/banners/:id', adminBannerPage); // 'nuevo' crea uno
route('/admin/menu', adminMenuPage);
route('/admin/menu/:id', adminMenuCardPage); // 'nuevo' crea una
route('/admin/servicios', adminServicesPage);
route('/admin/farmacias', adminStoresPage);
route('/admin/farmacias/:id', adminStorePage); // 'nueva' crea una
route('/admin/movimientos', adminMovesPage);
route('/admin/seguridad', adminSecurityPage);

// Fotos de productos: las entrega la API del panel (funciona también en un subdominio propio)
setPhotoBase('api/fotos/');
setMediaBase('api/imagenes/'); // fotos de banners y tarjetas del menú

function notFoundPage() {
  return adminGuard() || {
    title: 'Página no encontrada',
    html: adminShell('', 'Página no encontrada', emptyState({ icon: 'stone', title: 'Esta sección del panel no existe', actions: '<a class="btn btn--primary" href="#/admin">Ir al resumen</a>' })),
  };
}

// ── Armado de la página ──────────────────────────────────────
const storeUrl = () => bo.store || '/'; // la tienda (el servidor la indica al conectarse)
const isPanelRoute = (h) => /^\/admin(?:[/?]|$)/.test(h);

const app = document.getElementById('app');
app.innerHTML = `<a class="skip" href="#main" data-skip>Saltar al contenido</a>
  <div class="pstrip"><div class="wrap pstrip__row">${icon('shield')}<span>Panel de administración<span class="pstrip__more"> · Acceso solo para personal autorizado</span></span></div></div>
  <header class="pbar"><div class="wrap pbar__row">
    <a class="pbar__logo" href="#/admin" aria-label="Panel de ${esc(BRAND.fullName)}: ir al resumen">${logo({ compact: true })}<span class="pbar__tag">Panel</span></a>
    <div class="pbar__side">
      <a class="btn btn--ghost btn--sm" id="pbar-store" href="/" target="_blank" rel="noopener">${icon('external')}<span class="pbar__lbl">Ver tienda</span></a>
      <span class="pbar__who" id="pbar-who" hidden>${icon('user')}<b></b></span>
      <a class="btn btn--ghost btn--sm" href="#/admin/seguridad" id="pbar-security" data-auth hidden>${icon('lock')}<span class="pbar__lbl">Seguridad</span></a>
      <button type="button" class="btn btn--soft btn--sm" data-action="admin-logout" data-auth hidden>${icon('logout')}<span class="pbar__lbl">Salir</span></button>
    </div>
  </div></header>
  <main id="main" tabindex="-1"></main>
  <footer class="pfoot"><div class="wrap pfoot__row"><span>${esc(BRAND.fullName)} · Panel de administración · <span id="pfoot-version">versión ${esc(APP_VERSION)}</span></span><span>Cada cambio queda registrado en <a href="#/admin/movimientos">Movimientos</a>.</span></div></footer>
  <div id="overlays"></div><div id="toasts" aria-live="polite"></div>`;

function updateBar() {
  document.getElementById('pbar-store').setAttribute('href', storeUrl());
  const who = document.getElementById('pbar-who');
  who.hidden = !bo.user;
  who.querySelector('b').textContent = bo.user || '';
  document.querySelectorAll('[data-auth]').forEach((el) => { el.hidden = !bo.user; });
}

// Los enlaces a la tienda (por ejemplo "Ver en la tienda") se abren en otra pestaña
function storeLinks(root) {
  root.querySelectorAll('a[href^="#/"]').forEach((a) => {
    const h = a.getAttribute('href').slice(1);
    if (isPanelRoute(h)) return;
    a.setAttribute('href', `${storeUrl()}#${h}`);
    a.target = '_blank';
    a.rel = 'noopener';
  });
}

let current = null;

function render(to, opts = {}) {
  const { path, query } = parse(to);
  const m = match(path);
  let page = null;
  try {
    page = m ? m.handler(m.params, query, to) : null;
  } catch (err) {
    console.error(err);
    page = null;
  }
  if (page && page.redirect) { go(page.redirect, { replace: true }); return; }
  if (!page) page = notFoundPage();
  try { current?.cleanup?.(); } catch (e) { console.error(e); }
  if (!opts.rerender) closeAll();
  // Cada vista se monta en un <main> nuevo (los eventos de la anterior desaparecen con él)
  const old = document.getElementById('main');
  const main = old.cloneNode(false);
  main.innerHTML = page.html;
  old.replaceWith(main);
  storeLinks(main);
  document.title = `${page.title} | Panel · ${BRAND.fullName}`;
  let cleanup = null;
  try { cleanup = page.mount?.(main) || null; } catch (e) { console.error(e); }
  current = { page, cleanup, to, path };
  // En el celular, la pestaña activa del panel queda a la vista
  const tab = main.querySelector('.admin__tabs .is-on');
  if (tab) {
    const nav = tab.parentElement;
    if (nav.scrollWidth > nav.clientWidth) nav.scrollLeft = Math.max(0, tab.getBoundingClientRect().left - nav.getBoundingClientRect().left + nav.scrollLeft - 24);
  }
  if (opts.scroll !== false && !opts.rerender) window.scrollTo(0, 0);
  if (!opts.initial && !opts.pop && !opts.rerender && opts.scroll !== false) main.focus({ preventScroll: true });
}

const FIELD = /^(INPUT|TEXTAREA|SELECT)$/;

// Al llegar datos nuevos se repinta la vista sin perder lo que se está escribiendo
function rerenderCurrent() {
  if (!current) return;
  const y = window.scrollY;
  const a = document.activeElement;
  const keep = a && a.id && FIELD.test(a.tagName) && document.getElementById('main')?.contains(a) && !/^(checkbox|radio|file)$/.test(a.type)
    ? { id: a.id, value: a.value, s: a.selectionStart, e: a.selectionEnd }
    : null;
  render(current.to, { scroll: false, rerender: true });
  window.scrollTo(0, y);
  if (!keep) return;
  const el = document.getElementById(keep.id);
  if (!el || !FIELD.test(el.tagName)) return;
  if (el.value !== keep.value) {
    el.value = keep.value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  el.focus({ preventScroll: true });
  try { if (keep.s != null) el.setSelectionRange(keep.s, keep.e); } catch { /* este campo no tiene selección */ }
}

// ── Cambios de datos ─────────────────────────────────────────
let lastUser = null;
let leaving = false;
on('*', (evt) => {
  if (evt === 'backoffice') {
    updateBar();
    if (lastUser && !bo.user && !leaving) toast('Tu sesión terminó (por seguridad se cierra tras un rato sin uso). Vuelve a ingresar.', { tone: 'warn', timeout: 8000 });
    lastUser = bo.user;
  }
  const page = current?.page;
  if (!page) return;
  if (page.onState?.(evt)) return;
  const triggers = page.rerender || ['backoffice'];
  if (triggers.includes(evt)) rerenderCurrent();
});

// ── Clics globales ───────────────────────────────────────────
document.addEventListener('click', async (e) => {
  if (e.defaultPrevented) return;
  const t = e.target;
  if (t.closest('[data-skip]')) {
    e.preventDefault();
    document.getElementById('main').focus();
    return;
  }
  const a = t.closest('a[href^="#/"]');
  if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && a.target !== '_blank') {
    e.preventDefault();
    const h = a.getAttribute('href').slice(1);
    if (isPanelRoute(h)) go(h);
    else window.open(`${storeUrl()}#${h}`, '_blank', 'noopener');
    return;
  }
  const act = t.closest('[data-action]');
  if (!act) return;
  switch (act.dataset.action) {
    case 'admin-logout':
      leaving = true;
      act.disabled = true;
      await logout();
      // Se recarga la página: el código y los datos del panel no quedan en la memoria del navegador
      history.replaceState(null, '', `${location.pathname}#/salir`);
      location.reload();
      break;
    default:
  }
});

installFormSubmit();

start(render);
// Saludo después de ingresar desde la pantalla de acceso
const welcome = globalThis.PIEDRA_PANEL_WELCOME;
delete globalThis.PIEDRA_PANEL_WELCOME;
initAdmin().then(() => {
  if (!welcome || !bo.user) return;
  const w = welcome.kind === 'setup' ? { html: `Listo, creaste el administrador <b>${esc(bo.user)}</b>. Ya estás dentro del panel.`, tone: 'ok' } : welcomeText(welcome);
  toast(w.html, { tone: w.tone, timeout: w.tone === 'warn' ? 12000 : 3800 });
});

// Acceso para pruebas y depuración desde la consola
window.PiedraPanel = { bo, go, refresh };

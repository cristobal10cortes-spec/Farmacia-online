// Pantalla de ingreso del panel. Es lo ÚNICO del panel que el servidor entrega
// a quien no ha ingresado: el código del panel completo (panel.js) solo se
// descarga después de ingresar, y el servidor lo niega sin una sesión válida.

import './boot.js';
import { icon } from '../ui/icons.js';
import { logo } from '../ui/logo.js';
import { esc } from '../ui/dom.js';
import { BRAND } from '../config.js';
import { request, loginRequest, codeRequest, setupRequest } from './auth.js';
import { loginView } from './login.js';

const app = document.getElementById('app');
app.innerHTML = `<a class="skip" href="#main">Saltar al contenido</a>
  <div class="pstrip"><div class="wrap pstrip__row">${icon('shield')}<span>Panel de administración<span class="pstrip__more"> · Acceso solo para personal autorizado</span></span></div></div>
  <header class="pbar"><div class="wrap pbar__row">
    <span class="pbar__logo">${logo({ compact: true })}<span class="pbar__tag">Panel</span></span>
    <div class="pbar__side"><a class="btn btn--ghost btn--sm" id="pbar-store" href="/" target="_blank" rel="noopener">${icon('external')}<span class="pbar__lbl">Ver tienda</span></a></div>
  </div></header>
  <main id="main" tabindex="-1"><div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Conectando con el servidor…</p></div></div></main>
  <footer class="pfoot"><div class="wrap pfoot__row"><span>${esc(BRAND.fullName)} · Panel de administración</span><span>Acceso solo para personal autorizado · Cada ingreso queda registrado.</span></div></footer>
  <div id="overlays"></div><div id="toasts" aria-live="polite"></div>`;
document.title = `Ingresar | Panel · ${BRAND.fullName}`;

const main = () => document.getElementById('main');

/** Descarga y abre el panel completo (el servidor solo lo entrega con la sesión iniciada). */
function openPanel(welcome) {
  if (welcome) globalThis.PIEDRA_PANEL_WELCOME = welcome;
  const src = document.querySelector('meta[name="panel-app"]')?.getAttribute('content') || 'panel.js';
  const s = document.createElement('script');
  s.src = src;
  s.onerror = () => {
    main().innerHTML = `<div class="wrap page"><div class="admin-wait"><p>No se pudo abrir el panel. Recarga la página e inténtalo de nuevo.</p><button type="button" class="btn btn--primary" data-reload>Recargar</button></div></div>`;
  };
  document.body.append(s);
}

function showLogin(needsSetup, notice = '') {
  const view = loginView({
    needsSetup,
    notice,
    actions: { login: loginRequest, code: codeRequest, setup: setupRequest },
    onDone: (kind, r) => {
      main().innerHTML = '<div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Abriendo el panel…</p></div></div>';
      openPanel({ kind, recoveryLeft: r.recoveryLeft, alerts: r.alerts });
    },
  });
  const m = main().cloneNode(false);
  m.innerHTML = view.html;
  main().replaceWith(m);
  view.mount(m);
}

async function start() {
  // Mensaje al volver después de salir (la página se recarga al salir)
  let notice = '';
  if (location.hash === '#/salir') {
    notice = `${icon('checkCircle')} Cerraste la sesión de administrador.`;
    history.replaceState(null, '', `${location.pathname}#/admin`);
  }
  let s;
  try {
    s = await request('/session');
  } catch (e) {
    main().innerHTML = `<div class="wrap page"><div class="admin-wait"><p>${esc(e.message)}</p><button type="button" class="btn btn--primary" data-reload>Reintentar</button></div></div>`;
    return;
  }
  if (typeof s.store === 'string' && /^(\/|https?:\/\/[\w.:-]+\/)$/.test(s.store)) document.getElementById('pbar-store').setAttribute('href', s.store);
  if (s.user) { openPanel(null); return; }
  showLogin(!!s.needsSetup, notice);
  // Si se abre el enlace de primera configuración con esta pantalla ya abierta
  window.addEventListener('hashchange', function onHash() {
    if (globalThis.PiedraPanel) { window.removeEventListener('hashchange', onHash); return; }
    if (s.needsSetup && /[?&]clave=/.test(location.hash)) showLogin(true);
  });
}

document.addEventListener('click', (e) => { if (e.target.closest('[data-reload]')) location.reload(); });
start();

// Fotos de productos en el panel: revisa la medida y el formato, y la prepara
// (la achica si hace falta) antes de enviarla al servidor.

export const PHOTO_IDEAL = 800; // medida recomendada: 800 × 800 píxeles
export const PHOTO_MIN = 300; // medida mínima de cada lado
export const PHOTO_MAX_MB = 15; // peso máximo del archivo original
const MAX_OUT_CHARS = 1_600_000; // tamaño máximo de la foto preparada (~1,2 MB)

const TYPES = { 'image/jpeg': 'JPG', 'image/png': 'PNG' };

function kindOf(file) {
  if (TYPES[file.type]) return file.type;
  const ext = /\.(jpe?g|png)$/i.exec(file.name || '')?.[1]?.toLowerCase();
  if (!ext) return '';
  return ext === 'png' ? 'image/png' : 'image/jpeg';
}

const kb = (bytes) => (bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1).replace('.', ',')} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`);
export const px = (w, h) => `${w.toLocaleString('es-CL')} × ${h.toLocaleString('es-CL')} px`;

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode')); };
    img.src = url;
  });
}

function hasTransparency(ctx, w, h) {
  try {
    const { data } = ctx.getImageData(0, 0, w, h);
    for (let i = 3; i < data.length; i += 4 * 7) if (data[i] < 250) return true;
  } catch { /* sin acceso a los píxeles: se trata como opaca */ }
  return false;
}

/**
 * Revisa y prepara una foto. Devuelve { ok:false, error } o
 * { ok:true, dataUrl, width, height, outWidth, outHeight, label, notes }.
 */
export async function preparePhoto(file) {
  if (!file) return { ok: false, error: 'Elige una foto.' };
  const type = kindOf(file);
  if (!type) return { ok: false, error: 'La foto debe ser JPG o PNG.' };
  if (file.size > PHOTO_MAX_MB * 1048576) return { ok: false, error: `La foto pesa ${kb(file.size)}. El máximo es ${PHOTO_MAX_MB} MB.` };
  let img;
  try { img = await loadImage(file); } catch { return { ok: false, error: 'No pudimos abrir la foto. Prueba con otro archivo JPG o PNG.' }; }
  const w = img.naturalWidth;
  const h = img.naturalHeight;
  const label = `${TYPES[type]}, ${kb(file.size)}`;
  if (Math.min(w, h) < PHOTO_MIN) {
    return { ok: false, width: w, height: h, error: `La foto mide ${px(w, h)}: es muy pequeña. Necesita al menos ${px(PHOTO_MIN, PHOTO_MIN)} (lo ideal: ${px(PHOTO_IDEAL, PHOTO_IDEAL)}).` };
  }
  const notes = [];
  const ratio = Math.max(w, h) / Math.min(w, h);
  if (ratio > 2) notes.push(`Es muy alargada: el producto se verá pequeño. Lo ideal es una foto cuadrada de ${px(PHOTO_IDEAL, PHOTO_IDEAL)}.`);
  else if (ratio > 1.1) notes.push(`No es cuadrada: se verá completa, con espacio a los lados. Lo ideal es ${px(PHOTO_IDEAL, PHOTO_IDEAL)}.`);
  if (Math.min(w, h) < 600) notes.push(`Es un poco pequeña: puede verse borrosa en pantallas grandes. Lo ideal es ${px(PHOTO_IDEAL, PHOTO_IDEAL)}.`);
  // Se achica para que el lado más largo mida como máximo 800 px (nunca se agranda)
  const scale = Math.min(1, PHOTO_IDEAL / Math.max(w, h));
  const ow = Math.max(1, Math.round(w * scale));
  const oh = Math.max(1, Math.round(h * scale));
  const canvas = document.createElement('canvas');
  canvas.width = ow;
  canvas.height = oh;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, ow, oh);
  let dataUrl = '';
  // PNG con fondo transparente: se mantiene transparente
  if (type === 'image/png' && hasTransparency(ctx, ow, oh)) {
    dataUrl = canvas.toDataURL('image/png');
    if (dataUrl.length > MAX_OUT_CHARS) {
      dataUrl = '';
      notes.push('El fondo transparente se cambió a blanco para que la foto no pese tanto.');
    }
  }
  if (!dataUrl) {
    const flat = document.createElement('canvas');
    flat.width = ow;
    flat.height = oh;
    const fctx = flat.getContext('2d');
    fctx.fillStyle = '#FFFFFF';
    fctx.fillRect(0, 0, ow, oh);
    fctx.drawImage(canvas, 0, 0);
    for (const q of [0.88, 0.8, 0.7]) {
      dataUrl = flat.toDataURL('image/jpeg', q);
      if (dataUrl.length <= MAX_OUT_CHARS) break;
    }
  }
  if (!/^data:image\/(jpeg|png);base64,/.test(dataUrl) || dataUrl.length > MAX_OUT_CHARS) {
    return { ok: false, width: w, height: h, error: 'No pudimos preparar la foto. Prueba con otra.' };
  }
  return { ok: true, dataUrl, width: w, height: h, outWidth: ow, outHeight: oh, label, notes };
}

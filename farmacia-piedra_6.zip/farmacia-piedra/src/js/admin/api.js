// Panel de administración: conexión con el servidor.
//
// El panel no guarda nada por su cuenta: cada cambio se envía al servidor,
// que valida la sesión, revisa los datos y los guarda. Después el panel
// vuelve a pedir los datos (y los revisa cada 15 segundos por si otro
// administrador o una venta los cambió).

import { emit } from '../engine/state.js';
import { request, loginRequest, codeRequest, setupRequest } from './auth.js';
import { applyCatalogOverrides } from '../engine/catalog.js';
import { setOverridesMap } from '../engine/stockdata.js';
import { bannerList, liveFrom } from '../engine/bannerlist.js';
import { menuCardList, liveMenuCards } from '../engine/menucards.js';
import { servicesSection } from '../engine/services.js';
import { setStores } from '../data/stores.js';

export { ZONE_IDS, locLabel, stockAt, stockSnapshot, stockTotals, stockLevel, lowStock } from '../engine/stock.js';
export { bannerStatus, PROMO_VISIBLE, MAX_PROMOS, PHOTO_SIZES, photoFit } from '../engine/bannerlist.js';
export { SERVICE_ICONS, MAX_SERVICES, SERVICE_LIMITS, DEFAULT_SERVICES } from '../engine/services.js';
export { menuCardStatus, MENU_VISIBLE, MAX_MENU_CARDS } from '../engine/menucards.js';

export const bo = {
  mode: 'server',
  checked: false, // ya se preguntó al servidor si hay sesión
  user: null,
  csrf: null,
  needsSetup: false,
  twoFactor: null, // ¿la cuenta tiene verificación en dos pasos?
  store: '/', // dirección de la tienda (otra, si el panel tiene su propio subdominio)
  ready: false, // ya llegaron los datos
  version: null,
  orders: [],
  movements: [],
  banners: [],
  menu: [], // tarjetas del menú «Categorías»
  services: null, // «Servicios Piedra» (null = los de ejemplo)
  offline: false,
  error: null,
};

const API = 'api'; // relativo a la dirección del panel (por ejemplo /admin/api)

// Uso real del panel (clics, teclas). La revisión automática de datos no
// cuenta como uso: así la sesión se cierra sola si nadie lo ocupa por un rato.
let active = true;
if (typeof window !== 'undefined') {
  for (const ev of ['pointerdown', 'keydown', 'wheel', 'touchstart']) {
    window.addEventListener(ev, () => { active = true; }, { capture: true, passive: true });
  }
}

async function call(path, { method = 'GET', body, activity } = {}) {
  try {
    return await request(path, { method, body, activity, csrf: bo.csrf });
  } catch (e) {
    if (e.status === 401 && !/^\/(login|session|setup)/.test(path)) sessionEnded();
    throw e;
  }
}

function sessionEnded() {
  if (!bo.user) return;
  bo.user = null;
  bo.csrf = null;
  bo.ready = false;
  stopPolling();
  emit('backoffice');
}

function applyData(d) {
  bo.version = d.version;
  setStores(d.stores || []);
  const m = new Map(Object.entries(d.overrides || {}));
  setOverridesMap(m);
  applyCatalogOverrides(m);
  bo.banners = Array.isArray(d.banners) ? d.banners : [];
  bo.menu = Array.isArray(d.menu) ? d.menu : [];
  bo.services = d.services && Array.isArray(d.services.items) ? d.services : null;
  bo.orders = Array.isArray(d.orders) ? d.orders : [];
  bo.movements = Array.isArray(d.movements) ? d.movements : [];
  bo.ready = true;
  emit('backoffice');
}

/** Trae los datos del servidor (si cambiaron). */
export async function refresh(force = false) {
  if (!bo.user) return;
  const wasActive = active;
  active = false;
  try {
    const d = await call(`/data${!force && bo.version != null ? `?v=${encodeURIComponent(bo.version)}` : ''}`, { activity: force || wasActive });
    if (bo.offline) { bo.offline = false; emit('backoffice'); }
    if (d.notModified || d.unchanged) return;
    applyData(d);
  } catch (e) {
    active = active || wasActive;
    if (e.code === 'network' && !bo.offline) { bo.offline = true; emit('backoffice'); }
  }
}

let timer = null;
function startPolling() {
  stopPolling();
  timer = setInterval(() => { if (!document.hidden) refresh(); }, 15000);
}
function stopPolling() {
  if (timer) clearInterval(timer);
  timer = null;
}

export async function initAdmin() {
  try {
    const s = await call('/session');
    bo.user = s.user || null;
    bo.csrf = s.csrf || null;
    bo.needsSetup = !!s.needsSetup;
    bo.twoFactor = s.user ? !!s.twoFactor : null;
    if (typeof s.store === 'string' && /^(\/|https?:\/\/[\w.:-]+\/)$/.test(s.store)) bo.store = s.store;
  } catch (e) {
    bo.error = e.message;
    bo.offline = e.code === 'network';
  }
  bo.checked = true;
  emit('backoffice');
  if (bo.user) {
    await refresh(true);
    startPolling();
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && bo.user) refresh(); });
}

async function startWith(r) {
  bo.user = r.user;
  bo.csrf = r.csrf;
  bo.twoFactor = !!r.twoFactor;
  bo.needsSetup = false;
  bo.ready = false;
  emit('backoffice');
  await refresh(true);
  startPolling();
}

/** Ingreso con usuario y contraseña. Devuelve { ok, needCode?, ticket? } o { ok:false, error }. */
export async function login(user, password) {
  const r = await loginRequest(user, password);
  if (!r.ok || r.needCode) return r;
  await startWith(r);
  return r;
}

/** Segundo paso: código de la app del celular o código de respaldo. */
export async function loginCode(ticket, code) {
  const r = await codeRequest(ticket, code);
  if (r.ok) await startWith(r);
  return r;
}

/** Crea el primer administrador con la clave que muestra el servidor al iniciar. */
export async function setupFirstAdmin(token, user, password) {
  const r = await setupRequest(token, user, password);
  if (r.ok) await startWith(r);
  return r;
}

export async function logout() {
  try { await call('/logout', { method: 'POST', body: {} }); } catch { /* igual se cierra aquí */ }
  bo.user = null;
  bo.csrf = null;
  bo.ready = false;
  stopPolling();
  emit('backoffice');
}

export async function changePassword(current, next) {
  try {
    const r = await call('/password', { method: 'POST', body: { current, next } });
    bo.csrf = r.csrf;
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── Seguridad de la cuenta ───────────────────────────────────
const safe = (p) => p.then((r) => ({ ok: true, ...r }), (e) => ({ ok: false, error: e.message, code: e.code }));
export const securityInfo = () => call('/security', { activity: true });
export const start2fa = () => safe(call('/2fa/start', { method: 'POST', body: {} }));
export const enable2fa = (password, code) => safe(call('/2fa/enable', { method: 'POST', body: { password, code } }));
export const disable2fa = (password, code) => safe(call('/2fa/disable', { method: 'POST', body: { password, code } }));
export const newRecoveryCodes = (password, code) => safe(call('/2fa/recovery', { method: 'POST', body: { password, code } }));
export const closeOtherSessions = () => safe(call('/sessions/close-others', { method: 'POST', body: {} }));

// ── Cambios (el servidor los valida y guarda) ────────────────
async function op(path, method, body) {
  const r = await call(path, { method, body });
  await refresh(true);
  return r?.result;
}

/** Fija cantidades exactas: changes = [{ loc, qty }]. Devuelve cuántas ubicaciones cambiaron. */
export const changeStock = (pid, changes, { kind = 'ajuste', note = '' } = {}) => op('/stock', 'POST', { pid, mode: 'set', changes, kind, note });
/** Suma (o resta) unidades en una o varias ubicaciones. */
export const addStock = (pid, locs, qty, { note = '' } = {}) => op('/stock', 'POST', { pid, mode: 'add', locs: Array.isArray(locs) ? locs : [locs], qty, note });
/** Carga masiva: rows = [{ line, code, qty }] en una ubicación; mode 'add' (sumar) o 'set' (reemplazar). */
export const bulkStock = (loc, mode, rows, file = '') => op('/stock/bulk', 'POST', { loc, mode, rows, file });
/** Precio normal, oferta y (opcional) costo: cost undefined = no cambia, null = se borra. */
export const setPrice = (pid, price, offer, cost) => op('/price', 'POST', cost === undefined ? { pid, price, offer } : { pid, price, offer, cost });
/** Carga desde planilla: existencia, costo, precio y productos nuevos (ver importPlanilla en el servidor). */
export const importPlanilla = (body) => op('/import', 'POST', body);
export const setHidden = (pid, hidden) => op('/visibility', 'POST', { pid, hidden: !!hidden });
export const createProduct = (def, stock) => op('/products', 'POST', { def, stock });
export const updateProductDef = (pid, def) => op(`/products/${encodeURIComponent(pid)}`, 'PUT', { def });
export const deleteProduct = (pid) => op(`/products/${encodeURIComponent(pid)}`, 'DELETE');
export const setProductPhoto = (pid, image) => op(`/products/${encodeURIComponent(pid)}/foto`, 'PUT', { image });
export const removeProductPhoto = (pid) => op(`/products/${encodeURIComponent(pid)}/foto`, 'DELETE');
export const createStore = (store, initialStock = 0) => op('/stores', 'POST', { store, initialStock });
export const updateStore = (id, store) => op(`/stores/${encodeURIComponent(id)}`, 'PUT', { store });
export const deleteStore = (id) => op(`/stores/${encodeURIComponent(id)}`, 'DELETE');
export const saveBanner = (b) => op('/banners', 'POST', { banner: b });
export const setBannerActive = (id, active) => op(`/banners/${encodeURIComponent(id)}`, 'PATCH', { active: !!active });
export const moveBanner = (id, dir) => op(`/banners/${encodeURIComponent(id)}/move`, 'POST', { dir });
export const deleteBanner = (id) => op(`/banners/${encodeURIComponent(id)}`, 'DELETE');
export const saveMenuCard = (card) => op('/menu', 'POST', { card });
export const setMenuCardActive = (id, active) => op(`/menu/${encodeURIComponent(id)}`, 'PATCH', { active: !!active });
export const moveMenuCard = (id, dir) => op(`/menu/${encodeURIComponent(id)}/move`, 'POST', { dir });
export const deleteMenuCard = (id) => op(`/menu/${encodeURIComponent(id)}`, 'DELETE');
/** Busca movimientos en todo el historial: { desde, hasta, local, tipo, q } (los vacíos no filtran). */
export function searchMovements(filters = {}) {
  const qs = new URLSearchParams(Object.entries(filters).filter(([, v]) => v)).toString();
  return call(`/movimientos${qs ? `?${qs}` : ''}`, { activity: true });
}
/** Guarda la sección «Servicios Piedra» completa: { title, items }. */
export const saveServices = (section) => op('/servicios', 'PUT', { section });

export async function adminCancelOrder(order) {
  if (!order || order.cancelled) return false;
  await op(`/orders/${encodeURIComponent(order.id)}/cancel`, 'POST', {});
  return true;
}

/** Pasa el pedido a otra etapa (el cliente recibe un mensaje en su seguimiento). */
export const setOrderStatus = (id, status, note = '') => op(`/orders/${encodeURIComponent(id)}/status`, 'POST', { status, note });
/** Cambia la fecha de entrega o de retiro (el cliente recibe un mensaje). */
export const setDeliveryDate = (id, date, note = '') => op(`/orders/${encodeURIComponent(id)}/date`, 'POST', { date, note });

export const recetaUrl = (orderId, fileId) => `${API}/orders/${encodeURIComponent(orderId)}/recetas/${encodeURIComponent(fileId)}`;

// ── Lecturas ─────────────────────────────────────────────────
export const adminUser = () => bo.user || '';
export const adminLoggedIn = () => !!bo.user;
export const adminOrders = () => bo.orders.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
export function findAdminOrder(id) {
  const key = String(id || '').trim().toUpperCase();
  return bo.orders.find((o) => o.id === key) || null;
}
export const adminBannerList = (place = 'hero') => bannerList(bo.banners, place);
export const liveBanners = (place = 'hero') => liveFrom(bo.banners, place);
export const findBanner = (id) => adminBannerList('hero').find((b) => b.id === id) || adminBannerList('promo').find((b) => b.id === id) || null;
export const adminMenuList = () => menuCardList(bo.menu);
export const liveMenu = () => liveMenuCards(bo.menu);
export const findMenuCard = (id) => adminMenuList().find((c) => c.id === id) || null;
export const adminServices = () => servicesSection(bo.services);

/** Texto para mostrar cuando algo no se pudo guardar. */
export function friendlyError(err, fallback = 'No se pudo guardar. Revisa tu conexión e inténtalo de nuevo.') {
  const msg = err?.message;
  return msg && !/^\w+$/.test(msg) ? msg : fallback;
}

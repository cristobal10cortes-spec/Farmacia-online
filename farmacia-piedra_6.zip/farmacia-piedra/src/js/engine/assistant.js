// Asistente de ayuda: entiende lo que escribe el cliente y arma la respuesta.
// Devuelve mensajes como datos (sin HTML) para que la ventanita los dibuje.
//
// Tipos de mensaje:
//   { type: 'text', text, links?: [{ label, to }] }
//   { type: 'faq', q, a, to, group }
//   { type: 'products', title, items: [producto], more: { label, to } }
//   { type: 'stores', items: [{ name, address, comuna, label, turno, h24 }] }
//   { type: 'orders', items: [{ id, status: { text, tone }, total, at }] }
//   { type: 'contact', items: [{ icon, label, sub, tel? }] }
//   { type: 'note', text }
//   { type: 'chips', items: [texto] }
//   { type: 'health', title, tips, pharmacy, doctor, urgent, notes, more }   orientación de salud
//   { type: 'alert', tone?: 'care', title, text, points?, lines: [{ label, sub, tel }], foot? }
//
// Orientación de salud: información general sobre síntomas comunes. El
// asistente no es médico: no diagnostica, no receta ni indica dosis, y ante
// señales de alarma deriva a urgencias (SAMU 131), a Salud Responde o al CITUC.

import { BRAND, HELPBOT, ZONES } from '../config.js';
import { FAQ } from '../data/content.js';
import { STOPWORDS } from '../data/synonyms.js';
import { REGIONS } from '../data/regions.js';
import { SearchIndex } from './search.js';
import { SYNONYM_GROUPS, productIndex, byId } from './catalog.js';
import { fold } from './text.js';
import { storesNear, storeStatus, deliveryInfo } from './inventory.js';
import { STORES } from '../data/stores.js';
import { findOrder, statusLabel } from './orders.js';
import { state } from './state.js';
import { clp } from './format.js';
import { HEALTH_TOPICS, HEALTH_CHIPS, HEALTH_LINES } from '../data/health.js';

// ── Preguntas frecuentes ─────────────────────────────────────
const FAQ_DOCS = FAQ.flatMap((g) => g.items.map((it, i) => ({ id: `${g.id}-${i}`, group: g.title, groupId: g.id, ...it })));
let faqIndex = null;
function faqIdx() {
  if (!faqIndex) {
    faqIndex = new SearchIndex({
      docs: FAQ_DOCS,
      fields: [{ weight: 10, get: (d) => d.q }, { weight: 4, get: (d) => d.a }, { weight: 3, get: (d) => d.group }],
      synonyms: SYNONYM_GROUPS.filter((g) => g.kind !== 'marca'),
      stopwords: [...STOPWORDS, 'como', 'cuanto', 'cuando', 'donde', 'puedo', 'hago', 'tiene', 'hacer'],
    });
  }
  return faqIndex;
}
const faqDocs = (r) => r.items.map((it) => faqIdx().byId.get(it.id));
export function faqSearch(q) {
  return faqDocs(faqIdx().search(q));
}

// ── Frases de la ventanita ───────────────────────────────────
/** Frases que va mostrando la ventanita, con una propia de la página actual. */
export function teasersFor(path = '/') {
  const base = HELPBOT.teasers.length ? HELPBOT.teasers : ['¿Necesitas ayuda?'];
  let page = '';
  if (path.startsWith('/producto/')) page = '¿Tienes dudas sobre este producto?';
  else if (path === '/carro' || path === '/checkout') page = '¿Te ayudo a terminar tu compra?';
  else if (path.startsWith('/cotizar-receta')) page = '¿Te ayudo a cotizar tu receta?';
  else if (path.startsWith('/farmacias')) page = '¿Buscas una farmacia de turno?';
  else if (path.startsWith('/buscar') || path.startsWith('/categoria')) page = '¿No encuentras lo que buscas? Pregúntame.';
  return page ? [...base.slice(0, 2), page, ...base.slice(2)] : base.slice();
}

export const QUICK_CHIPS = ['Tengo un síntoma', 'Buscar un remedio', '¿Dónde está mi pedido?', 'Farmacias de turno', '¿Cómo compro con receta?', 'Hablar con una persona'];

export function greeting() {
  return [
    { type: 'text', text: `¡Hola! Soy el asistente virtual de ${BRAND.fullName}. Te ayudo a encontrar productos y te oriento si tienes algún síntoma. ¿En qué te puedo ayudar?` },
    { type: 'text', text: 'Escríbeme el nombre de un remedio (aunque no sepas cómo se escribe), lo que sientes, o tu duda sobre despachos, recetas o tu pedido.' },
    { type: 'note', text: 'No soy médico ni reemplazo una consulta. Si es una urgencia, llama al SAMU 131.' },
    { type: 'chips', items: QUICK_CHIPS },
  ];
}

// ── Orientación de salud ─────────────────────────────────────
const TOPIC_KEYS = HEALTH_TOPICS.flatMap((t) => t.keys.map((k) => ({ k: fold(k), t }))).sort((a, b) => b.k.length - a.k.length);
/** Síntomas mencionados, el más específico primero. */
export function topicsIn(q) {
  const hay = ` ${q} `;
  const found = [];
  for (const { k, t } of TOPIC_KEYS) if (hay.includes(` ${k} `) && !found.includes(t)) found.push(t);
  return found;
}

const CRISIS = /\b(suicid\w*|matarme|me quiero matar|quitarme la vida|no quiero vivir|quiero morir\w*|me quiero morir|morirme|hacerme dano|autolesion\w*|cortarme(?! (el|las|los|mis) (pelo|unas|cabello|callos|unas))|terminar con (todo|mi vida))\b/;
const POISON = /\b(intoxica\w*|envenena\w*|sobredosis|veneno|se trago|se tomo (todas|todos|muchas|muchos|varias|varios|el frasco|la caja)|(tome|tomo) (todas|muchas|demasiadas|varias)|(tomo|trago) cloro|ingirio)\b/;
const EMERGENCIES = [
  { re: /\b((dolor|dolores|opresion|presion|puntada|puntadas|apreton) (de|en el|en|al|del) pecho|duele (el|mucho el) pecho|dolor toracico|infarto)\b/, text: 'Un dolor u opresión en el pecho que se extiende al brazo, el cuello o la mandíbula, o que viene con falta de aire, sudor o náuseas, puede ser un infarto.' },
  { re: /\b(no puedo respirar|no puede respirar|me cuesta respirar|le cuesta respirar|cuesta respirar|me falta el aire|le falta el aire|falta de aire|dificultad para respirar|me ahogo|se ahoga|ahogando|asfixia\w*)\b/, text: 'La dificultad para respirar siempre necesita atención inmediata.' },
  { re: /\b(cara (chueca|caida|torcida|desviada)|boca (chueca|torcida)|no puede hablar|habla raro|se le traba la lengua|paralisis|perdio la fuerza|derrame cerebral|ataque cerebral|accidente cerebrovascular)\b/, text: 'La cara desviada, un brazo o una pierna sin fuerza, o la dificultad para hablar pueden ser un ataque cerebral: cada minuto cuenta.' },
  { re: /\b(desmay\w*|inconsciente|perdio el conocimiento|no despierta|convulsion\w*|convulsiona\w*)\b/, text: 'Si la persona no responde o está convulsionando, ponla de lado y no le metas nada en la boca mientras llega la ayuda.' },
  { re: /\b(hemorragia|sangra mucho|sangrando mucho|mucha sangre|vomit\w* (con )?sangre|deposiciones negras)\b/, text: 'Si una herida sangra mucho, presiona firme con un paño limpio mientras llega la ayuda.' },
  { re: /\b(anafilaxia|se (me|le) (hincho|hincharon) (la cara|la lengua|los labios|la garganta)|hinchazon de (la )?(cara|labios|lengua|garganta)|lengua hinchada|labios hinchados|garganta cerrada)\b/, text: 'La hinchazón de labios, lengua o garganta, sobre todo con dificultad para respirar, es una reacción alérgica grave.' },
];
const KIDS = /\b(guagua|guaguas|bebe|bebes|nino|nina|ninos|ninas|hijo|hija|hijos|hijas|lactante|recien nacido|pediatric\w*)\b/;
const PREGNANT = /\b(embarazada|embarazo|lactancia|amamantando|amamanto)\b/;
const PRODUCT_WORDS = /\b(jarabe\w*|pastilla\w*|comprimido\w*|capsula\w*|crema\w*|gel|spray|gotas|remedio\w*|medicamento\w*|producto\w*|precio\w*|comprar|venden|tienen|antigripal\w*|analgesico\w*|antialergico\w*)\b/;
// "¿El ibuprofeno necesita receta?"
const RX_Q = /\b(necesito receta|necesita receta|necesitan receta|lleva receta|llevan receta|requiere receta|requieren receta|piden receta|sin receta|con receta|venta libre|venta directa)\b/;
const RX_WORDS = new Set(['receta', 'recetas', 'medica', 'medicas', 'sin', 'con', 'lleva', 'llevan', 'requiere', 'requieren', 'piden', 'necesita', 'necesitan', 'venta', 'libre', 'directa', 'para', 'el', 'la', 'los', 'las']);
const DOCTOR = /\b(medico|medica|doctor|doctora|doctores|diagnostic\w*|recetar\w*|recetame|consulta medica|profesional de la salud|un profesional)\b/;

const line = (k) => ({ ...HEALTH_LINES[k] });

function crisisReply() {
  return [{
    type: 'alert', tone: 'care', title: 'No estás solo ni sola',
    text: 'Lamento mucho que te sientas así. Hay personas preparadas para escucharte ahora mismo:',
    lines: [line('vida'), line('samu')],
    foot: 'Si estás en peligro inmediato, llama al 131 o ve al servicio de urgencia más cercano. También ayuda contarle a alguien de confianza cómo te sientes.',
  }];
}

function poisonReply() {
  return [{
    type: 'alert', title: 'Posible intoxicación',
    text: 'Llama ahora al CITUC: te dirán qué hacer según lo que se tomó y cuánto. Ten a mano el envase.',
    lines: [line('cituc'), line('samu')],
    foot: 'No provoques el vómito. Si la persona está muy decaída, convulsiona o no responde, llama de inmediato al SAMU 131.',
  }];
}

function emergencyReply(points) {
  return [{
    type: 'alert', title: 'Esto puede ser una urgencia',
    text: 'Llama ahora al SAMU 131 o ve al servicio de urgencia más cercano. No esperes una respuesta por aquí.',
    points, lines: [line('samu'), line('salud')],
  }];
}

function doctorReply() {
  return [
    { type: 'text', text: 'No soy médico: soy un asistente automático y no puedo diagnosticar ni recetar. Sí te puedo orientar en síntomas comunes y decirte cuándo consultar. Para hablar con un profesional:' },
    {
      type: 'contact',
      items: [
        { icon: 'phone', ...line('salud') },
        { icon: 'pill', label: `Químico farmacéutico · ${BRAND.phone}`, sub: 'Dudas sobre medicamentos, en nuestras farmacias' },
        { icon: 'alert', ...line('samu') },
      ],
    },
    { type: 'chips', items: ['Tengo un síntoma'] },
  ];
}

function symptomPrompt() {
  return [
    { type: 'text', text: 'Cuéntame qué sientes (por ejemplo «me duele la cabeza» o «tengo tos»), o elige uno de estos:' },
    { type: 'chips', items: HEALTH_CHIPS },
    { type: 'note', text: 'Te doy orientación general: no reemplaza una consulta médica. Si es una urgencia, llama al SAMU 131.' },
  ];
}

function healthReply(topic, others, q) {
  const notes = [];
  if (KIDS.test(q)) notes.push('En niños y guaguas, los remedios y las dosis dependen de la edad y el peso: consulta al pediatra o al químico farmacéutico antes de darles algo.');
  if (PREGNANT.test(q)) notes.push('Si estás embarazada o amamantando, consulta a tu médico o al químico farmacéutico antes de tomar cualquier medicamento.');
  const pr = productIndex.search(topic.search);
  const items = pr.items.map((it) => byId.get(it.id)).filter((p) => p && p.rx === 'directa').slice(0, 3);
  const out = [{
    type: 'health', title: topic.title, tips: topic.tips, pharmacy: topic.pharmacy, doctor: topic.doctor, urgent: topic.urgent, notes,
    more: { label: 'Ver productos relacionados', to: `/buscar?q=${encodeURIComponent(topic.search)}` },
  }];
  if (items.length) out.push({ type: 'products', title: 'De venta directa en nuestras farmacias:', items, more: null });
  out.push({ type: 'chips', items: [...others.slice(0, 2).map((t) => t.title), 'Hablar con un profesional'] });
  return out;
}

// ── Comunas mencionadas ("¿llega a Temuco?") ─────────────────
let comunas = null;
function comunaIn(q) {
  if (!comunas) {
    comunas = REGIONS.flatMap((r) => r.comunas.map((c) => ({ key: fold(c), comuna: c, region: r.id })))
      .sort((a, b) => b.key.length - a.key.length); // "san pedro de atacama" antes que "san pedro"
  }
  const hay = ` ${q} `;
  const hit = comunas.find((c) => hay.includes(` ${c.key} `));
  return hit ? { region: hit.region, comuna: hit.comuna } : null;
}

// ── Respuestas ───────────────────────────────────────────────
const link = (label, to) => ({ label, to });

function contactReply() {
  return [
    { type: 'text', text: 'Claro. Puedes hablar con nuestro equipo y con un químico farmacéutico por estos medios:' },
    {
      type: 'contact',
      items: [
        { icon: 'phone', label: BRAND.phone, sub: `Venta telefónica · ${BRAND.phoneMobile}` },
        { icon: 'chat', label: `WhatsApp ${BRAND.whatsapp}`, sub: 'Respuesta en horario de atención' },
        { icon: 'mail', label: BRAND.email, sub: BRAND.hours },
      ],
    },
    { type: 'text', text: '', links: [link('Contacto y libro de reclamos', '/ayuda/contacto')] },
  ];
}

function orderReply(id) {
  if (id) {
    const o = findOrder(id);
    if (o) {
      const st = statusLabel(o);
      return [{ type: 'text', text: `Encontré tu pedido ${o.id}. Estado: ${st.text}.`, links: [link('Ver el pedido', `/pedido/${o.id}`)] }];
    }
    return [{ type: 'text', text: `No encuentro el pedido ${id} en este navegador. Puedes buscarlo con el número y tu correo en «Sigue tu pedido».`, links: [link('Sigue tu pedido', '/seguimiento')] }];
  }
  const mine = (state.orders || []).slice(0, 2);
  if (mine.length) {
    return [
      { type: 'text', text: mine.length === 1 ? 'Este es tu último pedido:' : 'Estos son tus últimos pedidos:' },
      { type: 'orders', items: mine.map((o) => ({ id: o.id, status: statusLabel(o), total: o.totals.total, at: o.createdAt })) },
      { type: 'text', text: '¿Buscas otro? Escríbeme su número (empieza con PD) o búscalo con tu correo.', links: [link('Sigue tu pedido', '/seguimiento')] },
    ];
  }
  return [{ type: 'text', text: 'Para seguir tu pedido escríbeme su número (empieza con PD y te llegó en el correo de confirmación) o búscalo con tu correo.', links: [link('Sigue tu pedido', '/seguimiento')] }];
}

function storesReply(loc, { night: wantNight = false } = {}, now = new Date()) {
  if (!STORES.length) {
    return [{ type: 'text', text: 'Por ahora no tenemos farmacias para visitar: vendemos online, con despacho a domicilio a todo Chile.', links: [link('Cómo funciona el despacho', '/ayuda/despacho')] }];
  }
  const near = storesNear(loc);
  if (!near.length) {
    return [{ type: 'text', text: `Aún no tenemos farmacias cerca de ${loc.comuna}. Puedes comprar online con despacho a domicilio.`, links: [link('Ver todas las farmacias', '/farmacias')] }];
  }
  const list = near.map((s) => ({ ...s, st: storeStatus(s, now) }));
  const night = list.filter((s) => s.st.turno || s.st.h24);
  const open = list.filter((s) => s.st.open);
  // De turno (toda la noche) si lo pidió; si no, las abiertas ahora
  const useNight = night.length && (wantNight || !open.length);
  const pick = (useNight ? night : open.length ? open : list).slice(0, 3);
  const intro = useNight
    ? `Estas farmacias atienden hoy toda la noche cerca de ${loc.comuna}:`
    : open.length ? `Estas farmacias están abiertas ahora cerca de ${loc.comuna}:` : `Por ahora están cerradas. Estas son las más cercanas a ${loc.comuna}:`;
  return [
    { type: 'text', text: intro },
    { type: 'stores', items: pick.map((s) => ({ name: s.name, address: s.address, comuna: s.comuna, label: s.st.label, turno: s.st.turno, h24: !!s.st.h24 })) },
    { type: 'text', text: '', links: [link('Ver farmacias de turno', '/farmacias?turno=1'), link('Todas las farmacias', '/farmacias')] },
  ];
}

function deliveryReply(loc) {
  const info = deliveryInfo(loc);
  if (!info.home.ok) return [{ type: 'text', text: info.home.reason, links: [link('Ver farmacias', '/farmacias')] }];
  const z = ZONES[info.zone];
  const when = /^(hoy|mañana)/.test(info.home.label) ? info.home.label : `el ${info.home.label}`;
  const out = [{ type: 'text', text: `Sí, despachamos a ${loc.comuna}. El despacho cuesta ${clp(z.shipping)} y es gratis sobre ${clp(z.freeFrom)}. Si compras ahora, llega ${when}.` }];
  if (info.express.ok) out.push({ type: 'text', text: `También hay despacho express: ${info.express.label.toLowerCase()}.` });
  out.push({ type: 'text', text: '', links: [link('Más sobre despachos', '/ayuda/despacho')] });
  return out;
}

const MED_NOTE = 'Antes de usar un medicamento lee sus indicaciones. Si tienes dudas o los síntomas siguen, consulta a un químico farmacéutico o a tu médico.';

function productsReply(raw, pr, { rxAll = false } = {}) {
  const items = pr.items.slice(0, 3).map((it) => byId.get(it.id)).filter(Boolean);
  const term = pr.corrected || raw;
  const out = [{
    type: 'products',
    title: rxAll ? 'Así se vende cada uno:' : pr.corrected ? `Encontré esto para «${pr.corrected}»:` : 'Encontré estos productos:',
    items,
    rxAll,
    more: pr.total > items.length ? { label: `Ver los ${pr.total} resultados`, to: `/buscar?q=${encodeURIComponent(term)}` } : null,
  }];
  if (items.some((p) => p.cat === 'medicamentos')) out.push({ type: 'note', text: MED_NOTE });
  return out;
}

function faqReply(f, extra = []) {
  return [{ type: 'faq', q: f.q, a: f.a, to: `/ayuda/${f.groupId}`, group: f.group }, ...extra];
}

// Palabras de la pregunta que no ayudan a encontrar productos ("¿tienen…?", "¿cuánto cuesta…?")
const FILLER = new Set(['que', 'tienen', 'tiene', 'tendran', 'venden', 'vende', 'necesito', 'necesita', 'quiero', 'quisiera', 'busco', 'buscando', 'comprar', 'compro', 'algo', 'favor', 'porfa', 'precio', 'precios', 'cuanto', 'cuanta', 'cuesta', 'cuestan', 'vale', 'valen', 'valor', 'donde', 'como', 'cual', 'cuales', 'hola', 'buenas', 'gracias', 'puedo', 'pueden', 'podria', 'ustedes', 'alguno', 'alguna', 'tengo', 'sirve', 'recomiendan', 'recomienda', 'recomiendas', 'hay', 'consigo', 'encuentro']);
const strip = (q) => q.split(' ').filter((w) => !FILLER.has(w)).join(' ');
const GREETING = /\b(hola|holi|ola|buenas|buen dia|buenos dias|buenas tardes|buenas noches|alo|hey|saludos|que tal|como estas|como esta)\b/g;

const QUESTION = /^(como|cuanto|cuanta|cuantos|cuantas|cuando|donde|que|cual|cuales|puedo|pueden|podria|hacen|tienen|aceptan|venden|necesito|se puede|hay|es|son|debo|despachan|llega|me)\b/;

/** Respuesta del asistente a lo que escribió el cliente. */
export function botReply(text, ctx = {}) {
  const raw = String(text || '').trim().slice(0, 300);
  const q = fold(raw);
  if (!q) return [];
  const loc = ctx.location || state.location;
  const words = q.split(' ').length;

  // Primero la seguridad: crisis, intoxicaciones y señales de alarma
  if (CRISIS.test(q)) return crisisReply();
  if (POISON.test(q)) return poisonReply();
  const alarms = EMERGENCIES.filter((e) => e.re.test(q)).map((e) => e.text);
  if (alarms.length) return emergencyReply(alarms);

  // Número de pedido (PD12345678)
  const idm = raw.match(/\bPD[\s-]?(\d{8})\b/i);
  if (idm) return orderReply(`PD${idm[1]}`);
  // Saludos y agradecimientos
  if (!q.replace(GREETING, '').trim()) return greeting();
  if (words <= 6 && /\b(gracias|muchas gracias|te pasaste|genial|perfecto|excelente|buenisimo)\b/.test(q)) {
    return [{ type: 'text', text: '¡De nada! Si necesitas algo más, aquí estoy.' }, { type: 'chips', items: QUICK_CHIPS.slice(0, 3) }];
  }
  // Atajos de los botones
  if (/^(preguntas frecuentes|centro de ayuda|ayuda)$/.test(q)) {
    return [{ type: 'text', text: 'En el centro de ayuda están todas las preguntas frecuentes. Estas son las más consultadas:', links: [link('Centro de ayuda', '/ayuda')] }, { type: 'chips', items: ['¿Cuánto demora el despacho?', '¿Qué medios de pago aceptan?', '¿Puedo devolver un producto?'] }];
  }
  if (/^(buscar|busco) (un )?(remedio|producto|medicamento)$/.test(q)) {
    return [{ type: 'text', text: 'Escríbeme el nombre del remedio o lo que sientes, aunque no sepas cómo se escribe. Por ejemplo: «paracetamol», «dolor de cabeza» o «protector solar».' }];
  }
  // Orientación de salud
  if (/^(tengo un sintoma|tengo sintomas|sintoma|sintomas|orientacion de salud|orientacion|me siento mal|estoy enfermo|estoy enferma|me siento enfermo|me siento enferma)$/.test(q)) return symptomPrompt();
  if (DOCTOR.test(q.replace(/\brecetas? medicas?\b/g, ' '))) return doctorReply();
  // Hablar con una persona
  if (/\b(hablar con|una persona|humano|ejecutiv\w*|operador\w*|llamar\w*|telefono|whatsapp|contactar\w*|datos de contacto|reclamo\w*|quimico farmaceutico)\b/.test(q)) return contactReply();
  // Pedidos
  if (/\b(mi pedido|mis pedidos|mi compra|mis compras|seguimiento|seguir mi|seguir el|rastrear|donde esta mi|no ha llegado|no me ha llegado|no llega|estado de mi|estado del pedido|numero de pedido)\b/.test(q)) return orderReply();
  // Farmacias de turno y horarios
  if (/\b(turno|turnos|abierta|abiertas|abierto|24 horas|de noche|horario|horarios|farmacia cerca|farmacias cerca|mas cercana|cerca de mi)\b/.test(q)) {
    return storesReply(comunaIn(q) || loc, { night: /\b(turno|turnos|noche|24 horas)\b/.test(q) });
  }
  // Despacho a una comuna
  const com = comunaIn(q);
  if (com && /\b(despach\w*|envio\w*|envia\w*|llega\w*|demora\w*|reparto|delivery|mandan)\b/.test(q)) return deliveryReply(com);
  // ¿Necesita receta? Se muestra la condición de venta de cada producto
  if (RX_Q.test(q)) {
    const rq = strip(q).split(' ').filter((w) => !RX_WORDS.has(w)).join(' ');
    const rr = rq ? productIndex.search(rq) : null;
    if (rr && rr.items.length && !rr.partial) {
      return [...productsReply(rq, rr, { rxAll: true }), { type: 'text', text: 'Los de receta se compran adjuntando una foto de la receta al pagar.', links: [link('Cómo comprar con receta', '/ayuda/recetas')] }];
    }
  }
  // Síntomas: orientación de salud (si busca un producto, primero los productos)
  const topics = topicsIn(q.replace(/^orientacion /, ''));
  if (topics.length && !PRODUCT_WORDS.test(q)) return healthReply(topics[0], topics.slice(1), q);

  const isQuestion = raw.includes('?') || raw.includes('¿') || QUESTION.test(q);
  const clean = q.replace(GREETING, ' ').replace(/\s+/g, ' ').trim() || q;
  const pq = strip(clean) || clean;
  // Preguntas frecuentes: se ordenan con la frase completa; sirven si calzan todas sus palabras
  const fr = faqIdx().search(clean);
  const faq = faqDocs(fr);
  const faqOK = faq.length > 0 && (!fr.partial || (faqIdx().search(pq).items.length > 0 && !faqIdx().search(pq).partial));
  const pr = productIndex.search(pq);
  const prodOK = pr.items.length > 0 && !pr.partial;
  const rxLinks = /\b(receta\w*|cotiz\w*)\b/.test(q) ? [{ type: 'text', text: '', links: [link('Cotizar mi receta', '/cotizar-receta')] }] : [];
  const moreFaq = faq[1] ? [{ type: 'chips', items: [faq[1].q] }] : [];

  // Si la pregunta frecuente calza y el producto solo aparece "corrigiendo" la palabra
  // (despacho → empacho), gana la pregunta frecuente
  if (prodOK && faqOK && isQuestion && !pr.corrected) return [...productsReply(pq, pr), ...faqReply(faq[0])];
  if (faqOK && (!prodOK || pr.corrected)) return faqReply(faq[0], [...rxLinks, ...moreFaq]);
  if (prodOK) return [...productsReply(pq, pr), ...(topics.length ? [{ type: 'chips', items: [`Orientación: ${topics[0].title}`] }] : [])];
  if (faq.length && isQuestion) return faqReply(faq[0], [...rxLinks, ...moreFaq]);
  if (pr.items.length) return productsReply(pq, pr);
  if (rxLinks.length) return [{ type: 'text', text: 'Puedes comprar medicamentos con receta adjuntando una foto de ella al pagar, o cotizarla primero.' }, ...rxLinks];
  return [
    { type: 'text', text: 'No encontré una respuesta para eso. ¿Puedes escribirlo de otra forma? También puedes hablar con nuestro equipo.' },
    { type: 'chips', items: ['Hablar con una persona', 'Buscar un remedio', 'Preguntas frecuentes'] },
  ];
}

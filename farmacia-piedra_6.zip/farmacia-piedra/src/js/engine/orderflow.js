// Etapas de un pedido que maneja la farmacia desde el panel (sitio oficial):
//   despacho:  recibido → embalaje → camino → entregado
//   retiro:    recibido → embalaje → listo  → entregado
// y los mensajes que ve el cliente en su seguimiento en cada cambio, además de
// las fechas de entrega. Lo usan la tienda, el panel y el servidor.

import { DAYS, MONTHS, santiago, addDays, dayLabel } from './format.js';

export const FLOW = {
  despacho: ['recibido', 'embalaje', 'camino', 'entregado'],
  retiro: ['recibido', 'embalaje', 'listo', 'entregado'],
};

const isPickup = (o) => o?.delivery?.type === 'retiro';
export const flowOf = (o) => FLOW[isPickup(o) ? 'retiro' : 'despacho'];

/** ¿El pedido lo maneja la farmacia desde el panel? (los de la tienda sin servidor avanzan solos) */
export const isManaged = (o) => !!o && typeof o.status === 'string';
export const statusOf = (o) => (isManaged(o) && flowOf(o).includes(o.status) ? o.status : 'recibido');

/** Nombre de cada etapa (como lo ve el cliente y la farmacia). */
export function statusInfo(o, status = statusOf(o)) {
  const pickup = isPickup(o);
  switch (status) {
    case 'embalaje': return { label: o?.hasRx ? 'Receta validada y pedido en preparación' : 'Pedido confirmado y en preparación', short: 'En preparación', wait: 'Esperando confirmación de la farmacia' };
    case 'camino': return { label: o?.delivery?.express ? 'En camino (express)' : 'En camino', short: 'En camino', wait: 'Preparando y embalando tu pedido' };
    case 'listo': return { label: 'Listo para retiro', short: 'Listo para retiro', wait: 'Preparando tu pedido para retiro' };
    case 'entregado': return pickup
      ? { label: 'Retirado', short: 'Retirado', wait: 'Esperando tu visita' }
      : { label: 'Entregado', short: 'Entregado', wait: 'En ruta a tu domicilio' };
    default: return { label: 'Pedido recibido', short: 'Por confirmar', wait: '' };
  }
}

export function nextStatus(o) {
  const f = flowOf(o);
  const i = f.indexOf(statusOf(o));
  return i >= 0 && i < f.length - 1 ? f[i + 1] : null;
}
export function prevStatus(o) {
  const f = flowOf(o);
  const i = f.indexOf(statusOf(o));
  return i > 0 ? f[i - 1] : null;
}

/** Texto del botón del panel para pasar a una etapa. */
export function actionLabel(o, status) {
  if (status === 'embalaje') return 'Confirmar pedido y pasar a embalaje';
  if (status === 'camino') return 'Marcar «En camino»';
  if (status === 'listo') return 'Marcar «Listo para retiro»';
  if (status === 'entregado') return isPickup(o) ? 'Marcar «Retirado»' : 'Marcar «Entregado»';
  return 'Volver a «Pedido recibido»';
}

// ── Fechas ───────────────────────────────────────────────────
const ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
export const validIso = (s) => {
  const m = ISO.exec(String(s || ''));
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
};
export const isoOf = (cal) => `${cal.year}-${String(cal.month).padStart(2, '0')}-${String(cal.day).padStart(2, '0')}`;
export function calOf(iso) {
  const m = ISO.exec(String(iso || ''));
  if (!m) return null;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12));
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), weekday: d.getUTCDay() };
}
export const todayIso = (now = new Date()) => isoOf(addDays(now, 0));

/** "jueves 17 de octubre" (con "hoy" o "mañana" si corresponde). */
export function dateText(iso, now = new Date()) {
  const cal = calOf(iso);
  return cal ? dayLabel(cal, santiago(now)) : '';
}
const DOW = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
const MON = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
/** Partes cortas para mostrar un día en una tarjeta: { dow: 'jue', day: 17, mon: 'oct' }. */
export function dayParts(iso) {
  const cal = calOf(iso);
  return cal ? { dow: DOW[cal.weekday], day: cal.day, mon: MON[cal.month - 1] } : null;
}

/** "jueves 17 de octubre" (sin hoy/mañana: para mensajes que se leen después). */
export function dateTextPlain(iso) {
  const cal = calOf(iso);
  return cal ? `${DAYS[cal.weekday]} ${cal.day} de ${MONTHS[cal.month - 1]}` : '';
}

/**
 * Días que el cliente puede elegir para el despacho: desde el primero posible,
 * los siguientes días hábiles (de lunes a sábado).
 */
export function deliveryDates(firstCal, count = 6) {
  if (!firstCal) return [];
  const out = [];
  const base = new Date(Date.UTC(firstCal.year, firstCal.month - 1, firstCal.day, 12));
  for (let i = 0; out.length < count && i < count * 2 + 2; i++) {
    const d = new Date(base.getTime() + i * 86400000);
    if (d.getUTCDay() === 0) continue;
    out.push(isoOf({ year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() }));
  }
  return out;
}

/** Cuándo llega o se retira el pedido, en palabras (usa la fecha guardada si la hay). */
export function deliveryWhen(o, now = new Date()) {
  const d = o?.delivery || {};
  if (!d.date || !validIso(d.date)) return d.eta || '';
  const day = dateText(d.date, now);
  if (d.type === 'retiro') return `Retira ${day}${d.from ? ` ${d.from}` : ''}${d.fromStock ? ' (lo traemos desde bodega)' : ''}`;
  return `Llega ${day}${d.window ? `, ${d.window}` : ''}`;
}

/** Lo que cambia cuando la farmacia avanza un pedido (para saber si hay que actualizarlo). */
export const progressKey = (o) => JSON.stringify([o?.status || '', !!o?.cancelled, (o?.messages || []).length, o?.delivery?.date || '']);

// ── Mensajes para el cliente ─────────────────────────────────
const firstName = (o) => String(o?.customer?.nombre || '').trim().split(/\s+/)[0] || '';

/** Mensaje que ve el cliente al pasar a una etapa (título y texto). */
export function statusMessage(o, status, note = '') {
  const d = o?.delivery || {};
  const when = d.date ? dateTextPlain(d.date) : '';
  let title;
  let text;
  switch (status) {
    case 'embalaje':
      title = 'Pedido confirmado';
      text = `Confirmamos tu pedido${o?.hasRx ? ' y validamos tu receta' : ''}. Ya lo estamos preparando y embalando.${when ? ` ${isPickup(o) ? 'Podrás retirarlo' : 'Llegará'} el ${when}.` : ''}`;
      break;
    case 'camino':
      title = 'Tu pedido va en camino';
      text = `Tu pedido salió hacia ${[d.address, d.comuna].filter(Boolean).join(', ') || 'tu domicilio'}.${when ? ` Llega el ${when}${d.window ? `, ${d.window}` : ''}.` : ''} Si no habrá nadie para recibirlo, avísanos.`;
      break;
    case 'listo':
      title = 'Tu pedido está listo para retiro';
      text = `Ya puedes retirarlo en ${d.storeName || 'la farmacia'}${d.storeAddress ? `, ${d.storeAddress}` : ''}. Lleva tu cédula de identidad${o?.hasRetenida ? ' y la receta original' : ''}.`;
      break;
    case 'entregado':
      title = isPickup(o) ? 'Pedido retirado' : 'Pedido entregado';
      text = '¡Gracias por comprar en Farmacias Piedra! Si tienes cualquier duda con tus productos, escríbenos.';
      break;
    default:
      title = 'Recibimos tu pedido';
      text = 'Te avisaremos aquí apenas lo confirmemos y empecemos a prepararlo.';
  }
  const n = String(note || '').trim();
  return { title, text: n ? `${text} ${n}` : text };
}

export function dateMessage(o, iso, note = '') {
  const pickup = isPickup(o);
  const n = String(note || '').trim();
  const text = `${pickup ? 'La nueva fecha para retirar tu pedido es' : 'La nueva fecha de entrega de tu pedido es'} el ${dateTextPlain(iso)}.${n ? ` ${n}` : ''}`;
  return { title: pickup ? 'Cambió la fecha de retiro' : 'Cambió la fecha de entrega', text };
}

export function cancelMessage(o, by) {
  return by === 'cliente'
    ? { title: 'Anulaste tu pedido', text: `Anulamos tu pedido como pediste.${o?.payment?.status === 'aprobado' ? ' La devolución del pago se verá reflejada según los plazos de tu banco.' : ''}` }
    : { title: 'Pedido anulado', text: `La farmacia anuló tu pedido.${o?.payment?.status === 'aprobado' ? ' La devolución del pago se verá reflejada según los plazos de tu banco.' : ''} Si tienes dudas, escríbenos.` };
}

/** Saludo + mensaje + firma (para enviarlo por correo o WhatsApp). */
export function messageForSending(o, msg) {
  const hola = `Hola${firstName(o) ? ` ${firstName(o)}` : ''}`;
  return `${hola}, te escribimos de Farmacias Piedra por tu pedido ${o?.id || ''}.\n\n${msg.title}: ${msg.text}\n\nPuedes ver el seguimiento en «Sigue tu pedido» con tu número de pedido y tu correo.\n\nSaludos,\nFarmacias Piedra`;
}

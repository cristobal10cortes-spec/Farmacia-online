// «Servicios Piedra»: los recuadros de servicios de la portada (Farmacias y
// turnos, Cotiza tu receta, Mi Tratamiento…). Lo usan la tienda (para
// mostrarlos), el panel (pestaña Servicios Piedra) y el servidor (para
// guardarlos). Mientras no se guarde nada, se usan los de ejemplo.

import { SERVICES, SERVICES_TITLE } from '../data/content.js';

/** Íconos que se pueden elegir para un servicio. */
export const SERVICE_ICONS = {
  store: 'Farmacia',
  moon: 'Turno de noche',
  clock: 'Horario',
  pin: 'Ubicación',
  file: 'Receta',
  refresh: 'Tratamiento',
  scale: 'Bioequivalentes',
  pill: 'Remedio',
  box: 'Pedido',
  truck: 'Despacho',
  phone: 'Teléfono',
  chat: 'Mensaje',
  mail: 'Correo',
  calendar: 'Calendario',
  thermo: 'Termómetro',
  heart: 'Corazón',
  shield: 'Escudo',
  star: 'Estrella',
  percent: 'Descuento',
  gift: 'Regalo',
  card: 'Tarjeta',
  baby: 'Bebé',
  paw: 'Mascotas',
  leaf: 'Natural',
  sparkle: 'Brillo',
  help: 'Ayuda',
};

export const MAX_SERVICES = 12;
export const SERVICE_LIMITS = { section: 40, title: 40, text: 90 };

export const DEFAULT_SERVICES = {
  title: SERVICES_TITLE,
  items: SERVICES.map((s, i) => ({ id: `s${i + 1}`, icon: s.icon, title: s.title, text: s.text, to: s.to, active: true })),
};

/** La sección guardada o, si nunca se guardó, la de ejemplo (builtin: true). */
export function servicesSection(stored) {
  if (stored && Array.isArray(stored.items)) {
    return { title: stored.title || SERVICES_TITLE, items: stored.items.map((x) => ({ ...x })), builtin: false };
  }
  return { title: DEFAULT_SERVICES.title, items: DEFAULT_SERVICES.items.map((x) => ({ ...x })), builtin: true };
}

/** Lo que se ve hoy en la portada: título y servicios activos, en orden. */
export function liveServices(stored) {
  const s = servicesSection(stored);
  return { title: s.title, items: s.items.filter((x) => x.active !== false) };
}

export const newServiceId = () => `S${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 1296).toString(36).toUpperCase().padStart(2, '0')}`;

// ── Validación (el servidor no confía en lo que llega) ──────
const ID = /^[A-Za-z0-9_-]{1,40}$/;
const PATH = /^\/(?!\/)[\w\-/?=&%.~+]*$/;
const txt = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

/**
 * Revisa la sección completa. Devuelve { section } o { error, index }
 * (index = número del servicio con problemas, desde 0).
 */
export function cleanServices(input = {}) {
  const raw = Array.isArray(input.items) ? input.items : null;
  if (!raw) return { error: 'No llegaron los servicios.' };
  if (raw.length > MAX_SERVICES) return { error: `Puedes tener hasta ${MAX_SERVICES} servicios.` };
  const seen = new Set();
  const items = [];
  for (let i = 0; i < raw.length; i++) {
    const x = raw[i] || {};
    let id = String(x.id || '');
    if (!ID.test(id) || seen.has(id)) id = `S${i + 1}${newServiceId().slice(1, 9)}`;
    seen.add(id);
    const item = {
      id,
      icon: Object.hasOwn(SERVICE_ICONS, x.icon) ? x.icon : 'star',
      title: txt(x.title, SERVICE_LIMITS.title),
      text: txt(x.text, SERVICE_LIMITS.text),
      to: txt(x.to, 200) || '/',
      active: x.active !== false,
    };
    if (!item.title) return { error: `Servicio ${i + 1}: escribe el título.`, index: i };
    if (!PATH.test(item.to)) return { error: `Servicio ${i + 1}: la dirección debe ser una página del sitio que empiece con /.`, index: i };
    items.push(item);
  }
  return { section: { title: txt(input.title, SERVICE_LIMITS.section) || SERVICES_TITLE, items, updatedAt: Date.now() } };
}

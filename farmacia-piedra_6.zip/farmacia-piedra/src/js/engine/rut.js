// RUT chileno: limpiar, calcular dígito verificador (módulo 11), validar y formatear.

export const cleanRut = (r) => String(r || '').replace(/[^0-9kK]/g, '').toUpperCase();

export function rutDv(body) {
  let sum = 0;
  let mul = 2;
  const digits = String(body).replace(/\D/g, '');
  for (let i = digits.length - 1; i >= 0; i--) {
    sum += Number(digits[i]) * mul;
    mul = mul === 7 ? 2 : mul + 1;
  }
  const r = 11 - (sum % 11);
  if (r === 11) return '0';
  if (r === 10) return 'K';
  return String(r);
}

export function validateRut(r) {
  const c = cleanRut(r);
  if (c.length < 2) return false;
  const body = c.slice(0, -1);
  const dv = c.slice(-1);
  if (!/^\d{6,8}$/.test(body)) return false;
  return rutDv(body) === dv;
}

export function formatRut(r) {
  const c = cleanRut(r);
  if (c.length < 2) return c;
  const body = c.slice(0, -1).replace(/^0+/, '');
  const dv = c.slice(-1);
  return `${body.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}-${dv}`;
}

// Celular chileno: 9 dígitos que comienzan con 9 (se acepta con o sin +56)
export function cleanPhone(p) {
  let d = String(p || '').replace(/\D/g, '');
  if (d.startsWith('56')) d = d.slice(2);
  return d;
}
export const validPhone = (p) => /^9\d{8}$/.test(cleanPhone(p));
export function formatPhone(p) {
  const d = cleanPhone(p);
  return d.length === 9 ? `+56 ${d[0]} ${d.slice(1, 5)} ${d.slice(5)}` : p;
}

export const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(e || '').trim());

// Formatos chilenos: pesos, fechas y horas en zona America/Santiago.

const TZ = 'America/Santiago';
const nf = new Intl.NumberFormat('es-CL');

export const clp = (n) => `$${nf.format(Math.round(Number(n) || 0))}`;
export const num = (n) => nf.format(Math.round(Number(n) || 0));

export const DAYS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
export const MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

// Partes de la fecha en hora de Santiago (con respaldo a la hora local)
export function santiago(date = new Date()) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: TZ, year: 'numeric', month: 'numeric', day: 'numeric',
      hour: 'numeric', minute: 'numeric', weekday: 'short', hourCycle: 'h23',
    }).formatToParts(date);
    const get = (t) => parts.find((p) => p.type === t)?.value;
    const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(get('weekday'));
    return {
      year: +get('year'), month: +get('month'), day: +get('day'),
      hour: +get('hour') % 24, minute: +get('minute'), weekday: wd,
    };
  } catch {
    return {
      year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate(),
      hour: date.getHours(), minute: date.getMinutes(), weekday: date.getDay(),
    };
  }
}

// Número de día (para rotaciones diarias como farmacias de turno)
export function dayNumber(date = new Date()) {
  const s = santiago(date);
  return Math.floor(Date.UTC(s.year, s.month - 1, s.day) / 86400000);
}

// Fecha calendario (en Santiago) desplazada `n` días
export function addDays(base, n) {
  const s = santiago(base);
  const d = new Date(Date.UTC(s.year, s.month - 1, s.day + n, 12));
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), weekday: d.getUTCDay() };
}

export function dayLabel(cal, today = santiago()) {
  const t = Date.UTC(today.year, today.month - 1, today.day);
  const c = Date.UTC(cal.year, cal.month - 1, cal.day);
  const diff = Math.round((c - t) / 86400000);
  const base = `${DAYS[cal.weekday]} ${cal.day} de ${MONTHS[cal.month - 1]}`;
  if (diff === 0) return `hoy ${base}`;
  if (diff === 1) return `mañana ${base}`;
  return base;
}

export const hhmm = (h) => {
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  return `${String(hh % 24).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
};

export function dateTime(ts) {
  const d = new Date(ts);
  try {
    return new Intl.DateTimeFormat('es-CL', { timeZone: TZ, day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }).format(d);
  } catch {
    return d.toLocaleString();
  }
}

export function shortDate(ts) {
  const d = new Date(ts);
  try {
    return new Intl.DateTimeFormat('es-CL', { timeZone: TZ, day: '2-digit', month: '2-digit', year: 'numeric' }).format(d);
  } catch {
    return d.toLocaleDateString();
  }
}

export const plural = (n, one, many) => `${num(n)} ${n === 1 ? one : many}`;

// Plural en español para nombres de unidades ("comprimido" → "comprimidos", "lápiz" → "lápices")
export function pluralEs(w) {
  if (!w || ['ml', 'g', 'dosis'].includes(w) || w.endsWith('s')) return w;
  if (/[aeiouáéó]$/.test(w)) return `${w}s`;
  if (w.endsWith('z')) return `${w.slice(0, -1)}ces`;
  if (w.endsWith('ón')) return `${w.slice(0, -2)}ones`;
  if (/t$/.test(w)) return `${w}s`;
  return `${w}es`;
}

export const qtyUnits = (n, unit) => (['ml', 'g'].includes(unit) ? `${num(n)} ${unit}` : `${num(n)} ${n === 1 ? unit : pluralEs(unit)}`);
export const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

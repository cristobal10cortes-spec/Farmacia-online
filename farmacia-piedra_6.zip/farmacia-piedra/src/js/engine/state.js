// Estado de la tienda (carro, sesión, pedidos…) guardado en este navegador.
// localStorage puede no estar disponible: todo funciona igual en memoria.

import { RULES } from '../config.js';

// El panel de administración usa su propia clave para no mezclarse con la tienda
const KEY = (typeof globalThis !== 'undefined' && globalThis.PIEDRA_STATE_KEY) || 'piedra:v1';
const listeners = new Map();

function load() {
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function defaults() {
  return {
    location: { ...RULES.defaultLocation },
    cart: [], // [{ id, qty }]
    favorites: [], // [productId]
    session: null, // email de la cuenta activa
    users: {}, // email → cuenta
    orders: [], // pedidos creados en este navegador
    recent: [], // búsquedas recientes
    coupon: null,
    quotes: [], // cotizaciones de receta enviadas
    newsletter: [],
    seenLocation: false,
    // Ventas de este navegador cuando no hay servidor (se descuentan solo aquí)
    localSales: [],
    // Preferencias del panel de administración (solo en el panel)
    adminPrefs: { demoSales: false },
  };
}

const saved = load();
export const state = { ...defaults(), ...(saved || {}) };
// Restos de versiones anteriores (el panel ya no vive en la tienda)
delete state.backoffice;
delete state.adminSession;

let saveTimer = null;
export function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* sin almacenamiento: seguimos en memoria */
    }
  }, 60);
}

/** Guarda ya. Devuelve false solo si el navegador se quedó sin espacio. */
export function saveNow() {
  clearTimeout(saveTimer);
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    return !(e && (e.name === 'QuotaExceededError' || e.code === 22 || /quota/i.test(e.message || '')));
  }
}

export function on(evt, fn) {
  if (!listeners.has(evt)) listeners.set(evt, new Set());
  listeners.get(evt).add(fn);
  return () => listeners.get(evt).delete(fn);
}

export function emit(evt, data) {
  save();
  for (const fn of listeners.get(evt) || []) {
    try { fn(data); } catch (e) { console.error(e); }
  }
  for (const fn of listeners.get('*') || []) {
    try { fn(evt, data); } catch (e) { console.error(e); }
  }
}

export const currentUser = () => (state.session && state.users[state.session]) || null;
export const isMember = () => !!currentUser()?.club;

export function resetAll() {
  Object.assign(state, defaults());
  emit('reset');
}

// Stock por ubicación (lectura). Lo usan el panel de administración y el
// servidor; ninguna función de este archivo guarda cambios.
//
// Ubicaciones: "o:<zona>" = bodega online de una zona de despacho,
//              "s:<id farmacia>" = una farmacia.

import { allProducts } from './catalog.js';
import { onlineStockRaw, storeStockRaw } from './inventory.js';
import { STORES, storeById } from '../data/stores.js';
import { ZONES } from '../config.js';

export const ZONE_IDS = Object.keys(ZONES);

/** ¿Es una ubicación de stock válida? */
export function validLoc(loc) {
  const [k, id, extra] = String(loc || '').split(':');
  if (extra !== undefined) return false;
  if (k === 'o') return ZONE_IDS.includes(id);
  if (k === 's') return !!storeById(id);
  return false;
}

export const locLabel = (loc) => {
  const [k, id] = String(loc).split(':');
  if (k === 'o') return `Bodega online · ${ZONES[id]?.name || id}`;
  return storeById(id)?.name || 'Farmacia eliminada';
};

// El panel y el servidor ven el stock que hay, aunque el producto esté oculto
export function stockAt(p, loc) {
  const [k, id] = String(loc).split(':');
  if (k === 'o') return onlineStockRaw(p, id);
  const st = storeById(id);
  return st ? storeStockRaw(p, st) : 0;
}

/** Stock actual de un producto en todas las ubicaciones. */
export function stockSnapshot(p) {
  const o = {};
  const s = {};
  for (const z of ZONE_IDS) o[z] = onlineStockRaw(p, z);
  for (const st of STORES) s[st.id] = storeStockRaw(p, st);
  return { o, s };
}

export function stockTotals(p) {
  const snap = stockSnapshot(p);
  const online = Object.values(snap.o).reduce((a, b) => a + b, 0);
  const stores = Object.values(snap.s).reduce((a, b) => a + b, 0);
  return { online, stores, total: online + stores };
}

/** Nivel de stock para alertas: 'sin' | 'bajo' | 'ok' */
export function stockLevel(p, totals = stockTotals(p)) {
  if (p.rx === 'cheque') return totals.stores <= 0 ? 'sin' : totals.stores <= 10 ? 'bajo' : 'ok';
  if (totals.total <= 0) return 'sin';
  if (totals.online <= 5 || totals.total <= 20) return 'bajo';
  return 'ok';
}

/** Productos con stock bajo o agotados (para alertas del panel). */
export function lowStock(limit = 8) {
  return allProducts()
    .filter((p) => !p.hidden && p.rx !== 'cheque')
    .map((p) => ({ p, t: stockTotals(p) }))
    .map((x) => ({ ...x, level: stockLevel(x.p, x.t) }))
    .filter((x) => x.level !== 'ok')
    .sort((a, b) => a.t.total - b.t.total || b.p.popularity - a.p.popularity)
    .slice(0, limit);
}

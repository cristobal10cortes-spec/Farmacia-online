// Pedidos: creación, seguimiento (simulado en el tiempo) y anulación.
//
// Con servidor (sitio oficial) el pedido lo crea y valida el servidor, que
// también descuenta el stock; aquí solo se guarda una copia para el cliente.
// Sin servidor, el pedido queda en este navegador y el stock se descuenta
// solo aquí.

import { state, emit } from './state.js';
import { isManaged, flowOf, statusOf, statusInfo } from './orderflow.js';

// Ventas de este navegador (sin servidor): se descuentan solo aquí
function recordLocalSale(order) {
  const at = Date.now();
  state.localSales = [...(state.localSales || []), ...(order.stockMoves || []).map((mv) => ({ ...mv, at, ref: order.id }))].slice(-500);
  emit('catalog');
}

function releaseLocalSale(order) {
  state.localSales = (state.localSales || []).filter((s) => s.ref !== order.id);
  emit('catalog');
}

/** Guarda (o actualiza) la copia local de un pedido hecho en el servidor. */
export function syncRemoteOrder(serverOrder) {
  const i = state.orders.findIndex((o) => o.id === serverOrder.id);
  const prev = i >= 0 ? state.orders[i] : null;
  // El seguimiento muestra RUT y celular a medias: si el pedido se hizo aquí, se guardan los datos completos
  // (la fecha de entrega y las etapas sí se toman siempre del servidor)
  const delivery = prev?.delivery?.pickupRut ? { ...serverOrder.delivery, pickupRut: prev.delivery.pickupRut } : serverOrder.delivery;
  const merged = { ...(prev || {}), ...serverOrder, ...(prev?.customer ? { customer: prev.customer } : {}), delivery, remote: true };
  if (i >= 0) state.orders[i] = merged;
  else state.orders.unshift(merged);
  emit('orders', merged);
  return merged;
}

const MIN = 60 * 1000;

function newId() {
  for (;;) {
    const id = `PD${Math.floor(10000000 + Math.random() * 89999999)}`;
    if (!state.orders.some((o) => o.id === id)) return id;
  }
}

export function createOrder({ customer, delivery, payment, totals, shipping, prescriptions = [], document, stockMoves = [] }) {
  const order = {
    id: newId(),
    createdAt: Date.now(),
    userEmail: state.session || null,
    customer,
    items: totals.lines.map((l) => ({
      id: l.product.id,
      slug: l.product.slug,
      name: l.product.name,
      brand: l.product.brand,
      qty: l.qty,
      unit: l.info.sale,
      total: l.total,
      rx: l.product.rx,
    })),
    totals: {
      listTotal: totals.listTotal,
      offerOff: totals.offerOff,
      promoOff: totals.promoOff,
      clubOff: totals.clubOff,
      couponOff: totals.couponOff,
      coupon: totals.coupon?.code || null,
      subtotal: totals.subtotal,
      shipping,
      total: totals.total + shipping,
    },
    delivery,
    payment,
    document,
    prescriptions,
    hasRx: totals.hasRx,
    hasRetenida: totals.hasRetenida,
    stockMoves,
    cancelled: false,
  };
  state.orders.unshift(order);
  emit('orders', order);
  recordLocalSale(order); // descuenta el stock en este navegador
  return order;
}

export const findOrder = (id) => state.orders.find((o) => o.id === String(id || '').trim().toUpperCase()) || null;

/** Cuándo pasó a cada etapa (la última vez). */
function stageTimes(order) {
  const at = { recibido: order.createdAt };
  for (const h of order.history || []) if (h && h.status && !h.back) at[h.status] = h.at;
  return at;
}

// Pedido que maneja la farmacia desde el panel: las etapas avanzan cuando ella las marca
function managedTimeline(order) {
  const flow = flowOf(order);
  const cur = flow.indexOf(statusOf(order));
  const at = stageTimes(order);
  if (order.cancelled) {
    return {
      steps: [{ key: 'recibido', label: 'Pedido recibido', at: order.createdAt, done: true }, { key: 'anulado', label: 'Pedido anulado', at: order.cancelledAt, done: true, current: true }],
      current: { key: 'anulado', label: 'Anulado' },
      done: true,
      cancelled: true,
      managed: true,
    };
  }
  const steps = flow.map((key, i) => {
    const info = statusInfo(order, key);
    return { key, label: info.label, wait: i === cur + 1 ? info.wait : '', at: i <= cur ? at[key] || null : null, done: i <= cur };
  });
  const next = steps[cur + 1] || null;
  steps.forEach((s, i) => { s.current = next ? s === next : i === cur; });
  return { steps, current: steps[cur], next, done: !next, canCancel: cur === 0, managed: true };
}

// Línea de tiempo del pedido. Sin servidor (demostración), cada etapa avanza en minutos.
export function orderTimeline(order, now = Date.now()) {
  if (isManaged(order)) return managedTimeline(order);
  const t0 = order.createdAt;
  const pickup = order.delivery.type === 'retiro';
  const steps = [{ key: 'recibido', label: 'Pedido recibido', at: t0 }];
  let base = t0;
  if (order.payment.method === 'transferencia') {
    base = t0 + 10 * MIN;
    steps.push({ key: 'pago', label: 'Transferencia confirmada', at: base, wait: 'Esperando tu transferencia' });
  } else if (order.payment.method === 'farmacia') {
    steps.push({ key: 'pago', label: 'Pagas al retirar en la farmacia', at: t0 });
  } else {
    steps.push({ key: 'pago', label: 'Pago aprobado', at: t0 });
  }
  if (order.hasRx) steps.push({ key: 'receta', label: 'Receta validada por químico farmacéutico', at: base + 3 * MIN, wait: 'Validando tu receta' });
  steps.push({ key: 'preparacion', label: 'Pedido preparado', at: base + 6 * MIN, wait: 'Preparando tu pedido' });
  if (pickup) {
    steps.push({ key: 'listo', label: 'Listo para retiro', at: base + 20 * MIN, wait: 'Pronto estará listo para retiro' });
    steps.push({ key: 'entregado', label: 'Retirado', at: base + 120 * MIN, wait: 'Esperando tu visita' });
  } else {
    steps.push({ key: 'camino', label: order.delivery.express ? 'En camino (express)' : 'En camino', at: base + 25 * MIN, wait: 'Coordinando el despacho' });
    steps.push({ key: 'entregado', label: 'Entregado', at: base + 90 * MIN, wait: 'En ruta a tu domicilio' });
  }
  if (order.cancelled) {
    return {
      steps: [steps[0], { key: 'anulado', label: 'Pedido anulado', at: order.cancelledAt, done: true, current: true }],
      current: { key: 'anulado', label: 'Anulado' },
      done: true,
      cancelled: true,
    };
  }
  let current = steps[0];
  for (const s of steps) {
    s.done = s.at <= now;
    if (s.done) current = s;
  }
  const next = steps.find((s) => !s.done);
  steps.forEach((s) => { s.current = s === (next || current); });
  return {
    steps,
    current,
    next,
    done: !next,
    canCancel: !order.cancelled && !steps.find((s) => s.key === 'preparacion')?.done,
  };
}

export function statusLabel(order) {
  const tl = orderTimeline(order);
  if (tl.cancelled) return { text: 'Anulado', tone: 'danger' };
  if (tl.managed) {
    const info = statusInfo(order);
    return { text: info.short, tone: tl.done ? 'ok' : statusOf(order) === 'recibido' ? 'warn' : 'info', key: statusOf(order) };
  }
  if (tl.done) return { text: tl.current.label, tone: 'ok' };
  return { text: tl.next?.wait || tl.current.label, tone: 'info' };
}

/** Anula un pedido hecho sin servidor (los del servidor se anulan allá). */
export function cancelOrder(id) {
  const o = findOrder(id);
  if (!o || o.remote) return false;
  const tl = orderTimeline(o);
  if (!tl.canCancel) return false;
  o.cancelled = true;
  o.cancelledAt = Date.now();
  emit('orders', o);
  releaseLocalSale(o); // repone el stock
  return true;
}

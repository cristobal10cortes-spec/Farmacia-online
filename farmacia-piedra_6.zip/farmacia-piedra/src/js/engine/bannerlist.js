// Banners de la tienda: lista, orden, fechas y validación. Lo usan la
// tienda (para mostrarlos), el panel y el servidor (para guardarlos).
//
// Hay dos lugares:
//  • 'hero'   el carrusel grande de arriba de la portada.
//  • 'promo'  los recuadros grandes de más abajo (después de «Ofertas destacadas»).
//
// Mientras no se guarde ninguno de un lugar, se usan los de ejemplo. Al
// primer cambio en el panel, esos ejemplos pasan a ser banners editables.

import { HERO, PROMOS } from '../data/content.js';
import { santiago } from './format.js';

export const BANNER_ARTS = ['be', 'club', 'sun', 'rx'];
export const BANNER_TONES = ['lapis', 'pyrite', 'sky', 'basalt', 'custom'];
export const BANNER_VISUALS = ['art', 'product', 'photo', 'none'];
export const BANNER_PLACES = ['hero', 'promo'];
/** Cuántos banners de más abajo se muestran a la vez (y cuántos se pueden guardar). */
export const PROMO_VISIBLE = 4;
export const MAX_PROMOS = 8;
/** Largo máximo de una foto recién subida (data URL, ~1 MB). */
export const MAX_BANNER_IMAGE = 1400000;

/**
 * Medidas recomendadas de las fotos, en píxeles. Coinciden con el tamaño
 * real de cada recuadro en la tienda (el doble de nítido en pantallas buenas):
 *  • hero   carrusel en computador: 1.232 × 330 px en pantalla (3,7 : 1)
 *  • heroM  carrusel en celular: casi cuadrado
 *  • promo  banner de más abajo en computador: 608 × 273 px (2,2 : 1)
 *  • menu   tarjeta del menú «Categorías»: 250 × 125 px (2 : 1)
 */
export const PHOTO_SIZES = {
  hero: { w: 1600, h: 430, label: 'computador' },
  heroM: { w: 800, h: 800, label: 'celular' },
  promo: { w: 1200, h: 540, label: 'banner de más abajo' },
  menu: { w: 600, h: 300, label: 'tarjeta del menú' },
};

/**
 * ¿La foto subida sirve para ese lugar? Devuelve { tone: 'ok'|'warn', text }.
 * Se avisa si es chica (se verá borrosa) o si su forma es muy distinta (se recorta).
 */
export function photoFit(w, h, size) {
  const W = Math.round(Number(w) || 0);
  const H = Math.round(Number(h) || 0);
  if (!W || !H || !size) return { tone: 'warn', text: 'No pudimos leer la medida de la foto.' };
  const fmt = (n) => n.toLocaleString('es-CL');
  const ideal = `${fmt(size.w)} × ${fmt(size.h)} px`;
  const ratio = W / H;
  const want = size.w / size.h;
  const off = Math.abs(ratio - want) / want;
  if (W < size.w * 0.5 || H < size.h * 0.5) return { tone: 'warn', text: `Tu foto mide ${fmt(W)} × ${fmt(H)} px: es chica y puede verse borrosa. Lo ideal es ${ideal}.` };
  if (off > 0.2) {
    const cut = ratio > want ? 'los lados' : 'arriba y abajo';
    return { tone: 'warn', text: `Tu foto mide ${fmt(W)} × ${fmt(H)} px: tiene otra forma, así que se recortará por ${cut}. Mira la vista previa o usa una de ${ideal}.` };
  }
  return { tone: 'ok', text: `Tu foto mide ${fmt(W)} × ${fmt(H)} px: tiene buena medida.` };
}

export const DEFAULT_BANNERS = HERO.map((h, i) => ({
  id: h.id, place: 'hero', eyebrow: h.eyebrow, title: h.title, text: h.text, cta: h.cta, to: h.to,
  tone: h.tone, color: '', visual: 'art', art: h.art, productId: '', image: '', imageM: '', photoOnly: false,
  active: true, order: i, from: '', until: '', dynamic: h.id === 'club' ? 'club' : '',
}));

export const DEFAULT_PROMOS = PROMOS.map((h, i) => ({
  id: h.id, place: 'promo', eyebrow: h.eyebrow, title: h.title, text: h.text, cta: h.cta, to: h.to,
  tone: h.tone, color: '', visual: 'none', art: '', productId: '', image: '', imageM: '', photoOnly: false,
  active: true, order: i, from: '', until: '', dynamic: '',
}));

export const placeOf = (b) => (b?.place === 'promo' ? 'promo' : 'hero');
export const defaultsFor = (place) => (place === 'promo' ? DEFAULT_PROMOS : DEFAULT_BANNERS);

export const byOrder = (a, b) => (a.order ?? 0) - (b.order ?? 0) || String(a.id).localeCompare(String(b.id));

export const todayIso = () => {
  const t = santiago();
  return `${t.year}-${String(t.month).padStart(2, '0')}-${String(t.day).padStart(2, '0')}`;
};

/** Banners guardados de ese lugar o, si no hay ninguno, los de ejemplo (marcados builtin). */
export function bannerList(stored, place = 'hero') {
  const own = (stored || []).filter((b) => placeOf(b) === place);
  const list = own.length ? own.slice() : defaultsFor(place).map((b) => ({ ...b, builtin: true }));
  return list.sort(byOrder);
}

/** Estado de un banner: 'activo' | 'pausado' | 'programado' | 'vencido'. */
export function bannerStatus(b, today = todayIso()) {
  if (!b.active) return 'pausado';
  if (b.from && b.from > today) return 'programado';
  if (b.until && b.until < today) return 'vencido';
  return 'activo';
}

/** Banners que se muestran hoy en ese lugar, en orden. */
export function liveFrom(stored, place = 'hero') {
  const today = todayIso();
  const list = bannerList(stored, place).filter((b) => bannerStatus(b, today) === 'activo');
  return place === 'promo' ? list.slice(0, PROMO_VISIBLE) : list;
}

export const newBannerId = () => `B${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 1296).toString(36).toUpperCase().padStart(2, '0')}`;

// ── Fotos ────────────────────────────────────────────────────
// Una foto se guarda en el servidor y el banner solo anota su referencia
// («media:clave?v=versión»). Mientras se edita, la foto recién subida viaja
// como data URL; el servidor la revisa, la guarda y la cambia por la referencia.
const DATA_IMG = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
const MEDIA_REF = /^media:([A-Za-z0-9_-]{1,60})\?v=([a-z0-9]{1,16})$/;
export const isUploadImage = (s) => DATA_IMG.test(String(s || ''));
export const isMediaRef = (s) => MEDIA_REF.test(String(s || ''));
export const isImageRef = (s) => isUploadImage(s) || isMediaRef(s);
export const mediaRef = (key, v) => `media:${key}?v=${v}`;

let mediaBase = '/api/imagenes/';
/** Dónde se piden las fotos guardadas (la tienda y el panel usan direcciones distintas). */
export function setMediaBase(base) { mediaBase = String(base || '/api/imagenes/'); }
/** Dirección para mostrar la foto ('' si no hay una válida). */
export function imageSrc(ref) {
  const s = String(ref || '');
  const m = MEDIA_REF.exec(s);
  if (m) return `${mediaBase}${m[1]}?v=${m[2]}`;
  return DATA_IMG.test(s) ? s : '';
}

// ── Validación (el servidor no confía en lo que llega) ──────
const ID = /^[A-Za-z0-9_-]{1,40}$/;
const HEX = /^#[0-9a-f]{6}$/i;
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const PATH = /^\/(?!\/)[\w\-/?=&%.~+]*$/;
const txt = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

export const validBannerId = (id) => ID.test(String(id || ''));

function cleanImage(v, label) {
  const s = String(v || '');
  if (!s) return { ref: '' };
  if (!isImageRef(s)) return { error: `La ${label} no es válida (JPG o PNG).` };
  if (s.length > MAX_BANNER_IMAGE) return { error: `La ${label} es muy pesada. Prueba con una más liviana.` };
  return { ref: s };
}

/**
 * Deja solo campos conocidos y con el formato correcto.
 * Devuelve { banner } o { error }.
 */
export function cleanBanner(input = {}) {
  const place = input.place === 'promo' ? 'promo' : 'hero';
  const b = {
    id: String(input.id || ''),
    place,
    eyebrow: txt(input.eyebrow, 40),
    title: txt(input.title, 90),
    text: txt(input.text, 180),
    cta: txt(input.cta, 30) || 'Ver más',
    to: txt(input.to, 200) || '/',
    tone: BANNER_TONES.includes(input.tone) ? input.tone : 'lapis',
    color: HEX.test(String(input.color || '')) ? String(input.color) : '',
    visual: BANNER_VISUALS.includes(input.visual) ? input.visual : 'none',
    art: BANNER_ARTS.includes(input.art) ? input.art : '',
    productId: ID.test(String(input.productId || '')) ? String(input.productId) : '',
    image: '',
    imageM: '',
    photoOnly: false,
    active: input.active !== false,
    order: Number.isFinite(Number(input.order)) ? Math.max(0, Math.min(999, Math.round(Number(input.order)))) : 0,
    from: DAY.test(String(input.from || '')) ? String(input.from) : '',
    until: DAY.test(String(input.until || '')) ? String(input.until) : '',
    dynamic: input.dynamic === 'club' && place === 'hero' ? 'club' : '',
    updatedAt: Date.now(),
  };
  if (b.id && !ID.test(b.id)) return { error: 'El banner tiene un identificador inválido.' };
  if (!b.title) return { error: 'Escribe el título del banner.' };
  if (!PATH.test(b.to)) return { error: 'La dirección del botón debe ser una dirección del sitio que empiece con /.' };
  if (b.tone === 'custom' && !b.color) b.tone = 'lapis';
  // Los de más abajo usan foto o el fondo de color (sin ilustraciones)
  if (place === 'promo' && (b.visual === 'art' || b.visual === 'product')) b.visual = 'none';
  if (b.visual === 'photo') {
    const main = cleanImage(input.image, 'foto del banner');
    if (main.error) return { error: main.error };
    if (!main.ref) return { error: 'Sube la foto del banner.' };
    b.image = main.ref;
    if (place === 'hero') {
      const m = cleanImage(input.imageM, 'foto para celular');
      if (m.error) return { error: m.error };
      b.imageM = m.ref;
    }
    b.photoOnly = input.photoOnly === true;
  }
  if (b.visual === 'art' && !b.art) b.art = 'be';
  if (b.visual === 'product' && !b.productId) return { error: 'Elige el producto que se verá en el banner.' };
  if (b.from && b.until && b.until < b.from) return { error: 'La fecha final debe ser posterior a la inicial.' };
  return { banner: b };
}

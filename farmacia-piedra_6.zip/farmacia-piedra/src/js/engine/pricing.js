// Precios: oferta, Club Piedra (campañas por día y programa Mi Tratamiento),
// promociones por cantidad, cupones y costo de despacho.

import { CLUB, COUPONS, ZONES, RULES } from '../config.js';
import { santiago } from './format.js';
import { salePrice } from './catalog.js';

// Campañas Club activas hoy (según el día de la semana en Santiago)
export function activeCampaigns(date = new Date()) {
  const wd = santiago(date).weekday;
  return CLUB.campaigns.filter((c) => c.days.includes(wd));
}

const inCats = (p, cats) => cats.includes(p.cat) || p.also.some((a) => cats.includes(a.cat));

/**
 * Descuento Club aplicable a un producto.
 * ctx: { treatment: Set<id>, date }
 */
export function clubDiscount(p, ctx = {}) {
  let pct = p.clubPct || 0;
  let source = pct ? 'producto' : null;
  let label = pct ? `${pct}% Club` : '';
  for (const c of activeCampaigns(ctx.date)) {
    if (p.rx === 'directa' && inCats(p, c.cats) && c.pct > pct) {
      pct = c.pct;
      source = 'campaña';
      label = `${c.title}: ${c.pct}%`;
    }
  }
  if (ctx.treatment && ctx.treatment.has(p.id) && CLUB.treatmentPct > pct) {
    pct = CLUB.treatmentPct;
    source = 'tratamiento';
    label = `Mi Tratamiento: ${CLUB.treatmentPct}%`;
  }
  return { pct, source, label };
}

export function priceInfo(p, ctx = {}) {
  const sale = salePrice(p);
  const club = clubDiscount(p, ctx);
  const clubPrice = club.pct ? Math.round(sale * (1 - club.pct / 100)) : null;
  return {
    list: p.price,
    sale,
    offPct: p.offer && p.offer < p.price ? Math.round((1 - p.offer / p.price) * 100) : 0,
    clubPrice,
    clubPct: club.pct,
    clubLabel: club.label,
    clubSource: club.source,
    perUnit: Math.round(sale / Math.max(1, p.units)),
  };
}

// Programa Mi Tratamiento: medicamentos de uso crónico con receta simple
export const treatmentEligible = (p) => p.chronic && p.rx === 'simple';

export const PROMO_LABEL = {
  '2x1': '2x1',
  '3x2': '3x2',
  '2da-50': '2ª unidad -50%',
};

export const PROMO_TEXT = {
  '2x1': 'Lleva 2 y paga 1.',
  '3x2': 'Lleva 3 y paga 2.',
  '2da-50': 'La segunda unidad tiene 50% de descuento.',
};

export function promoDiscount(promo, qty, unit) {
  if (!promo || qty < 2) return 0;
  if (promo === '2x1') return Math.floor(qty / 2) * unit;
  if (promo === '3x2') return Math.floor(qty / 3) * unit;
  if (promo === '2da-50') return Math.floor(qty / 2) * Math.round(unit * 0.5);
  return 0;
}

/**
 * Totales del carro.
 * items: [{ product, qty }]; ctx: { member, treatment, date, coupon, ordersCount }
 */
export function cartTotals(items, ctx = {}) {
  const lines = items.map(({ product: p, qty }) => {
    const info = priceInfo(p, ctx);
    const listTotal = p.price * qty;
    const saleTotal = info.sale * qty;
    const promoOff = promoDiscount(p.promo, qty, info.sale);
    const clubOff = ctx.member && info.clubPrice ? (info.sale - info.clubPrice) * qty : 0;
    // Promociones y descuento Club no son acumulables: se aplica el mayor.
    const usePromo = promoOff >= clubOff;
    const lineOff = usePromo ? promoOff : clubOff;
    return {
      product: p, qty, info,
      listTotal, saleTotal,
      offerOff: listTotal - saleTotal,
      promoOff: usePromo ? promoOff : 0,
      clubOff: usePromo ? 0 : clubOff,
      total: saleTotal - lineOff,
      // Ahorro Club que obtendría si fuera socio (para invitar a unirse)
      clubPotential: !ctx.member && info.clubPrice ? Math.max(0, (info.sale - info.clubPrice) * qty - promoOff) : 0,
    };
  });
  const sum = (k) => lines.reduce((a, l) => a + l[k], 0);
  const t = {
    lines,
    count: lines.reduce((a, l) => a + l.qty, 0),
    listTotal: sum('listTotal'),
    offerOff: sum('offerOff'),
    promoOff: sum('promoOff'),
    clubOff: sum('clubOff'),
    clubPotential: sum('clubPotential'),
    subtotal: sum('total'),
    hasRx: lines.some((l) => l.product.rx !== 'directa'),
    hasRetenida: lines.some((l) => l.product.rx === 'retenida'),
    hasCheque: lines.some((l) => l.product.rx === 'cheque'),
    hasCold: lines.some((l) => l.product.cold),
  };
  t.coupon = null;
  t.couponOff = 0;
  t.freeShippingCoupon = false;
  if (ctx.coupon) {
    const v = evaluateCoupon(ctx.coupon, t, ctx);
    if (v.ok) {
      t.coupon = v.coupon;
      t.couponOff = v.amount;
      t.freeShippingCoupon = v.coupon.type === 'shipping';
    } else {
      t.couponError = v.error;
    }
  }
  t.total = Math.max(0, t.subtotal - t.couponOff);
  return t;
}

export function findCoupon(code) {
  const c = String(code || '').trim().toUpperCase();
  return COUPONS.find((x) => x.code === c) || null;
}

export function evaluateCoupon(code, totals, ctx = {}) {
  const coupon = findCoupon(code);
  if (!coupon) return { ok: false, error: 'Ese cupón no existe. Revisa que esté bien escrito.' };
  if (coupon.firstOrder && (ctx.ordersCount || 0) > 0) return { ok: false, error: 'Este cupón es solo para la primera compra.' };
  const eligible = totals.lines
    .filter((l) => !(coupon.excludeRx && l.product.rx !== 'directa') && !l.promoOff)
    .reduce((a, l) => a + l.total, 0);
  if (totals.subtotal < (coupon.minAmount || 0)) {
    return { ok: false, error: `Este cupón requiere una compra mínima de $${(coupon.minAmount).toLocaleString('es-CL')}.` };
  }
  if (coupon.type === 'shipping') return { ok: true, coupon, amount: 0 };
  if (!eligible) return { ok: false, error: 'Ningún producto del carro aplica para este cupón (no aplica a medicamentos con receta ni productos en promoción).' };
  let amount = coupon.type === 'pct' ? Math.round(eligible * coupon.value / 100) : Math.min(coupon.value, eligible);
  if (coupon.max) amount = Math.min(amount, coupon.max);
  return { ok: true, coupon, amount };
}

// Costo de despacho a domicilio según zona y monto
// (el despacho express tiene tarifa fija y no entra en el despacho gratis)
export function shippingCost({ zone, subtotal, express = false, freeCoupon = false }) {
  if (express) return RULES.expressCost;
  const z = ZONES[zone] || ZONES.SUR;
  if (freeCoupon || subtotal >= z.freeFrom) return 0;
  return z.shipping;
}

export const freeShippingFrom = (zone) => (ZONES[zone] || ZONES.SUR).freeFrom;

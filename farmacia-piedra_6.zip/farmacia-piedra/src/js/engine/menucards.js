// Accesos destacados del menú «Categorías» (las tarjetas de color de la
// derecha). Lo usan la tienda (para mostrarlos), el panel y el servidor
// (para guardarlos). Mismo esquema que los banners: mientras no se guarde
// ninguno se usan los de ejemplo; al primer cambio pasan a ser editables.

import { bannerStatus, todayIso, byOrder, isImageRef, MAX_BANNER_IMAGE } from './bannerlist.js';

export { byOrder };

/** Colores de fondo: todos con texto blanco legible (contraste AA). */
export const MENU_TONES = {
  lapis: 'Azul',
  pyrite: 'Dorado',
  jade: 'Verde',
  sky: 'Celeste',
  coral: 'Rojo',
  basalt: 'Grafito',
};

/** Íconos que se pueden elegir para una tarjeta. */
export const MENU_ICONS = {
  star: 'Estrella',
  scale: 'Balanza',
  percent: 'Porcentaje',
  tag: 'Etiqueta',
  gift: 'Regalo',
  pill: 'Remedio',
  file: 'Receta',
  truck: 'Despacho',
  clock: 'Reloj',
  store: 'Farmacia',
  heart: 'Corazón',
  leaf: 'Hoja',
  sparkle: 'Brillo',
  baby: 'Bebé',
  sun: 'Sol',
  shield: 'Escudo',
};

/** Cuántas tarjetas activas caben en el menú y cuántas se pueden guardar. */
export const MENU_VISIBLE = 4;
export const MAX_MENU_CARDS = 12;

export const DEFAULT_MENU_CARDS = [
  { id: 'club', kicker: 'Club Piedra', title: 'Precios de socio toda la semana', text: 'Inscríbete gratis.', to: '/club', tone: 'pyrite', icon: 'star', active: true, order: 0, from: '', until: '', dynamic: 'club' },
  { id: 'bioeq', kicker: 'Bioequivalentes', title: 'El mismo efecto, a menor precio', text: 'Compara alternativas certificadas.', to: '/bioequivalentes', tone: 'lapis', icon: 'scale', active: true, order: 1, from: '', until: '', dynamic: '' },
];

/** Tarjetas guardadas o, si no hay ninguna, las de ejemplo (marcadas builtin). */
export function menuCardList(stored) {
  const list = stored && stored.length ? stored.slice() : DEFAULT_MENU_CARDS.map((c) => ({ ...c, builtin: true }));
  return list.sort(byOrder);
}

/** 'activo' | 'pausado' | 'programado' | 'vencido' (igual que los banners). */
export const menuCardStatus = (c, today = todayIso()) => bannerStatus(c, today);

/** Las que se ven hoy en el menú, en orden (máximo MENU_VISIBLE). */
export function liveMenuCards(stored) {
  const today = todayIso();
  return menuCardList(stored).filter((c) => menuCardStatus(c, today) === 'activo').slice(0, MENU_VISIBLE);
}

export const newMenuCardId = () => `M${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 1296).toString(36).toUpperCase().padStart(2, '0')}`;

// ── Validación (el servidor no confía en lo que llega) ──────
const ID = /^[A-Za-z0-9_-]{1,40}$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const PATH = /^\/(?!\/)[\w\-/?=&%.~+]*$/;
const txt = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

export const validMenuCardId = (id) => ID.test(String(id || ''));
export const MENU_LIMITS = { kicker: 28, title: 70, text: 110 };

/** Deja solo campos conocidos y con el formato correcto. Devuelve { card } o { error }. */
export function cleanMenuCard(input = {}) {
  const c = {
    id: String(input.id || ''),
    kicker: txt(input.kicker, MENU_LIMITS.kicker),
    title: txt(input.title, MENU_LIMITS.title),
    text: txt(input.text, MENU_LIMITS.text),
    to: txt(input.to, 200) || '/',
    tone: Object.hasOwn(MENU_TONES, input.tone) ? input.tone : 'lapis',
    icon: Object.hasOwn(MENU_ICONS, input.icon) ? input.icon : '',
    image: '',
    active: input.active !== false,
    order: Number.isFinite(Number(input.order)) ? Math.max(0, Math.min(999, Math.round(Number(input.order)))) : 0,
    from: DAY.test(String(input.from || '')) ? String(input.from) : '',
    until: DAY.test(String(input.until || '')) ? String(input.until) : '',
    dynamic: input.dynamic === 'club' ? 'club' : '',
    updatedAt: Date.now(),
  };
  if (c.id && !ID.test(c.id)) return { error: 'La tarjeta tiene un identificador inválido.' };
  if (!c.title) return { error: 'Escribe el título de la tarjeta.' };
  if (!PATH.test(c.to)) return { error: 'La dirección debe ser una dirección del sitio que empiece con /.' };
  // Foto de fondo (opcional)
  const img = String(input.image || '');
  if (img) {
    if (!isImageRef(img)) return { error: 'La imagen de la tarjeta no es válida (JPG o PNG).' };
    if (img.length > MAX_BANNER_IMAGE) return { error: 'La imagen de la tarjeta es muy pesada. Prueba con una más liviana.' };
    c.image = img;
  }
  if (c.from && c.until && c.until < c.from) return { error: 'La fecha final debe ser posterior a la inicial.' };
  return { card: c };
}

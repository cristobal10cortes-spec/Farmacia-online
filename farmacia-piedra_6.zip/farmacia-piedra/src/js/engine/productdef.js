// Productos creados en el panel: listas de opciones y validación de la ficha.
// La usan el panel (formulario) y el servidor (que no confía en lo que llega).

import { RX } from '../config.js';
import { ALL_SUBS } from '../data/categories.js';
import { normalizeProduct } from '../data/products.js';

export const PRODUCT_FORMATS = ['comprimidos', 'comprimidos recubiertos', 'comprimidos efervescentes', 'cápsulas', 'jarabe', 'suspensión oral', 'gotas', 'solución', 'crema', 'gel', 'ungüento', 'loción', 'spray', 'sobres', 'polvo', 'shampoo', 'jabón', 'pañales', 'toallitas', 'unidad'];
export const PRODUCT_UNITS = ['comprimido', 'cápsula', 'ml', 'g', 'sobre', 'unidad', 'dosis', 'parche', 'supositorio', 'ampolla'];
export const PRODUCT_ARTS = [['', 'Automático (según formato)'], ['box', 'Caja'], ['bottle', 'Frasco'], ['dropper', 'Gotario'], ['tube', 'Pomo o tubo'], ['spray', 'Spray'], ['pump', 'Botella con dispensador'], ['jar', 'Pote'], ['tubeEff', 'Tubo de efervescentes'], ['pack', 'Paquete'], ['inhaler', 'Inhalador'], ['soap', 'Jabón en barra'], ['stick', 'Barra'], ['polish', 'Frasco pequeño']];

const SUBS = new Set(ALL_SUBS.map((s) => `${s.cat}/${s.id}`));
const ARTS = new Set(PRODUCT_ARTS.map(([k]) => k).filter(Boolean));
const txt = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const int = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v)) : NaN);
const words = (v, maxItems, maxLen) => (Array.isArray(v) ? v : String(v || '').split(/[,;\n]/))
  .map((x) => txt(x, maxLen).toLowerCase()).filter(Boolean).slice(0, maxItems);

/**
 * Ficha de un producto nuevo (formato corto: n, b, c, ai, st, f, u, un, rx,
 * be, cold, p, o, t, d, art, s). Devuelve { def } o { error }.
 * imported: viene de una planilla (el principio activo es opcional).
 */
export function cleanDef(input = {}, { imported = false } = {}) {
  const c = String(input.c || '');
  const isMed = c.startsWith('medicamentos/');
  const def = {
    n: txt(input.n, 120),
    b: txt(input.b, 60),
    c,
    f: txt(input.f, 40) || 'unidad',
    u: int(input.u),
    un: txt(input.un, 30) || 'unidad',
    p: int(input.p),
    t: words(input.t, 20, 40),
    d: txt(input.d, 600),
    s: Number.isFinite(int(input.s)) ? Math.max(0, Math.min(100000, int(input.s))) : 60,
  };
  if (!def.n) return { error: 'Escribe el nombre del producto.' };
  if (!def.b) return { error: 'Escribe la marca o el laboratorio.' };
  if (!SUBS.has(c)) return { error: 'Elige una categoría válida.' };
  if (!(def.u >= 1 && def.u <= 10000)) return { error: 'Indica cuánto contiene el envase.' };
  if (!(def.p >= 1 && def.p <= 10000000)) return { error: 'Ingresa un precio normal válido.' };
  const o = int(input.o);
  if (o > 0) {
    if (o >= def.p) return { error: 'La oferta debe ser menor que el precio normal.' };
    def.o = o;
  }
  if (input.art && ARTS.has(String(input.art))) def.art = String(input.art);
  if (isMed) {
    def.ai = words(input.ai, 6, 60);
    // Los productos que vienen de una planilla pueden no traerlo (se agrega después en su ficha)
    if (!def.ai.length && !imported) return { error: 'Indica el principio activo (para el buscador y los bioequivalentes).' };
    if (!def.ai.length) delete def.ai;
    const st = txt(input.st, 40);
    if (st) def.st = st;
    def.rx = Object.prototype.hasOwnProperty.call(RX, String(input.rx)) ? String(input.rx) : 'directa';
    if (input.be) def.be = 1;
  } else {
    def.rx = 'directa';
  }
  if (input.cold) def.cold = 1;
  try {
    normalizeProduct(def, 'VALIDACION', 'validacion');
  } catch {
    return { error: 'Los datos del producto no son válidos.' };
  }
  return { def };
}

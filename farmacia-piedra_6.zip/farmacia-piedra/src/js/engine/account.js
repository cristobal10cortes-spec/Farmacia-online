// Cuentas de cliente (demostración: se guardan solo en este navegador).
// En producción esto vive en un servidor con contraseñas cifradas allí.

import { state, emit, currentUser } from './state.js';
import { CLUB } from '../config.js';
import { validateRut, formatRut, validEmail, validPhone, cleanPhone } from './rut.js';

async function hashPassword(pass, salt) {
  const text = `${salt}:${pass}`;
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 5381;
    for (let i = 0; i < text.length; i++) h = (h * 33) ^ text.charCodeAt(i);
    return `x${(h >>> 0).toString(16)}`;
  }
}

const randomSalt = () => Math.random().toString(36).slice(2, 10);

export function passwordIssues(p) {
  const out = [];
  if (!p || p.length < 8) out.push('al menos 8 caracteres');
  if (!/[a-zA-Z]/.test(p || '')) out.push('una letra');
  if (!/\d/.test(p || '')) out.push('un número');
  return out;
}

/** Valida y crea una cuenta. Devuelve { ok } o { ok:false, errors:{campo:mensaje} } */
export async function register(d) {
  const errors = {};
  const email = String(d.email || '').trim().toLowerCase();
  if (!validateRut(d.rut)) errors.rut = 'Ingresa un RUT válido, por ejemplo 12.345.678-5.';
  if (!String(d.nombre || '').trim()) errors.nombre = 'Ingresa tu nombre.';
  if (!String(d.apellidoP || '').trim()) errors.apellidoP = 'Ingresa tu apellido paterno.';
  if (!validEmail(email)) errors.email = 'Ingresa un correo válido.';
  else if (state.users[email]) errors.email = 'Ya existe una cuenta con este correo. Inicia sesión.';
  if (!validPhone(d.phone)) errors.phone = 'Ingresa un celular de 9 dígitos que comience con 9.';
  const issues = passwordIssues(d.password);
  if (issues.length) errors.password = `La contraseña necesita ${issues.join(', ')}.`;
  if (d.password !== d.password2) errors.password2 = 'Las contraseñas no coinciden.';
  if (!d.terms) errors.terms = 'Debes aceptar los términos y condiciones.';
  if (Object.keys(errors).length) return { ok: false, errors };
  const salt = randomSalt();
  state.users[email] = {
    email,
    rut: formatRut(d.rut),
    nombre: String(d.nombre).trim(),
    apellidoP: String(d.apellidoP).trim(),
    apellidoM: String(d.apellidoM || '').trim(),
    phone: cleanPhone(d.phone),
    birth: d.birth || '',
    prevision: d.prevision || '',
    club: !!d.club,
    marketing: !!d.marketing,
    salt,
    hash: await hashPassword(d.password, salt),
    createdAt: Date.now(),
    addresses: [],
    treatment: [],
    prescriptions: [],
  };
  state.session = email;
  emit('user');
  return { ok: true };
}

export async function login(email, password) {
  const e = String(email || '').trim().toLowerCase();
  const u = state.users[e];
  if (!u) return { ok: false, error: 'No encontramos una cuenta con ese correo.' };
  if ((await hashPassword(password, u.salt)) !== u.hash) return { ok: false, error: 'La contraseña no es correcta.' };
  state.session = e;
  emit('user');
  return { ok: true };
}

export function logout() {
  state.session = null;
  emit('user');
}

export function updateUser(patch) {
  const u = currentUser();
  if (!u) return false;
  Object.assign(u, patch);
  emit('user');
  return true;
}

export function joinClub() {
  return updateUser({ club: true });
}

// Programa Mi Tratamiento: hasta CLUB.treatmentMax productos inscritos
export function toggleTreatment(productId) {
  const u = currentUser();
  if (!u) return { ok: false, error: 'Inicia sesión para inscribir productos.' };
  const i = u.treatment.indexOf(productId);
  if (i >= 0) {
    u.treatment.splice(i, 1);
  } else {
    if (u.treatment.length >= CLUB.treatmentMax) return { ok: false, error: `Puedes inscribir hasta ${CLUB.treatmentMax} productos.` };
    u.treatment.push(productId);
  }
  emit('user');
  return { ok: true, enrolled: i < 0 };
}

export const treatmentSet = () => new Set(currentUser()?.treatment || []);

export function addAddress(a) {
  const u = currentUser();
  if (!u) return false;
  u.addresses.push({ id: `D${Date.now()}`, ...a });
  emit('user');
  return true;
}

export function removeAddress(id) {
  const u = currentUser();
  if (!u) return false;
  u.addresses = u.addresses.filter((a) => a.id !== id);
  emit('user');
  return true;
}

export function savePrescription(meta) {
  const u = currentUser();
  if (!u) return;
  u.prescriptions.unshift({ id: `R${Date.now()}${Math.floor(Math.random() * 99)}`, date: Date.now(), ...meta });
  u.prescriptions = u.prescriptions.slice(0, 20);
  emit('user');
}

export function removePrescription(id) {
  const u = currentUser();
  if (!u) return;
  u.prescriptions = u.prescriptions.filter((r) => r.id !== id);
  emit('user');
}

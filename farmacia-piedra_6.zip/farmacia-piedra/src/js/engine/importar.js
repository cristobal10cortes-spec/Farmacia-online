// Productos nuevos desde una planilla (por ejemplo, la que exporta eleventa):
// con el nombre, el departamento y el precio arma la ficha del producto
// (categoría, principio activo, contenido, marca y si necesita receta).
//
// Es una propuesta: en el panel se revisa por departamento antes de cargar, y
// después cada producto se puede corregir en su ficha.

import { fold } from './text.js';
import { ALL_SUBS } from '../data/categories.js';

// ── Principios activos → subcategoría ────────────────────────
// (nombre para mostrar; el buscador los encuentra con o sin tildes)
const ING = {
  'medicamentos/dolor-y-fiebre': 'paracetamol, ibuprofeno, naproxeno, ácido acetilsalicílico, ketoprofeno, dexketoprofeno, ketorolaco, metamizol, diclofenaco, meloxicam, piroxicam, celecoxib, etoricoxib, nimesulida, tramadol, codeína, clonixinato de lisina, ergotamina, sumatriptán, naratriptán, zolmitriptán, orfenadrina, ciclobenzaprina, tiocolchicósido, capsaicina, cafeína, butilbromuro de hioscina, hioscina, pargeverina, propifenazona',
  'medicamentos/resfrio-y-tos': 'fenilefrina, clorfenamina, pseudoefedrina, ambroxol, bromhexina, dextrometorfano, acetilcisteína, carbocisteína, levodropropizina, oxolamina, guaifenesina, noscapina, cloperastina, clofedianol, hedera helix, oximetazolina, xilometazolina, cetilpiridinio, benzocaína, alcanfor, mentol, eucalipto, clorhexidina',
  'medicamentos/alergias-y-respiratorio': 'loratadina, desloratadina, cetirizina, levocetirizina, fexofenadina, bilastina, rupatadina, ebastina, hidroxicina, dexclorfenamina, montelukast, salbutamol, budesonida, fluticasona, beclometasona, formoterol, salmeterol, tiotropio, ipratropio, ciclesonida, azelastina',
  'medicamentos/sistema-digestivo': 'omeprazol, esomeprazol, lansoprazol, pantoprazol, rabeprazol, famotidina, ranitidina, domperidona, metoclopramida, ondansetrón, loperamida, racecadotrilo, acotiamida, sulfasalazina, atropina, papaverina, simeticona, magaldrato, hidróxido de aluminio, hidróxido de magnesio, alginato de sodio, bicarbonato de sodio, lactulosa, macrogol, polietilenglicol, bisacodilo, senósidos, picosulfato de sodio, psyllium, trimebutina, mebeverina, pinaverio, saccharomyces boulardii, lactobacillus, bifidobacterium, subsalicilato de bismuto, dimenhidrinato, sucralfato, ácido ursodesoxicólico, ácido ursodeoxicólico, pancreatina, lactobacillus reuteri, clidinio, clordiazepóxido, sales de rehidratación',
  'medicamentos/cardiovascular': 'losartán, valsartán, telmisartán, olmesartán, candesartán, irbesartán, enalapril, captopril, lisinopril, ramipril, amlodipino, nifedipino, verapamilo, diltiazem, atenolol, bisoprolol, carvedilol, nebivolol, propranolol, metoprolol, hidroclorotiazida, furosemida, espironolactona, clortalidona, indapamida, atorvastatina, rosuvastatina, simvastatina, pravastatina, ezetimiba, fenofibrato, gemfibrozilo, clopidogrel, warfarina, acenocumarol, rivaroxabán, apixabán, dabigatrán, digoxina, amiodarona, isosorbide, trimetazidina, cilostazol, pentoxifilina, ivabradina, sacubitrilo, ácido fenofíbrico, ticagrelor, prasugrel, doxazosina, diosmina, hesperidina',
  'medicamentos/diabetes-y-endocrino': 'metformina, glibenclamida, glimepirida, gliclazida, sitagliptina, vildagliptina, linagliptina, saxagliptina, alogliptina, dapagliflozina, empagliflozina, canagliflozina, pioglitazona, insulina, levotiroxina, metimazol, propiltiouracilo',
  'medicamentos/antibioticos-e-infecciones': 'amoxicilina, ácido clavulánico, ampicilina, cloxacilina, flucloxacilina, bencilpenicilina, penicilina, cefadroxilo, cefalexina, cefuroxima, cefixima, ceftriaxona, azitromicina, claritromicina, eritromicina, ciprofloxacino, levofloxacino, moxifloxacino, norfloxacino, nitrofurantoína, fosfomicina, cotrimoxazol, sulfametoxazol, trimetoprima, doxiciclina, minociclina, tetraciclina, clindamicina, metronidazol, tinidazol, secnidazol, gentamicina, fluconazol, itraconazol, clotrimazol, miconazol, nistatina, valaciclovir, oseltamivir, albendazol, mebendazol, nitazoxanida, ivermectina',
  'medicamentos/salud-mental-y-sueno': 'sertralina, escitalopram, citalopram, fluoxetina, paroxetina, venlafaxina, desvenlafaxina, duloxetina, bupropión, mirtazapina, trazodona, amitriptilina, quetiapina, risperidona, olanzapina, aripiprazol, haloperidol, brexpiprazol, sulpirida, clonazepam, alprazolam, lorazepam, diazepam, bromazepam, clotiazepam, zolpidem, zopiclona, eszopiclona, litio, lamotrigina, ácido valproico, carbamazepina, oxcarbazepina, levetiracetam, topiramato, fenitoína, primidona, pregabalina, gabapentina, donepezilo, memantina, metilfenidato, atomoxetina, doxilamina, piracetam, disulfiramo',
  'medicamentos/dermatologia': 'ketoconazol, betametasona, hidrocortisona, mometasona, clobetasol, triamcinolona, desonida, mupirocina, ácido fusídico, aciclovir, terbinafina, ciclopirox, permetrina, dimeticona, adapaleno, peróxido de benzoilo, tretinoína, isotretinoína, ácido azelaico, hidroquinona, tacrolimus, pimecrolimus, ácido salicílico, calcipotriol, minoxidil',
  'medicamentos/ojos-y-oidos': 'hialuronato de sodio, carboximetilcelulosa, hipromelosa, tobramicina, timolol, nafazolina, feniramina, latanoprost, travoprost, bimatoprost, dorzolamida, brimonidina, olopatadina, ketotifeno, peróxido de carbamida',
  'medicamentos/huesos-y-articulaciones': 'glucosamina, condroitina, alendronato, ácido alendrónico, risedronato, leflunomida, metotrexato, ibandronato, alopurinol, colchicina, diacereína, calcifediol',
  'medicamentos/anticonceptivos': 'levonorgestrel, etinilestradiol, drospirenona, desogestrel, gestodeno, dienogest, ciproterona, clormadinona, norgestimato, estradiol, progesterona, didrogesterona, medroxiprogesterona, noretisterona, tibolona, clomifeno, cabergolina',
  'medicamentos/bienestar-sexual': 'sildenafil, tadalafilo, tadalafil, vardenafil',
  'medicamentos/otros-medicamentos': 'tamsulosina, solifenacina, tolterodina, oxibutinina, flavoxato, finasterida, dutasterida, mirabegrón, tamoxifeno, bicalutamida, anastrozol, letrozol, prednisona, prednisolona, metilprednisolona, dexametasona, deflazacort, azatioprina, difenidol, hierro sacarosa',
  'vitaminas-y-suplementos/vitaminas-y-minerales': 'vitamina c, vitamina d3, vitamina d, colecalciferol, vitamina e, vitamina b12, cianocobalamina, complejo b, ácido fólico, hierro, sulfato ferroso, fumarato ferroso, zinc, calcio, carbonato de calcio, citrato de calcio, multivitamínico, biotina, luteína, inositol',
  'vitaminas-y-suplementos/magnesio-y-colageno': 'magnesio, colágeno, omega 3, ácido hialurónico',
  'vitaminas-y-suplementos/sueno-y-energia': 'melatonina, valeriana, pasiflora, melisa, ginseng, l-acetilcarnitina',
  'vitaminas-y-suplementos/naturales': 'ginkgo biloba, cardo mariano, aloe vera, aloe, linaza, castaño de india, cúrcuma, ajo, propóleo, equinácea, moringa, maca, spirulina, fenogreco',
};
// Abreviaturas y errores comunes en los nombres
const ALIAS = {
  'acido acetilsalicilico': ['aas', 'ass', 'aspirina'], paracetamol: ['paracet', 'paracetam'], clorfenamina: ['clorfenam', 'clorefenamina', 'clorfeniramina'],
  pseudoefedrina: ['pseudoef', 'pseudoefedr'], 'acido clavulanico': ['ac clavulanico'], tadalafilo: [], 'vitamina d3': ['vit d3'], 'vitamina c': ['vit c', 'cebion'],
  'vitamina e': ['vit e'], 'vitamina b12': ['vit b12'], 'complejo b': ['vit b1', 'b1 b6 b12'], 'hedera helix': ['hiedra'], 'omega 3': ['omega'],
  'saccharomyces boulardii': ['saccharomyces boulardi', 'saccharomyces'], 'butilbromuro de hioscina': ['hisocina', 'buscapina'], colecalciferol: [],
  'acido folico': ['ac folico'], levocetirizina: ['levocetizina'], 'lactobacillus reuteri': ['l reuteri', 'l reueri', 'reuteri'], 'acido hialuronico': ['ac hialuronico'], 'clonixinato de lisina': ['clonixinato'], ondansetron: [], magnesio: ['mag tab', 'lactato de magnesio'],
};

const TABLE = (() => {
  const list = [];
  for (const [sub, names] of Object.entries(ING)) {
    for (const display of names.split(',').map((s) => s.trim()).filter(Boolean)) {
      const key = fold(display);
      list.push({ key, display, sub });
      for (const a of ALIAS[key] || []) list.push({ key: a, display, sub });
    }
  }
  return list.sort((a, b) => b.key.length - a.key.length); // primero las de varias palabras
})();
const ING_WORDS = new Set(TABLE.flatMap((t) => t.key.split(' ')));

/** Nombre "doblado" con abreviaturas comunes expandidas: "Ac. Clavulanico" → "acido clavulanico". */
function plain(name) {
  return ` ${fold(String(name).replace(/\b[Aa]c\.\s*/g, 'acido ').replace(/\b[Vv]it\.\s*/g, 'vitamina ').replace(/[+/,()]/g, ' '))} `;
}

/** Principios activos que aparecen en el nombre (hasta 3, en orden). */
export function findIngredients(name) {
  let s = plain(name);
  const hits = [];
  for (const t of TABLE) {
    const at = s.indexOf(` ${t.key} `);
    if (at < 0) continue;
    if (!hits.some((h) => h.display === t.display)) hits.push({ ...t, at });
    s = `${s.slice(0, at)} ${' '.repeat(t.key.length)} ${s.slice(at + t.key.length + 2)}`;
  }
  return hits.sort((a, b) => a.at - b.at).slice(0, 3);
}

// ── Palabras clave → subcategoría (productos sin principio activo) ──
// [expresión, 'categoría/sub', venta directa aunque sea de Medicamentos]
const RULES = [
  [/\b(preservativos?|condon(es)?|lubricante)\b/, 'medicamentos/bienestar-sexual', true, null, true],
  [/\b(test de embarazo|termometro|tensiometro|glucometro|tiras reactivas|lancetas|oximetro|nebulizador|saturometro)\b/, 'medicamentos/monitores-y-diagnostico', true, null, true],
  [/\b(lentes de contacto|sol ?mult|multiproposito|renu|opti ?free|lagrimas? artificial\w*|limpiador de oidos)\b/, 'medicamentos/ojos-y-oidos', true, null, true],
  [/\b(sol ?ofta?|oftalmic\w*|colirio|gotas oculares|otico|oidos)\b/, 'medicamentos/ojos-y-oidos', false, 'med', true],
  [/\b(aerocamara|espaciador)\b/, 'medicamentos/alergias-y-respiratorio', true, null, true],
  [/\b(protector solar|bloqueador|fotoprotector|spf|fps|solar|heliocare|anthelios|after sun)\b/, 'dermocosmetica/proteccion-solar'],
  [/\b(panal(es)? adulto|pants adulto|incontinencia|apositos? (de )?incontinencia|ropa interior|plenitud|tena|protector de cama|sabanillas?)\b/, 'cuidado-personal/adulto-mayor'],
  [/\b(panal(es)?|toallitas humedas)\b/, 'infantil-y-mama/panales-y-toallitas'],
  [/\b(absorbente(s)? (de )?leche|protector(es)? mamario|mamadera|chupete|lactancia|extractor de leche|tetina|portaleche)\b/, 'infantil-y-mama/alimentacion-y-lactancia'],
  [/\b(crema dental|cre dent|pasta dental|dentifrico|cepillo|enjuague|colutorio|hilo dental|seda dental|blanqueador dental|tabletas reveladoras|cuidado bucal|bucal|encias|protesis dental|corega|fijador dental|listerine|colgate|pepsodent|sensodyne|oral b|elmex|kolynos|aquafresh|parodontax|vitis|curaprox|phb|fluor\w*|interprox|interdental)\b/, 'cuidado-personal/cuidado-bucal'],
  [/\b(shampoo|shamp|champu|acondicionador|tintura|tinte|coloracion|capilar|cabello|pelo|caspa|piojos|liendres|mascarilla capilar|casting|igora|koleston|fijador|gomina|laca|ondulado|rizos)\b/, 'cuidado-personal/cuidado-capilar'],
  [/\b(afeitar|afeitado|prestobarba|gillette|depilacion|depilatori\w*|cera|veet|rasuradora|after shave|gillete|mach ?3|repuestos?)\b/, 'cuidado-personal/afeitado'],
  [/\b(desodorante|desod|antitranspirante|jabon|gel de ducha|gel de bano|body wash|jabon liquido|talco)\b/, 'cuidado-personal/desodorantes-y-jabones'],
  [/\b(toallas? higienicas?|tampon(es)?|protector(es)? diarios?|copa menstrual|higiene intima|intimo|intima)\b/, 'cuidado-personal/higiene-femenina'],
  [/\b(esmalte|quitaesmalte|unas|lima de unas|acetona|labial|balsamo labial|lip|lapiz labial|cuticulas?|alicate|labios)\b/, 'belleza/unas-y-labios'],
  [/\b(maquillaje|mascara de pestanas|rimel|base liquida|corrector|polvo compacto|delineador|sombra|rubor)\b/, 'belleza/maquillaje'],
  [/\b(desmaquill\w*|micelar|bifasico)\b/, 'dermocosmetica/limpieza-facial'],
  [/\b(acne|acniben|effaclar|sebium|piel grasa|matificante|espinillas|imperfecciones|blemish|puntos negros)\b/, 'dermocosmetica/piel-grasa-y-acne'],
  [/\b(limpiador\w*|espuma limpiadora|exfoliante|limpieza|tonico)\b/, 'dermocosmetica/limpieza-facial', false, 'personal'],
  [/\b(serum|antiedad|anti edad|arrugas|retinol|contorno de ojos|antiarrugas|reafirmante|hydro boost)\b/, 'dermocosmetica/antiedad'],
  [/\b(bebe|baby|guagua|infantil|kids|ninos|nino|pediatric\w*)\b/, 'infantil-y-mama/cuidado-del-bebe', false, 'personal'],
  [/\b(colonia|perfume|eau de|edt|edp|fragancia|body splash|body mist)\b/, 'dermocosmetica/cuidado-corporal', false, 'personal'],
  [/\b(crema de manos|crema manos|corporal|body|locion|rosa mosqueta|urea|aceite|crema humectante|crema hidratante|manteca|exfoliante corporal|estrias|vaseline|vaselina)\b/, 'dermocosmetica/cuidado-corporal', false, 'personal'],
  [/\b(hidratante|humectante|crema|creme|emulsion|fluido|nutratopic|piel seca|atopic|agua termal|nivea)\b/, 'dermocosmetica/hidratacion', false, 'personal'],
  [/\b(gasa|venda|curitas|parches? curita|aposito|algodon|alcohol|agua oxigenada|povidona|tela adhesiva|micropore|cinta adhesiva|jeringa|guantes|mascarilla|suero fisiologico|cavilon|coban|termo gel|bolsa de agua|cabestrillo|inmovilizador|rodillera|tobillera|faja|frasco|gotero|vaso|recolector)\b/, 'medicamentos/primeros-auxilios', true],
  [/\b(proteina|whey|creatina|bcaa|pre entreno|barra proteica|protein)\b/, 'vitaminas-y-suplementos/nutricion-deportiva'],
  [/\b(ensure|pediasure|glucerna|enterex|suplemento nutricional|nutricion|nutrashure|vitasure|fortini|nessucar|leche|formula|veggi milk|sustituto)\b/, 'vitaminas-y-suplementos/nutricion-clinica'],
  [/\b(suerox|electrolitos|isotonica|bebida)\b/, 'vitaminas-y-suplementos/nutricion-clinica'],
  [/\b(magnesio|colageno|omega)\b/, 'vitaminas-y-suplementos/magnesio-y-colageno'],
  [/\b(melatonina|valeriana|pasiflora|passiflora|melissa|dormir|sueno|estres|ginseng|energia|terapia floral|rescate|floral)\b/, 'vitaminas-y-suplementos/sueno-y-energia'],
  [/\b(vitamina|vitaminas|multivitaminico|zinc|hierro|calcio|acido folico|biotina|b12|probiotico|postbiotic|prebiotico)\b/, 'vitaminas-y-suplementos/vitaminas-y-minerales'],
  [/\b(pulgas|garrapatas|antiparasitario|veterinari|mascota|perro|gato)\b/, 'mascotas/antiparasitarios'],
  [/\b(jarabe|jbe|antitusivo|tos|expectorante|mucolitico|antigripal|resfrio|descongestionante|garganta|pastillas para la garganta|pastillas|gripe|vaporub|vick|agua de mar|nasal)\b/, 'medicamentos/resfrio-y-tos', false, 'med'],
  [/\b(antiacido|acidez|sal de fruta|laxante|diarrea|colon|enzimas|digestivo|hemorroides|hemorroidal|probiotico|biogaia)\b/, 'medicamentos/sistema-digestivo', false, 'med'],
  [/\b(ungüento|unguento|pomada|crema topica|gel topico|locion capilar|pasta lassar)\b/, 'medicamentos/dermatologia', false, 'med'],
];

// ── Departamentos (columna "Departamento" de eleventa) ───────
// family: dónde buscar si el nombre no dice nada · rx: directa | simple | hide
const LABS = {
  saval: 'Saval', eurofarma: 'Eurofarma', 'l chile teva': 'Laboratorio Chile', 'lab chile': 'Laboratorio Chile', megalabs: 'Megalabs', prater: 'Prater',
  'itf labomed': 'ITF Labomed', bago: 'Bagó', maver: 'Maver', abbott: 'Abbott', andromaco: 'Andrómaco', knop: 'Knop', merck: 'Merck', pasteur: 'Pasteur',
  cassara: 'Cassará', farmoquimica: 'Farmoquímica', tecnofarma: 'Tecnofarma', bayer: 'Bayer', 'faes farma': 'Faes Farma', sanitas: 'Sanitas', mintlab: 'Mintlab',
  heel: 'Heel', synthon: 'Synthon', 'royal pharma': 'Royal Pharma', 'garden house': 'Garden House', 'ximena polanco': 'Ximena Polanco',
  'chemo pharma': 'Chemopharma', sanofi: 'Sanofi', recalcine: 'Recalcine', gador: 'Gador', opko: 'Opko', 'dr reddys': "Dr. Reddy's", gsk: 'GSK', pfizer: 'Pfizer',
  novartis: 'Novartis', roche: 'Roche', 'laboratorio chile': 'Laboratorio Chile', 'hospifarma': 'Hospifarma',
};
const NATURAL_LABS = new Set(['knop', 'heel', 'garden house', 'ximena polanco']);
const DEPTS = [
  [/^perfumeria|^cosmetic|^belleza|^cuidado personal|^higiene|^aseo/, { family: 'personal', rx: 'directa' }],
  [/^dermato|^dermo/, { family: 'dermo', rx: 'directa' }],
  [/^naturales?|^natural|^homeopat|^fitoterap|^hierbas/, { family: 'natural', rx: 'directa' }],
  [/^insumos?|^curacion|^ortopedia/, { family: 'insumos', rx: 'directa' }],
  [/^suplementos?|^nutricion|^alimentos/, { family: 'nutri', rx: 'directa', sub: 'vitaminas-y-suplementos/nutricion-clinica' }],
  [/^proteinas?|^deport/, { family: 'nutri', rx: 'directa', sub: 'vitaminas-y-suplementos/nutricion-deportiva' }],
  [/^vitaminas?/, { family: 'natural', rx: 'directa', sub: 'vitaminas-y-suplementos/vitaminas-y-minerales' }],
  [/^oficinal/, { family: 'insumos', rx: 'directa' }],
  [/^bebidas?|^jugos?/, { family: 'nutri', rx: 'directa', sub: 'vitaminas-y-suplementos/nutricion-clinica' }],
  [/^hogar|^limpieza|^bazar|^regalo/, { family: 'personal', rx: 'hide' }],
  [/^helado|^confite|^golosina|^snack|^comida/, { family: 'nutri', rx: 'hide', sub: 'vitaminas-y-suplementos/nutricion-clinica' }],
  [/^controlad|^psicotrop|^estupefac/, { family: 'med', rx: 'hide', rxIfShown: 'retenida' }],
  [/^recetario|^magistral|^inyectable|^cenabast|^hospital/, { family: 'med', rx: 'hide' }],
  [/^bioequivalente/, { family: 'med', rx: 'simple', be: true }],
  [/^antibiotico|^antimicrobian/, { family: 'med', rx: 'simple', sub: 'medicamentos/antibioticos-e-infecciones' }],
  [/^anticon|^hormona/, { family: 'med', rx: 'simple', sub: 'medicamentos/anticonceptivos' }],
  [/^hipoglicem|^diabet/, { family: 'med', rx: 'simple', sub: 'medicamentos/diabetes-y-endocrino' }],
  [/^salud sexual|^sexual/, { family: 'med', rx: 'simple', sub: 'medicamentos/bienestar-sexual' }],
  [/^bebe|^infantil|^maternidad|^mama/, { family: 'personal', rx: 'directa', sub: 'infantil-y-mama/cuidado-del-bebe' }],
  [/^mascota|^veterinar/, { family: 'personal', rx: 'directa', sub: 'mascotas/higiene-mascotas' }],
];
const FALLBACK = {
  med: 'medicamentos/otros-medicamentos',
  personal: 'cuidado-personal/desodorantes-y-jabones',
  dermo: 'dermocosmetica/hidratacion',
  natural: 'vitaminas-y-suplementos/naturales',
  nutri: 'vitaminas-y-suplementos/nutricion-clinica',
  insumos: 'medicamentos/primeros-auxilios',
};
const SUB_NAMES = new Map(ALL_SUBS.map((s) => [fold(s.name), `${s.cat}/${s.id}`]));
const SUB_IDS = new Set(ALL_SUBS.map((s) => `${s.cat}/${s.id}`));

/** Lo que se propone para un departamento: { family, rx, sub?, be?, lab?, rxIfShown? }. */
export function deptDefaults(dept) {
  const d = fold(dept).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!d) return { family: 'any', rx: 'simple' };
  // Una subcategoría de la tienda con ese nombre (la planilla que descarga el panel)
  const own = SUB_NAMES.get(d);
  if (own) return { family: own.startsWith('medicamentos/') ? 'med' : 'personal', rx: own.startsWith('medicamentos/') ? 'simple' : 'directa', sub: own };
  for (const [re, v] of DEPTS) if (re.test(d)) return { ...v };
  const labKey = Object.keys(LABS).find((k) => d === k || d.replace(/ /g, '') === k.replace(/ /g, ''));
  if (labKey) return NATURAL_LABS.has(labKey) ? { family: 'natural', rx: 'directa', lab: LABS[labKey] } : { family: 'med', rx: 'simple', lab: LABS[labKey] };
  // Departamentos como "Marca", "Farmacia", "Genéricos" o el nombre de un laboratorio desconocido
  return { family: 'med', rx: 'simple' };
}

// ── Contenido, formato y concentración ───────────────────────
const NUM = '(\\d{1,5}(?:[.,]\\d{1,2})?)';
const lastMatch = (re, s) => { let m; let out = null; const g = new RegExp(re.source, 'g'); while ((m = g.exec(s))) if (s[m.index - 1] !== '/') out = m; return out; };
const toInt = (v) => Math.max(1, Math.min(10000, Math.round(Number(String(v).replace(',', '.')) || 1)));

export function parseContent(name) {
  const s = ` ${fold(name).replace(/(\d)\s*x\s*(\d)/g, '$1 x $2').replace(/\bcon (mast|rec|disp)\b/g, 'com $1')} `;
  const pick = (f, un, re, reAfter) => {
    const m = s.match(re) || (reAfter ? s.match(reAfter) : null);
    return m ? { u: toInt(m[1]), un, f } : null;
  };
  const tab = /\b(comprimidos?|comp|comps|com|tab|tabs|tabletas?|grageas?|minitabs|laminas)\b/;
  if (tab.test(s)) {
    const f = /eferv/.test(s) ? 'comprimidos efervescentes' : /\brec\b|recubierto/.test(s) ? 'comprimidos recubiertos' : 'comprimidos';
    const r = pick(f, 'comprimido', /(\d{1,4})\s*(?:comprimidos?|comp|comps|com|tab|tabs|tabletas?|grageas?|minitabs|laminas)\b/, /(?:comprimidos?|comp|com|tab|tabletas?)(?:\s*(?:rec|mast|lib|pro|sl|blan|recubiertos?|masticables?|sublinguales?))*\s*(?:x\s*)?(\d{1,4})\b/)
      || pick(f, 'comprimido', /\bx\s*(\d{1,4})\b/);
    if (r) return r;
  }
  if (/\b(capsulas?|caps?|cap|perlas)\b/.test(s)) {
    const r = pick('cápsulas', 'cápsula', /(\d{1,4})\s*(?:capsulas?|caps?|perlas)\b/, /(?:capsulas?|caps?)(?:\s*(?:blan|blandas|lp))*\s*(?:x\s*)?(\d{1,4})\b/) || pick('cápsulas', 'cápsula', /\bx\s*(\d{1,4})\b/);
    if (r) return r;
  }
  if (/\b(sobres?|sachets?)\b/.test(s)) {
    const r = pick('sobres', 'sobre', /(\d{1,4})\s*(?:sobres?|sachets?)\b/, /\bsobres?\s*(?:x\s*)?(\d{1,4})\b/) || pick('sobres', 'sobre', /\bx\s*(\d{1,4})\b/);
    if (r) return r;
  }
  if (/\b(ampollas?|amp)\b/.test(s)) return pick('solución', 'ampolla', /(\d{1,3})\s*(?:ampollas?|amp)\b/, /\bx\s*(\d{1,3})\b/) || { u: 1, un: 'ampolla', f: 'solución' };
  if (/\bsupositorios?\b/.test(s)) return pick('unidad', 'supositorio', /(\d{1,3})\s*supositorios?\b/, /supositorios?\s*(?:x\s*)?(\d{1,3})\b/) || { u: 1, un: 'supositorio', f: 'unidad' };
  if (/\bparches?\b/.test(s) && !/curita/.test(s)) return pick('unidad', 'parche', /(\d{1,3})\s*parches?\b/, /\bx\s*(\d{1,3})\b/) || { u: 1, un: 'parche', f: 'unidad' };
  if (/\bdosis\b/.test(s)) return pick('spray', 'dosis', /(\d{1,4})\s*dosis\b/) || { u: 1, un: 'dosis', f: 'spray' };
  const liquidF = /\bcrema\b/.test(s) ? 'crema' : /\b(acondicionador|balsamo)\b/.test(s) ? 'shampoo' : /\b(jarabe|jbe)\b/.test(s) ? 'jarabe' : /\bsusp/.test(s) ? 'suspensión oral' : /\bgotas\b|sol ?oft|colirio/.test(s) ? 'gotas'
    : /\bspray\b/.test(s) ? 'spray' : /\bshampoo|shamp|champu/.test(s) ? 'shampoo' : /\blocion\b/.test(s) ? 'loción' : /\bgel\b/.test(s) ? 'gel'
      : /\bjabon\b/.test(s) ? 'jabón' : 'solución';
  const ml = lastMatch(new RegExp(`${NUM}\\s*(?:ml|cc|mililitros)\\b`), s) || lastMatch(new RegExp(`${NUM}\\s*(?:lt|litros?)\\b`), s);
  if (ml) return { u: /lt|litro/.test(ml[0]) ? toInt(Number(ml[1].replace(',', '.')) * 1000) : toInt(ml[1]), un: 'ml', f: liquidF };
  const g = lastMatch(new RegExp(`${NUM}\\s*(?:g|gr|grs|gramos|grms|grmaos)\\b`), s) || lastMatch(new RegExp(`${NUM}\\s*(?:kg|kilos?)\\b`), s);
  if (g) {
    const f = /\bcrema\b/.test(s) ? 'crema' : /\b(unguento|pomada|pasta)\b/.test(s) ? 'ungüento' : /\bgel\b/.test(s) ? 'gel' : /\b(polvo|tarro|proteina|leche)\b/.test(s) ? 'polvo' : /\bjabon\b/.test(s) ? 'jabón' : 'unidad';
    return { u: /kg|kilo/.test(g[0]) ? toInt(Number(g[1].replace(',', '.')) * 1000) : toInt(g[1]), un: 'g', f };
  }
  const f = /\bpanal/.test(s) ? 'pañales' : /\btoallitas\b/.test(s) ? 'toallitas' : 'unidad';
  return pick(f, 'unidad', /(\d{1,4})\s*(?:unidades|unidad|unid|uds?|u)\b/, /\b(?:x|caja con|pack|set de)\s*(\d{1,4})\b/) || { u: 1, un: 'unidad', f };
}

/** Concentración: "500 mg", "80/10 mg", "0.05 %". */
export function parseStrength(name) {
  const m = String(name).match(/(\d+(?:[.,]\d+)?(?:\s*\/\s*\d+(?:[.,]\d+)?)*)\s*(mg|mcg|µg|ui|%)(?![a-z])/i);
  return m ? `${m[1].replace(/\s+/g, '')} ${m[2].toLowerCase()}`.slice(0, 40) : '';
}

// ── Nombre y marca ───────────────────────────────────────────
const SMALL = new Set(['de', 'del', 'la', 'el', 'y', 'con', 'sin', 'para', 'en', 'x', 'a', 'al', 'por', 'e']);
const UNITS_LC = new Set(['cc', 'ml', 'mg', 'mcg', 'gr', 'grs', 'g', 'kg', 'lt', 'ui', 'cm', 'mm', 'mt', 'un', 'und', 'unid', 'comp', 'caps', 'cap', 'x']);
const KEEP_UP = new Set(['SPF', 'FPS', 'UV', 'UVA', 'UVB', 'BE', 'ISP', 'AM', 'PM', 'CD', 'XR', 'SR', 'LP', 'HCL', 'DHA', 'EPA', 'AAS', 'GSK', 'ITF', 'FQP', 'PHB', 'B12', 'D3', 'K2', 'II', 'III', 'IV', 'MSD', 'NF']);
/** "ALCOHOL 95° 1000 CC ELITE" → "Alcohol 95° 1000 cc Elite" (solo si todo viene en mayúsculas). */
export function prettyName(name) {
  const s = String(name || '').replace(/\s+/g, ' ').trim();
  const letters = s.replace(/[^A-Za-zÁÉÍÓÚÑÜáéíóúñü]/g, '');
  const upper = s.replace(/[^A-ZÁÉÍÓÚÑÜ]/g, '');
  if (letters.length < 4 || upper.length / letters.length < 0.85) return s;
  return s.split(' ').map((w, i) => {
    if (KEEP_UP.has(w)) return w;
    if (/\d/.test(w)) return w.toLowerCase();
    const lw = w.toLowerCase();
    if (UNITS_LC.has(lw)) return lw;
    if (i > 0 && SMALL.has(lw)) return lw;
    return lw.replace(/(^|[-/(.])([a-záéíóúñü])/g, (m, a, b) => a + b.toUpperCase());
  }).join(' ');
}

const STOP = new Set(['ml', 'cc', 'gr', 'grs', 'g', 'mg', 'mcg', 'ui', 'comp', 'com', 'comprimidos', 'comprimido', 'capsulas', 'cap', 'caps', 'unidades', 'unidad', 'unid', 'sobres',
  'sobre', 'crema', 'gel', 'jarabe', 'jbe', 'suspension', 'susp', 'oral', 'adulto', 'adultos', 'infantil', 'pediatrico', 'pediatrica', 'ninos', 'kids', 'sabor', 'frutilla',
  'chocolate', 'vainilla', 'menta', 'regular', 'original', 'plus', 'forte', 'max', 'duo', 'classic', 'blanco', 'negro', 'rojo', 'azul', 'verde', 'rosado', 'lavanda',
  'manzana', 'naranja', 'limon', 'pina', 'kiwi', 'pomelo', 'arandano', 'frambuesa', 'chirimoya', 'durazno', 'coco', 'miel', 'neutro', 'fresh', 'sensitive', 'extra',
  'gramos', 'litro', 'litros', 'lt', 'kg', 'rec', 'mast', 'blan', 'pro', 'lib', 'x', 'y', 'de', 'con', 'sin', 'para', 'tab', 'tabletas', 'ampolla', 'ampollas', 'dosis',
  'spray', 'gotas', 'locion', 'solucion', 'sol', 'unguento', 'polvo', 'tarro', 'bolsa', 'caja', 'pack', 'set', 'kit', 'cm', 'mm', 'mt', 'talla', 'unisex', 'hombre',
  'mujer', 'piel', 'grasa', 'seca', 'mixta', 'normal', 'cenabast', 'topica', 'topico', 'oft', 'oftalmica', 'nasal', 'vaginal', 'rectal', 'cremoso', 'liquido', 'dispersables',
  'bucodispersables', 'masticables', 'efervescentes', 'recubiertos', 'blandas', 'sublinguales', 'lp', 'sr', 'xr', 'cd', 'am', 'pm', 'universal', 'ultra', 'mini', 'grande',
  'mediano', 'pequeno', 'xl', 'l', 'm', 's', 'n', 'nº', 'no', 'num', 'size', 'u']);
const GENERIC_FIRST = new Set(['crema', 'shampoo', 'shamp', 'acondicionador', 'jabon', 'desodorante', 'helado', 'algodon', 'gasa', 'alcohol', 'pasta', 'protector', 'toallas',
  'toalla', 'toallitas', 'gel', 'locion', 'aceite', 'colonia', 'perfume', 'cepillo', 'enjuague', 'hilo', 'seda', 'panal', 'panales', 'termometro', 'aerocamara', 'aposito',
  'venda', 'parche', 'parches', 'tela', 'jeringa', 'guantes', 'mascarilla', 'suero', 'agua', 'balsamo', 'labial', 'esmalte', 'quitaesmalte', 'tintura', 'tinte', 'set', 'kit',
  'pack', 'absorbente', 'vaselina', 'desod', 'quita', 'medias', 'collar', 'bicarbonato', 'pomada', 'anilina', 'frasco', 'gotero', 'vaso', 'bolsa', 'cinta', 'tabletas', 'sales', 'sal', 'leche', 'formula',
  'proteina', 'creatina', 'barra', 'te', 'infusion', 'mamadera', 'chupete', 'pinza', 'lima', 'tijera', 'peineta', 'cepillos', 'hidratante', 'serum', 'agua', 'spray', 'polvo',
  'bloqueador', 'fotoprotector', 'emulsion', 'espuma', 'mousse', 'body', 'baby', 'bebe', 'nino', 'kids', 'loción', 'jarabe', 'gotas', 'vitamina', 'multivitaminico',
  'calcio', 'magnesio', 'colageno', 'omega', 'melatonina', 'ajo', 'aloe', 'ginkgo', 'curcuma', 'propoleo', 'test', 'tiras', 'lancetas', 'condones', 'preservativos',
  'lubricante', 'apositos', 'curitas', 'tela', 'micropore', 'rodillera', 'tobillera', 'faja', 'cabestrillo', 'nebulizador', 'tensiometro', 'oximetro', 'glucometro', 'bebida']);
const SUFFIX2 = new Set(['pharma', 'farma', 'labs', 'lab', 'pharmaceutical', 'healthcare', 'life', 'medical', 'house', 'polanco', 'natural', 'naturals', 'nutrition', 'chile', 'reddys', 'investi']);
const titleWord = (w) => (w.length <= 3 && /^[A-Z]+$/.test(w) ? w : w[0].toUpperCase() + w.slice(1).toLowerCase());

/** Marca o laboratorio, a partir del nombre (y del departamento si es un laboratorio). */
export function guessBrand(name, { lab = '', family = 'med' } = {}) {
  if (lab) return lab;
  const raw = String(name).replace(/[()]/g, ' ').replace(/\s+/g, ' ').trim();
  const labM = raw.match(/\b(?:lab|laboratorio|labs)\.?\s+([A-Za-zÁÉÍÓÚÑáéíóúñ][\w.\-'ÁÉÍÓÚÑáéíóúñ]*(?:\s+[A-Za-zÁÉÍÓÚÑáéíóúñ][\w\-'ÁÉÍÓÚÑáéíóúñ]*)?)\s*\.?$/i);
  if (labM) {
    const b = labM[1].replace(/\.$/, '');
    const known = LABS[fold(b).replace(/[^a-z ]/g, ' ').trim()];
    return known || (fold(b) === 'chile' ? 'Laboratorio Chile' : b.split(/\s+/).map(titleWord).join(' '));
  }
  const words = raw.split(' ').map((w) => w.replace(/[.,;:]+$/, '')).filter(Boolean);
  const ok = (w) => w && /^[A-Za-zÁÉÍÓÚÑáéíóúñ][A-Za-zÁÉÍÓÚÑáéíóúñ'&\-.]{2,}$/.test(w) && !STOP.has(fold(w)) && !ING_WORDS.has(fold(w)) && !/^talla/i.test(w);
  const last = () => {
    const w = words[words.length - 1];
    if (!ok(w)) return '';
    const prev = words[words.length - 2];
    if (SUFFIX2.has(fold(w)) && prev && ok(prev)) return `${titleWord(prev)} ${titleWord(w)}`;
    const known = LABS[fold(w)];
    return known || titleWord(w);
  };
  const first = () => (ok(words[0]) && !GENERIC_FIRST.has(fold(words[0])) ? titleWord(words[0]) : '');
  const second = () => (GENERIC_FIRST.has(fold(words[0] || '')) && ok(words[1]) && !GENERIC_FIRST.has(fold(words[1])) ? titleWord(words[1]) : '');
  // Medicamentos y naturales: el laboratorio va al final · cuidado personal: la marca va al principio
  const b = family === 'med' || family === 'natural' || family === 'nutri' ? last() || first() || second() : first() || last() || second();
  return (b || 'Sin marca').slice(0, 60);
}

// ── La ficha completa ────────────────────────────────────────
/**
 * Propone la ficha de un producto nuevo.
 * row: { code, name, dept, price }
 * choice (opcional, lo que se eligió en el panel para su departamento): { sub: 'auto' | 'cat/sub', rx: 'directa' | 'simple' | 'hide' }
 * → { def, hidden, rx: 'directa'|'simple'|'hide', sub, how }
 */
export function proposeProduct(row, choice = null) {
  const dd = deptDefaults(row.dept);
  const rxChoice = choice?.rx || dd.rx;
  const nameShown = prettyName(row.name);
  const f = ` ${fold(nameShown)} `;
  const ings = findIngredients(nameShown);
  const fam = dd.family;
  let sub = '';
  let how = 'departamento';
  let directaRule = false;
  if (choice?.sub && choice.sub !== 'auto' && SUB_IDS.has(choice.sub)) {
    sub = choice.sub;
  } else {
    // 1) principio activo · 2) subcategoría del departamento · 3) palabras del nombre · 4) la de la familia
    const medOk = fam === 'med' || fam === 'any' || fam === 'insumos';
    // Dermatológicos: solo principios activos de medicamentos (una crema con betametasona es un medicamento)
    const ing = medOk ? ings[0]
      : fam === 'dermo' ? ings.find((x) => x.sub.startsWith('medicamentos/'))
        : fam === 'natural' || fam === 'nutri' ? ings.find((x) => !x.sub.startsWith('medicamentos/')) : null;
    const rule = RULES.find(([re, target, , only]) => re.test(f)
      && (only === 'med' ? medOk : only === 'personal' ? fam === 'personal' || fam === 'dermo' : true)
      && (medOk || !target.startsWith('medicamentos/') || target === 'medicamentos/primeros-auxilios' || target === 'medicamentos/monitores-y-diagnostico'));
    if (rule && rule[4]) { sub = rule[1]; how = 'nombre'; directaRule = !!rule[2]; }
    else if (ing) { sub = ing.sub; how = 'principio activo'; }
    else if (dd.sub) sub = dd.sub;
    else if (rule) { sub = rule[1]; how = 'nombre'; directaRule = !!rule[2]; }
    else sub = FALLBACK[fam] || FALLBACK.med;
  }
  const isMed = sub.startsWith('medicamentos/');
  const c = parseContent(nameShown);
  const def = {
    n: nameShown.slice(0, 120),
    b: guessBrand(nameShown, { lab: dd.lab, family: isMed ? 'med' : dd.family }),
    c: sub,
    f: c.f,
    u: c.u,
    un: c.un,
    p: Math.round(Number(row.price) || 0),
    t: [fold(row.dept || '')].filter(Boolean).slice(0, 1),
    s: 50,
  };
  if (isMed) {
    def.ai = ings.filter((x) => x.sub.startsWith('medicamentos/') || ings.length > 1).map((x) => x.display).slice(0, 3);
    if (!def.ai.length) delete def.ai;
    const st = parseStrength(nameShown);
    if (st) def.st = st;
    const rx = rxChoice === 'hide' ? dd.rxIfShown || 'simple' : rxChoice;
    def.rx = directaRule && rxChoice !== 'hide' ? 'directa' : rx === 'directa' || rx === 'simple' || rx === 'retenida' ? rx : 'simple';
    if (dd.be && def.ai) def.be = 1;
  }
  return { def, hidden: rxChoice === 'hide', rx: rxChoice, sub, how };
}

export const SUB_LABEL = new Map(ALL_SUBS.map((s) => [`${s.cat}/${s.id}`, `${s.catName} › ${s.name}`]));

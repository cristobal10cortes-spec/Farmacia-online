// ─────────────────────────────────────────────────────────────
//  MOTOR DE BÚSQUEDA TOLERANTE A ERRORES
//
//  Para cada palabra que escribe el paciente busca, en orden:
//   1. coincidencia exacta            ("paracetamol")
//   2. misma raíz (plural/singular)   ("pañal" ↔ "pañales")
//   3. mismo sonido en español        ("zetirizina" ↔ "cetirizina")
//   4. comienzo de palabra            ("parac" → "paracetamol")
//   5. sinónimos, marcas y síntomas   ("acetaminofén", "panadol", "dolor de cabeza")
//   6. errores de tipeo (distancia)   ("paqazetami" → "paracetamol")
//  Luego combina las palabras (todas deben calzar; si ninguna
//  combinación calza completa, muestra las más parecidas) y
//  ordena por relevancia, campo donde calzó y popularidad.
// ─────────────────────────────────────────────────────────────

import { tokenize, stem, phonetic, isNumeric } from './text.js';
import { osa, dice, maxEdits } from './distance.js';

const MAX_CANDIDATES = 8;

export class SearchIndex {
  /**
   * @param {object} cfg
   * @param {Array}  cfg.docs       documentos con `id`
   * @param {Array}  cfg.fields     [{ weight, get(doc) → string|string[] }]
   * @param {Array}  [cfg.synonyms] [{ words:[], to:[], kind }]
   * @param {Array}  [cfg.stopwords]
   * @param {Array}  [cfg.weakWords]
   * @param {Function} [cfg.boost]  doc → 0..1 (popularidad)
   */
  constructor({ docs, fields, synonyms = [], stopwords = [], weakWords = [], boost = null }) {
    this.docs = docs;
    this.byId = new Map(docs.map((d) => [d.id, d]));
    this.stop = new Set(stopwords);
    this.weak = new Set(weakWords);
    this.boost = boost;
    this.vocab = new Map();
    this.display = new Map();
    this.firstToken = new Map(); // docId → primera palabra del campo principal
    this.concepts = [];
    this.cache = new Map();
    this._index(fields);
    this._buildKeys();
    this._addSynonyms(synonyms);
    this._finalize();
  }

  // ── Indexación ──────────────────────────────────────────────
  _index(fields) {
    this.maxWeight = Math.max(...fields.map((f) => f.weight));
    for (const doc of this.docs) {
      fields.forEach((f, fi) => {
        const v = f.get(doc);
        if (!v) return;
        for (const text of Array.isArray(v) ? v : [v]) {
          if (!text) continue;
          this._learnDisplay(text);
          const toks = tokenize(text);
          if (fi === 0 && toks.length && !this.firstToken.has(doc.id)) {
            this.firstToken.set(doc.id, toks.find((t) => !this.stop.has(t)) || toks[0]);
          }
          for (const t of toks) this._post(t, doc.id, f.weight);
          // Palabras pegadas: "la roche" → "laroche", "rosa mosqueta" → "rosamosqueta"
          if (f.weight >= 7) {
            for (let i = 0; i < toks.length - 1; i++) {
              const a = toks[i];
              const b = toks[i + 1];
              if (isNumeric(a) || isNumeric(b) || b.length < 2) continue;
              const joined = a + b;
              if (!this.display.has(joined)) this.display.set(joined, `${this.display.get(a) || a} ${this.display.get(b) || b}`);
              this._post(joined, doc.id, f.weight * 0.9);
              this.vocab.get(joined).joined = true;
            }
          }
        }
      });
    }
  }

  _post(term, id, w) {
    if (this.stop.has(term)) return;
    let e = this.vocab.get(term);
    if (!e) {
      e = { term, postings: new Map(), virtual: false };
      this.vocab.set(term, e);
    }
    if (w > (e.postings.get(id) || 0)) e.postings.set(id, w);
  }

  // Guarda la forma "bonita" de cada palabra (con tildes) para mostrarla.
  _learnDisplay(text) {
    for (const raw of String(text).toLowerCase().split(/[\s/,;:()+\-]+/)) {
      const clean = raw.replace(/^[^0-9a-záéíóúüñ]+|[^0-9a-záéíóúüñ%]+$/gi, '');
      const toks = tokenize(clean);
      if (toks.length !== 1) continue;
      const cur = this.display.get(toks[0]);
      if (!cur || (/[áéíóúüñ]/.test(clean) && !/[áéíóúüñ]/.test(cur))) this.display.set(toks[0], clean.replace(/%$/, ''));
    }
  }

  _buildKeys() {
    this.stemIdx = new Map();
    this.phonIdx = new Map();
    for (const e of this.vocab.values()) this._keyEntry(e);
  }

  _keyEntry(e) {
    e.stem = stem(e.term);
    e.phon = phonetic(e.term);
    e.num = isNumeric(e.term);
    if (!this.stemIdx.has(e.stem)) this.stemIdx.set(e.stem, new Set());
    this.stemIdx.get(e.stem).add(e.term);
    if (!this.phonIdx.has(e.phon)) this.phonIdx.set(e.phon, new Set());
    this.phonIdx.get(e.phon).add(e.term);
  }

  // Postings de una palabra exacta o con la misma raíz (sin difusos)
  _exactPostings(t) {
    const out = new Map();
    const terms = new Set([t, ...(this.stemIdx.get(stem(t)) || [])]);
    for (const term of terms) {
      const e = this.vocab.get(term);
      if (!e || e.virtual) continue;
      for (const [id, w] of e.postings) if (w > (out.get(id) || 0)) out.set(id, w);
    }
    return out.size ? out : null;
  }

  _postingsForTargets(targets) {
    const out = new Map();
    for (const toks of targets) {
      if (!toks.length) continue;
      let acc = null;
      for (const t of toks) {
        const p = this._exactPostings(t);
        if (!p) { acc = null; break; }
        if (!acc) acc = new Map(p);
        else for (const id of [...acc.keys()]) {
          if (!p.has(id)) acc.delete(id);
          else acc.set(id, Math.min(acc.get(id), p.get(id)));
        }
      }
      if (acc) for (const [id, w] of acc) if (w > (out.get(id) || 0)) out.set(id, w);
    }
    return out;
  }

  _addSynonyms(groups) {
    for (const g of groups) {
      const targets = g.to.map((x) => tokenize(x).filter((t) => !this.stop.has(t)));
      const postings = this._postingsForTargets(targets);
      if (!postings.size) continue;
      for (const w of g.words) {
        const toks = tokenize(w).filter((t) => !this.stop.has(t));
        if (!toks.length) continue;
        if (toks.length === 1) {
          const t = toks[0];
          let e = this.vocab.get(t);
          // Si ya existe una palabra real con la misma raíz, se enriquece esa (no se crea un sinónimo)
          if (!e) {
            const sameStem = [...(this.stemIdx.get(stem(t)) || [])].map((x) => this.vocab.get(x)).find((x) => x && !x.virtual);
            if (sameStem) e = sameStem;
          }
          if (!e) {
            e = { term: t, postings: new Map(), virtual: true, synonymOf: g.to[0], kind: g.kind };
            this.vocab.set(t, e);
            this._keyEntry(e);
            this.display.set(t, w);
          }
          for (const [id, wt] of postings) {
            const val = e.virtual ? wt : Math.min(wt, 4);
            if (val > (e.postings.get(id) || 0)) e.postings.set(id, val);
          }
        } else {
          this.concepts.push({ tokens: toks, phrase: w, postings, label: g.to[0], kind: g.kind });
        }
      }
    }
    // Las frases más largas primero
    this.concepts.sort((a, b) => b.tokens.length - a.tokens.length);
  }

  _finalize() {
    this.N = this.docs.length;
    this.terms = [...this.vocab.values()];
    this.textTerms = this.terms.filter((e) => !e.num);
    this.numTerms = this.terms.filter((e) => e.num);
    for (const e of this.terms) {
      e.df = e.postings.size;
      e.idf = 0.55 + 0.45 * (Math.log(1 + this.N / Math.max(1, e.df)) / Math.log(1 + this.N));
    }
  }

  // ── Expansión de una palabra en candidatos ──────────────────
  // allowPrefix = la palabra se está escribiendo (autocompletar): se prefieren
  // las palabras que comienzan igual por sobre las parecidas.
  expand(t, allowPrefix = false) {
    const out = new Map();
    const add = (term, score, how) => {
      const cur = out.get(term);
      if (!cur || score > cur.score) out.set(term, { term, score, how });
    };
    if (this.vocab.has(t)) add(t, 1, this.vocab.get(t).virtual ? 'syn' : 'exact');
    if (isNumeric(t)) {
      if (allowPrefix) for (const e of this.numTerms) if (e.term !== t && e.term.startsWith(t)) add(e.term, 0.62, 'prefix');
      return this._pick(out, t, allowPrefix);
    }
    if (t.length === 1 && !allowPrefix) return this._pick(out, t, allowPrefix);

    const st = stem(t);
    const ph = phonetic(t);
    if (t.length > 1) {
      for (const term of this.stemIdx.get(st) || []) if (term !== t) add(term, 0.97, this.vocab.get(term).virtual ? 'syn' : 'stem');
      if (ph.length >= 3) {
        const lim = maxEdits(t.length) + 1;
        for (const term of this.phonIdx.get(ph) || []) {
          if (term !== t && osa(t, term, lim) <= lim) add(term, 0.93, 'phon');
        }
      }
    }

    if (allowPrefix || t.length >= 3) {
      const short = t.length <= 3;
      for (const e of this.textTerms) {
        if (!e.joined && e.term.length > t.length && e.term.startsWith(t)) {
          let sc = short ? 0.72 : 0.62 + 0.3 * (t.length / e.term.length);
          if (allowPrefix) sc += 0.06;
          // Un sinónimo (p. ej. una marca) no le gana a una palabra real que empieza igual
          if (e.virtual) sc -= allowPrefix ? 0.08 : 0.15;
          add(e.term, sc, 'prefix');
        }
      }
      if (ph.length >= 3) {
        for (const e of this.textTerms) {
          if (!e.joined && e.phon.length > ph.length && e.phon.startsWith(ph)) {
            let sc = 0.6 + 0.25 * (ph.length / e.phon.length) + (allowPrefix ? 0.06 : 0);
            if (e.virtual) sc -= 0.08;
            add(e.term, sc, 'prefix');
          }
        }
      }
    }

    const hasExact = out.has(t) && out.get(t).how !== 'syn';
    if (!hasExact && t.length >= 4) {
      const maxD = maxEdits(t.length);
      const damp = allowPrefix ? 0.88 : 1;
      for (const e of this.textTerms) {
        if (Math.abs(e.term.length - t.length) > maxD + 1) continue;
        if (e.term.startsWith(t)) continue; // ya cuenta como "empieza igual"
        // La distancia escrita no puede ser mucho mayor que la tolerada…
        const d0 = osa(t, e.term, maxD + 1);
        if (d0 > maxD + 1) continue;
        // …y la distancia "por sonido" debe quedar dentro de lo tolerado.
        let d = d0;
        if (d > 0 && ph.length >= 3) {
          const dp = osa(ph, e.phon, maxD);
          if (dp < d) d = dp;
        }
        if (d > maxD) continue;
        if (d === 0) { add(e.term, 0.92, 'phon'); continue; }
        const L = Math.max(t.length, e.term.length);
        const sameStart = ph[0] === e.phon[0];
        const dc = dice(ph, e.phon);
        if (!sameStart && (dc < 0.5 || t.length <= 5)) continue;
        if (d >= 3 && dc < 0.45) continue;
        const sim = 1 - d / L;
        let sc = Math.min(0.88, 0.55 + 0.35 * sim + 0.08 * dc + (sameStart ? 0.03 : 0)) * damp;
        if (e.virtual) sc -= 0.04;
        add(e.term, sc, 'fuzzy');
      }
      if (allowPrefix) {
        const maxP = t.length <= 6 ? 1 : 2;
        for (const e of this.textTerms) {
          if (e.joined || e.phon.length <= ph.length) continue;
          const pre = e.phon.slice(0, ph.length);
          if (pre[0] !== ph[0]) continue;
          const d = osa(ph, pre, maxP);
          if (d <= maxP) add(e.term, 0.6 + 0.2 * (ph.length / e.phon.length) - 0.05 * d - (e.virtual ? 0.06 : 0), 'fuzzyPrefix');
        }
      }
    }
    return this._pick(out, t, allowPrefix);
  }

  _pick(out, t, allowPrefix = false) {
    let list = [...out.values()].sort((a, b) => b.score - a.score
      || (this.vocab.get(b.term)?.df || 0) - (this.vocab.get(a.term)?.df || 0)
      || a.term.length - b.term.length);
    if (!list.length) return list;
    // Si hay una coincidencia "segura" (exacta, raíz, sonido o sinónimo), se descartan las aproximadas.
    const SURE = ['exact', 'stem', 'phon', 'syn'];
    const strong = list.some((c) => SURE.includes(c.how) && c.score >= 0.9);
    if (strong) {
      list = list.filter((c) => SURE.includes(c.how) || (allowPrefix && c.how === 'prefix' && c.score >= 0.6));
    } else {
      const floor = Math.max(0.45, list[0].score - 0.2);
      list = list.filter((c) => c.score >= floor);
    }
    return list.slice(0, allowPrefix ? 40 : MAX_CANDIDATES);
  }

  // ── Búsqueda ────────────────────────────────────────────────
  /**
   * @param {string} query
   * @param {object} [opts]
   * @param {boolean} [opts.prefix]  la última palabra puede estar incompleta (autocompletar)
   * @param {Function} [opts.filter] doc → boolean
   */
  search(query, opts = {}) {
    const key = `${query}\u0001${opts.prefix ? 1 : 0}`;
    if (!opts.filter && this.cache.has(key)) return this.cache.get(key);
    const res = this._search(String(query || ''), opts);
    if (!opts.filter) {
      if (this.cache.size > 300) this.cache.delete(this.cache.keys().next().value);
      this.cache.set(key, res);
    }
    return res;
  }

  _search(query, opts) {
    const all = tokenize(query);
    const empty = { query, items: [], total: 0, partial: false, corrected: null, completion: '', corrections: [], notes: [], terms: [], tokens: [] };
    if (!all.length) return empty;
    let toks = all.filter((t) => !this.stop.has(t));
    if (!toks.length) toks = all;

    // 1) Frases conocidas (síntomas, marcas de varias palabras…)
    const units = [];
    const notes = [];
    for (let i = 0; i < toks.length;) {
      let matched = null;
      for (const c of this.concepts) {
        const n = c.tokens.length;
        if (i + n > toks.length) continue;
        let ok = true;
        for (let k = 0; k < n; k++) {
          const a = toks[i + k];
          const b = c.tokens[k];
          if (a !== b && stem(a) !== stem(b) && phonetic(a) !== phonetic(b)) { ok = false; break; }
        }
        if (ok) { matched = c; break; }
      }
      if (matched) {
        units.push({ type: 'concept', concept: matched, text: toks.slice(i, i + matched.tokens.length).join(' ') });
        notes.push({ from: matched.phrase, to: matched.label, kind: matched.kind });
        i += matched.tokens.length;
      } else {
        units.push({ type: 'term', text: toks[i] });
        i += 1;
      }
    }

    // 2) Candidatos por palabra
    const lastIdx = units.length - 1;
    units.forEach((u, i) => {
      if (u.type === 'term') {
        u.cands = this.expand(u.text, !!opts.prefix && i === lastIdx);
        u.weak = this.weak.has(u.text);
      }
    });
    if (units.every((u) => u.weak)) units.forEach((u) => { u.weak = false; });
    const reqCount = units.filter((u) => !u.weak).length;

    // 3) Puntaje por documento
    const scores = new Map();
    const hit = (id) => {
      let s = scores.get(id);
      if (!s) { s = { id, sum: 0, req: 0, per: new Array(units.length).fill(0), how: new Array(units.length).fill(null) }; scores.set(id, s); }
      return s;
    };
    units.forEach((u, ui) => {
      if (u.type === 'concept') {
        for (const [id, w] of u.concept.postings) {
          const s = hit(id);
          const v = 0.9 * (w / this.maxWeight);
          if (v > s.per[ui]) { s.per[ui] = v; s.how[ui] = { term: u.concept.label, how: 'concept' }; }
        }
        return;
      }
      for (const c of u.cands) {
        const e = this.vocab.get(c.term);
        if (!e) continue;
        for (const [id, w] of e.postings) {
          const s = hit(id);
          const v = c.score * (w / this.maxWeight) * e.idf;
          if (v > s.per[ui]) { s.per[ui] = v; s.how[ui] = c; }
        }
      }
    });

    const filter = opts.filter;
    // La mejor coincidencia de cada palabra: una coincidencia muy débil (p. ej. solo
    // por la descripción) no cuenta como "calza" si otros productos calzan fuerte.
    const bestPer = new Array(units.length).fill(0);
    for (const s of scores.values()) s.per.forEach((v, ui) => { if (v > bestPer[ui]) bestPer[ui] = v; });
    let best = 0;
    const rows = [];
    for (const s of scores.values()) {
      const doc = this.byId.get(s.id);
      if (!doc || (filter && !filter(doc))) continue;
      let req = 0;
      let sum = 0;
      units.forEach((u, ui) => {
        sum += s.per[ui];
        if (s.per[ui] > 0 && s.per[ui] >= 0.25 * bestPer[ui] && !u.weak) req++;
      });
      s.req = req;
      // Bonos: la primera palabra del nombre calza; todo calza "limpio"; popularidad
      const firstUnit = units.findIndex((u) => !u.weak);
      const ft = this.firstToken.get(s.id);
      const h0 = firstUnit >= 0 ? s.how[firstUnit] : null;
      if (h0 && ft && (h0.term === ft || stem(h0.term) === stem(ft))) sum += 0.25;
      if (s.how.every((h, ui) => units[ui].weak || (h && (h.how === 'exact' || h.how === 'stem' || h.how === 'concept' || h.how === 'syn')))) sum += 0.1;
      if (this.boost) sum += 0.12 * this.boost(doc);
      s.sum = sum;
      if (req > best) best = req;
      rows.push(s);
    }
    if (!best) return { ...empty, tokens: toks, notes };
    let items = rows
      .filter((r) => r.req === best)
      .sort((a, b) => b.sum - a.sum)
      .map((r) => ({ id: r.id, score: r.sum }));
    // Corte relativo: se descartan coincidencias muy débiles frente a la mejor
    const topScore = items[0].score;
    items = items.filter((it) => it.score >= topScore * 0.2);

    // 4) Correcciones ("¿Quisiste decir…?"), autocompletado y notas de sinónimos
    const corrections = [];
    const finalWords = [];
    const completeWords = [];
    const terms = new Set();
    units.forEach((u, ui) => {
      if (u.type === 'concept') {
        finalWords.push(u.text);
        completeWords.push(u.text);
        for (const t of u.concept.tokens) terms.add(t);
        return;
      }
      // El mejor candidato que efectivamente aparece en los resultados mostrados
      const topHow = items.length ? scores.get(items[0].id).how[ui] : null;
      const used = new Set(items.slice(0, 20).map((it) => scores.get(it.id).how[ui]?.term).filter(Boolean));
      const chosen = (topHow && u.cands.find((c) => c.term === topHow.term)) || u.cands.find((c) => used.has(c.term)) || u.cands[0];
      if (!chosen) { finalWords.push(u.text); completeWords.push(u.text); return; }
      terms.add(chosen.term);
      const e = this.vocab.get(chosen.term);
      const sameRoot = stem(chosen.term) === stem(u.text);
      const shown = this.display.get(chosen.term) || chosen.term;
      if (e && e.virtual) {
        notes.push({ from: shown, to: e.synonymOf, kind: e.kind });
        finalWords.push(shown);
        completeWords.push(shown);
        for (const t of tokenize(e.synonymOf)) terms.add(t);
        if (!sameRoot && chosen.how !== 'prefix') corrections.push({ from: u.text, to: shown });
        return;
      }
      if ((chosen.how === 'fuzzy' || chosen.how === 'phon' || chosen.how === 'fuzzyPrefix') && !sameRoot) {
        corrections.push({ from: u.text, to: shown });
        finalWords.push(shown);
        completeWords.push(shown);
      } else if (chosen.how === 'prefix') {
        finalWords.push(opts.prefix ? u.text : shown);
        completeWords.push(shown);
      } else {
        finalWords.push(u.text);
        completeWords.push(u.text);
      }
      for (const c of u.cands) if (c.score >= 0.8) terms.add(c.term);
    });

    return {
      query,
      tokens: toks,
      items,
      total: items.length,
      partial: best < reqCount,
      corrected: corrections.length ? finalWords.join(' ') : null,
      completion: completeWords.join(' '),
      corrections,
      notes: dedupeNotes(notes),
      terms: [...terms],
    };
  }

  // Palabra a mostrar (con tildes) para un término normalizado
  pretty(term) {
    return this.display.get(term) || term;
  }
}

function dedupeNotes(notes) {
  const seen = new Set();
  return notes.filter((n) => {
    const k = `${n.from}>${n.to}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

// Contacto con el cliente desde el panel: mensajes listos según el motivo y
// enlaces para escribir un correo, abrir WhatsApp o llamar. No se envía nada
// solo: se abre el programa de correo o WhatsApp con el mensaje para revisarlo.

import { cleanPhone, validPhone, validEmail, formatPhone } from './rut.js';
import { statusMessage, dateMessage, statusOf } from './orderflow.js';

const RX_KINDS = ['simple', 'retenida', 'cheque'];
const firstName = (c) => String(c?.nombre || '').trim().split(/\s+/)[0] || '';
const SIGN = '\n\nSaludos,\nFarmacias Piedra';

/** Motivos de contacto que tienen sentido para este pedido (el primero es el general). */
export function contactTemplates(o) {
  const c = o?.customer || {};
  const d = o?.delivery || {};
  const id = o?.id || '';
  const hola = `Hola${firstName(c) ? ` ${firstName(c)}` : ''}`;
  const rxItems = (o?.items || []).filter((it) => RX_KINDS.includes(it.rx)).map((it) => `• ${it.name}`);
  const list = [
    { id: 'consulta', label: 'Consulta sobre el pedido', subject: `Tu pedido ${id} en Farmacias Piedra`, body: `${hola}, te escribimos de Farmacias Piedra por tu pedido ${id}.\n\n` },
  ];
  if (rxItems.length) {
    list.push({ id: 'receta', label: 'Falta o no se lee la receta', subject: `Necesitamos tu receta · pedido ${id}`, body: `${hola}, para preparar tu pedido ${id} necesitamos una foto clara de la receta médica de:\n${rxItems.join('\n')}\n\nPuedes responder este mensaje con la foto (que se lean el nombre del paciente, el medicamento, la fecha y la firma).` });
  }
  list.push({ id: 'stock', label: 'Un producto no está disponible', subject: `Sobre un producto de tu pedido ${id}`, body: `${hola}, te escribimos por tu pedido ${id}. Uno de los productos no está disponible en este momento.\n\n¿Prefieres que lo cambiemos por una alternativa equivalente, esperar la reposición o quitarlo del pedido (te devolvemos ese monto)?` });
  // Avisos de cada etapa: el mismo texto que el cliente ve en su seguimiento
  const intro = `${hola}, te escribimos de Farmacias Piedra por tu pedido ${id}.\n\n`;
  const stage = (key, label, subject, msg) => list.push({ id: key, label, subject, body: `${intro}${msg.title}: ${msg.text}` });
  stage('confirmado', 'Pedido confirmado y en preparación', `Confirmamos tu pedido ${id}`, statusMessage(o, 'embalaje'));
  if (d.type === 'retiro') {
    stage('listo', 'Listo para retiro', `Tu pedido ${id} está listo para retiro`, statusMessage(o, 'listo'));
  } else {
    const where = [d.address, d.comuna].filter(Boolean).join(', ');
    list.push({ id: 'entrega', label: 'Coordinar la entrega', subject: `Coordinemos la entrega de tu pedido ${id}`, body: `${hola}, queremos coordinar la entrega de tu pedido ${id}${where ? ` en ${where}` : ''}.\n\n¿En qué horario te acomoda recibirlo?` });
    stage('camino', 'Pedido en camino', `Tu pedido ${id} va en camino`, statusMessage(o, 'camino'));
  }
  if (d.date) stage('fecha', d.type === 'retiro' ? 'Fecha de retiro' : 'Fecha de entrega', `Fecha de ${d.type === 'retiro' ? 'retiro' : 'entrega'} de tu pedido ${id}`, dateMessage(o, d.date));
  stage('entregado', d.type === 'retiro' ? 'Pedido retirado' : 'Pedido entregado', `Gracias por tu compra · pedido ${id}`, statusMessage(o, 'entregado'));
  if (o?.cancelled) {
    list.push({ id: 'anulado', label: 'Pedido anulado', subject: `Tu pedido ${id} fue anulado`, body: `${hola}, te contamos que tu pedido ${id} fue anulado.${o.payment?.status === 'aprobado' ? ' La devolución del pago se verá reflejada según los plazos de tu banco.' : ''}\n\nSi tienes cualquier duda, responde este mensaje.` });
  }
  return list.map((t) => ({ ...t, body: `${t.body.trimEnd()}${SIGN}` }));
}

/** Motivo que corresponde a la etapa actual del pedido (el que se muestra primero). */
export function suggestedTemplate(o) {
  if (o?.cancelled) return 'anulado';
  const s = statusOf(o);
  if (s === 'embalaje') return 'confirmado';
  if (s === 'camino' || s === 'listo' || s === 'entregado') return s;
  return 'consulta';
}

/** Correo: cada parte de la dirección va codificada (así un ? o & no rompe el enlace). */
export function mailtoHref(email, subject = '', body = '') {
  const e = String(email || '').trim();
  if (!validEmail(e)) return '';
  const at = e.lastIndexOf('@');
  const addr = `${encodeURIComponent(e.slice(0, at))}@${encodeURIComponent(e.slice(at + 1))}`;
  const q = [subject && `subject=${encodeURIComponent(subject)}`, body && `body=${encodeURIComponent(body.replace(/\r?\n/g, '\r\n'))}`].filter(Boolean).join('&');
  return `mailto:${addr}${q ? `?${q}` : ''}`;
}

/** Celular chileno en formato internacional, solo dígitos (569XXXXXXXX). */
export const intlPhone = (p) => (validPhone(p) ? `56${cleanPhone(p)}` : '');

export function whatsappHref(phone, text = '') {
  const n = intlPhone(phone);
  return n ? `https://wa.me/${n}${text ? `?text=${encodeURIComponent(text)}` : ''}` : '';
}

export function telHref(phone) {
  const n = intlPhone(phone);
  return n ? `tel:+${n}` : '';
}

export { formatPhone };

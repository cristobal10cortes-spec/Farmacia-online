// Planillas de inventario para la carga masiva del panel.
//
// Lee:     CSV (separado por ; , o tabulador; UTF-8 o el "ANSI" que guarda Excel
//          en Windows) y Excel .xlsx.
// Escribe: la planilla para llenar, en .xlsx y en .csv.
//
// La primera fila lleva los títulos, de izquierda a derecha:
//     Código | Nombre del producto | Cantidad
// (se aceptan otros nombres parecidos y otro orden; el nombre es opcional).
//
// No usa librerías: un .xlsx es un .zip con archivos XML adentro. Funciona igual
// en el navegador y en Node (para las pruebas).

import { tokenize } from './text.js';

export const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5 MB
export const MAX_ROWS = 5000; // filas con datos
export const MAX_QTY = 99999;
export const HEADERS = ['Código', 'Nombre del producto', 'Cantidad'];

export class PlanillaError extends Error {
  constructor(message) { super(message); this.name = 'PlanillaError'; }
}
const fail = (msg) => { throw new PlanillaError(msg); };

// ── Tipo de archivo ──────────────────────────────────────────
/** 'xlsx' | 'xls' | 'csv' según el contenido (no según el nombre). */
export function fileKind(bytes) {
  const b = bytes;
  if (b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04) return 'xlsx';
  if (b.length >= 4 && b[0] === 0xd0 && b[1] === 0xcf && b[2] === 0x11 && b[3] === 0xe0) return 'xls';
  return 'csv';
}

// ── Texto (CSV) ──────────────────────────────────────────────
/** Excel en Windows guarda los CSV en "ANSI" (windows-1252); los demás, en UTF-8. */
export function decodeText(bytes) {
  const b = bytes;
  if (b[0] === 0xff && b[1] === 0xfe) return new TextDecoder('utf-16le').decode(b.subarray(2));
  if (b[0] === 0xfe && b[1] === 0xff) return new TextDecoder('utf-16be').decode(b.subarray(2));
  const body = b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf ? b.subarray(3) : b;
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(body);
  } catch {
    return new TextDecoder('windows-1252').decode(body);
  }
}

function guessDelimiter(text) {
  const counts = { ';': 0, ',': 0, '\t': 0 };
  let quoted = false;
  let lines = 0;
  for (let i = 0; i < text.length && lines < 6; i++) {
    const ch = text[i];
    if (ch === '"') quoted = !quoted;
    else if (!quoted && ch in counts) counts[ch]++;
    else if (!quoted && ch === '\n') lines++;
  }
  // En Chile Excel usa ; (la coma es el decimal); si empatan, gana ;
  const [best, n] = Object.entries(counts).sort((x, y) => y[1] - x[1] || (x[0] === ';' ? -1 : y[0] === ';' ? 1 : 0))[0];
  return n ? best : ';';
}

/** CSV → filas (arreglos de textos). Respeta comillas, saltos de línea dentro de comillas y "sep=;". */
export function parseCsv(input) {
  let text = String(input || '').replace(/^﻿/, '');
  let delim = null;
  const sep = /^sep=(.)\r?\n/i.exec(text);
  if (sep) { delim = sep[1]; text = text.slice(sep[0].length); }
  delim = delim || guessDelimiter(text);
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  let i = 0;
  const limit = MAX_ROWS + 50;
  while (i < text.length) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') { cell += '"'; i += 2; continue; }
        quoted = false; i++; continue;
      }
      cell += ch; i++; continue;
    }
    if (ch === '"' && cell.trim() === '') { quoted = true; cell = ''; i++; continue; }
    if (ch === delim) { row.push(cell); cell = ''; i++; continue; }
    if (ch === '\r' || ch === '\n') {
      row.push(cell); cell = '';
      rows.push(row); row = [];
      if (rows.length > limit) fail(`La planilla tiene más de ${MAX_ROWS.toLocaleString('es-CL')} filas. Divídela en archivos más chicos.`);
      i += ch === '\r' && text[i + 1] === '\n' ? 2 : 1;
      continue;
    }
    cell += ch; i++;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

// ── ZIP (para leer y escribir .xlsx) ─────────────────────────
const u16 = (b, o) => b[o] | (b[o + 1] << 8);
const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;

async function inflateRaw(data, maxOut) {
  const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const reader = stream.getReader();
  const parts = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxOut) { await reader.cancel().catch(() => {}); fail('El archivo de Excel es demasiado grande por dentro.'); }
    parts.push(value);
  }
  const out = new Uint8Array(total);
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}

/** Abre un .zip y devuelve el contenido de los archivos pedidos. */
async function unzip(bytes, wanted, { maxEach = 40 * 1024 * 1024, maxTotal = 80 * 1024 * 1024 } = {}) {
  const b = bytes;
  let eocd = -1;
  for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) {
    if (u32(b, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) fail('El archivo no es un Excel válido (está dañado o incompleto).');
  const count = u16(b, eocd + 10);
  let p = u32(b, eocd + 16);
  if (count > 5000) fail('El archivo de Excel tiene demasiadas partes.');
  const names = [];
  const out = new Map();
  let total = 0;
  for (let n = 0; n < count; n++) {
    if (p + 46 > b.length || u32(b, p) !== 0x02014b50) fail('El archivo no es un Excel válido (está dañado).');
    const method = u16(b, p + 10);
    const csize = u32(b, p + 20);
    const usize = u32(b, p + 24);
    const nlen = u16(b, p + 28);
    const xlen = u16(b, p + 30);
    const clen = u16(b, p + 32);
    const local = u32(b, p + 42);
    const name = new TextDecoder().decode(b.subarray(p + 46, p + 46 + nlen));
    names.push(name);
    p += 46 + nlen + xlen + clen;
    if (!wanted(name)) continue;
    if (csize === 0xffffffff || usize === 0xffffffff) fail('El archivo de Excel es demasiado grande.');
    if (u32(b, local) !== 0x04034b50) fail('El archivo no es un Excel válido (está dañado).');
    const start = local + 30 + u16(b, local + 26) + u16(b, local + 28);
    const data = b.subarray(start, start + csize);
    let content;
    if (method === 0) content = data;
    else if (method === 8) content = await inflateRaw(data, Math.min(maxEach, maxTotal - total));
    else fail('El archivo de Excel usa una compresión que no conocemos. Guárdalo de nuevo como .xlsx.');
    total += content.length;
    out.set(name, content);
  }
  return { files: out, names };
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** Arma un .zip sin comprimir (los .xlsx que generamos son chicos). */
function zip(files) {
  const enc = new TextEncoder();
  const parts = [];
  const central = [];
  let offset = 0;
  const DOS_TIME = 0;
  const DOS_DATE = ((2026 - 1980) << 9) | (1 << 5) | 1;
  for (const [name, content] of files) {
    const data = typeof content === 'string' ? enc.encode(content) : content;
    const nm = enc.encode(name);
    const crc = crc32(data);
    const head = new Uint8Array(30 + nm.length);
    const dv = new DataView(head.buffer);
    dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, 0, true);
    dv.setUint16(10, DOS_TIME, true); dv.setUint16(12, DOS_DATE, true); dv.setUint32(14, crc, true);
    dv.setUint32(18, data.length, true); dv.setUint32(22, data.length, true); dv.setUint16(26, nm.length, true); dv.setUint16(28, 0, true);
    head.set(nm, 30);
    const cen = new Uint8Array(46 + nm.length);
    const cv = new DataView(cen.buffer);
    cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true); cv.setUint16(10, 0, true);
    cv.setUint16(12, DOS_TIME, true); cv.setUint16(14, DOS_DATE, true); cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true); cv.setUint32(24, data.length, true); cv.setUint16(28, nm.length, true);
    cv.setUint32(42, offset, true);
    cen.set(nm, 46);
    parts.push(head, data);
    central.push(cen);
    offset += head.length + data.length;
  }
  const cenSize = central.reduce((a, c) => a + c.length, 0);
  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, files.length, true); ev.setUint16(10, files.length, true);
  ev.setUint32(12, cenSize, true); ev.setUint32(16, offset, true);
  const all = [...parts, ...central, end];
  const out = new Uint8Array(all.reduce((a, c) => a + c.length, 0));
  let o = 0;
  for (const c of all) { out.set(c, o); o += c.length; }
  return out;
}

// ── XML ──────────────────────────────────────────────────────
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const unescapeXml = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (m, e) => {
  if (e[0] === '#') {
    const cp = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
    return cp > 0 && cp <= 0x10ffff ? String.fromCodePoint(cp) : '';
  }
  return ENT[e.toLowerCase()];
});
const escapeXml = (s) => String(s ?? '')
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f￾￿]/g, '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const attrs = (s) => {
  const o = {};
  for (const m of String(s || '').matchAll(/([\w:.-]+)\s*=\s*("([^"]*)"|'([^']*)')/g)) o[m[1]] = unescapeXml(m[3] ?? m[4] ?? '');
  return o;
};
/** Texto de un nodo con <t> (sin la guía fonética <rPh> que agrega Excel en japonés). */
const textOf = (xml) => unescapeXml(
  String(xml || '').replace(/<rPh\b[\s\S]*?<\/rPh>/g, '').replace(/<t\b[^>]*\/>/g, '')
    .match(/<t\b[^>]*>[\s\S]*?<\/t>/g)?.map((t) => t.replace(/^<t\b[^>]*>|<\/t>$/g, '')).join('') ?? '',
);

/** Número guardado por Excel → texto como se ve (sin notación científica ni 0,30000000000000004). */
function numberText(v) {
  const s = String(v).trim();
  if (!/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(s)) return s;
  const n = Number(s);
  if (!Number.isFinite(n)) return s;
  const r = Math.round(n);
  if (Math.abs(n - r) < 1e-9 && Math.abs(r) < 1e21) return Math.abs(r) <= Number.MAX_SAFE_INTEGER ? String(r) : BigInt(r).toString();
  return String(Number(n.toPrecision(15)));
}

const colIndex = (ref) => {
  const m = /^([A-Z]+)/i.exec(ref || '');
  if (!m) return -1;
  let n = 0;
  for (const ch of m[1].toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
};

function sheetRows(xml, shared) {
  const data = /<sheetData\b[^>]*>([\s\S]*)<\/sheetData>/.exec(xml)?.[1] || '';
  const rows = [];
  let nextRow = 0;
  for (const rm of data.matchAll(/<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g)) {
    const ra = attrs(rm[1]);
    const r = ra.r ? Math.max(0, parseInt(ra.r, 10) - 1) : nextRow;
    nextRow = r + 1;
    if (r > MAX_ROWS + 50) fail(`La planilla tiene más de ${MAX_ROWS.toLocaleString('es-CL')} filas. Divídela en archivos más chicos.`);
    const cells = [];
    let nextCol = 0;
    for (const cm of String(rm[2] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const ca = attrs(cm[1]);
      const c = ca.r ? colIndex(ca.r) : nextCol;
      nextCol = c + 1;
      if (c < 0 || c > 200) continue;
      const inner = cm[2] || '';
      const v = /<v\b[^>]*>([\s\S]*?)<\/v>/.exec(inner)?.[1];
      let val = '';
      switch (ca.t) {
        case 's': val = shared[parseInt(v, 10)] ?? ''; break;
        case 'inlineStr': val = textOf(/<is\b[^>]*>([\s\S]*?)<\/is>/.exec(inner)?.[1] || ''); break;
        case 'str': case 'd': val = unescapeXml(v ?? ''); break;
        case 'b': val = v === '1' ? 'VERDADERO' : 'FALSO'; break;
        case 'e': val = unescapeXml(v ?? '#ERROR'); break;
        default: val = v == null ? '' : numberText(unescapeXml(v));
      }
      cells[c] = val;
    }
    rows[r] = Array.from(cells, (x) => x ?? '');
  }
  return Array.from(rows, (x) => x ?? []);
}

/** .xlsx → hojas visibles en orden: [{ name, rows }]. */
export async function parseXlsx(bytes) {
  const want = (n) => n === 'xl/workbook.xml' || n === 'xl/_rels/workbook.xml.rels' || n === 'xl/sharedStrings.xml' || /^xl\/worksheets\/[^/]+\.xml$/.test(n) || n === 'mimetype';
  const { files, names } = await unzip(bytes, want);
  const dec = new TextDecoder();
  const get = (n) => (files.has(n) ? dec.decode(files.get(n)) : '');
  if (!files.has('xl/workbook.xml')) {
    if (/opendocument/.test(get('mimetype')) || names.includes('content.xml')) fail('Este archivo es de LibreOffice/OpenOffice (.ods). Guárdalo como «Libro de Excel (.xlsx)» o como CSV.');
    fail('El archivo no es una planilla de Excel (.xlsx).');
  }
  const shared = [...get('xl/sharedStrings.xml').matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>|<si\b[^>]*\/>/g)].map((m) => textOf(m[1] || ''));
  const rels = {};
  for (const m of get('xl/_rels/workbook.xml.rels').matchAll(/<Relationship\b([^>]*?)\/?>/g)) {
    const a = attrs(m[1]);
    if (a.Id && a.Target) rels[a.Id] = a.Target.startsWith('/') ? a.Target.slice(1) : `xl/${a.Target.replace(/^\.\//, '')}`;
  }
  const sheets = [];
  for (const m of get('xl/workbook.xml').matchAll(/<sheet\b([^>]*?)\/?>/g)) {
    const a = attrs(m[1]);
    if (a.state === 'hidden' || a.state === 'veryHidden') continue;
    const rid = a['r:id'] || Object.entries(a).find(([k]) => /:id$/.test(k))?.[1];
    const path = rels[rid];
    if (!path || !files.has(path)) continue;
    sheets.push({ name: a.name || `Hoja ${sheets.length + 1}`, rows: sheetRows(get(path), shared) });
    if (sheets.length >= 20) break;
  }
  if (!sheets.length) fail('El archivo de Excel no tiene hojas con datos.');
  return sheets;
}

// ── De la tabla a los productos ──────────────────────────────
const norm = (s) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const IS_CODE = (h) => /^(cod|codigo|cdigo|codigos|sku|id|idproducto|codigoproducto|codigodelproducto|codigointerno|codigosku|skuproducto|codproducto|codigoarticulo|item|ref|referencia)$/.test(h) || /^(codigo|sku)/.test(h);
const IS_NAME = (h) => /^(nombre|nombres|producto|productos|nombreproducto|nombredelproducto|descripcion|descripciondelproducto|articulo|detalle|glosa|nombrecomercial)$/.test(h) || /^(nombre|descripcion|producto)/.test(h);
const IS_QTY = (h) => /^(cantidad|cantidades|cant|stock|unidades|unid|un|uds|existencia|existencias|inventario|conteo|qty|total|cantidadcontada|stockreal|stockfisico|saldo)$/.test(h) || /^(cantidad|stock|unidades|existencia)/.test(h);
const IS_COST = (h) => /^(pcosto|preciocosto|preciodecosto|costo|costos|costounitario|costoneto|pcompra|preciocompra|preciodecompra|cpp|valorcosto|costopromedio)$/.test(h) || /^(costo|preciocosto|pcosto)/.test(h);
const IS_PRICE = (h) => /^(pventa|precioventa|preciodeventa|precio|precios|pvp|preciopublico|precioalpublico|preciodelpublico|pventapublico|preciolista|preciodelista|preciounitario|valorventa|valor|pv|precioventapublico)$/.test(h) || /^(precioventa|pventa|precioalpublico|preciopublico)/.test(h);
const IS_DEPT = (h) => /^(departamento|departamentos|depto|dpto|categoria|categorias|familia|rubro|linea|seccion|grupo|subcategoria|tipo)$/.test(h);

/** Busca la fila de títulos (en las primeras 15 filas). Hace falta el código y al menos cantidad, precio o costo. */
export function findHeader(rows) {
  for (let r = 0; r < Math.min(rows.length, 15); r++) {
    const row = rows[r] || [];
    const c = { code: -1, name: -1, qty: -1, cost: -1, price: -1, dept: -1 };
    row.forEach((cell, i) => {
      const h = norm(cell);
      if (!h) return;
      if (c.code < 0 && IS_CODE(h)) c.code = i;
      else if (c.cost < 0 && IS_COST(h)) c.cost = i;
      else if (c.price < 0 && IS_PRICE(h)) c.price = i;
      else if (c.qty < 0 && IS_QTY(h)) c.qty = i;
      else if (c.dept < 0 && IS_DEPT(h)) c.dept = i;
      else if (c.name < 0 && IS_NAME(h)) c.name = i;
    });
    if (c.code >= 0 && (c.qty >= 0 || c.price >= 0 || c.cost >= 0)) return { row: r, ...c };
  }
  return null;
}

/** "SKU 420101", "'420101", "420101.0" → "420101". */
export function cleanCode(v) {
  let s = String(v ?? '').trim().replace(/^'+/, '').replace(/^sku\s*[:#-]?\s*/i, '').replace(/\s+/g, '');
  if (/^\d+[.,]0+$/.test(s)) s = s.replace(/[.,]0+$/, '');
  return s.toUpperCase();
}

/**
 * Cantidad escrita en la planilla → { qty } | { empty } | { error }.
 * Acepta "1.200" o "1 200" (miles), "12,0"; no acepta decimales ni negativos.
 */
export function parseQty(v) {
  const s = String(v ?? '').replace(/[\s ]/g, '');
  if (!s) return { empty: true };
  let t = s;
  if (/^-/.test(t)) return { error: 'La cantidad no puede ser negativa.' };
  if (/^\+/.test(t)) t = t.slice(1);
  if (/^\d{1,3}(,\d{3})+\.0+$/.test(t) || /^\d{1,3}(\.\d{3})+,0+$/.test(t)) t = t.replace(/[.,]0+$/, '').replace(/[.,]/g, '');
  else if (/^\d{1,3}([.,]\d{3})+$/.test(t)) t = t.replace(/[.,]/g, '');
  else if (/^\d+[.,]0+$/.test(t)) t = t.replace(/[.,]0+$/, '');
  if (/^\d+[.,]\d+$/.test(t)) return { error: 'La cantidad debe ser un número entero (sin decimales).' };
  if (!/^\d+$/.test(t)) return { error: `«${String(v).trim().slice(0, 20)}» no es una cantidad.` };
  const n = Number(t);
  if (n > MAX_QTY) return { error: `La cantidad máxima por fila es ${MAX_QTY.toLocaleString('es-CL')}.` };
  return { qty: n };
}

export const MAX_PRICE = 10000000;
/**
 * Precio escrito en la planilla (pesos) → { value } | { empty } | { error }.
 * Acepta "$2,830" (como lo exporta eleventa), "$2.830", "2830", "2.830,00" y "2830.00".
 */
export function parseMoney(v) {
  let t = String(v ?? '').replace(/[\s\u00a0]/g, '').replace(/^(clp|\$)+/i, '').replace(/\$/g, '');
  if (!t) return { empty: true };
  if (/^-/.test(t)) return { error: 'El precio no puede ser negativo.' };
  let n;
  if (/^\d+$/.test(t)) n = Number(t);
  else if (/^\d{1,3}(,\d{3})+(\.\d{1,2})?$/.test(t)) n = Number(t.replace(/,/g, ''));
  else if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(t)) n = Number(t.replace(/\./g, '').replace(',', '.'));
  else if (/^\d+[.,]\d{1,2}$/.test(t)) n = Number(t.replace(',', '.'));
  else return { error: `«${String(v).trim().slice(0, 20)}» no es un precio.` };
  n = Math.round(n);
  if (n > MAX_PRICE) return { error: 'El precio es demasiado alto.' };
  return { value: n };
}

/**
 * Filas de la planilla → [{ line, code, name, qtyText, costText, priceText, deptText }].
 * line es el número de fila como lo ve Excel (1 = primera fila).
 */
export function readTable(rows) {
  const h = findHeader(rows);
  let start;
  let cols;
  let noHeader = false;
  if (h) {
    start = h.row + 1;
    cols = h;
  } else {
    // Sin títulos: si parece Código | Nombre | Cantidad, se lee igual
    const first = rows.findIndex((r) => (r || []).some((c) => String(c).trim()));
    const r = rows[first] || [];
    const looksLike = first >= 0 && /^[A-Za-z0-9_-]{1,40}$/.test(cleanCode(r[0])) && /\d/.test(r[0]) && parseQty(r[2]).qty != null;
    if (!looksLike) fail('No encontramos los títulos en la primera fila. Escribe, de izquierda a derecha: Código, Nombre del producto y Cantidad (y si quieres, Precio costo y Precio venta).');
    start = first;
    cols = { code: 0, name: 1, qty: 2, cost: -1, price: -1, dept: -1 };
    noHeader = true;
  }
  const items = [];
  for (let r = start; r < rows.length; r++) {
    const row = rows[r] || [];
    const code = String(row[cols.code] ?? '').trim();
    const name = cols.name >= 0 ? String(row[cols.name] ?? '').trim() : '';
    const cell = (k) => (cols[k] >= 0 ? String(row[cols[k]] ?? '').trim() : '');
    const qtyText = cell('qty');
    const costText = cell('cost');
    const priceText = cell('price');
    const deptText = cell('dept');
    if (!code && !name && !qtyText && !costText && !priceText) continue;
    items.push({ line: r + 1, code, name, qtyText, costText, priceText, deptText });
    if (items.length > MAX_ROWS) fail(`La planilla tiene más de ${MAX_ROWS.toLocaleString('es-CL')} filas con datos. Divídela en archivos más chicos.`);
  }
  if (!items.length) fail('La planilla no tiene filas con productos debajo de los títulos.');
  const has = { qty: cols.qty >= 0, cost: cols.cost >= 0, price: cols.price >= 0, dept: cols.dept >= 0, name: cols.name >= 0 };
  return { items, noHeader, columns: cols, has };
}

/**
 * Un CSV abierto "mal" en Excel queda todo en la columna A ("420101;Paracetamol;10").
 * Si la hoja se ve así, se vuelve a separar.
 */
function unjoin(rows) {
  const filled = rows.filter((r) => (r || []).some((c) => String(c).trim())).slice(0, 10);
  const joined = filled.length && filled.every((r) => r.filter((c) => String(c).trim()).length === 1 && /[;\t,]/.test(r.find((c) => String(c).trim())));
  return joined ? parseCsv(rows.map((r) => (r || []).find((c) => String(c).trim()) || '').join('\n')) : rows;
}

/** Lee un archivo (bytes) y devuelve sus filas de productos. */
export async function readPlanilla(bytes) {
  if (!bytes || !bytes.length) fail('El archivo está vacío.');
  if (bytes.length > MAX_FILE_BYTES) fail('El archivo pesa más de 5 MB. Divídelo en archivos más chicos.');
  const kind = fileKind(bytes);
  if (kind === 'xls') fail('Este archivo es de una versión antigua de Excel (.xls). En Excel: Archivo › Guardar como › «Libro de Excel (.xlsx)» o «CSV», y súbelo de nuevo.');
  if (kind === 'xlsx') {
    const sheets = await parseXlsx(bytes);
    // La primera hoja que tenga los títulos (o la primera, si ninguna los tiene)
    const sheet = sheets.find((s) => findHeader(s.rows)) || sheets[0];
    return { kind, sheet: sheet.name, ...readTable(findHeader(sheet.rows) ? sheet.rows : unjoin(sheet.rows)) };
  }
  const text = decodeText(bytes);
  if (/\u0000/.test(text.slice(0, 2000))) fail('No pudimos leer el archivo. Súbelo como Excel (.xlsx) o CSV.');
  return { kind, sheet: '', ...readTable(parseCsv(text)) };
}

// ── Revisión contra los productos de la farmacia ─────────────
/** ¿El nombre escrito en la planilla se parece al del producto? */
export function nameMatches(fileName, productName) {
  const a = tokenize(fileName).filter((t) => t.length >= 3 || /^\d+$/.test(t));
  if (!a.length) return true;
  const b = tokenize(productName);
  const hit = a.filter((t) => b.some((u) => u === t || (t.length >= 4 && (u.startsWith(t) || t.startsWith(u))))).length;
  return hit / a.length >= 0.5;
}

/**
 * Revisa las filas contra los productos de la farmacia.
 * findProduct(code) → el producto o null. Con { create: true } los códigos que no
 * existen se pueden crear (si traen nombre y precio de venta).
 * → { rows, load, counts }
 *   rows[i].status: 'ok' (se actualiza) | 'new' (se crea) | 'warn' (se carga, revisar) | 'error' (no se carga) | 'empty' (no cambia)
 *   load: [{ p (o null si es nuevo), code, name, dept, qty?, cost?, price?, lines, warn }]
 */
export function checkItems(items, findProduct, { create = false } = {}) {
  const rows = [];
  const byKey = new Map();
  for (const it of items) {
    const row = { ...it, status: 'ok', msg: '', pid: null };
    rows.push(row);
    const code = cleanCode(it.code);
    const q = parseQty(it.qtyText);
    const c = parseMoney(it.costText);
    const pr = parseMoney(it.priceText);
    const nothing = q.empty && c.empty && pr.empty;
    if (!code) {
      const blank = nothing && !it.name;
      row.status = blank ? 'empty' : 'error';
      row.msg = blank ? 'Fila vacía.' : 'Falta el código del producto.';
      continue;
    }
    if (!/^[A-Z0-9_-]{1,40}$/.test(code)) { row.status = 'error'; row.msg = 'El código tiene caracteres que no se pueden usar (solo letras, números, guion y guion bajo).'; continue; }
    row.key = code;
    const p = findProduct(code);
    if (p) row.pid = p.id;
    const errs = [q.error, c.error, pr.error].filter(Boolean);
    if (errs.length) { row.status = 'error'; row.msg = errs.join(' '); continue; }
    if (pr.value === 0) { row.status = 'error'; row.msg = 'El precio de venta no puede ser $0.'; continue; }
    if (!p) {
      if (!create) { row.status = 'error'; row.msg = 'Este código no existe en la farmacia: no se carga.'; continue; }
      if (!it.name) { row.status = 'error'; row.msg = 'Producto nuevo sin nombre: no se puede crear.'; continue; }
      if (pr.empty) { row.status = 'error'; row.msg = 'Producto nuevo sin precio de venta: no se puede crear.'; continue; }
    } else if (nothing) {
      row.status = 'empty';
      row.msg = 'Sin cantidad ni precios: este producto no cambia.';
      continue;
    }
    if (q.qty != null) row.qty = q.qty;
    if (c.value != null) row.cost = c.value;
    if (pr.value != null) row.price = pr.value;
    if (p && it.name) {
      const full = [p.name, p.brand].filter(Boolean).join(' · ');
      if (!nameMatches(it.name, full)) row.mismatch = `El nombre de la planilla no coincide: con este código el producto es «${full}». Revisa el código.`;
    }
    const key = p ? p.id : `+${code}`;
    const e = byKey.get(key) || { p, code, name: it.name, dept: it.deptText || '', lines: [], rows: [] };
    if (row.qty != null) e.qty = Math.min(MAX_QTY, (e.qty || 0) + row.qty);
    if (row.cost != null) e.cost = row.cost;
    if (row.price != null) e.price = row.price;
    e.lines.push(it.line);
    e.rows.push(row);
    byKey.set(key, e);
  }
  for (const e of byKey.values()) {
    const n = e.rows.length;
    const dup = n > 1 ? `Aparece ${n} veces (filas ${e.lines.join(', ')})${e.qty != null ? `: se suman ${e.qty.toLocaleString('es-CL')} unidades` : ''}${e.rows.some((r) => r.price != null || r.cost != null) ? '; vale el último precio' : ''}.` : '';
    const priceNow = e.price ?? e.p?.price;
    const loss = e.cost != null && priceNow != null && e.cost > priceNow ? 'El costo es mayor que el precio de venta.' : '';
    for (const r of e.rows) {
      const msg = [dup, r.mismatch, loss].filter(Boolean).join(' ');
      if (msg) { r.status = 'warn'; r.msg = msg; } else if (!e.p) r.status = 'new';
      r.isNew = !e.p;
      delete r.mismatch;
    }
    e.warn = e.rows.some((r) => r.status === 'warn');
    delete e.rows;
  }
  const load = [...byKey.values()];
  const counts = { ok: 0, new: 0, warn: 0, error: 0, empty: 0 };
  for (const r of rows) counts[r.status]++;
  counts.create = load.filter((e) => !e.p).length;
  counts.update = load.length - counts.create;
  return { rows, load, counts };
}

// ── Planillas para descargar ─────────────────────────────────
/** Evita que Excel tome un texto como fórmula (=, +, -, @ al comienzo). */
const safeCell = (v) => (/^[=+\-@\t\r]/.test(String(v ?? '')) ? `'${v}` : String(v ?? ''));

/** CSV con ; (como lo abre Excel en Chile), UTF-8 con BOM para que respete tildes y ñ. */
export function planillaCsv(rows, headers = HEADERS) {
  const cell = (v) => {
    const s = safeCell(v);
    return /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return `﻿${[headers, ...rows].map((r) => r.map(cell).join(';')).join('\r\n')}\r\n`;
}

const colName = (i) => { let s = ''; let n = i + 1; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
const strCell = (ref, v, s) => {
  const t = escapeXml(v);
  return `<c r="${ref}" t="inlineStr"${s ? ` s="${s}"` : ''}><is><t${/^\s|\s$/.test(t) ? ' xml:space="preserve"' : ''}>${t}</t></is></c>`;
};

/** Columnas de la planilla que se descarga: Código | Nombre | Cantidad | Precio costo | Precio venta | Departamento. */
export const TEMPLATE_HEADERS = ['Código', 'Nombre del producto', 'Cantidad', 'Precio costo', 'Precio venta', 'Departamento'];
const COLS = [
  { w: 16, kind: 'code' },
  { w: 62, kind: 'text' },
  { w: 12, kind: 'int', max: MAX_QTY, msg: `Escribe un número entero entre 0 y ${MAX_QTY}, sin decimales.` },
  { w: 14, kind: 'money', max: MAX_PRICE, msg: 'Escribe el costo en pesos, sin decimales.' },
  { w: 14, kind: 'money', max: MAX_PRICE, msg: 'Escribe el precio de venta (al público) en pesos, sin decimales.' },
  { w: 26, kind: 'text' },
];

/**
 * Planilla .xlsx: hoja «Inventario» con las columnas de TEMPLATE_HEADERS (títulos en
 * negrita, fila fija, filtro y validación de números) y una hoja con instrucciones.
 * rows: [[código, nombre, cantidad, costo, venta, departamento]] (lo que falte queda en blanco)
 */
export function planillaXlsx(rows, { help = [], headers = TEMPLATE_HEADERS } = {}) {
  const nCols = headers.length;
  const last = Math.max(rows.length + 1, 2);
  const validTo = Math.max(last, 1000);
  const lastCol = colName(nCols - 1);
  const cellOf = (ci, n, v) => {
    const spec = COLS[ci] || { kind: 'text' };
    const ref = `${colName(ci)}${n}`;
    if (v === '' || v == null) return '';
    if (spec.kind === 'code') return strCell(ref, v, 2);
    if ((spec.kind === 'int' || spec.kind === 'money') && Number.isFinite(Number(v)) && String(v).trim() !== '') return `<c r="${ref}" s="${spec.kind === 'money' ? 4 : 3}"><v>${Math.round(Number(v))}</v></c>`;
    return strCell(ref, v);
  };
  const body = [
    `<row r="1">${headers.map((h, i) => strCell(`${colName(i)}1`, h, 1)).join('')}</row>`,
    ...rows.map((r, i) => `<row r="${i + 2}">${Array.from({ length: nCols }, (_, ci) => cellOf(ci, i + 2, r[ci])).join('')}</row>`),
  ].join('');
  const valid = COLS.slice(0, nCols).map((c, i) => ({ ...c, i })).filter((c) => c.kind === 'int' || c.kind === 'money');
  const sheet1 = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<dimension ref="A1:${lastCol}${last}"/>
<sheetViews><sheetView workbookViewId="0" tabSelected="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="C2" sqref="C2"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="15"/>
<cols>${headers.map((_, i) => `<col min="${i + 1}" max="${i + 1}" width="${(COLS[i] || { w: 16 }).w}" customWidth="1"/>`).join('')}</cols>
<sheetData>${body}</sheetData>
<autoFilter ref="A1:${lastCol}${last}"/>
${valid.length ? `<dataValidations count="${valid.length}">${valid.map((c) => `<dataValidation type="whole" operator="between" allowBlank="1" showErrorMessage="1" errorTitle="${escapeXml(headers[c.i])}" error="${escapeXml(c.msg)}" sqref="${colName(c.i)}2:${colName(c.i)}${validTo}"><formula1>0</formula1><formula2>${c.max}</formula2></dataValidation>`).join('')}</dataValidations>` : ''}
<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
</worksheet>`;
  const helpRows = help.map((line, i) => `<row r="${i + 1}">${strCell(`A${i + 1}`, line, i === 0 ? 1 : 0)}</row>`).join('');
  const sheet2 = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView workbookViewId="0"/></sheetViews>
<sheetFormatPr defaultRowHeight="15"/>
<cols><col min="1" max="1" width="110" customWidth="1"/></cols>
<sheetData>${helpRows}</sheetData>
<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
</worksheet>`;
  const withHelp = help.length > 0;
  const files = [
    ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>${withHelp ? '<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' : ''}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`],
    ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`],
    ['docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Inventario Farmacias Piedra</dc:title><dc:creator>Farmacias Piedra</dc:creator></cp:coreProperties>`],
    ['docProps/app.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Farmacias Piedra</Application></Properties>`],
    ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets><sheet name="Inventario" sheetId="1" r:id="rId1"/>${withHelp ? '<sheet name="Cómo llenarla" sheetId="2" r:id="rId2"/>' : ''}</sheets><definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">Inventario!$A$1:$${lastCol}$${last}</definedName></definedNames></workbook>`],
    ['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>${withHelp ? '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>' : ''}<Relationship Id="rId9" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
    ['xl/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF223D8F"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`],
    ['xl/worksheets/sheet1.xml', sheet1],
  ];
  if (withHelp) files.push(['xl/worksheets/sheet2.xml', sheet2]);
  return zip(files);
}

// Normalización de texto en español para el buscador.

// Minúsculas, sin tildes ni ñ, decimales con punto y sin símbolos.
export function fold(str) {
  return String(str ?? '')
    .toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/(\d),(\d)/g, '$1.$2')
    .replace(/[^a-z0-9.\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Separa en palabras. "500mg" → ["500","mg"], "b12" → ["b","12"].
export function tokenize(str) {
  return fold(str)
    .replace(/([a-z])(\d)/g, '$1 $2')
    .replace(/(\d)([a-z])/g, '$1 $2')
    .split(' ')
    .map((t) => t.replace(/^\.+|\.+$/g, ''))
    .filter(Boolean);
}

export const isNumeric = (t) => /^\d+(\.\d+)?$/.test(t);

// Raíz liviana para plurales: "pañales"→"panal", "jarabes"→"jarabe", "sobres"/"sobre"→"sobr".
export function stem(t) {
  if (!t || t.length <= 3 || isNumeric(t) || /(is|us)$/.test(t)) return t;
  let s = t.endsWith('s') ? t.slice(0, -1) : t;
  if (s.length > 3 && /[lnrdjz]e$/.test(s)) s = s.slice(0, -1);
  return s;
}

// Clave fonética para el español: une letras que suenan igual.
// "paqazetami" → "pakasetami"   "paracetamol" → "parasetamol"
// "amoxisilina" = "amoxicilina" → "amoksisilina"   "ivuprofeno" = "ibuprofeno"
export function phonetic(w) {
  if (!w || isNumeric(w)) return w;
  let s = w;
  s = s.replace(/ph/g, 'f').replace(/th/g, 't').replace(/sh/g, 's');
  s = s.replace(/ch/g, '#');
  s = s.replace(/qu([ei])/g, 'k$1').replace(/q/g, 'k');
  s = s.replace(/c([ei])/g, 's$1').replace(/c/g, 'k');
  s = s.replace(/z/g, 's');
  s = s.replace(/^x/, 's').replace(/x/g, 'ks');
  s = s.replace(/gu([ei])/g, 'G$1').replace(/g([ei])/g, 'j$1').replace(/G/g, 'g');
  s = s.replace(/v/g, 'b').replace(/w/g, 'u');
  s = s.replace(/ll/g, 'y').replace(/y$/, 'i').replace(/y([^aeiou])/g, 'i$1');
  s = s.replace(/h/g, '');
  s = s.replace(/#/g, 'c');
  s = s.replace(/n([bp])/g, 'm$1');
  s = s.replace(/(.)\1+/g, '$1');
  return s;
}

// Resalta (con <mark>) las partes de un texto que calzan con las palabras buscadas.
export function highlight(text, terms, esc) {
  const safe = esc(text);
  if (!terms || !terms.length) return safe;
  const folded = fold(text);
  // Mapa de posiciones: fold() no cambia la longitud salvo espacios colapsados,
  // así que trabajamos carácter a carácter sobre una versión alineada.
  const aligned = String(text).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (aligned.length !== String(text).length) return safe;
  const marks = new Array(text.length).fill(false);
  for (const term of terms) {
    if (!term || term.length < 2) continue;
    let from = 0;
    for (;;) {
      const i = aligned.indexOf(term, from);
      if (i < 0) break;
      const before = i === 0 ? ' ' : aligned[i - 1];
      if (!/[a-z0-9]/.test(before)) for (let k = i; k < i + term.length; k++) marks[k] = true;
      from = i + 1;
    }
  }
  if (!marks.some(Boolean) || !folded) return safe;
  let out = '';
  let open = false;
  for (let i = 0; i < text.length; i++) {
    if (marks[i] && !open) { out += '<mark>'; open = true; }
    if (!marks[i] && open) { out += '</mark>'; open = false; }
    out += esc(text[i]);
  }
  if (open) out += '</mark>';
  return out;
}

// Operaciones de la tienda que dependen de la sesión: carro, favoritos y contexto de precios.

import { state, emit, currentUser, isMember } from './state.js';
import { byId } from './catalog.js';
import { RULES } from '../config.js';
import { cartTotals } from './pricing.js';
import { treatmentSet } from './account.js';

export const maxQty = (p) => (p.rx !== 'directa' ? RULES.maxQtyRx : RULES.maxQty);
export const qtyOf = (id) => state.cart.find((l) => l.id === id)?.qty || 0;
export const cartCount = () => state.cart.reduce((a, l) => a + l.qty, 0);

export function setQty(id, qty) {
  const p = byId.get(id);
  if (!p) return 0;
  // Receta cheque: solo venta presencial, nunca entra al carro online.
  const q = p.rx === 'cheque' || p.hidden ? 0 : Math.max(0, Math.min(maxQty(p), Math.floor(Number(qty) || 0)));
  const line = state.cart.find((l) => l.id === id);
  if (!q) state.cart = state.cart.filter((l) => l.id !== id);
  else if (line) line.qty = q;
  else state.cart.push({ id, qty: q, at: Date.now() });
  emit('cart', { id, qty: q });
  return q;
}

export const addToCart = (id, n = 1) => setQty(id, qtyOf(id) + n);
export const removeFromCart = (id) => setQty(id, 0);

export function clearCart() {
  state.cart = [];
  state.coupon = null;
  emit('cart', {});
}

export function cartItems() {
  return state.cart.map((l) => ({ product: byId.get(l.id), qty: l.qty })).filter((x) => x.product);
}

export function priceCtx() {
  const u = currentUser();
  return {
    member: isMember(),
    treatment: treatmentSet(),
    date: new Date(),
    coupon: state.coupon,
    ordersCount: u ? state.orders.filter((o) => o.userEmail === u.email && !o.cancelled).length : state.orders.filter((o) => !o.cancelled).length,
  };
}

export const totals = () => cartTotals(cartItems(), priceCtx());

export function setCoupon(code) {
  state.coupon = code ? String(code).trim().toUpperCase() : null;
  emit('cart', { coupon: state.coupon });
}

export const isFav = (id) => state.favorites.includes(id);
export function toggleFav(id) {
  const i = state.favorites.indexOf(id);
  if (i >= 0) state.favorites.splice(i, 1);
  else state.favorites.unshift(id);
  emit('favorites', { id, on: i < 0 });
  return i < 0;
}

export function addRecent(q) {
  const v = String(q || '').trim();
  if (!v) return;
  state.recent = [v, ...state.recent.filter((x) => x.toLowerCase() !== v.toLowerCase())].slice(0, 6);
  emit('recent');
}

export function clearRecent() {
  state.recent = [];
  emit('recent');
}

export function setLocation(region, comuna) {
  state.location = { region, comuna };
  state.seenLocation = true;
  emit('location', state.location);
}

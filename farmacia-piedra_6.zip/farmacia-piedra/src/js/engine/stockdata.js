// Registro del catálogo administrado (stock, precios, visibilidad y productos
// nuevos que cambia el administrador). Lo leen el inventario y el panel.
//
// Ubicaciones de stock: "o:<zona>" = bodega online de una zona de despacho,
// "s:<id farmacia>" = una farmacia.

import { state } from './state.js';

let overrides = new Map();

export const getOverride = (id) => overrides.get(id) || null;
export const allOverrides = () => overrides;
export function setOverridesMap(m) { overrides = m; }

// Compras de prueba hechas en este navegador cuando la tienda funciona sin
// servidor (archivo de demostración): se descuentan solo aquí. Con servidor,
// el stock lo descuenta el servidor y esta lista queda vacía.
export function localSold(pid, loc, since = 0) {
  const list = state.localSales;
  if (!list || !list.length) return 0;
  let n = 0;
  for (const s of list) if (s.pid === pid && s.loc === loc && s.at > since) n += s.qty;
  return n;
}

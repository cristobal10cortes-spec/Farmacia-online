// Stock por farmacia y en bodega online, horarios, turnos y plazos de entrega.
// El stock de ejemplo de las bodegas online es determinístico (siempre el mismo
// para un producto). Las farmacias las crea el administrador: parten sin stock.

import { STORES } from '../data/stores.js';
import { regionById, regionOfComuna } from '../data/regions.js';
import { RULES, ZONES } from '../config.js';
import { santiago, addDays, dayLabel, hhmm, DAYS } from './format.js';
import { getOverride, localSold } from './stockdata.js';

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function zoneOf(location) {
  const r = regionById(location?.region) || regionOfComuna(location?.comuna);
  return r?.zone || 'RM';
}

// Stock de ejemplo (determinístico) para productos que el administrador aún no toca
export function sampleOnlineStock(p, zone) {
  if (p.rx === 'cheque') return 0;
  const h = hash(`${zone}|${p.id}`) % 100;
  if (h < 6) return 0;
  return 5 + (h % 40);
}

// Unidades que hay (lo que fijó el administrador, o el de ejemplo en bodegas)
// menos las ventas que solo conoce este navegador. Lo usan el panel y el servidor.
export function onlineStockRaw(p, zone) {
  if (p.rx === 'cheque') return 0;
  const ov = getOverride(p.id);
  const v = ov?.stock?.o?.[zone];
  const base = v != null ? v : p.custom ? 0 : sampleOnlineStock(p, zone);
  return Math.max(0, base - localSold(p.id, `o:${zone}`, ov?.stockAt || 0));
}

export function storeStockRaw(p, store) {
  const ov = getOverride(p.id);
  const v = ov?.stock?.s?.[store.id];
  return Math.max(0, (v != null ? v : 0) - localSold(p.id, `s:${store.id}`, ov?.stockAt || 0));
}

// Unidades a la venta (un producto oculto no se vende, aunque tenga stock)
export const onlineStock = (p, zone) => (p.hidden ? 0 : onlineStockRaw(p, zone));
export const storeStock = (p, store) => (p.hidden ? 0 : storeStockRaw(p, store));

// Farmacias de la comuna primero y luego del resto de la región
export function storesNear(location) {
  const region = regionById(location?.region) || regionOfComuna(location?.comuna);
  const list = STORES.filter((s) => s.region === region?.id);
  return list.sort((a, b) => (b.comuna === location.comuna) - (a.comuna === location.comuna) || a.name.localeCompare(b.name, 'es'))
    .map((s) => ({ ...s, inComuna: s.comuna === location.comuna }));
}

const hoursFor = (store, weekday) => (weekday === 0 ? store.hours.sun : weekday === 6 ? store.hours.sat : store.hours.wk);

/** Fecha de hoy en Santiago ('AAAA-MM-DD'). */
export function isoToday(now = new Date()) {
  const t = santiago(now);
  return `${t.year}-${String(t.month).padStart(2, '0')}-${String(t.day).padStart(2, '0')}`;
}

// Farmacia de turno: los días que indicó el administrador (ese día atiende toda la noche)
export function isTurno(store, now = new Date()) {
  if (store.h24 || !store.turnos?.length) return false;
  return store.turnos.includes(isoToday(now));
}

export function storeStatus(store, now = new Date()) {
  const s = santiago(now);
  const turno = isTurno(store, now);
  if (store.h24) return { open: true, h24: true, turno: false, label: 'Abierta las 24 horas' };
  if (turno) return { open: true, h24: false, turno: true, label: 'De turno hoy: abierta toda la noche' };
  const t = s.hour + s.minute / 60;
  const today = hoursFor(store, s.weekday);
  if (today && t >= today[0] && t < today[1]) {
    return { open: true, turno: false, label: `Abierta · cierra a las ${hhmm(today[1])}`, closes: today[1] };
  }
  if (today && t < today[0]) return { open: false, turno: false, label: `Cerrada · abre hoy a las ${hhmm(today[0])}` };
  for (let i = 1; i <= 7; i++) {
    const wd = (s.weekday + i) % 7;
    const h = hoursFor(store, wd);
    if (h) return { open: false, turno: false, label: `Cerrada · abre ${i === 1 ? 'mañana' : `el ${DAYS[wd]}`} a las ${hhmm(h[0])}` };
  }
  return { open: false, turno: false, label: 'Cerrada' };
}

export function hoursText(store) {
  if (store.h24) return 'Abierta las 24 horas, todos los días';
  const f = (h) => (h ? `${hhmm(h[0])} a ${hhmm(h[1])}` : 'cerrado');
  return `Lun a vie ${f(store.hours.wk)} · Sáb ${f(store.hours.sat)} · Dom ${f(store.hours.sun)}`;
}

function addBusinessDays(now, n) {
  let found = 0;
  let step = 0;
  let cal = addDays(now, 0);
  while (found < n) {
    step++;
    cal = addDays(now, step);
    if (cal.weekday !== 0) found++;
  }
  return cal;
}

/**
 * Opciones de despacho para una ubicación.
 * opts: { hasCold, now }
 */
export function deliveryInfo(location, opts = {}) {
  const now = opts.now || new Date();
  const s = santiago(now);
  const zone = zoneOf(location);
  const z = ZONES[zone];
  const out = { zone, zoneName: z.name, home: { ok: true }, express: { ok: false } };
  if (RULES.noDeliveryComunas.includes(location.comuna)) {
    out.home = { ok: false, reason: `Por ahora no despachamos a domicilio en ${location.comuna}.${STORES.length ? ' Puedes retirar en farmacia.' : ''}` };
    return out;
  }
  if (opts.hasCold && !RULES.coldChainZones.includes(zone)) {
    out.home = { ok: false, reason: STORES.length ? 'Hay productos refrigerados: en tu zona solo se pueden retirar en farmacia.' : 'Hay productos refrigerados: por ahora solo los despachamos en la Región Metropolitana.' };
    return out;
  }
  const days = z.days + (s.hour >= 20 ? 1 : 0);
  const cal = addBusinessDays(now, days);
  out.home = { ok: true, days, date: cal, label: dayLabel(cal, s) };
  if (RULES.expressComunas.includes(location.comuna) && s.weekday !== 0 && s.hour >= 8 && s.hour < RULES.expressCutoffHour) {
    out.express = { ok: true, label: `Hoy entre las ${hhmm(s.hour + 1)} y las ${hhmm(s.hour + 3)}` };
  } else if (RULES.expressComunas.includes(location.comuna)) {
    out.express = { ok: false, reason: `El despacho express se puede pedir de lunes a sábado entre 08:00 y ${hhmm(RULES.expressCutoffHour)}.` };
  }
  return out;
}

// ¿Una farmacia tiene todo el carro? ¿Cuándo se puede retirar?
export function pickupInfo(store, items, now = new Date()) {
  const s = santiago(now);
  const zone = regionById(store.region)?.zone || 'RM';
  const missing = items.filter(({ product, qty }) => storeStock(product, store) < qty);
  // Lo que falta en la farmacia se trae desde la bodega de la zona, si alcanza.
  const short = missing.filter(({ product, qty }) => storeStock(product, store) + onlineStock(product, zone) < qty);
  if (short.length) {
    return { ready: false, unavailable: true, missing: short, label: `Sin stock suficiente: ${short.map((x) => x.product.name).join(', ')}` };
  }
  // date: día de retiro (AAAA-MM-DD); from: desde qué hora
  const iso = (cal) => `${cal.year}-${String(cal.month).padStart(2, '0')}-${String(cal.day).padStart(2, '0')}`;
  if (missing.length) {
    const cal = addBusinessDays(now, 2);
    return { ready: false, missing, label: `Disponible ${dayLabel(cal, s)} (lo traemos desde bodega)`, date: iso(cal), from: '', fromStock: true };
  }
  const t = s.hour + s.minute / 60;
  const ready = Math.ceil((t + RULES.pickupReadyHours) * 2) / 2;
  const st = storeStatus(store, now);
  if (store.h24 || st.turno) {
    if (ready < 23.5) return { ready: true, missing: [], label: `Retira hoy desde las ${hhmm(ready)}`, date: iso(addDays(now, 0)), from: `desde las ${hhmm(ready)}` };
    return { ready: true, missing: [], label: 'Retira mañana desde las 08:00', date: iso(addDays(now, 1)), from: 'desde las 08:00' };
  }
  const today = hoursFor(store, s.weekday);
  if (today) {
    const start = Math.max(ready, today[0] + 1);
    if (start <= today[1] - 0.5) return { ready: true, missing: [], label: `Retira hoy desde las ${hhmm(start)}`, date: iso(addDays(now, 0)), from: `desde las ${hhmm(start)}` };
  }
  for (let i = 1; i <= 7; i++) {
    const wd = (s.weekday + i) % 7;
    const h = hoursFor(store, wd);
    if (h) return { ready: true, missing: [], label: `Retira ${i === 1 ? 'mañana' : `el ${DAYS[wd]}`} desde las ${hhmm(h[0] + 1)}`, date: iso(addDays(now, i)), from: `desde las ${hhmm(h[0] + 1)}` };
  }
  return { ready: false, missing: [], label: 'Sin horario disponible' };
}

// Disponibilidad de un producto en la ubicación elegida (para fichas y tarjetas)
export function productAvailability(p, location, now = new Date()) {
  const zone = zoneOf(location);
  const del = deliveryInfo(location, { hasCold: p.cold, now });
  const online = onlineStock(p, zone);
  const near = storesNear(location);
  const withStock = near.filter((st) => storeStock(p, st) > 0);
  const inComuna = withStock.filter((st) => st.inComuna);
  const noStores = !STORES.length;
  return {
    noStores,
    online,
    delivery: {
      ok: p.rx !== 'cheque' && del.home.ok && online > 0,
      text: p.rx === 'cheque' ? 'Solo venta presencial'
        : !del.home.ok ? del.home.reason
          : online > 0 ? `Llega ${del.home.label}` : 'Sin stock para despacho',
    },
    pickup: {
      ok: p.rx !== 'cheque' && withStock.length > 0,
      count: withStock.length,
      inComuna: inComuna.length,
      text: noStores ? 'Por ahora vendemos solo con despacho a domicilio'
        : withStock.length
          ? `Disponible en ${withStock.length} ${withStock.length === 1 ? 'farmacia' : 'farmacias'}${inComuna.length ? ` (${inComuna.length} en ${location.comuna})` : ' de tu región'}`
          : near.length ? 'Sin stock en farmacias de tu región' : 'No hay farmacias en tu región',
    },
    stores: near.map((st) => ({ store: st, stock: storeStock(p, st), status: storeStatus(st, now) })),
  };
}

// Productos del carro que superan el stock de despacho de una zona
export function deliveryShortages(items, zone) {
  return items
    .map(({ product, qty }) => ({ product, qty, available: onlineStock(product, zone) }))
    .filter((x) => x.available < x.qty);
}

// De dónde sale cada unidad vendida: despacho = bodega de la zona; retiro =
// la farmacia elegida y, si no alcanza, la bodega de su zona.
export function stockMovesFor(items, delivery) {
  const moves = [];
  for (const { product, qty } of items) {
    if (delivery.type === 'retiro') {
      const store = STORES.find((x) => x.id === delivery.storeId);
      const zone = regionById(store?.region)?.zone || 'RM';
      const fromStore = store ? Math.min(qty, storeStock(product, store)) : 0;
      if (fromStore > 0) moves.push({ pid: product.id, loc: `s:${store.id}`, qty: fromStore });
      if (qty - fromStore > 0) moves.push({ pid: product.id, loc: `o:${zone}`, qty: qty - fromStore });
    } else {
      moves.push({ pid: product.id, loc: `o:${delivery.zone}`, qty });
    }
  }
  return moves;
}

// Servicio de catálogo: búsqueda, filtros, facetas, orden y relaciones entre productos.

import { PRODUCTS, normalizeProduct, slugify } from '../data/products.js';
import { CATEGORIES, ALL_SUBS, categoryById, subById } from '../data/categories.js';
import { NAMES, BRANDS, NEEDS, STOPWORDS, WEAK_WORDS } from '../data/synonyms.js';
import { SearchIndex } from './search.js';
import { fold } from './text.js';

// PRODUCTS = productos visibles en la tienda (se actualiza en el lugar).
// byId / bySlug incluyen también los ocultos y los creados en el panel.
const BASE = PRODUCTS.slice();
export const byId = new Map(PRODUCTS.map((p) => [p.id, p]));
export const bySlug = new Map(PRODUCTS.map((p) => [p.slug, p]));

export const SYNONYM_GROUPS = [
  ...NAMES.map((g) => ({ ...g, kind: 'nombre' })),
  ...BRANDS.map((g) => ({ ...g, kind: 'marca' })),
  ...NEEDS.map((g) => ({ ...g, kind: 'necesidad' })),
];

function categoryNames(p) {
  const out = [];
  const c = categoryById(p.cat);
  const s = subById(p.cat, p.sub);
  if (c) out.push(c.name);
  if (s) out.push(s.name);
  for (const a of p.also) {
    const as = subById(a.cat, a.sub);
    if (as) out.push(as.name);
  }
  return out;
}

function categoryKeywords(p) {
  const s = subById(p.cat, p.sub);
  return [...(categoryById(p.cat)?.keywords || []), ...(s?.keywords || [])];
}

function buildIndex() {
  const maxPop = Math.max(1, ...PRODUCTS.map((p) => p.popularity));
  return new SearchIndex({
    docs: PRODUCTS.slice(),
    fields: [
      { weight: 10, get: (p) => p.name },
      { weight: 9, get: (p) => p.ingredients },
      { weight: 7, get: (p) => p.brand },
      { weight: 5, get: (p) => p.tags.map((t) => t.replace(/_/g, ' ')) },
      { weight: 2, get: (p) => categoryNames(p) },
      { weight: 4, get: (p) => [p.form, p.variant ? `talla ${p.variant}` : ''] },
      { weight: 1, get: (p) => categoryKeywords(p) },
      { weight: 1, get: (p) => p.desc },
    ],
    synonyms: SYNONYM_GROUPS,
    stopwords: STOPWORDS,
    weakWords: WEAK_WORDS,
    boost: (p) => p.popularity / maxPop,
  });
}

export let productIndex = buildIndex();
// Sube cada vez que cambian precios, productos o visibilidad (para refrescar cachés)
export let catalogVersion = 0;

/** Subcategorías con productos a la venta ("cat/sub"); las marcadas onlyIfUsed se muestran solo si tienen. */
let usedCache = { v: -1, set: null };
export function usedSubs() {
  if (usedCache.v !== catalogVersion || !usedCache.set) {
    const set = new Set();
    for (const p of PRODUCTS) {
      set.add(`${p.cat}/${p.sub}`);
      for (const a of p.also) set.add(`${a.cat}/${a.sub}`);
    }
    usedCache = { v: catalogVersion, set };
  }
  return usedCache.set;
}
export const subsOf = (c) => (c?.subs || []).filter((s) => !s.onlyIfUsed || usedSubs().has(`${c.id}/${s.id}`));

/** Todos los productos, incluidos los ocultos (para el panel). */
export const allProducts = () => [...byId.values()];

function uniqueSlug(base, id) {
  let slug = base || `producto-${id.toLowerCase()}`;
  let n = 2;
  while (bySlug.has(slug) && bySlug.get(slug).id !== id) slug = `${base}-${n++}`;
  return slug;
}

const hiddenSig = () => [...byId.values()].filter((p) => p.hidden).map((p) => p.id).sort().join(',');

/**
 * Aplica lo que definió el administrador: precios, ofertas, productos ocultos
 * y productos nuevos. `overrides` es un Map id → documento.
 * Devuelve los ids que dejaron de estar a la venta (ocultos o eliminados).
 */
export function applyCatalogOverrides(overrides) {
  const before = hiddenSig();
  let structural = false;
  // 1) Volver a los valores originales
  for (const p of byId.values()) {
    if (p._orig) { p.price = p._orig.price; p.offer = p._orig.offer; }
    p.hidden = false;
    delete p.photo;
  }
  // 2) Productos creados en el panel
  const wanted = new Set();
  for (const [id, o] of overrides) {
    if (!o || !o.def || !o.def.n || !o.def.c) continue;
    wanted.add(id);
    const cur = byId.get(id);
    const sig = JSON.stringify(o.def);
    if (cur && cur._sig === sig) continue;
    const slugBase = slugify(`${o.def.n} ${o.def.b || ''}`);
    const slug = cur && cur._slugBase === slugBase ? cur.slug : uniqueSlug(slugBase, id);
    let p;
    try { p = normalizeProduct(o.def, id, slug); } catch { continue; }
    Object.assign(p, { custom: true, _sig: sig, _slugBase: slugBase, createdAt: o.createdAt || 0 });
    if (cur) bySlug.delete(cur.slug);
    byId.set(id, p);
    bySlug.set(slug, p);
    structural = true;
  }
  const gone = [];
  for (const p of [...byId.values()]) {
    if (p.custom && !wanted.has(p.id)) {
      byId.delete(p.id);
      bySlug.delete(p.slug);
      gone.push(p.id);
      structural = true;
    }
  }
  // 3) Precios, ofertas y visibilidad
  for (const [id, o] of overrides) {
    const p = byId.get(id);
    if (!p || !o) continue;
    if (o.priceSet && o.price > 0) {
      if (!p._orig) p._orig = { price: p.price, offer: p.offer };
      p.price = Math.round(o.price);
      p.offer = o.offer && o.offer < o.price ? Math.round(o.offer) : null;
    }
    if (o.hidden) p.hidden = true;
    // Foto propia: solo se guarda su versión y medida (la imagen la entrega el servidor)
    if (o.photo && /^[a-z0-9]{1,20}$/.test(String(o.photo.v || ''))) p.photo = { v: String(o.photo.v), w: Number(o.photo.w) || 0, h: Number(o.photo.h) || 0 };
  }
  if (hiddenSig() !== before) structural = true;
  // 4) Lista visible y buscador
  const customs = [...byId.values()].filter((p) => p.custom).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  PRODUCTS.length = 0;
  for (const p of [...BASE, ...customs]) if (!p.hidden) PRODUCTS.push(p);
  if (structural) productIndex = buildIndex();
  catalogVersion++;
  return [...gone, ...[...byId.values()].filter((p) => p.hidden).map((p) => p.id)];
}

const CAT_DOCS = [
  ...CATEGORIES.map((c) => ({ id: c.id, type: 'cat', name: c.name, keywords: c.keywords, path: `/categoria/${c.id}` })),
  ...ALL_SUBS.map((s) => ({ id: `${s.cat}/${s.id}`, type: 'sub', name: s.name, parent: s.catName, keywords: s.keywords, path: `/categoria/${s.cat}/${s.id}` })),
];

export const categoryIndex = new SearchIndex({
  docs: CAT_DOCS,
  fields: [{ weight: 10, get: (d) => d.name }, { weight: 6, get: (d) => d.keywords }],
  stopwords: STOPWORDS,
});

// ── Utilidades de producto ───────────────────────────────────
export const salePrice = (p) => (p.offer && p.offer < p.price ? p.offer : p.price);
export const discountPct = (p) => (p.offer && p.offer < p.price ? Math.round((1 - p.offer / p.price) * 100) : 0);
export const inCategory = (p, cat, sub) => (p.cat === cat && (!sub || p.sub === sub)) || p.also.some((a) => a.cat === cat && (!sub || a.sub === sub));
export const getProduct = (key) => bySlug.get(key) || byId.get(key) || null;

const ingKey = (p) => p.ingredients.map(fold).sort().join('+');
const strengthKey = (p) => fold(p.strength).replace(/\s/g, '');

// Productos con el mismo principio activo (y misma concentración si se pide)
export function alternativesFor(p, { sameStrength = true } = {}) {
  if (!p.ingredients.length || !p.isMedicine) return [];
  const k = ingKey(p);
  return PRODUCTS.filter((x) => x.id !== p.id && x.isMedicine && ingKey(x) === k && (!sameStrength || strengthKey(x) === strengthKey(p)))
    .sort((a, b) => unitPrice(a) - unitPrice(b));
}

export const unitPrice = (p) => salePrice(p) / Math.max(1, p.units);

// ¿Tiene alternativa bioequivalente (u otra opción equivalente)?
export function hasBioequivalent(p) {
  return alternativesFor(p).some((x) => x.be);
}

export function variantsOf(p) {
  if (!p.group) return [];
  return PRODUCTS.filter((x) => x.group === p.group);
}

export function relatedTo(p, n = 10) {
  const differs = (x) => x.id !== p.id && (!p.group || x.group !== p.group);
  const bySub = PRODUCTS.filter((x) => differs(x) && x.cat === p.cat && x.sub === p.sub)
    .sort((a, b) => b.popularity - a.popularity);
  if (bySub.length >= n) return bySub.slice(0, n);
  const byCat = PRODUCTS.filter((x) => differs(x) && x.cat === p.cat && x.sub !== p.sub)
    .sort((a, b) => b.popularity - a.popularity);
  return [...bySub, ...byCat].slice(0, n);
}

export function bestSellers(n = 12, pred = () => true) {
  return PRODUCTS.filter(pred).sort((a, b) => b.popularity - a.popularity).slice(0, n);
}

export function onSale(n = 12, pred = () => true) {
  return PRODUCTS.filter((p) => (p.offer || p.promo) && p.rx === 'directa' && pred(p))
    .sort((a, b) => (discountPct(b) + (b.promo ? 30 : 0)) - (discountPct(a) + (a.promo ? 30 : 0)) || b.popularity - a.popularity)
    .slice(0, n);
}

export function allBrands() {
  const m = new Map();
  for (const p of PRODUCTS) m.set(p.brand, (m.get(p.brand) || 0) + 1);
  return [...m.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => a.name.localeCompare(b.name, 'es'));
}

export function allIngredients() {
  const m = new Map();
  for (const p of PRODUCTS) {
    if (!p.isMedicine) continue;
    for (const ing of p.ingredients) {
      const k = fold(ing);
      const cur = m.get(k) || { key: k, name: ing, count: 0, be: 0, minPrice: Infinity };
      cur.count++;
      if (p.be) cur.be++;
      cur.minPrice = Math.min(cur.minPrice, salePrice(p));
      m.set(k, cur);
    }
  }
  return [...m.values()].sort((a, b) => a.name.localeCompare(b.name, 'es'));
}

// ── Listado con búsqueda, filtros, facetas y orden ───────────
export const SORTS = [
  { id: 'relevancia', label: 'Más relevantes', needsQuery: true },
  { id: 'destacados', label: 'Destacados' },
  { id: 'mas-vendidos', label: 'Más vendidos' },
  { id: 'ofertas', label: 'Mayor descuento' },
  { id: 'precio-asc', label: 'Precio: menor a mayor' },
  { id: 'precio-desc', label: 'Precio: mayor a menor' },
  { id: 'nombre-asc', label: 'Nombre: A - Z' },
  { id: 'nombre-desc', label: 'Nombre: Z - A' },
];

export const PRICE_RANGES = [
  { id: '0-4999', label: 'Hasta $4.999', min: 0, max: 4999 },
  { id: '5000-9999', label: '$5.000 a $9.999', min: 5000, max: 9999 },
  { id: '10000-19999', label: '$10.000 a $19.999', min: 10000, max: 19999 },
  { id: '20000-', label: 'Desde $20.000', min: 20000, max: Infinity },
];

const RX_ORDER = ['directa', 'simple', 'retenida', 'cheque'];

/**
 * @param {object} o
 * q, cat, sub, view ('ofertas'|'bioequivalentes'), filters: { marca:[], venta:[], be, oferta, formato:[], activo:[], precio }
 * sort, page, size, isAvailable(p) → boolean (stock online)
 */
export function listProducts(o) {
  const filters = o.filters || {};
  let search = null;
  let base;
  if (o.q && o.q.trim()) {
    search = productIndex.search(o.q);
    const score = new Map(search.items.map((it) => [it.id, it.score]));
    base = search.items.map((it) => byId.get(it.id)).filter(Boolean);
    base.score = score;
  } else {
    base = PRODUCTS.slice();
  }
  if (o.cat) base = base.filter((p) => inCategory(p, o.cat, o.sub));
  if (o.view === 'ofertas') base = base.filter((p) => (p.offer || p.promo) && p.rx === 'directa');
  if (o.view === 'bioequivalentes') base = base.filter((p) => p.be);

  const tests = {
    marca: (p) => !filters.marca?.length || filters.marca.includes(p.brand),
    venta: (p) => !filters.venta?.length || filters.venta.includes(p.rx),
    be: (p) => !filters.be || p.be,
    oferta: (p) => !filters.oferta || !!(p.offer || p.promo),
    formato: (p) => !filters.formato?.length || filters.formato.includes(formatGroup(p)),
    activo: (p) => !filters.activo?.length || p.ingredients.some((i) => filters.activo.includes(fold(i))),
    precio: (p) => {
      if (!filters.precio) return true;
      const r = PRICE_RANGES.find((x) => x.id === filters.precio);
      const v = salePrice(p);
      return !r || (v >= r.min && v <= r.max);
    },
    sub: (p) => !filters.sub?.length || filters.sub.includes(`${p.cat}/${p.sub}`),
    stock: (p) => !filters.stock || !o.isAvailable || o.isAvailable(p),
  };
  const keys = Object.keys(tests);
  const passAll = (p, except) => keys.every((k) => k === except || tests[k](p));

  const facets = {
    sub: countBy(base.filter((p) => passAll(p, 'sub')), (p) => `${p.cat}/${p.sub}`),
    marca: countBy(base.filter((p) => passAll(p, 'marca')), (p) => p.brand),
    venta: countBy(base.filter((p) => passAll(p, 'venta')), (p) => p.rx),
    formato: countBy(base.filter((p) => passAll(p, 'formato')), formatGroup),
    activo: countBy(base.filter((p) => passAll(p, 'activo')), (p) => p.ingredients.map(fold)),
    precio: countBy(base.filter((p) => passAll(p, 'precio')), (p) => PRICE_RANGES.find((r) => salePrice(p) >= r.min && salePrice(p) <= r.max)?.id),
    be: base.filter((p) => passAll(p, 'be') && p.be).length,
    oferta: base.filter((p) => passAll(p, 'oferta') && (p.offer || p.promo)).length,
  };
  facets.venta.sort((a, b) => RX_ORDER.indexOf(a.key) - RX_ORDER.indexOf(b.key));

  let items = base.filter((p) => passAll(p));
  const sort = o.sort || (search ? 'relevancia' : 'destacados');
  items = sortProducts(items, sort, base.score);

  const size = [12, 24, 48].includes(+o.size) ? +o.size : 24;
  const pages = Math.max(1, Math.ceil(items.length / size));
  const page = Math.min(Math.max(1, +o.page || 1), pages);
  return {
    total: items.length,
    items: items.slice((page - 1) * size, page * size),
    all: items,
    page, pages, size, sort,
    facets,
    search,
  };
}

export function sortProducts(items, sort, score) {
  const arr = items.slice();
  const name = (p) => p.name;
  switch (sort) {
    case 'relevancia':
      if (score) return arr.sort((a, b) => (score.get(b.id) || 0) - (score.get(a.id) || 0));
      return arr.sort((a, b) => b.popularity - a.popularity);
    case 'mas-vendidos': return arr.sort((a, b) => b.popularity - a.popularity);
    case 'ofertas': return arr.sort((a, b) => discountPct(b) + (b.promo ? 25 : 0) - (discountPct(a) + (a.promo ? 25 : 0)) || b.popularity - a.popularity);
    case 'precio-asc': return arr.sort((a, b) => salePrice(a) - salePrice(b));
    case 'precio-desc': return arr.sort((a, b) => salePrice(b) - salePrice(a));
    case 'nombre-asc': return arr.sort((a, b) => name(a).localeCompare(name(b), 'es'));
    case 'nombre-desc': return arr.sort((a, b) => name(b).localeCompare(name(a), 'es'));
    default: // destacados: popularidad con un empujón a las ofertas
      return arr.sort((a, b) => (b.popularity + (b.offer || b.promo ? 150 : 0)) - (a.popularity + (a.offer || a.promo ? 150 : 0)));
  }
}

function countBy(list, keyFn) {
  const m = new Map();
  for (const p of list) {
    const k = keyFn(p);
    for (const key of Array.isArray(k) ? k : [k]) if (key) m.set(key, (m.get(key) || 0) + 1);
  }
  return [...m.entries()].map(([key, count]) => ({ key, count })).sort((a, b) => b.count - a.count || String(a.key).localeCompare(String(b.key), 'es'));
}

// Agrupa formatos parecidos para el filtro "Formato"
export function formatGroup(p) {
  const f = fold(p.form);
  if (/comprimido|capsula|tableta|ovulo|supositorio/.test(f)) return 'Comprimidos y cápsulas';
  if (/jarabe|suspension|solucion oral/.test(f)) return 'Jarabes y suspensiones';
  if (/gotas/.test(f)) return 'Gotas';
  if (/crema|gel|unguento|balsamo|pasta|locion|fluido|emulsion|aceite/.test(f)) return 'Cremas, geles y lociones';
  if (/spray|nasal|inhalador|espuma/.test(f)) return 'Sprays e inhaladores';
  if (/sobre|polvo/.test(f)) return 'Sobres y polvos';
  if (/shampoo|acondicionador|micelar|limpiador|enjuague|jabon/.test(f)) return 'Higiene';
  if (/panal|toallita|toalla|aposito|protector|mascarilla|tampon/.test(f)) return 'Pañales y desechables';
  return 'Otros';
}

export const rxOrder = RX_ORDER;
export { PRODUCTS };

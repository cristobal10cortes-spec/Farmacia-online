// Farmacias del panel: validación de la ficha y conversión de horarios.
// La usan el panel (formulario) y el servidor (que no confía en lo que llega).

import { regionById } from '../data/regions.js';

const ID = /^F[0-9A-Z]{2,20}$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const DAY_NAMES = { wk: 'lunes a viernes', sat: 'sábado', sun: 'domingo' };
const txt = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

export const validStoreId = (id) => ID.test(String(id || ''));
export const newStoreId = () => `F${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 1296).toString(36).toUpperCase().padStart(2, '0')}`;

/** 'HH:MM' → horas (8:30 → 8.5). Un cierre a las 00:00 significa medianoche (24). */
export function timeToHours(v, { closing = false } = {}) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(v || '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 24 || min > 59 || (h === 24 && min > 0)) return null;
  let x = h + min / 60;
  if (closing && x === 0) x = 24;
  return Math.round(x * 4) / 4;
}

/** Horas → 'HH:MM' (24 → '00:00'). */
export function hoursToTime(x) {
  const t = Math.round(Number(x) * 60);
  return `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
}

function daysBefore(iso, n) {
  const d = new Date(`${iso}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}

/**
 * Deja solo campos conocidos y con el formato correcto.
 * today ('AAAA-MM-DD'): se descartan los días de turno de hace más de un mes.
 * Devuelve { store } o { error }.
 */
export function cleanStore(input = {}, { today = '' } = {}) {
  const region = regionById(String(input.region || ''));
  const recetario = input.recetario === true || (Array.isArray(input.services) && input.services.includes('recetario'));
  const s = {
    id: String(input.id || ''),
    name: txt(input.name, 60),
    address: txt(input.address, 100),
    region: region ? region.id : '',
    comuna: txt(input.comuna, 60),
    phone: txt(input.phone, 20),
    h24: input.h24 === true,
    services: recetario ? ['retiro', 'recetario'] : ['retiro'],
    hours: { wk: null, sat: null, sun: null },
    turnos: [],
  };
  if (s.id && !ID.test(s.id)) return { error: 'La farmacia tiene un identificador inválido.' };
  if (!s.name) return { error: 'Escribe el nombre de la farmacia.' };
  if (!s.address) return { error: 'Escribe la dirección (calle y número).' };
  if (!region) return { error: 'Elige la región.' };
  if (!region.comunas.includes(s.comuna)) return { error: 'Elige una comuna de la región.' };
  if (s.phone && !/^[+\d ()-]{6,20}$/.test(s.phone)) return { error: 'El teléfono solo puede tener números, espacios y el signo +.' };
  const hours = input.hours && typeof input.hours === 'object' ? input.hours : {};
  for (const k of ['wk', 'sat', 'sun']) {
    const h = hours[k];
    if (h == null || h === false) continue;
    if (!Array.isArray(h) || h.length !== 2) return { error: `Revisa el horario de ${DAY_NAMES[k]}.` };
    const a = Math.round(Number(h[0]) * 4) / 4;
    const b = Math.round(Number(h[1]) * 4) / 4;
    if (!(a >= 0 && b <= 24 && a < b)) return { error: `Revisa el horario de ${DAY_NAMES[k]}: la hora de cierre debe ser después de la de apertura.` };
    s.hours[k] = [a, b];
  }
  if (!s.h24 && !s.hours.wk && !s.hours.sat && !s.hours.sun) return { error: 'Indica el horario de al menos un día, o marca «Abierta las 24 horas».' };
  const days = Array.isArray(input.turnos) ? input.turnos.map(String).filter((d) => DAY.test(d)) : [];
  const from = today ? daysBefore(today, 31) : '';
  s.turnos = s.h24 ? [] : [...new Set(days)].filter((d) => !from || d >= from).sort().slice(-400);
  return { store: s };
}

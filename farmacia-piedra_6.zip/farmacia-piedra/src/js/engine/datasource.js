// Datos que administra el dueño (stock, precios, productos nuevos, banners,
// farmacias y tarjetas del menú).
// La tienda pública solo los LEE: se cambian en el panel de administración,
// que es una aplicación aparte que vive en el servidor, con usuario y contraseña.
//
// De dónde vienen:
//  • 'api'    servidor de Farmacias Piedra (sitio oficial). La página lo indica
//             con <meta name="piedra-api" content="/api">.
//  • 'local'  página abierta sin servidor (archivo o vista previa): datos de
//             ejemplo; las compras de prueba se guardan solo en ese navegador.

import { state, emit } from './state.js';
import { applyCatalogOverrides } from './catalog.js';
import { setOverridesMap } from './stockdata.js';
import { liveFrom, setMediaBase } from './bannerlist.js';
import { liveServices } from './services.js';
import { liveMenuCards } from './menucards.js';
import { setPhotoBase } from '../ui/art.js';
import { setStores } from '../data/stores.js';
import { syncRemoteOrder } from './orders.js';
import { progressKey } from './orderflow.js';

export const ds = {
  mode: 'connecting', // 'connecting' | 'api' | 'local'
  ready: false,
  bannersReady: false, // ya se sabe qué banners mostrar
  banners: [],
  menuReady: false, // ya se saben las tarjetas del menú «Categorías»
  menu: [],
  services: null, // «Servicios Piedra» guardados en el panel (null = los de ejemplo)
  version: null,
  error: null,
};

export function apiBase() {
  if (typeof document === 'undefined') return '';
  const v = document.querySelector('meta[name="piedra-api"]')?.getAttribute('content') || '';
  return v.trim().replace(/\/+$/, '');
}

export const remote = () => ds.mode === 'api';
export const liveBanners = () => liveFrom(ds.banners);
/** Banners de más abajo (los recuadros grandes después de «Ofertas destacadas»). */
export const livePromos = () => liveFrom(ds.banners, 'promo');
/** «Servicios Piedra»: { title, items } que se ven hoy. */
export const servicesNow = () => liveServices(ds.services);
/** Tarjetas del menú «Categorías» que se ven hoy (ninguna mientras cargan). */
export const liveMenu = () => (ds.menuReady ? liveMenuCards(ds.menu) : []);

function setCatalog(m) {
  setOverridesMap(m);
  const off = applyCatalogOverrides(m);
  // Lo que ya no se vende sale de los carros
  if (off.length && state.cart.some((l) => off.includes(l.id))) {
    state.cart = state.cart.filter((l) => !off.includes(l.id));
    emit('cart', {});
  }
  emit('catalog');
}

function bannersLoaded(list) {
  ds.banners = Array.isArray(list) ? list : [];
  ds.bannersReady = true;
  emit('banners');
}

function menuLoaded(list) {
  ds.menu = Array.isArray(list) ? list : [];
  ds.menuReady = true;
  emit('menu');
}

// ── Servidor ─────────────────────────────────────────────────
async function request(path, { method = 'GET', body, timeout = 20000 } = {}) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeout) : null;
  let res;
  try {
    res = await fetch(`${apiBase()}${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json', Accept: 'application/json' } : { Accept: 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
      cache: 'no-store',
      credentials: 'omit',
      signal: ctrl?.signal,
    });
  } catch {
    const e = new Error('No pudimos conectarnos con la farmacia. Revisa tu conexión e inténtalo de nuevo.');
    e.code = 'network';
    throw e;
  } finally {
    if (timer) clearTimeout(timer);
  }
  if (res.status === 304) return { notModified: true };
  let data = null;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) {
    const e = new Error(data?.error || 'No pudimos completar la operación. Inténtalo de nuevo.');
    e.code = data?.code || `http_${res.status}`;
    e.data = data;
    throw e;
  }
  return data;
}

/** Trae del servidor los precios, el stock y los banners vigentes. */
export async function refreshCatalog() {
  if (ds.mode !== 'api') return;
  try {
    const r = await request(`/catalog${ds.version != null ? `?v=${encodeURIComponent(ds.version)}` : ''}`);
    if (r.notModified || r.unchanged || (r.version != null && r.version === ds.version)) return;
    ds.version = r.version;
    ds.error = null;
    setStores(r.stores || []); // farmacias que administra el dueño
    setCatalog(new Map(Object.entries(r.overrides || {})));
    ds.services = r.services && Array.isArray(r.services.items) ? r.services : null;
    bannersLoaded(r.banners || []);
    menuLoaded(r.menu || []);
    ds.ready = true;
  } catch (e) {
    ds.error = e.code || 'network';
    if (!ds.ready) {
      // Sin servidor: la tienda sigue funcionando con los datos de ejemplo
      ds.ready = true;
      bannersLoaded([]);
      menuLoaded([]);
    }
  }
}

export function submitOrder(payload) {
  return request('/orders', { method: 'POST', body: payload, timeout: 45000 });
}

export function fetchRemoteOrder(id, email) {
  return request(`/orders/${encodeURIComponent(id)}?email=${encodeURIComponent(email || '')}`);
}

// Pedidos hechos en este navegador: se revisa si la farmacia los avanzó (como máximo cada 30 s)
let ordersCheckedAt = 0;
export async function refreshRemoteOrders(list) {
  if (ds.mode !== 'api' || Date.now() - ordersCheckedAt < 30000) return;
  ordersCheckedAt = Date.now();
  for (const o of (list || []).filter((x) => x.remote && x.customer?.email).slice(0, 8)) {
    try {
      const r = await fetchRemoteOrder(o.id, o.customer.email);
      if (r?.order && progressKey(r.order) !== progressKey(o)) syncRemoteOrder(r.order);
    } catch { /* sin conexión: se intenta la próxima vez */ }
  }
}

export function cancelRemoteOrder(id, email) {
  return request(`/orders/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: { email } });
}

// ── Inicio ───────────────────────────────────────────────────
export async function initDataSource() {
  if (apiBase()) {
    ds.mode = 'api';
    setPhotoBase(`${apiBase()}/fotos/`); // fotos de productos que sube el administrador
    setMediaBase(`${apiBase()}/imagenes/`); // fotos de banners y tarjetas del menú
    // El servidor lleva el stock real: las ventas de prueba de este navegador ya no cuentan
    if (state.localSales?.length) state.localSales = [];
    emit('backoffice');
    await refreshCatalog();
    // Cambios del panel: se revisan cada minuto y al volver a la pestaña
    setInterval(refreshCatalog, 60000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCatalog(); });
    return;
  }
  ds.mode = 'local';
  ds.ready = true;
  bannersLoaded([]);
  menuLoaded([]);
  emit('backoffice');
}

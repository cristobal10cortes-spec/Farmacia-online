// Página de inicio.

import { $, $$, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { rail } from '../ui/components.js';
import { FAQ } from '../data/content.js';
import { heroCarouselHtml, mountHeroCarousel, withLiveText, promoGridHtml } from '../ui/banners.js';
import { ds, liveBanners, livePromos, servicesNow } from '../engine/datasource.js';
import { CATEGORIES } from '../data/categories.js';
import { onSale, bestSellers, allBrands } from '../engine/catalog.js';
import { activeCampaigns } from '../engine/pricing.js';
import { CLUB } from '../config.js';

const heroSlides = () => liveBanners().map(withLiveText);

export function homePage() {
  const slides = heroSlides();
  const services = servicesNow();
  const camp = activeCampaigns()[0];
  const tiles = [{ id: 'ofertas', name: 'Ofertas', icon: 'percent', to: '/ofertas', sale: true }, ...CATEGORIES.map((c) => ({ id: c.id, name: c.name, icon: c.icon, to: `/categoria/${c.id}` }))];
  const brands = allBrands().filter((b) => !b.name.startsWith('Piedra') && !b.name.startsWith('Lab.') && !['Austral Pharma', 'Genéricos del Pacífico', 'Vet Andes'].includes(b.name)).sort((a, b) => b.count - a.count).slice(0, 14);
  const faqs = FAQ.flatMap((g) => g.items.slice(0, 1).map((it) => ({ ...it, g: g.id }))).slice(0, 4);
  const html = `<div class="wrap page">
    <h1 class="visually-hidden">Farmacias Piedra: farmacia online</h1>
    ${ds.bannersReady ? heroCarouselHtml(slides) : '<div class="hero hero--loading" aria-hidden="true"></div>'}

    ${camp ? `<div class="today">${`<span class="today__tag">${icon('star')}Hoy en el Club</span>`}<span><b>${esc(camp.title)}:</b> ${esc(camp.text)}.</span><a href="#/club" data-link>Ver beneficios</a></div>` : ''}

    <section aria-labelledby="cats-t" style="display:grid;gap:14px">
      <h2 class="sec-title" id="cats-t">Compra por categoría</h2>
      <div class="cats">${tiles.map((t) => `<a class="cat-tile${t.sale ? ' cat-tile--sale' : ''}" href="#${t.to}" data-link><span class="cat-tile__ico">${icon(t.icon)}</span>${esc(t.name)}</a>`).join('')}</div>
    </section>

    ${rail('Ofertas destacadas', onSale(14), { href: '/ofertas', sub: 'Precios de internet y promociones por cantidad.' })}

    ${ds.bannersReady ? promoGridHtml(livePromos()) : ''}

    ${rail('Lo más vendido', bestSellers(14), { href: '/buscar?orden=mas-vendidos', sub: 'Lo que más compran nuestros clientes esta semana.' })}

    ${services.items.length ? `<section aria-labelledby="svc-t" style="display:grid;gap:14px">
      <h2 class="sec-title" id="svc-t">${esc(services.title)}</h2>
      <div class="services" style="--cols:${Math.min(6, services.items.length)}">${services.items.map((s) => `<a class="service" href="#${esc(s.to)}" data-link>${icon(s.icon)}<b>${esc(s.title)}</b>${s.text ? `<span>${esc(s.text)}</span>` : ''}</a>`).join('')}</div>
    </section>` : ''}

    ${rail('Dermocosmética', bestSellers(14, (p) => p.cat === 'dermocosmetica'), { href: '/categoria/dermocosmetica', sub: 'Protección solar, limpieza e hidratación.' })}
    ${rail('Vitaminas y suplementos', bestSellers(14, (p) => p.cat === 'vitaminas-y-suplementos'), { href: '/categoria/vitaminas-y-suplementos' })}
    ${rail('Mundo bebé', bestSellers(14, (p) => p.cat === 'infantil-y-mama'), { href: '/categoria/infantil-y-mama' })}

    <section aria-labelledby="brands-t" style="display:grid;gap:14px">
      <div class="sec-head"><h2 class="sec-title" id="brands-t">Marcas destacadas</h2><a class="link-more" href="#/marcas" data-link>Todas las marcas ${icon('arrowRight')}</a></div>
      <div class="brands-strip">${brands.map((b) => `<a class="brand-pill" href="#/buscar?marca=${encodeURIComponent(b.name)}" data-link>${esc(b.name)}</a>`).join('')}</div>
    </section>

    <section aria-labelledby="faq-t" style="display:grid;gap:14px">
      <div class="sec-head"><h2 class="sec-title" id="faq-t">Preguntas frecuentes</h2><a class="link-more" href="#/ayuda" data-link>Centro de ayuda ${icon('arrowRight')}</a></div>
      <div>${faqs.map((f) => `<details class="acc"><summary>${esc(f.q)}${icon('chevronDown')}</summary><div class="acc__body"><p>${esc(f.a)}</p></div></details>`).join('')}</div>
    </section>
  </div>`;

  return {
    title: 'Farmacia online',
    rerender: ['user', 'location', 'catalog', 'banners'],
    html,
    mount(root) {
      return mountHeroCarousel($('#hero', root));
    },
  };
}

export { CLUB };

// Panel → ficha de un pedido: etapas (confirmar y embalar, en camino o listo
// para retiro, entregado), fecha de entrega y mensajes que ve el cliente.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { dateTime } from '../engine/format.js';
import { orderTimeline } from '../engine/orders.js';
import { isManaged, flowOf, statusOf, statusInfo, nextStatus, prevStatus, actionLabel, deliveryWhen, dateText, todayIso, messageForSending } from '../engine/orderflow.js';
import { mailtoHref, whatsappHref } from '../engine/contact.js';
import { findAdminOrder, setOrderStatus, setDeliveryDate, adminCancelOrder, friendlyError } from '../admin/api.js';

const NEXT_HELP = {
  embalaje: 'Revisa el pedido (y la receta, si tiene). Al confirmarlo, el cliente ve «Pedido confirmado» y que lo estás preparando.',
  camino: 'Cuando el pedido salga a reparto, márcalo en camino: el cliente ve la fecha en que llega.',
  listo: 'Cuando esté embalado y listo en la farmacia, avísale que puede retirarlo.',
  entregado: 'Márcalo cuando el cliente ya lo tenga en sus manos.',
};

function stepper(o) {
  const flow = flowOf(o);
  const cur = flow.indexOf(statusOf(o));
  return `<ol class="ostep" aria-label="Etapas del pedido">${flow.map((k, i) => `<li class="ostep__item${i < cur ? ' is-done' : ''}${i === cur ? ' is-current' : ''}"><span class="ostep__dot">${i <= cur ? icon('check') : i + 1}</span><span>${esc(statusInfo(o, k).short === 'Por confirmar' ? 'Recibido' : statusInfo(o, k).short)}</span></li>`).join('')}</ol>`;
}

function messagesHtml(o) {
  const list = (o.messages || []).slice().reverse();
  if (!list.length) return '';
  const c = o.customer || {};
  return `<div class="omsg"><h3 class="omsg__title">${icon('chat')} Mensajes que ve el cliente en su seguimiento</h3>
    <ol class="omsg__list">${list.map((m, i) => {
      const body = messageForSending(o, m);
      const mail = mailtoHref(c.email, `${m.title} · pedido ${o.id}`, body);
      const wa = whatsappHref(c.phone, body);
      return `<li class="omsg__item${i === 0 ? ' is-last' : ''}"><div><b>${esc(m.title)}</b><span>${esc(m.text)}</span><small>${esc(dateTime(m.at))}</small></div>
        ${i === 0 && m.kind !== 'recibido' ? `<div class="omsg__send"><span>Avísale también:</span>${mail ? `<a class="btn btn--soft btn--sm" href="${esc(mail)}" data-send="correo">${icon('mail')} Correo</a>` : ''}${wa ? `<a class="btn btn--soft btn--sm" href="${esc(wa)}" target="_blank" rel="noopener noreferrer" data-send="whatsapp">${icon('chat')} WhatsApp</a>` : ''}</div>` : ''}</li>`;
    }).join('')}</ol></div>`;
}

export function orderFlowHtml(o) {
  const tl = orderTimeline(o);
  const d = o.delivery || {};
  const pickup = d.type === 'retiro';
  // Pedidos de antes (sin etapas): se pueden empezar a manejar desde aquí
  const managed = isManaged(o);
  const next = o.cancelled ? null : nextStatus(o);
  const prev = o.cancelled ? null : prevStatus(o);
  const status = statusOf(o);
  const canDate = !o.cancelled && status !== 'entregado';
  const head = o.cancelled
    ? `<span class="chip chip--danger">Anulado</span>`
    : `<span class="chip chip--${status === 'entregado' ? 'ok' : status === 'recibido' ? 'warn' : 'info'}">${esc(statusInfo(o).short)}</span>`;
  return `<section class="panel oflow" id="oflow">
    <div class="panel__head"><h2 class="panel__title">Etapa del pedido</h2>${head}</div>
    ${o.cancelled ? notice('danger', `Pedido anulado el ${esc(dateTime(o.cancelledAt))}. Las unidades volvieron al stock.`) : stepper(o)}
    ${!managed && !o.cancelled ? '<p class="field__hint">Este pedido es de antes de las etapas: al marcar la siguiente, el cliente empieza a ver los mensajes.</p>' : ''}
    ${next ? `<div class="oflow__next">
      <p class="oflow__help">${icon('info')} ${esc(NEXT_HELP[next] || '')}</p>
      <label class="field oflow__note"><span>Mensaje adicional para el cliente <span class="field__opt">(opcional)</span></span><textarea id="of-note" rows="2" maxlength="300" placeholder="${next === 'camino' ? 'Ej: El repartidor llega entre las 15:00 y las 18:00.' : next === 'embalaje' ? 'Ej: Tu receta está correcta.' : 'Ej: Te esperamos hasta las 21:00.'}"></textarea></label>
      <div class="oflow__btns"><button type="button" class="btn btn--primary" data-flow="${esc(next)}">${icon(next === 'embalaje' ? 'box' : next === 'camino' ? 'truck' : next === 'listo' ? 'store' : 'checkCircle')} ${esc(actionLabel(o, next))}</button>
      ${prev ? `<button type="button" class="btn btn--link btn--sm" data-flow-back="${esc(prev)}">Volver a «${esc(statusInfo(o, prev).short === 'Por confirmar' ? 'Pedido recibido' : statusInfo(o, prev).short)}»</button>` : ''}</div>
    </div>` : !o.cancelled ? `${notice('ok', `${pickup ? 'Pedido retirado' : 'Pedido entregado'}${o.deliveredAt ? ` el ${esc(dateTime(o.deliveredAt))}` : ''}.`)}${prev ? `<button type="button" class="btn btn--link btn--sm" data-flow-back="${esc(prev)}">Volver a «${esc(statusInfo(o, prev).short)}»</button>` : ''}` : ''}
    <div class="oflow__date">
      <div><small>${pickup ? 'Retiro' : 'Entrega'}</small><b id="of-when">${esc(deliveryWhen(o) || 'Sin fecha')}</b></div>
      ${canDate ? `<form class="oflow__dateform" id="of-date" novalidate>
        <label class="visually-hidden" for="of-date-in">Nueva fecha</label>
        <input type="date" id="of-date-in" name="date" min="${todayIso()}" value="${esc(d.date || '')}" required>
        <button type="submit" class="btn btn--ghost btn--sm">${icon('calendar')} Cambiar fecha</button>
      </form>` : ''}
    </div>
    ${messagesHtml(o)}
    ${!o.cancelled && !tl.done ? `<div class="oflow__cancel"><button type="button" class="btn btn--ghost btn--sm" data-cancel>${icon('x')} Anular y reponer stock</button></div>` : ''}
  </section>`;
}

/** Botones de etapas, fecha y anular. `onChange` se llama después de cada cambio. */
export function mountOrderFlow(root, id, onChange) {
  const repaint = () => {
    const o = findAdminOrder(id);
    const box = $('#oflow', root);
    if (o && box) box.outerHTML = orderFlowHtml(o);
    onChange?.(o);
  };
  root.addEventListener('click', async (e) => {
    const fwd = e.target.closest('[data-flow]');
    const back = e.target.closest('[data-flow-back]');
    const cancel = e.target.closest('[data-cancel]');
    if (!fwd && !back && !cancel) return;
    const o = findAdminOrder(id);
    if (!o) return;
    try {
      if (cancel) {
        if (!(await confirmDialog({ title: '¿Anular este pedido?', text: `Se anulará <b>${esc(o.id)}</b> y sus unidades volverán al stock. Si se pagó con tarjeta, corresponde devolver el monto. El cliente verá el aviso en su seguimiento.`, confirmText: 'Anular pedido', danger: true }))) return;
        if (await adminCancelOrder(o)) toast('Anulaste el pedido y repusimos el stock.', { tone: 'info' });
      } else if (back) {
        if (!(await confirmDialog({ title: '¿Volver a la etapa anterior?', text: 'Úsalo si marcaste una etapa por error. El cliente no recibe un mensaje nuevo.', confirmText: 'Volver atrás' }))) return;
        back.disabled = true;
        await setOrderStatus(o.id, back.dataset.flowBack);
        toast('El pedido volvió a la etapa anterior.', { tone: 'info' });
      } else {
        fwd.disabled = true;
        const note = $('#of-note', root)?.value.trim() || '';
        await setOrderStatus(o.id, fwd.dataset.flow, note);
        const after = findAdminOrder(id);
        toast(`Listo: <b>${esc(statusInfo(after || o, fwd.dataset.flow).short)}</b>. El cliente ya ve el mensaje en su seguimiento; si quieres, avísale también por correo o WhatsApp.`);
      }
    } catch (err) {
      toast(esc(friendlyError(err)), { tone: 'warn', timeout: 6000 });
    }
    repaint();
  });
  root.addEventListener('submit', async (e) => {
    if (!e.target.matches('#of-date')) return;
    e.preventDefault();
    const o = findAdminOrder(id);
    const v = e.target.date.value;
    if (!o || !v) { e.target.date.focus(); return; }
    if (v < todayIso()) { toast('La fecha no puede ser anterior a hoy.', { tone: 'warn' }); return; }
    const btn = e.target.querySelector('button');
    btn.disabled = true;
    try {
      await setDeliveryDate(o.id, v);
      toast(`Cambiaste la fecha a <b>${esc(dateText(v))}</b>. El cliente ya la ve en su seguimiento.`);
    } catch (err) {
      toast(esc(friendlyError(err)), { tone: 'warn', timeout: 6000 });
    }
    repaint();
  });
}

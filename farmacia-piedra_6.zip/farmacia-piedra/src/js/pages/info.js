// Club Piedra, bioequivalentes, marcas, ayuda, textos legales y página no encontrada.

import { $, $$, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { breadcrumbs, rail, pebbles, notice, emptyState, field, beSeal } from '../ui/components.js';
import { CLUB, BRAND } from '../config.js';
import { FAQ, LEGAL, LEGAL_LINKS } from '../data/content.js';
import { CATEGORIES } from '../data/categories.js';
import { PRODUCTS, allBrands, allIngredients, unitPrice, salePrice, productIndex, byId } from '../engine/catalog.js';
import { activeCampaigns, clubDiscount, priceInfo } from '../engine/pricing.js';
import { priceCtx } from '../engine/shop.js';
import { fold } from '../engine/text.js';
import { state, currentUser } from '../engine/state.js';
import { joinClub } from '../engine/account.js';
import { faqSearch } from '../engine/assistant.js';
import { clp, DAYS, santiago } from '../engine/format.js';
import { validEmail, validateRut } from '../engine/rut.js';
import { toast } from '../ui/overlay.js';
import { go } from '../router.js';

const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

// ── Club Piedra ──────────────────────────────────────────────
export function clubPage(params, query) {
  const u = currentUser();
  const today = santiago().weekday;
  const order = [1, 2, 3, 4, 5, 6, 0];
  const clubToday = PRODUCTS.filter((p) => clubDiscount(p, { date: new Date() }).pct > 0).sort((a, b) => b.popularity - a.popularity).slice(0, 14);
  const cta = !u ? '<a class="btn btn--lg" href="#/registro?volver=%2Fclub" data-link>Inscríbete gratis</a>'
    : !u.club ? '<button type="button" class="btn btn--lg" data-join>Unirme al Club</button>'
      : `<span class="btn btn--lg" aria-disabled="true">${icon('check')} Ya eres socio</span>`;
  const html = `<div class="wrap page">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Club Piedra' }])}
    <section class="club-hero">
      <div class="club-hero__copy">
        <span class="hero__eyebrow">Gratis con tu RUT</span>
        <h1>Club Piedra</h1>
        <p>Precios Club en la web y en farmacias, campañas distintas cada día de la semana y ${CLUB.treatmentPct}% permanente en tus medicamentos crónicos con Mi Tratamiento.</p>
        ${cta}
      </div>
      ${pebbles()}
    </section>
    <section style="display:grid;gap:14px" aria-labelledby="week-t">
      <div class="sec-head"><div><h2 class="sec-title" id="week-t">Beneficios de la semana</h2><p class="sec-sub">Descuentos exclusivos para socios en compras online. No acumulables con otras promociones.</p></div></div>
      <div class="week">${order.map((d) => {
        const c = CLUB.campaigns.find((x) => x.days.includes(d));
        return `<div class="day${d === today ? ' is-today' : ''}${c ? '' : ' day--empty'}"><span class="day__name">${DAYS[d]}</span>${c ? `<span class="day__pct">${c.pct}%</span><b>${esc(c.title)}</b><span class="day__txt">${esc(c.text)}</span>` : '<span class="day__txt">Precios Club en productos seleccionados.</span>'}</div>`;
      }).join('')}</div>
    </section>
    <section class="programs" aria-label="Programas">
      <div class="program" id="tratamiento">${icon('refresh')}<h3>Mi Tratamiento</h3><p>Inscribe hasta ${CLUB.treatmentMax} medicamentos de uso crónico con receta simple (presión, colesterol, diabetes, tiroides…) y paga siempre ${CLUB.treatmentPct}% menos.</p><a class="btn btn--club btn--sm" href="#/cuenta/tratamiento" data-link>Inscribir productos</a></div>
      <div class="program">${icon('star')}<h3>Precio Club</h3><p>Productos con precio especial para socios todos los días, marcado con la etiqueta dorada <span class="price__club"><b>Club</b> $</span> en cada producto.</p><a class="btn btn--club btn--sm" href="#/ofertas" data-link>Ver ofertas</a></div>
      <div class="program">${icon('file')}<h3>Recetas guardadas</h3><p>Guarda tus recetas en tu cuenta y adjúntalas en un clic cuando vuelvas a comprar.</p><a class="btn btn--club btn--sm" href="#/cuenta/recetas" data-link>Mis recetas</a></div>
    </section>
    ${rail('Con precio Club hoy', clubToday, { sub: 'Descuentos que aplican hoy a socios del Club.' })}
    <section style="display:grid;gap:12px"><h2 class="sec-title">Preguntas sobre el Club</h2>
      <div>${FAQ.find((g) => g.id === 'club').items.map((f) => `<details class="acc"><summary>${esc(f.q)}${icon('chevronDown')}</summary><div class="acc__body"><p>${esc(f.a)}</p></div></details>`).join('')}</div>
    </section>
  </div>`;
  return {
    title: 'Club Piedra',
    rerender: ['user', 'location'],
    html,
    mount(root) {
      root.addEventListener('click', (e) => {
        if (e.target.closest('[data-join]')) { joinClub(); toast('¡Ya eres socio del Club Piedra!'); }
      });
      if (query.ver === 'tratamiento') requestAnimationFrame(() => document.getElementById('tratamiento')?.scrollIntoView({ block: 'center' }));
      return null;
    },
  };
}

// ── Bioequivalentes ──────────────────────────────────────────
function compareTable(key) {
  const prods = PRODUCTS.filter((p) => p.isMedicine && p.ingredients.some((i) => fold(i) === key));
  if (!prods.length) return emptyState({ icon: 'scale', title: 'No encontramos ese principio activo', text: 'Revisa cómo se escribe o elige uno de la lista.' });
  const groups = new Map();
  for (const p of prods) {
    const k = `${p.ingredients.map(cap).join(' + ')} ${p.strength} · ${p.form}`;
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(p);
  }
  const ctx = priceCtx();
  return [...groups.entries()].map(([k, list]) => {
    list.sort((a, b) => unitPrice(a) - unitPrice(b));
    const maxU = unitPrice(list[list.length - 1]);
    return `<div style="display:grid;gap:8px"><h3 style="font-size:17px">${esc(k)}</h3><div class="table-wrap"><table class="table">
      <thead><tr><th>Producto</th><th>Bioequivalente</th><th class="num">Por unidad</th><th class="num">Precio</th><th></th></tr></thead>
      <tbody>${list.map((p, i) => {
        const save = Math.round((maxU - unitPrice(p)) * p.units);
        return `<tr${i === 0 && list.length > 1 ? ' class="is-current"' : ''}>
          <td><a href="#/producto/${p.slug}" data-link style="display:flex;gap:10px;align-items:center;color:inherit;text-decoration:none"><img src="${productImg(p)}" alt="" width="44" height="44" style="width:44px;height:44px;border-radius:8px;background:var(--tile)"><span><b style="display:block;font-size:12px;color:var(--muted);letter-spacing:.06em;text-transform:uppercase">${esc(p.brand)}</b>${esc(p.name)}${i === 0 && list.length > 1 ? ' <span class="chip chip--ok">Más conveniente</span>' : ''}</span></a></td>
          <td>${p.be ? beSeal() : '<span class="muted">—</span>'}</td>
          <td class="num">${clp(unitPrice(p))}</td>
          <td class="num"><b>${clp(priceInfo(p, ctx).sale)}</b>${save > 0 ? `<br><span style="color:var(--ok);font-size:12.5px;font-weight:700">Ahorras ${clp(save)}</span>` : ''}</td>
          <td><button type="button" class="btn btn--soft btn--sm" data-action="add" data-id="${p.id}">Agregar</button></td></tr>`;
      }).join('')}</tbody></table></div></div>`;
  }).join('');
}

export function bioPage(params, query) {
  const ings = allIngredients().filter((i) => i.count > 0);
  let key = query.activo ? fold(query.activo) : '';
  let corrected = '';
  if (key && !ings.some((i) => i.key === key)) {
    const r = productIndex.search(query.activo);
    const p = r.items.length ? byId.get(r.items[0].id) : null;
    const hit = p?.ingredients.map(fold).find((i) => ings.some((x) => x.key === i));
    if (hit) { corrected = hit; key = hit; }
  }
  const ing = ings.find((i) => i.key === key);
  const html = `<div class="wrap page">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Bioequivalentes' }])}
    <div class="page-head"><h1 class="page-title">Medicamentos bioequivalentes</h1><p class="page-sub">Compara precios entre medicamentos con el mismo principio activo y elige la alternativa que más te conviene.</p></div>
    <div class="be-explain">
      <div class="program">${icon('scale')}<h3>¿Qué es un bioequivalente?</h3><p>Es un medicamento que demostró ante el Instituto de Salud Pública (ISP) que actúa en el organismo igual que el medicamento de referencia: misma dosis, misma eficacia y seguridad.</p></div>
      <div class="program">${beSeal(true)}<h3>¿Cómo lo reconozco?</h3><p>Por el sello amarillo <b>BE</b> en el envase y en nuestra web. Puedes pedirle a tu químico farmacéutico la alternativa bioequivalente de tu receta.</p></div>
      <div class="program">${icon('tag')}<h3>¿Por qué ahorro?</h3><p>Los bioequivalentes suelen costar bastante menos que la marca de referencia. Aquí te mostramos el precio por unidad para comparar de forma justa.</p></div>
    </div>
    <section class="panel" style="display:grid;gap:14px">
      <h2 class="sec-title">Compara por principio activo</h2>
      <form class="help__search" id="bio-form" role="search"><label class="visually-hidden" for="bio-q">Principio activo o nombre del medicamento</label><input class="input" id="bio-q" name="q" value="${esc(query.activo || '')}" placeholder="Ej: losartán, paracetamol, omeprazol o la marca que usas" autocomplete="off"><button class="btn btn--primary" type="submit">Comparar</button></form>
      ${corrected ? notice('club', `Mostrando <b>${esc(ing?.name || corrected)}</b> para “${esc(query.activo)}”.`, 'sparkle') : ''}
      ${key ? compareTable(key) : ''}
    </section>
    <section style="display:grid;gap:12px"><div class="sec-head"><h2 class="sec-title">Principios activos</h2><a class="link-more" href="#/bioequivalentes/todos" data-link>Ver todos los productos BE ${icon('arrowRight')}</a></div>
      <div class="ing-grid">${ings.map((i) => `<a class="ing" href="#/bioequivalentes?activo=${encodeURIComponent(i.key)}" data-link><b>${esc(i.name)}</b><small>${i.count} ${i.count === 1 ? 'opción' : 'opciones'}${i.be ? ` · ${i.be} BE` : ''} · desde ${clp(i.minPrice)}</small></a>`).join('')}</div>
    </section>
  </div>`;
  return {
    title: ing ? `Bioequivalentes de ${ing.name}` : 'Bioequivalentes',
    html,
    mount(root) {
      $('#bio-form', root).addEventListener('submit', (e) => {
        e.preventDefault();
        const v = e.target.q.value.trim();
        go(v ? `/bioequivalentes?activo=${encodeURIComponent(v)}` : '/bioequivalentes', { scroll: false });
      });
      if (key) requestAnimationFrame(() => $('#bio-form', root)?.scrollIntoView({ block: 'start', behavior: 'smooth' }));
      return null;
    },
  };
}

// ── Marcas ───────────────────────────────────────────────────
export function brandsPage() {
  const brands = allBrands();
  const groups = new Map();
  for (const b of brands) {
    const l = fold(b.name)[0].toUpperCase();
    const k = /[A-Z]/.test(l) ? l : '#';
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(b);
  }
  const letters = [...groups.keys()].sort();
  return {
    title: 'Marcas',
    html: `<div class="wrap page page--tight">
      ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Marcas' }])}
      <div class="page-head"><h1 class="page-title">Marcas y laboratorios</h1><p class="page-sub">${brands.length} marcas disponibles.</p></div>
      <nav class="az" aria-label="Ir a la letra">${letters.map((l) => `<a href="#brand-${l}" data-jump="brand-${l}">${l}</a>`).join('')}</nav>
      <div class="brand-groups">${letters.map((l) => `<section class="brand-group" id="brand-${l}" style="scroll-margin-top:160px"><h2>${l}</h2><div class="brand-list">${groups.get(l).map((b) => `<a href="#/buscar?marca=${encodeURIComponent(b.name)}" data-link>${esc(b.name)}<small>${b.count}</small></a>`).join('')}</div></section>`).join('')}</div>
    </div>`,
    mount(root) {
      root.addEventListener('click', (e) => {
        const j = e.target.closest('[data-jump]');
        if (!j) return;
        e.preventDefault();
        document.getElementById(j.dataset.jump)?.scrollIntoView({ behavior: 'smooth' });
      });
      return null;
    },
  };
}

// ── Ayuda ────────────────────────────────────────────────────
export function helpPage(params, query) {
  const section = params.section || '';
  const q = query.q || '';
  const nav = [['', 'Todas las preguntas'], ...FAQ.map((g) => [g.id, g.title]), ['contacto', 'Contacto'], ['reclamos', 'Libro de reclamos']];
  let content;
  if (section === 'contacto') {
    content = `<h2 class="sec-title">Contacto</h2>
      <div class="contact-cards">
        <div class="contact-card">${icon('phone')}<span>Venta telefónica y ayuda</span><b>${esc(BRAND.phone)}</b><span>${esc(BRAND.phoneMobile)} · ${esc(BRAND.hours)}</span></div>
        <div class="contact-card">${icon('chat')}<span>WhatsApp</span><b>${esc(BRAND.whatsapp)}</b><span>Respuesta en horario de atención</span></div>
        <div class="contact-card">${icon('mail')}<span>Correo</span><b>${esc(BRAND.email)}</b><span>Respondemos en menos de 24 horas hábiles</span></div>
      </div>
      <form class="panel form-grid" id="contact-form" novalidate>
        <h3 class="panel__title full" style="margin:0">Escríbenos</h3>
        ${field({ label: 'Nombre', name: 'nombre', required: true, autocomplete: 'name' })}
        ${field({ label: 'Correo', name: 'email', type: 'email', required: true, autocomplete: 'email' })}
        ${field({ label: 'Número de pedido', name: 'pedido', placeholder: 'PD12345678' })}
        ${field({ label: 'Motivo', name: 'motivo', options: ['Consulta sobre un producto', 'Mi pedido', 'Recetas', 'Cambios y devoluciones', 'Club Piedra', 'Otro'], required: true })}
        ${field({ label: 'Mensaje', name: 'mensaje', type: 'textarea', required: true, full: true })}
        <div class="full"><button class="btn btn--primary" type="submit">Enviar mensaje</button></div>
      </form>`;
  } else if (section === 'reclamos') {
    content = `<h2 class="sec-title">Libro de reclamos</h2>
      <p class="page-sub">Registra tu reclamo o sugerencia. Te responderemos dentro del plazo legal y recibirás un número de folio.</p>
      <form class="panel form-grid" id="claim-form" novalidate>
        ${field({ label: 'Nombre completo', name: 'nombre', required: true })}
        ${field({ label: 'RUT', name: 'rut', required: true, placeholder: '12.345.678-5' })}
        ${field({ label: 'Correo', name: 'email', type: 'email', required: true })}
        ${field({ label: 'Farmacia o canal', name: 'canal', options: ['Sitio web', 'Venta telefónica', 'Farmacia'], required: true })}
        ${field({ label: 'Detalle', name: 'detalle', type: 'textarea', required: true, full: true })}
        <div class="full"><button class="btn btn--primary" type="submit">Registrar reclamo</button></div>
      </form>`;
  } else {
    const groups = section ? FAQ.filter((g) => g.id === section) : FAQ;
    if (section && !groups.length) return null;
    let list;
    if (q) {
      const found = faqSearch(q);
      list = found.length ? `<p class="toolbar__count">${found.length} ${found.length === 1 ? 'respuesta' : 'respuestas'} para “${esc(q)}”</p>${found.map((f) => `<details class="acc" open><summary>${esc(f.q)}${icon('chevronDown')}</summary><div class="acc__body"><p>${esc(f.a)}</p><p class="muted">${esc(f.group)}</p></div></details>`).join('')}`
        : emptyState({ icon: 'help', title: `No encontramos respuestas para “${q}”`, text: 'Prueba con otras palabras o escríbenos.', actions: '<a class="btn btn--primary" href="#/ayuda/contacto" data-link>Contactarnos</a>' });
    } else {
      list = groups.map((g) => `<section style="display:grid;gap:8px"><h2 class="sec-title" style="font-size:20px">${esc(g.title)}</h2>${g.items.map((f) => `<details class="acc"${section ? ' open' : ''}><summary>${esc(f.q)}${icon('chevronDown')}</summary><div class="acc__body"><p>${esc(f.a)}</p></div></details>`).join('')}</section>`).join('');
    }
    content = `<form class="help__search" id="help-form" role="search"><label class="visually-hidden" for="help-q">Busca tu pregunta</label><input class="input" id="help-q" name="q" value="${esc(q)}" placeholder="Ej: ¿cuánto demora el despacho?"><button class="btn btn--primary" type="submit">${icon('search')} Buscar</button></form>${list}`;
  }
  return {
    title: 'Ayuda',
    html: `<div class="wrap page page--tight">
      ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Ayuda' }])}
      <div class="page-head"><h1 class="page-title">¿En qué te ayudamos?</h1></div>
      <div class="help">
        <nav class="help__nav" aria-label="Temas de ayuda">${nav.map(([id, t]) => `<a href="#/ayuda${id ? `/${id}` : ''}" data-link class="${id === section ? 'is-on' : ''}">${esc(t)}</a>`).join('')}</nav>
        <div style="display:grid;gap:18px;min-width:0">${content}</div>
      </div>
    </div>`,
    mount(root) {
      root.addEventListener('submit', (e) => {
        const f = e.target;
        e.preventDefault();
        if (f.id === 'help-form') { go(`/ayuda${section ? `/${section}` : ''}?q=${encodeURIComponent(f.q.value.trim())}`, { scroll: false }); return; }
        const v = formData(f);
        const errors = {};
        for (const el of f.elements) if (el.required && !String(v[el.name] || '').trim()) errors[el.name] = 'Completa este campo.';
        if (v.email && !validEmail(v.email)) errors.email = 'Ingresa un correo válido.';
        if (v.rut && !validateRut(v.rut)) errors.rut = 'Ingresa un RUT válido, por ejemplo 12.345.678-5.';
        if (!setErrors(f, errors)) return;
        const folio = `R-${Math.floor(100000 + Math.random() * 899999)}`;
        f.outerHTML = notice('ok', f.id === 'claim-form'
          ? `Registramos tu reclamo con el folio <b>${folio}</b>. Te escribiremos a <b>${esc(v.email)}</b>. (Demostración: no se envían correos.)`
          : `Gracias, <b>${esc(v.nombre)}</b>. Recibimos tu mensaje y te responderemos a <b>${esc(v.email)}</b>. (Demostración: no se envían correos.)`);
      });
      return null;
    },
  };
}

// ── Textos legales e institucionales ─────────────────────────
export function legalPage(params) {
  const doc = LEGAL[params.doc];
  if (!doc) return null;
  return {
    title: doc.title,
    html: `<div class="wrap page page--tight">
      ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: doc.title }])}
      <div class="page-head"><h1 class="page-title">${esc(doc.title)}</h1></div>
      <div class="help">
        <nav class="help__nav" aria-label="Información legal">${LEGAL_LINKS.map(([id, t]) => `<a href="#/legal/${id}" data-link class="${id === params.doc ? 'is-on' : ''}">${esc(t)}</a>`).join('')}</nav>
        <article class="prose">${doc.body.map(([h, p]) => `<section><h2>${esc(h)}</h2><p>${esc(p)}</p></section>`).join('')}
          ${notice('info', 'Texto de ejemplo para la demostración. Reemplázalo por el texto legal oficial de tu empresa.')}</article>
      </div>
    </div>`,
  };
}

// ── No encontrada ────────────────────────────────────────────
export function notFoundPage() {
  return {
    title: 'Página no encontrada',
    html: `<div class="wrap page"><div class="nf">
      <span class="nf__code">404</span>
      <h1 class="page-title">No encontramos esta página</h1>
      <p class="page-sub">Puede que el enlace esté mal escrito o que la página ya no exista.</p>
      <div class="empty__actions"><a class="btn btn--primary" href="#/" data-link>Volver al inicio</a><a class="btn btn--ghost" href="#/ofertas" data-link>Ver ofertas</a></div>
      <div class="sub-chips" style="justify-content:center;margin-top:10px">${CATEGORIES.map((c) => `<a href="#/categoria/${c.id}" data-link>${esc(c.name)}</a>`).join('')}</div>
    </div></div>`,
  };
}

export { state };

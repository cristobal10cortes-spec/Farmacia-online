// Panel → Productos y stock → Carga masiva (Excel o CSV).
//
// 1) Descargar la planilla (o usar la que exporta eleventa).
// 2) Subir el archivo: se lee aquí mismo, en el navegador.
// 3) Elegir dónde va la existencia (sumar o reemplazar), si se actualizan precio
//    y costo, y qué hacer con los productos que no existen (se crean, con la
//    categoría y la condición de venta según su departamento).
// 4) Revisar y confirmar: el servidor vuelve a validar y guarda todo junto.

import { $, $$, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { ZONES } from '../config.js';
import { STORES } from '../data/stores.js';
import { REGIONS, regionLabel } from '../data/regions.js';
import { CATEGORIES, ALL_SUBS, subById } from '../data/categories.js';
import { byId, allProducts, catalogVersion } from '../engine/catalog.js';
import { getOverride } from '../engine/stockdata.js';
import { num, clp } from '../engine/format.js';
import { readPlanilla, checkItems, planillaCsv, planillaXlsx, TEMPLATE_HEADERS, MAX_ROWS, PlanillaError } from '../engine/planilla.js';
import { proposeProduct, deptDefaults, SUB_LABEL } from '../engine/importar.js';
import { bo, ZONE_IDS, locLabel, stockAt, importPlanilla, friendlyError } from '../admin/api.js';
import { adminShell, adminGuard } from './admin.js';

const SHOW_ROWS = 400;
const NO_DEPT = '(sin departamento)';
const MAP_KEY = 'piedra:carga-departamentos';

// Lo que se está cargando (se mantiene si el panel se repinta con datos nuevos)
const S = {
  file: '', sheet: '', kind: '', items: null, has: {}, noHeader: false, gen: 0,
  loc: '', mode: '', opts: { price: true, cost: true, create: true, hideDemo: true },
  busy: false, result: null, sig: '',
};
function reset() {
  Object.assign(S, { file: '', sheet: '', kind: '', items: null, has: {}, noHeader: false, mode: '', busy: false, result: null, sig: '' });
  S.opts = { price: true, cost: true, create: true, hideDemo: true };
}
// Archivos ya cargados en esta sesión (para avisar si se va a sumar dos veces lo mismo)
const DONE = [];
const repeated = () => !!S.sig && S.mode === 'add' && DONE.some((d) => d.sig === S.sig && d.mode === 'add' && d.loc === S.loc);

async function fingerprint(bytes) {
  try {
    const h = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    return Array.from(h.slice(0, 12), (b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    return '';
  }
}

// ── Departamentos → categoría y condición de venta (se recuerda en este navegador) ──
let deptMap = {};
try { deptMap = JSON.parse(localStorage.getItem(MAP_KEY) || '{}') || {}; } catch { deptMap = {}; }
const saveMap = () => { try { localStorage.setItem(MAP_KEY, JSON.stringify(deptMap)); } catch { /* sin almacenamiento */ } };
const deptKey = (d) => String(d || '').trim() || NO_DEPT;
function choiceFor(dept) {
  const k = deptKey(dept).toLowerCase();
  const d = deptDefaults(dept);
  const saved = deptMap[k];
  return { sub: saved?.sub || 'auto', rx: saved?.rx || d.rx };
}

// ── Revisión (con memoria: con miles de filas no se recalcula a cada rato) ──
function codeIndex() {
  const m = new Map();
  for (const k of byId.keys()) m.set(k.toUpperCase(), k);
  for (const p of byId.values()) { const c = getOverride(p.id)?.code; if (c) m.set(String(c).toUpperCase(), p.id); }
  return m;
}
let memo = { key: '', value: null };
function analysis() {
  if (!S.items) return null;
  const key = `${S.gen}|${catalogVersion}|${S.opts.create}|${JSON.stringify(deptMap)}`;
  if (memo.key === key) return memo.value;
  const idx = codeIndex();
  const c = checkItems(S.items, (code) => byId.get(idx.get(code)) || null, { create: S.opts.create });
  const props = new Map();
  const depts = new Map();
  for (const e of c.load) {
    if (e.p) continue;
    const pr = proposeProduct({ code: e.code, name: e.name, dept: e.dept, price: e.price }, choiceFor(e.dept));
    props.set(e.code, pr);
    const k = deptKey(e.dept);
    const d = depts.get(k) || { name: k, count: 0, subs: new Map() };
    d.count++;
    d.subs.set(pr.sub, (d.subs.get(pr.sub) || 0) + 1);
    depts.set(k, d);
  }
  // ¿Cuántos se crearían? (aunque esté desmarcado, para ofrecerlo)
  const wouldCreate = S.opts.create ? c.counts.create : checkItems(S.items, (code) => byId.get(idx.get(code)) || null, { create: true }).counts.create;
  memo = { key, value: { c, props, depts, wouldCreate } };
  return memo.value;
}

const demoVisible = () => allProducts().filter((p) => !p.custom && !p.hidden).length;
const hasQty = (a) => a.c.load.some((e) => e.qty != null && (e.p || S.opts.create));

/** Lo que se va a enviar al servidor según las opciones elegidas. */
function payloadRows(a) {
  const rows = [];
  for (const e of a.c.load) {
    const r = { line: e.lines[0] };
    if (e.p) {
      r.code = e.p.id;
      if (e.qty != null) r.qty = e.qty;
      if (S.opts.cost && e.cost != null) r.cost = e.cost;
      if (S.opts.price && e.price != null) r.price = e.price;
      if (r.qty == null && r.cost == null && r.price == null) continue;
    } else {
      if (!S.opts.create) continue;
      const pr = a.props.get(e.code);
      r.code = e.code;
      r.price = e.price;
      if (e.qty != null) r.qty = e.qty;
      if (e.cost != null) r.cost = e.cost;
      r.def = pr.def;
      if (pr.hidden) r.hidden = true;
    }
    rows.push(r);
  }
  return rows;
}

// ── Planilla para descargar ──────────────────────────────────
const HELP = [
  'Cómo llenar esta planilla',
  'Columnas (de izquierda a derecha): Código · Nombre del producto · Cantidad · Precio costo · Precio venta · Departamento.',
  '1. Cantidad: la existencia que vas a cargar (números enteros). Si la dejas en blanco, el stock de ese producto no cambia.',
  '2. Precio costo: lo que te cuesta el producto. Solo lo ves tú en el panel; nunca aparece en la tienda.',
  '3. Precio venta: el precio al público, el que paga el cliente en la tienda.',
  '4. No cambies los códigos de la columna A: con ellos se reconoce cada producto.',
  '5. Para agregar productos nuevos, escribe una fila con su código, nombre, precio venta y departamento (por ejemplo «Perfumería» o «Bioequivalentes»).',
  '6. Guarda el archivo (Excel .xlsx o CSV) y súbelo en el panel: Productos y stock › Carga masiva.',
  'También puedes subir directamente el Excel de inventario que descargas de eleventa.',
  'Antes de guardar, el panel te muestra qué va a cambiar para que lo revises.',
];

function templateRows() {
  const order = new Map(CATEGORIES.map((c, i) => [c.id, i]));
  return allProducts()
    .filter((p) => p.custom || !p.hidden)
    .sort((a, b) => (order.get(a.cat) ?? 99) - (order.get(b.cat) ?? 99) || a.name.localeCompare(b.name, 'es') || String(a.brand).localeCompare(String(b.brand), 'es'))
    .map((p) => {
      const ov = getOverride(p.id) || {};
      return [ov.code || p.id, ov.code ? p.name : [p.name, p.brand].filter(Boolean).join(' · '), '', ov.cost ?? '', p.price, subById(p.cat, p.sub)?.name || ''];
    });
}

function download(name, data, type) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.rel = 'noopener';
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
const stamp = () => new Date().toISOString().slice(0, 10);

// ── Partes de la página ──────────────────────────────────────
function locSelect() {
  const opt = (v, label) => `<option value="${esc(v)}"${v === S.loc ? ' selected' : ''}>${esc(label)}</option>`;
  const regions = REGIONS.map((r) => ({ r, stores: STORES.filter((s) => s.region === r.id) })).filter((x) => x.stores.length);
  return `<option value=""${S.loc ? '' : ' selected'} disabled>Elige una farmacia o bodega…</option>
    ${regions.map(({ r, stores }) => `<optgroup label="Farmacias · ${esc(regionLabel(r))}">${stores.map((s) => opt(`s:${s.id}`, `${s.name} (${s.comuna})`)).join('')}</optgroup>`).join('')}
    <optgroup label="Bodegas online (despacho a domicilio)">${ZONE_IDS.map((z) => opt(`o:${z}`, `Bodega online · ${ZONES[z].name}`)).join('')}</optgroup>`;
}

const sample = () => `<div class="cm-sample" role="table" aria-label="Ejemplo de planilla">
    <div class="cm-sample__row cm-sample__row--head" role="row"><span class="cm-sample__n" aria-hidden="true"></span>${['A', 'B', 'C', 'D', 'E', 'F'].map((c) => `<span role="columnheader" class="cm-sample__col">${c}</span>`).join('')}</div>
    <div class="cm-sample__row cm-sample__row--titles" role="row"><span class="cm-sample__n">1</span>${TEMPLATE_HEADERS.map((h) => `<b role="cell">${esc(h)}</b>`).join('')}</div>
    <div class="cm-sample__row" role="row"><span class="cm-sample__n">2</span><span role="cell">7800060005723</span><span role="cell">Paracetamol 500 mg 16 comprimidos</span><span role="cell" class="num">24</span><span role="cell" class="num">$650</span><span role="cell" class="num">$1.190</span><span role="cell">Bioequivalentes</span></div>
    <div class="cm-sample__row" role="row"><span class="cm-sample__n">3</span><span role="cell">7804640561364</span><span role="cell">Crema de manos argán 50 ml</span><span role="cell" class="num">10</span><span role="cell" class="num">$1.290</span><span role="cell" class="num">$2.490</span><span role="cell">Perfumería</span></div>
  </div>`;

function pageBody() {
  const n = allProducts().filter((p) => p.custom || !p.hidden).length;
  return `<div class="cm">
    <section class="panel cm-step">
      <h2 class="panel__title"><span class="cm-step__n">1</span> Prepara tu planilla</h2>
      <p>La <b>primera fila</b> lleva los títulos, de izquierda a derecha: <b>Código</b>, <b>Nombre del producto</b>, <b>Cantidad</b>, <b>Precio costo</b>, <b>Precio venta</b> (al público) y <b>Departamento</b>. Debajo, un producto por fila. Solo el código es obligatorio: las columnas que no traigas no cambian.</p>
      ${sample()}
      <div class="cm-dl">
        <button type="button" class="btn btn--primary" data-dl="xlsx">${icon('file')} Descargar planilla Excel (.xlsx)</button>
        <button type="button" class="btn btn--ghost" data-dl="csv">${icon('file')} Descargar planilla CSV</button>
      </div>
      <p class="field__hint">Viene con tus <b>${num(n)}</b> productos, sus precios y la cantidad en blanco. <b>¿Usas eleventa?</b> Sube directo el Excel de inventario que descargas de ahí (Código, Producto, P. Costo, P. Venta, Existencia y Departamento): no hace falta ordenarlo.</p>
    </section>

    <section class="panel cm-step">
      <h2 class="panel__title"><span class="cm-step__n">2</span> Sube el archivo</h2>
      <label class="rx-upload__drop cm-drop" id="cm-drop">${icon('upload')}<span><b>Elegir planilla</b> · Excel (.xlsx) o CSV<small>Toca para elegirla o arrástrala aquí · hasta 5 MB y ${num(MAX_ROWS)} filas</small></span><input type="file" id="cm-file" accept=".xlsx,.csv,.txt,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"></label>
      <div id="cm-msg" aria-live="polite"></div>
    </section>

    <div id="cm-work"${S.items || S.result ? '' : ' hidden'}>${workHtml()}</div>
  </div>`;
}

const SUB_OPTIONS = (() => {
  const by = new Map();
  for (const s of ALL_SUBS) { if (!by.has(s.catName)) by.set(s.catName, []); by.get(s.catName).push(s); }
  return [...by].map(([cat, subs]) => `<optgroup label="${esc(cat)}">${subs.map((s) => `<option value="${esc(`${s.cat}/${s.id}`)}">${esc(s.name)}</option>`).join('')}</optgroup>`).join('');
})();
const RX_OPTIONS = [['directa', 'Venta directa'], ['simple', 'Con receta'], ['hide', 'No publicar']];

function deptHint(d) {
  const top = [...d.subs].sort((a, b) => b[1] - a[1]).slice(0, 3);
  return top.map(([sub, n]) => `${esc(SUB_LABEL.get(sub) || sub)} (${num(n)})`).join(' · ') + (d.subs.size > 3 ? ' · …' : '');
}

function deptTable(a) {
  if (!S.opts.create || !a.depts.size) return '';
  const list = [...a.depts.values()].sort((x, y) => y.count - x.count);
  return `<div class="cm-depts" id="cm-depts">
      <h3 class="cm-sub">${icon('list')} Productos nuevos por departamento</h3>
      <p class="field__hint">Elige en qué categoría de la tienda queda cada departamento y si se vende con receta. Con «Automático» cada producto se ubica según su nombre (principio activo y palabras como «shampoo» o «protector solar»); después puedes corregir cualquiera en su ficha.</p>
      <div class="atable atable--depts" role="table" aria-label="Departamentos">
        <div class="atable__row atable__row--head" role="row"><span role="columnheader">Departamento</span><span role="columnheader" class="num">Nuevos</span><span role="columnheader">Categoría en la tienda</span><span role="columnheader">Condición</span></div>
        ${list.map((d) => {
          const ch = choiceFor(d.name === NO_DEPT ? '' : d.name);
          const k = esc(d.name.toLowerCase());
          return `<div class="atable__row" role="row" data-dept="${k}">
            <span role="cell" class="cm-dept"><b>${esc(d.name)}</b><small data-dept-hint>${deptHint(d)}</small></span>
            <span role="cell" class="num"><span class="atable__lbl">Nuevos</span>${num(d.count)}</span>
            <span role="cell"><span class="atable__lbl">Categoría</span><select data-dept-sub aria-label="Categoría para ${esc(d.name)}"><option value="auto">Automático (según el nombre)</option>${SUB_OPTIONS.replace(`value="${esc(ch.sub)}"`, `value="${esc(ch.sub)}" selected`)}</select></span>
            <span role="cell"><span class="atable__lbl">Condición</span><select data-dept-rx aria-label="Condición de venta para ${esc(d.name)}">${RX_OPTIONS.map(([v, l]) => `<option value="${v}"${v === ch.rx ? ' selected' : ''}>${l}</option>`).join('')}</select></span>
          </div>`;
        }).join('')}
      </div>
      <p class="field__hint">«Con receta» solo aplica a medicamentos: lo que quede en otras categorías (cuidado personal, vitaminas…) se vende directo. «No publicar» crea el producto oculto: lo publicas después desde su ficha.</p>
    </div>`;
}

function workHtml() {
  if (S.result) return resultHtml();
  if (!S.items) return '';
  const a = analysis();
  const qty = S.has.qty;
  const demo = demoVisible();
  const opt = (k, label, hint, show = true) => (show ? `<label class="check cm-opt"><input type="checkbox" data-opt="${k}"${S.opts[k] ? ' checked' : ''}><span><b>${label}</b>${hint ? `<small>${hint}</small>` : ''}</span></label>` : '');
  return `<section class="panel cm-step">
      <h2 class="panel__title"><span class="cm-step__n">3</span> ¿Qué se carga?</h2>
      <p class="cm-file">${icon(S.kind === 'xlsx' ? 'file' : 'list')} <b>${esc(S.file)}</b>${S.sheet ? ` · hoja «${esc(S.sheet)}»` : ''} · ${num(S.items.length)} ${S.items.length === 1 ? 'fila' : 'filas'} con datos <button type="button" class="btn btn--link btn--sm" data-other>Subir otro archivo</button></p>
      <p class="cm-cols">Columnas encontradas: ${[['name', 'Nombre'], ['qty', 'Cantidad'], ['cost', 'Precio costo'], ['price', 'Precio venta'], ['dept', 'Departamento']].map(([k, l]) => `<span class="chip${S.has[k] ? ' chip--ok' : ''}">${S.has[k] ? icon('check') : icon('x')}${l}</span>`).join('')}</p>
      ${S.noHeader ? notice('warn', 'No encontramos los títulos, así que leímos las columnas en orden: <b>A = Código</b>, <b>B = Nombre</b>, <b>C = Cantidad</b>. Revisa que sea así.') : ''}
      ${qty ? `<div class="cm-how">
        <div class="field"><label for="cm-loc">¿Dónde se carga la existencia?</label><select id="cm-loc" name="loc" required>${locSelect()}</select></div>
        <fieldset class="cm-mode"><legend>¿Qué hacer con la cantidad de la planilla?</legend>
          <div class="radio-cards cm-mode__cards">
            <label class="radio-card"><input type="radio" name="cm-mode" value="add"${S.mode === 'add' ? ' checked' : ''}><span class="radio-card__main"><span class="radio-card__title">${icon('plus')} Sumar al stock actual</span><small>Llegó mercadería: la cantidad se agrega a lo que ya hay.</small></span></label>
            <label class="radio-card"><input type="radio" name="cm-mode" value="set"${S.mode === 'set' ? ' checked' : ''}><span class="radio-card__main"><span class="radio-card__title">${icon('refresh')} Reemplazar el stock</span><small>Hiciste un conteo (o es tu inventario de eleventa): el stock queda igual a la planilla.</small></span></label>
          </div>
        </fieldset>
      </div>` : ''}
      <div class="cm-opts">
        ${opt('price', 'Actualizar el precio de venta', 'El precio al público que ve el cliente. Si el producto tiene una oferta más alta que el precio nuevo, la oferta se quita.', S.has.price)}
        ${opt('cost', 'Guardar el precio costo', 'Solo se ve en el panel (con el margen de cada producto); nunca aparece en la tienda.', S.has.cost)}
        ${opt('create', `Crear los ${num(a.wouldCreate)} productos que no existen`, 'Con su código, nombre, precio, costo y existencia. Necesitan precio de venta.', a.wouldCreate > 0)}
        ${opt('hideDemo', `Ocultar los ${num(demo)} productos de ejemplo de la tienda`, 'Dejan de verse en la tienda; siguen en el panel (filtro «Ocultos») por si quieres volver a mostrarlos.', S.opts.create && a.wouldCreate > 0 && demo > 0)}
      </div>
      ${deptTable(a)}
    </section>
    <section class="panel cm-step">
      <h2 class="panel__title"><span class="cm-step__n">4</span> Revisa y confirma</h2>
      <div id="cm-preview">${previewHtml()}</div>
    </section>`;
}

const STATUS = {
  error: ['No se carga', 'danger'],
  warn: ['Revisar', 'warn'],
  ok: ['Se actualiza', 'ok'],
  new: ['Nuevo', 'info'],
  empty: ['Sin cambios', ''],
};
const RX_SHORT = { directa: 'Venta directa', simple: 'Con receta', retenida: 'Receta retenida', cheque: 'Receta cheque' };

function previewHtml() {
  const a = analysis();
  if (!a) return '';
  const { c, props } = a;
  const { rows, load, counts } = c;
  const loc = S.loc;
  const mode = S.mode;
  const needLoc = hasQty(a);
  const entry = new Map(load.map((e) => [e.p ? e.p.id : `+${e.code}`, e]));
  const stockAfter = (e) => (e.p ? (mode === 'add' ? stockAt(e.p, loc) + e.qty : e.qty) : e.qty);
  const upd = load.filter((e) => e.p);
  const created = S.opts.create ? load.filter((e) => !e.p) : [];
  const hiddenNew = created.filter((e) => props.get(e.code)?.hidden).length;
  const stockCh = needLoc && loc && mode ? upd.filter((e) => e.qty != null && stockAfter(e) !== stockAt(e.p, loc)) : [];
  const priceCh = S.opts.price ? upd.filter((e) => e.price != null && e.price !== e.p.price) : [];
  const costCh = S.opts.cost ? upd.filter((e) => e.cost != null && e.cost !== (getOverride(e.p.id)?.cost ?? null)) : [];
  const nothing = !created.length && !stockCh.length && !priceCh.length && !costCh.length;
  const ready = (!needLoc || (loc && mode)) && !nothing;
  const summary = `<div class="cm-sum">
      ${created.length ? `<span class="chip chip--info">${icon('plus')}${num(created.length)} ${created.length === 1 ? 'producto nuevo' : 'productos nuevos'}${hiddenNew ? ` (${num(hiddenNew)} sin publicar)` : ''}</span>` : ''}
      ${upd.length ? `<span class="chip chip--ok">${icon('checkCircle')}${num(upd.length)} ${upd.length === 1 ? 'producto existente' : 'productos existentes'}</span>` : ''}
      ${counts.warn ? `<span class="chip chip--warn">${icon('alert')}${num(counts.warn)} para revisar</span>` : ''}
      ${counts.error ? `<span class="chip chip--danger">${icon('x')}${num(counts.error)} con error (no se cargan)</span>` : ''}
      ${counts.empty ? `<span class="chip">${num(counts.empty)} sin cambios</span>` : ''}
    </div>`;
  const parts = [];
  if (created.length) parts.push(`se crean <b>${num(created.length)}</b> productos${hiddenNew ? ` (<b>${num(hiddenNew)}</b> quedan sin publicar)` : ''}`);
  if (stockCh.length) parts.push(`${mode === 'add' ? 'se suma existencia a' : 'cambia la existencia de'} <b>${num(stockCh.length)}</b> productos en <b>${esc(locLabel(loc))}</b>`);
  if (priceCh.length) parts.push(`cambia el precio de venta de <b>${num(priceCh.length)}</b>`);
  if (costCh.length) parts.push(`se guarda el costo de <b>${num(costCh.length)}</b>`);
  if (S.opts.hideDemo && created.length && demoVisible()) parts.push(`se ocultan los <b>${num(demoVisible())}</b> productos de ejemplo`);
  const plan = needLoc && (!loc || !mode)
    ? notice('info', `Elige ${!loc && !mode ? 'dónde se carga la existencia y si se suma o reemplaza' : !loc ? 'dónde se carga la existencia' : 'si la cantidad se suma o reemplaza el stock'} para ver cómo queda cada producto.`)
    : notice(nothing ? 'info' : 'ok', nothing ? 'Con lo que elegiste no cambia nada: los productos ya tienen esas cantidades y precios.' : `Al cargar: ${parts.join('; ')}.`);
  const listed = rows.filter((r) => r.status !== 'empty' && (S.opts.create || !r.isNew));
  const rank = { error: 0, warn: 1, new: 2, ok: 3 };
  listed.sort((x, y) => rank[x.status] - rank[y.status] || x.line - y.line);
  const shown = listed.slice(0, SHOW_ROWS);
  const money = (v) => (v != null ? clp(v) : '—');
  const table = shown.length ? `<div class="atable atable--cm" role="table" aria-label="Revisión de la planilla">
      <div class="atable__row atable__row--head" role="row"><span role="columnheader">Fila</span><span role="columnheader">Producto</span><span role="columnheader" class="num">Existencia</span><span role="columnheader" class="num">Costo</span><span role="columnheader" class="num">Precio venta</span><span role="columnheader">Estado</span></div>
      ${shown.map((r) => {
        const p = r.pid ? byId.get(r.pid) : null;
        const e = entry.get(p ? p.id : `+${r.key}`);
        const pr = !p && r.key ? props.get(r.key) : null;
        const [label, tone] = STATUS[r.status];
        let stock = r.qty != null ? num(r.qty) : '<span class="muted">—</span>';
        if (e && p && e.qty != null && loc && mode) {
          const now = stockAt(p, loc);
          const aft = stockAfter(e);
          stock = `${num(now)} → <b class="${aft > now ? 'is-up' : aft < now ? 'is-down' : ''}">${num(aft)}</b>`;
        }
        let price = r.price != null ? money(r.price) : r.priceText ? esc(r.priceText) : '<span class="muted">—</span>';
        if (p && r.price != null && S.opts.price && r.price !== p.price) price = `${clp(p.price)} → <b>${clp(r.price)}</b>`;
        else if (p && r.price != null && !S.opts.price) price = `<span class="muted">${clp(p.price)}</span>`;
        const cost = r.cost != null ? (S.opts.cost || !p ? money(r.cost) : '<span class="muted">no se guarda</span>') : r.costText ? esc(r.costText) : '<span class="muted">—</span>';
        const sub = p
          ? `${esc(p.brand || '')} · Código ${esc(getOverride(p.id)?.code || p.id)}`
          : pr ? `${esc(pr.def.b)} · ${esc(SUB_LABEL.get(pr.sub) || '')} · ${pr.hidden ? 'No se publica' : esc(pr.def.rx && pr.sub.startsWith('medicamentos/') ? RX_SHORT[pr.def.rx] : 'Venta directa')}` : `Código ${esc(r.code || '(vacío)')}`;
        return `<div class="atable__row cm-row cm-row--${r.status}" role="row" data-line="${r.line}">
          <span role="cell" class="cm-line"><span class="atable__lbl">Fila</span>${r.line}</span>
          <span role="cell" class="cm-prod">${p ? `<b>${esc(p.name)}</b>` : `<b>${esc(pr ? pr.def.n : r.name || 'Sin nombre')}</b>`}<small>${sub}</small>${r.msg ? `<small class="cm-msg cm-msg--${r.status}">${esc(r.msg)}</small>` : ''}</span>
          <span role="cell" class="num"><span class="atable__lbl">Existencia</span>${stock}</span>
          <span role="cell" class="num"><span class="atable__lbl">Costo</span>${cost}</span>
          <span role="cell" class="num"><span class="atable__lbl">Precio venta</span>${price}</span>
          <span role="cell"><span class="chip${tone ? ` chip--${tone}` : ''}">${label}</span></span>
        </div>`;
      }).join('')}
    </div>${listed.length > shown.length ? `<p class="field__hint">Se muestran las primeras ${num(SHOW_ROWS)} filas de ${num(listed.length)} (primero las que tienen problemas).</p>` : ''}` : '';
  const again = repeated() ? notice('warn', '<b>Ojo:</b> ya cargaste este mismo archivo con «Sumar» en esta ubicación. Si lo cargas de nuevo, las cantidades se sumarán otra vez.') : '';
  const total = created.length + new Set([...stockCh, ...priceCh, ...costCh].map((e) => e.p.id)).size;
  return `${summary}${again}${plan}${table}
    <div class="cm-actions">
      <button type="button" class="btn btn--primary" id="cm-go"${ready && !S.busy ? '' : ' disabled'}>${icon('upload')} ${S.busy ? 'Cargando…' : `Cargar${total ? ` (${num(total)} ${total === 1 ? 'producto' : 'productos'})` : ''}`}</button>
      ${counts.error || counts.warn ? `<button type="button" class="btn btn--ghost" data-dl="problemas">${icon('file')} Descargar filas con problemas</button>` : ''}
    </div>
    ${counts.error ? '<p class="field__hint">Las filas con error no se cargan. Corrígelas en una planilla aparte (puedes partir de «Descargar filas con problemas») y súbela después. Si vuelves a subir la misma planilla con «Sumar», las filas que ya se cargaron se sumarían otra vez.</p>' : ''}`;
}

function resultHtml() {
  const r = S.result;
  const lines = [];
  if (r.created) lines.push(`Se crearon <b>${num(r.created)}</b> productos${r.createdHidden ? ` (<b>${num(r.createdHidden)}</b> sin publicar: los encuentras en Productos › Ocultos)` : ''}.`);
  if (r.stock) lines.push(`Cambió la existencia de <b>${num(r.stock)}</b> productos en <b>${esc(locLabel(r.loc))}</b> (${r.units >= 0 ? '+' : '−'}${num(Math.abs(r.units))} unidades).`);
  if (r.price) lines.push(`Cambió el precio de venta de <b>${num(r.price)}</b> productos.`);
  if (r.cost) lines.push(`Se guardó el costo de <b>${num(r.cost)}</b> productos.`);
  if (r.hiddenDemo) lines.push(`Se ocultaron los <b>${num(r.hiddenDemo)}</b> productos de ejemplo.`);
  const skipped = r.notLoaded || 0;
  return `<section class="panel cm-step cm-done" id="cm-done">
    ${notice('ok', `<b>Listo.</b> ${lines.length ? lines.join(' ') : 'No hubo cambios: los productos ya tenían esas cantidades y precios.'}`, 'checkCircle')}
    ${skipped ? notice('warn', `${num(skipped)} ${skipped === 1 ? 'fila no se cargó' : 'filas no se cargaron'} (código que no existe, sin precio o con datos inválidos).`) : ''}
    <p class="field__hint">Cada cambio quedó registrado en Movimientos como «Carga masiva${S.file ? ` · ${esc(S.file)}` : ''}».${r.created ? ' Los productos nuevos tienen un dibujo del envase: puedes subir su foto en la ficha de cada uno.' : ''}</p>
    <div class="cm-actions">
      ${r.created ? `<a class="btn btn--primary" href="#/admin/productos?estado=nuevo" data-link>${icon('box')} Ver los productos nuevos</a>` : ''}
      <a class="btn ${r.created ? 'btn--ghost' : 'btn--primary'}" href="#/admin/movimientos" data-link>${icon('list')} Ver en Movimientos</a>
      <button type="button" class="btn btn--ghost" data-other>${icon('upload')} Cargar otra planilla</button>
    </div>
  </section>`;
}

// ── Página ───────────────────────────────────────────────────
export function adminBulkPage() {
  const guard = adminGuard();
  if (guard) return guard;
  return {
    title: 'Carga masiva · Administración',
    rerender: ['backoffice'],
    html: adminShell('productos', 'Carga masiva (Excel o CSV)', pageBody(), {
      sub: 'Carga de una vez la existencia, el precio costo, el precio de venta y los productos nuevos desde una planilla.',
      actions: `<a class="btn btn--ghost btn--sm" href="#/admin/productos" data-link>${icon('arrowLeft')} Productos</a>`,
    }),
    // Con datos nuevos (por ejemplo una venta) solo se actualiza la revisión, sin borrar lo elegido
    onState(evt) {
      if (evt !== 'backoffice' || !bo.user || !bo.ready) return false;
      const box = document.getElementById('cm-preview');
      if (box && !S.busy) box.innerHTML = previewHtml();
      return !!document.getElementById('cm-work');
    },
    mount(root) {
      const work = $('#cm-work', root);
      const msg = $('#cm-msg', root);
      const paint = () => {
        work.innerHTML = workHtml();
        work.hidden = !(S.items || S.result);
      };
      const paintPreview = () => { const box = $('#cm-preview', root); if (box) box.innerHTML = previewHtml(); };

      async function handle(file) {
        if (!file) return;
        msg.innerHTML = `<p class="cm-reading">${icon('refresh')} Leyendo <b>${esc(file.name)}</b>…</p>`;
        try {
          const bytes = new Uint8Array(await file.arrayBuffer());
          const r = await readPlanilla(bytes);
          reset();
          Object.assign(S, { file: file.name.slice(0, 80), sheet: r.sheet, kind: r.kind, items: r.items, has: r.has || { qty: true }, noHeader: r.noHeader, gen: S.gen + 1, sig: await fingerprint(bytes) });
          msg.innerHTML = '';
          paint();
          work.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } catch (err) {
          reset();
          paint();
          msg.innerHTML = notice('danger', esc(err instanceof PlanillaError ? err.message : 'No pudimos leer el archivo. Revisa que sea una planilla de Excel (.xlsx) o CSV.'));
        }
      }

      const input = $('#cm-file', root);
      const drop = $('#cm-drop', root);
      input.addEventListener('change', () => { handle(input.files?.[0]); input.value = ''; });
      drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-drag'); });
      drop.addEventListener('dragleave', () => drop.classList.remove('is-drag'));
      drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('is-drag'); handle(e.dataTransfer?.files?.[0]); });

      root.addEventListener('change', (e) => {
        const t = e.target;
        if (t.id === 'cm-loc') { S.loc = t.value; paintPreview(); return; }
        if (t.name === 'cm-mode') { S.mode = t.value; paintPreview(); return; }
        if (t.dataset.opt) {
          S.opts[t.dataset.opt] = t.checked;
          if (t.dataset.opt === 'create') { paint(); return; }
          paintPreview();
          return;
        }
        const row = t.closest('[data-dept]');
        if (row && (t.matches('[data-dept-sub]') || t.matches('[data-dept-rx]'))) {
          const k = row.dataset.dept;
          deptMap[k] = { sub: $('[data-dept-sub]', row).value, rx: $('[data-dept-rx]', row).value };
          saveMap();
          const a = analysis();
          for (const el of $$('[data-dept]', root)) {
            const d = [...a.depts.values()].find((x) => x.name.toLowerCase() === el.dataset.dept);
            const hint = $('[data-dept-hint]', el);
            if (d && hint) hint.innerHTML = deptHint(d);
          }
          paintPreview();
        }
      });

      root.addEventListener('click', async (e) => {
        const dl = e.target.closest('[data-dl]');
        if (dl) {
          const kind = dl.dataset.dl;
          if (kind === 'xlsx') download(`inventario-farmacias-piedra-${stamp()}.xlsx`, planillaXlsx(templateRows(), { help: HELP }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
          else if (kind === 'csv') download(`inventario-farmacias-piedra-${stamp()}.csv`, planillaCsv(templateRows(), TEMPLATE_HEADERS), 'text/csv;charset=utf-8');
          else if (kind === 'problemas') {
            const a = analysis();
            const bad = a ? a.c.rows.filter((r) => r.status === 'error' || r.status === 'warn') : [];
            download(`filas-con-problemas-${stamp()}.csv`, planillaCsv(bad.map((r) => [r.line, r.code, r.name, r.qtyText, r.costText, r.priceText, r.deptText, r.msg]), ['Fila', ...TEMPLATE_HEADERS, 'Problema']), 'text/csv;charset=utf-8');
          }
          return;
        }
        if (e.target.closest('[data-other]')) {
          reset();
          paint();
          msg.innerHTML = '';
          input.click();
          return;
        }
        if (!e.target.closest('#cm-go')) return;
        const a = analysis();
        if (!a || S.busy) return;
        const rows = payloadRows(a);
        const needLoc = rows.some((r) => r.qty != null);
        if (!rows.length || (needLoc && (!S.loc || !S.mode))) return;
        const nNew = rows.filter((r) => r.def).length;
        const nUpd = rows.length - nNew;
        const hideDemo = S.opts.hideDemo && nNew > 0 && demoVisible() > 0;
        const bits = [];
        if (nNew) bits.push(`se crearán <b>${num(nNew)}</b> productos nuevos`);
        if (nUpd) bits.push(`se actualizarán <b>${num(nUpd)}</b> productos`);
        if (needLoc) bits.push(`la existencia ${S.mode === 'add' ? 'se suma en' : 'queda igual a la planilla en'} <b>${esc(locLabel(S.loc))}</b>`);
        if (hideDemo) bits.push(`se ocultarán los <b>${num(demoVisible())}</b> productos de ejemplo`);
        const ok = await confirmDialog({
          title: '¿Cargar la planilla?',
          text: `${bits.join('; ')}.${a.c.counts.error ? ` Las ${num(a.c.counts.error)} filas con error no se cargan.` : ''}${repeated() ? ' <b>Ya cargaste este mismo archivo con «Sumar»: las cantidades se sumarán otra vez.</b>' : ''}`,
          confirmText: repeated() ? 'Sí, sumar otra vez' : 'Cargar',
          danger: repeated(),
        });
        if (!ok) return;
        S.busy = true;
        paintPreview();
        try {
          const r = await importPlanilla({ file: S.file, loc: needLoc ? S.loc : undefined, mode: needLoc ? S.mode : undefined, rows, hideDemo });
          if (S.sig && needLoc) DONE.push({ sig: S.sig, mode: S.mode, loc: S.loc, at: Date.now() });
          S.busy = false;
          S.result = { ...r, notLoaded: a.c.counts.error + (r.skippedCount || 0) };
          S.items = null;
          paint();
          toast(r.created ? `Listo: creaste <b>${num(r.created)}</b> productos.` : 'Listo: cargaste la planilla.');
          work.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } catch (err) {
          S.busy = false;
          paintPreview();
          toast(esc(friendlyError(err)), { tone: 'warn', timeout: 7000 });
        }
      });
    },
  };
}

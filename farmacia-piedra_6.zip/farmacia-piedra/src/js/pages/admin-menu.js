// Panel: tarjetas de color del menú «Categorías» de la tienda
// (crear, editar, ordenar, pausar, programar y eliminar).

import { $, $$, esc, formData, setErrors, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice, emptyState } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { menuCardHtml, withLiveMenuText } from '../ui/megacards.js';
import { go } from '../router.js';
import { MENU_TONES, MENU_ICONS, MENU_LIMITS } from '../engine/menucards.js';
import { adminShell, adminGuard, saveError } from './admin.js';
import { destOf, destSelect, destTo, destErrors, destLabel, productOptions } from './admin-banners.js';
import { imageDropHtml, mountImageDrop, sizeText } from '../admin/imgdrop.js';
import {
  bo, adminMenuList, liveMenu, menuCardStatus, findMenuCard, saveMenuCard, deleteMenuCard, moveMenuCard, setMenuCardActive,
  MENU_VISIBLE, MAX_MENU_CARDS, PHOTO_SIZES,
} from '../admin/api.js';

const STATUS = {
  activo: ['En el menú', 'ok'],
  pausado: ['Pausada', ''],
  programado: ['Programada', 'info'],
  vencido: ['Terminada', 'warn'],
};

const fmtDate = (iso) => (iso ? iso.split('-').reverse().join('-') : '');
const TITLE = 'Menú Categorías · Administración';

function menuWait() {
  if (bo.ready) return null;
  return {
    title: TITLE,
    rerender: ['backoffice'],
    html: '<div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Cargando las tarjetas del menú…</p></div></div>',
  };
}

function statusChip(c, hiddenByLimit) {
  if (hiddenByLimit) return `<span class="chip chip--warn" title="En el menú caben ${MENU_VISIBLE} tarjetas activas. Sube esta o pausa otra para que aparezca.">No cabe en el menú</span>`;
  const [label, tone] = STATUS[menuCardStatus(c)];
  return `<span class="chip${tone ? ` chip--${tone}` : ''}">${esc(label)}</span>`;
}

// ── Lista ────────────────────────────────────────────────────
export function adminMenuPage() {
  const guard = adminGuard() || menuWait();
  if (guard) return guard;
  const list = adminMenuList();
  const live = liveMenu();
  const liveIds = new Set(live.map((c) => c.id));
  const builtin = list.some((c) => c.builtin);
  const full = list.length >= MAX_MENU_CARDS;
  const activeNow = list.filter((c) => menuCardStatus(c) === 'activo');
  const newBtn = full
    ? `<button type="button" class="btn btn--primary btn--sm" disabled title="Puedes guardar hasta ${MAX_MENU_CARDS} tarjetas">${icon('plus')} Nueva tarjeta</button>`
    : `<a class="btn btn--primary btn--sm" href="#/admin/menu/nuevo" data-link>${icon('plus')} Nueva tarjeta</a>`;

  const body = `<section class="panel mnow">
      <div class="panel__head"><h2 class="panel__title">Así se ve hoy en la tienda</h2><span class="muted">Columna derecha del menú «Categorías»</span></div>
      ${live.length ? `<div class="mnow__cards">${live.map((c) => menuCardHtml(withLiveMenuText(c), { tag: 'div' })).join('')}</div>` : `<div class="chart-empty">${icon('menu')}<p><b>No hay tarjetas activas hoy.</b><br>El menú «Categorías» se muestra sin la columna de destacados.</p></div>`}
    </section>
    ${builtin ? notice('info', 'Estas son las <b>tarjetas de ejemplo</b>. Apenas edites, agregues, ordenes o pauses alguna, pasan a ser tuyas.') : ''}
    ${activeNow.length > MENU_VISIBLE ? notice('warn', `Tienes ${activeNow.length} tarjetas activas, pero en el menú caben <b>${MENU_VISIBLE}</b>. Se muestran las primeras de la lista; ordénalas con las flechas.`) : ''}
    ${list.length ? `<ol class="blist mlist">${list.map((c, i) => {
      const status = menuCardStatus(c);
      const over = status === 'activo' && !liveIds.has(c.id);
      return `<li class="bcard mrow${status === 'activo' && !over ? '' : ' is-off'}" data-card="${esc(c.id)}">
      <div class="mrow__prev" aria-hidden="true">${menuCardHtml(withLiveMenuText(c), { tag: 'div' })}</div>
      <div class="bcard__info">
        <span class="bcard__pos">${i + 1}</span>
        <div><b>${esc(c.title)}</b>
          <small>${c.kicker ? `${esc(c.kicker)} · ` : ''}Lleva a ${esc(destLabel(c.to))}</small>
          <div class="bcard__chips">${statusChip(c, over)}${c.dynamic === 'club' ? `<span class="chip chip--club" title="Muestra la campaña del Club de cada día. Si editas su texto, queda fijo.">${icon('star')}Cambia solo cada día</span>` : ''}${c.from || c.until ? `<span class="chip">${icon('calendar')}${c.from ? `desde ${fmtDate(c.from)}` : ''}${c.from && c.until ? ' ' : ''}${c.until ? `hasta ${fmtDate(c.until)}` : ''}</span>` : ''}</div>
        </div>
      </div>
      <div class="bcard__act">
        <button type="button" class="icon-btn" data-mmove="-1" data-id="${esc(c.id)}" aria-label="Subir ${esc(c.title)}" ${i === 0 ? 'disabled' : ''}>${icon('arrowUp')}</button>
        <button type="button" class="icon-btn" data-mmove="1" data-id="${esc(c.id)}" aria-label="Bajar ${esc(c.title)}" ${i === list.length - 1 ? 'disabled' : ''}>${icon('arrowDown')}</button>
        <button type="button" class="btn btn--ghost btn--sm" data-mactive="${c.active ? '0' : '1'}" data-id="${esc(c.id)}">${icon(c.active ? 'pause' : 'play')} ${c.active ? 'Pausar' : 'Activar'}</button>
        <a class="btn btn--soft btn--sm" href="#/admin/menu/${esc(c.id)}" data-link>${icon('edit')} Editar</a>
        <button type="button" class="btn btn--ghost btn--sm" data-mdel="${esc(c.id)}" aria-label="Eliminar ${esc(c.title)}">${icon('trash')}</button>
      </div>
    </li>`;
    }).join('')}</ol>` : emptyState({ icon: 'menu', title: 'Aún no hay tarjetas', text: 'Crea la primera para destacar el Club, una oferta o un servicio dentro del menú «Categorías».', actions: '<a class="btn btn--primary" href="#/admin/menu/nuevo" data-link>Crear tarjeta</a>' })}
    ${full ? `<p class="muted mlist__max">${icon('info', 'inline-ico')} Llegaste al máximo de ${MAX_MENU_CARDS} tarjetas guardadas. Elimina alguna para crear otra.</p>` : ''}`;

  return {
    title: TITLE,
    rerender: ['backoffice', 'catalog'],
    html: adminShell('menu', 'Menú «Categorías»', body, {
      sub: `Las tarjetas de color que aparecen a la derecha cuando el cliente abre «Categorías». Se ven hasta ${MENU_VISIBLE}, en el orden de esta lista. Cada una puede llevar una imagen de fondo de ${sizeText(PHOTO_SIZES.menu)}.`,
      actions: newBtn,
    }),
    mount(root) {
      root.addEventListener('click', async (e) => {
        const mv = e.target.closest('[data-mmove]');
        const ac = e.target.closest('[data-mactive]');
        const del = e.target.closest('[data-mdel]');
        const btn = mv || ac;
        try {
          if (mv) {
            mv.disabled = true;
            await moveMenuCard(mv.dataset.id, Number(mv.dataset.mmove));
          } else if (ac) {
            ac.disabled = true;
            await setMenuCardActive(ac.dataset.id, ac.dataset.mactive === '1');
            toast(ac.dataset.mactive === '1' ? 'La tarjeta vuelve al menú.' : 'Pausaste la tarjeta: ya no se muestra.', { tone: 'info' });
          } else if (del) {
            const c = findMenuCard(del.dataset.mdel);
            if (!(await confirmDialog({ title: '¿Eliminar esta tarjeta?', text: `Se eliminará <b>${esc(c?.title || '')}</b> del menú «Categorías».`, confirmText: 'Eliminar tarjeta', danger: true }))) return;
            await deleteMenuCard(del.dataset.mdel);
            toast('Eliminaste la tarjeta.', { tone: 'info' });
          }
        } catch (err) {
          saveError(err);
        } finally {
          if (btn?.isConnected) btn.disabled = false;
        }
      });
    },
  };
}

// ── Crear / editar ───────────────────────────────────────────
function menuForm(c, isNew) {
  const d = destOf(c.to);
  const counter = (name, val) => `<span class="field__count" data-count="${name}">${String(val || '').length}/${MENU_LIMITS[name]}</span>`;
  return `<form id="mform" class="bform" novalidate>
    <fieldset class="panel form-grid"><legend class="panel__title">Texto</legend>
      <div class="field"><label for="m-kicker">Etiqueta superior <span class="field__opt">(opcional)</span></label><input id="m-kicker" name="kicker" maxlength="${MENU_LIMITS.kicker}" value="${esc(c.kicker || '')}" placeholder="Ej: Ofertas de la semana">${counter('kicker', c.kicker)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="m-dest">Al hacer clic lleva a</label>${destSelect(d, 'm')}<p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="search"${d.dest === 'search' ? '' : ' hidden'}><label for="m-q">Palabra a buscar</label><input id="m-q" name="q" value="${esc(d.q || '')}" placeholder="Ej: protector solar"><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="product"${d.dest === 'product' ? '' : ' hidden'}><label for="m-dprod">Producto</label><select id="m-dprod" name="dprod"><option value="">Elegir producto…</option>${productOptions(d.dprod)}</select><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="custom"${d.dest === 'custom' ? '' : ' hidden'}><label for="m-path">Dirección (empieza con /)</label><input id="m-path" name="path" value="${esc(d.path || '')}" placeholder="Ej: /categoria/belleza"><p class="field__error" aria-live="polite"></p></div>
      <div class="field field--full"><label for="m-title">Título</label><input id="m-title" name="title" maxlength="${MENU_LIMITS.title}" value="${esc(c.title || '')}" required placeholder="Ej: Hasta 30% en vitaminas">${counter('title', c.title)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field field--full"><label for="m-text">Texto corto <span class="field__opt">(opcional)</span></label><input id="m-text" name="text" maxlength="${MENU_LIMITS.text}" value="${esc(c.text || '')}" placeholder="Una frase corta, por ejemplo: Solo hasta el domingo.">${counter('text', c.text)}<p class="field__error" aria-live="polite"></p></div>
    </fieldset>
    <fieldset class="panel bform__design"><legend class="panel__title">Diseño</legend>
      <p class="bform__label">Color de fondo</p>
      <div class="swatches" role="radiogroup" aria-label="Color de fondo">${Object.entries(MENU_TONES).map(([k, label]) => `<label class="swatch"><input type="radio" name="tone" value="${k}"${(c.tone || 'lapis') === k ? ' checked' : ''}><span class="swatch__chip mchip mcard--${k}" aria-hidden="true"></span><span>${esc(label)}</span></label>`).join('')}</div>
      <p class="bform__label">Ícono</p>
      <div class="icon-pick" role="radiogroup" aria-label="Ícono">
        <label class="icon-pick__opt" title="Sin ícono"><input type="radio" name="icon" value=""${c.icon ? '' : ' checked'}><span>${icon('x')}<small>Ninguno</small></span></label>
        ${Object.entries(MENU_ICONS).map(([k, label]) => `<label class="icon-pick__opt" title="${esc(label)}"><input type="radio" name="icon" value="${k}"${c.icon === k ? ' checked' : ''}><span>${icon(k)}<small>${esc(label)}</small></span></label>`).join('')}
      </div>
    </fieldset>
    <fieldset class="panel form-grid"><legend class="panel__title">Publicación</legend>
      <div class="field full"><label class="switch"><input type="checkbox" name="active"${c.active === false ? '' : ' checked'}><span class="switch__track" aria-hidden="true"></span><span><b>Mostrar en el menú</b><small>Si la apagas, la tarjeta queda guardada pero no se ve.</small></span></label></div>
      <div class="field"><label for="m-from">Mostrar desde <span class="field__opt">(opcional)</span></label><input id="m-from" name="from" type="date" value="${esc(c.from || '')}"><p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="m-until">Mostrar hasta <span class="field__opt">(opcional)</span></label><input id="m-until" name="until" type="date" value="${esc(c.until || '')}"><p class="field__error" aria-live="polite"></p></div>
    </fieldset>
    <div class="pform__actions"><button class="btn btn--primary btn--lg" type="submit">${isNew ? `${icon('plus')} Crear tarjeta` : 'Guardar tarjeta'}</button><a class="btn btn--ghost btn--lg" href="#/admin/menu" data-link>Cancelar</a>${isNew ? '' : `<button type="button" class="btn btn--ghost btn--lg bform__del" data-mdel>${icon('trash')} Eliminar</button>`}</div>
  </form>`;
}

function cardFromForm(v, cur, image) {
  return {
    ...cur,
    image: image || '',
    kicker: v.kicker.trim(),
    title: v.title.trim(),
    text: v.text.trim(),
    to: destTo(v),
    tone: v.tone || 'lapis',
    icon: v.icon || '',
    active: !!v.active,
    from: v.from || '',
    until: v.until || '',
  };
}

function validate(v) {
  const e = {};
  if (!v.title.trim()) e.title = 'Escribe el título de la tarjeta.';
  destErrors(v, e);
  if (v.from && v.until && v.until < v.from) e.until = 'La fecha final debe ser posterior a la inicial.';
  return e;
}

export function adminMenuCardPage(params) {
  const guard = adminGuard() || menuWait();
  if (guard) return guard;
  const isNew = params.id === 'nuevo' || !params.id;
  const cur = isNew
    ? { kicker: '', title: '', text: '', to: '/ofertas', tone: 'jade', icon: 'percent', active: true }
    : findMenuCard(params.id);
  const back = `<a class="btn btn--ghost btn--sm" href="#/admin/menu" data-link>${icon('arrowLeft')} Menú</a>`;
  if (!cur) {
    return { title: 'Tarjeta no encontrada', html: adminShell('menu', 'Tarjeta no encontrada', emptyState({ icon: 'menu', title: 'No encontramos esa tarjeta', text: 'Puede que se haya eliminado.', actions: '<a class="btn btn--primary" href="#/admin/menu" data-link>Volver al menú</a>' })) };
  }
  if (isNew && adminMenuList().length >= MAX_MENU_CARDS) {
    return { title: TITLE, html: adminShell('menu', 'Nueva tarjeta', emptyState({ icon: 'menu', title: `Ya tienes ${MAX_MENU_CARDS} tarjetas`, text: 'Elimina alguna que ya no uses para crear otra.', actions: '<a class="btn btn--primary" href="#/admin/menu" data-link>Volver al menú</a>' }), { actions: back }) };
  }
  const body = `<div class="mform-wrap">
      <div class="mform-main">
        ${cur.dynamic === 'club' ? notice('info', 'Hoy esta tarjeta muestra sola la <b>campaña del Club de cada día</b>. Si cambias la etiqueta, el título o el texto, quedará fijo con lo que escribas.') : ''}
        ${menuForm(cur, isNew)}
      </div>
      <aside class="panel mform-prev" aria-label="Vista previa">
        <h2 class="panel__title">Vista previa</h2>
        <p class="muted">Así se verá en el menú «Categorías».</p>
        <div class="mform-prev__col" id="mpreview">${menuCardHtml(withLiveMenuText(cur.title ? cur : { ...cur, title: 'Título de la tarjeta' }), { tag: 'div' })}</div>
        ${imageDropHtml({ name: 'mphoto', title: 'Imagen de fondo', optional: true, size: PHOTO_SIZES.menu, image: cur.image || '', note: 'Va detrás del texto, con un velo del color elegido para que se lea. Si no subes una, la tarjeta queda solo con el color.' })}
      </aside>
    </div>`;
  return {
    title: `${isNew ? 'Nueva tarjeta' : 'Editar tarjeta'} · Administración`,
    html: adminShell('menu', isNew ? 'Nueva tarjeta del menú' : 'Editar tarjeta del menú', body, { actions: back }),
    onState: () => true, // no repintar mientras se edita
    mount(root) {
      const f = $('#mform', root);
      const preview = $('#mpreview', root);
      let image = cur.image || '';
      const sync = () => {
        const v = formData(f);
        $$('[data-dest]', f).forEach((el) => { el.hidden = el.dataset.dest !== v.dest; });
        $$('[data-count]', f).forEach((el) => { el.textContent = `${(v[el.dataset.count] || '').length}/${MENU_LIMITS[el.dataset.count]}`; });
        const draft = cardFromForm(v, cur, image);
        // La tarjeta del Club sigue con su texto automático hasta que se edite
        const auto = cur.dynamic === 'club' && draft.title === cur.title && draft.text === (cur.text || '') && draft.kicker === (cur.kicker || '');
        const shown = auto ? withLiveMenuText(draft) : draft;
        preview.innerHTML = menuCardHtml(shown.title ? shown : { ...shown, title: 'Título de la tarjeta' }, { tag: 'div' });
      };
      mountImageDrop($('[data-idrop="mphoto"]', root), {
        size: PHOTO_SIZES.menu,
        maxW: 600,
        maxChars: 300000,
        onChange(url) { image = url; sync(); },
      });
      f.addEventListener('input', debounce(sync, 100));
      f.addEventListener('change', sync);
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = formData(f);
        if (!setErrors(f, validate(v))) return;
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        try {
          await saveMenuCard(cardFromForm(v, isNew ? {} : cur, image));
          toast(isNew ? 'Creaste la tarjeta. Ya está en el menú «Categorías».' : 'Guardamos los cambios de la tarjeta.');
          go('/admin/menu');
        } catch (err) {
          saveError(err);
        } finally {
          btn.disabled = false;
        }
      });
      root.addEventListener('click', async (e) => {
        if (!e.target.closest('[data-mdel]')) return;
        if (!(await confirmDialog({ title: '¿Eliminar esta tarjeta?', text: `Se eliminará <b>${esc(cur.title)}</b> del menú «Categorías».`, confirmText: 'Eliminar tarjeta', danger: true }))) return;
        try { await deleteMenuCard(cur.id); toast('Eliminaste la tarjeta.', { tone: 'info' }); go('/admin/menu', { replace: true }); } catch (err) { saveError(err); }
      });
      sync();
      return null;
    },
  };
}

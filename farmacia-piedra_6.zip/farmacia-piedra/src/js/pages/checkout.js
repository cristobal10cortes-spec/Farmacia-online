// Checkout en pasos: datos, entrega (despacho o retiro), recetas y pago.

import { $, $$, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { field, checkbox, notice, emptyState } from '../ui/components.js';
import { stepsHtml, summaryRows } from './cart.js';
import { BRAND, RX, ZONES } from '../config.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { PREVISIONES } from '../data/content.js';
import { totals, clearCart, cartItems, priceCtx } from '../engine/shop.js';
import { shippingCost } from '../engine/pricing.js';
import { deliveryInfo, storesNear, pickupInfo, zoneOf, hoursText, deliveryShortages, stockMovesFor } from '../engine/inventory.js';
import { STORES } from '../data/stores.js';
import { state, currentUser } from '../engine/state.js';
import { addAddress, savePrescription } from '../engine/account.js';
import { createOrder, syncRemoteOrder } from '../engine/orders.js';
import { deliveryDates, dayParts, dateText, todayIso } from '../engine/orderflow.js';
import { remote, submitOrder, refreshCatalog } from '../engine/datasource.js';
import { validateRut, formatRut, validEmail, validPhone, cleanPhone, formatPhone } from '../engine/rut.js';
import { clp } from '../engine/format.js';
import { openModal, toast, clearToasts } from '../ui/overlay.js';
import { go } from '../router.js';

let co = null;

function freshCheckout() {
  const u = currentUser();
  return {
    step: u ? 2 : 1,
    customer: u ? { nombre: u.nombre, apellidos: [u.apellidoP, u.apellidoM].filter(Boolean).join(' '), rut: u.rut, email: u.email, phone: u.phone } : { nombre: '', apellidos: '', rut: '', email: '', phone: '' },
    delivery: {
      type: 'despacho', region: state.location.region, comuna: state.location.comuna,
      calle: '', numero: '', depto: '', indicaciones: '', speed: 'estandar', date: '', storeId: '', pickupBy: 'yo', pickupName: '', pickupRut: '', saveAddr: !!u,
    },
    recetas: {},
    rxDeclare: false,
    payment: 'tarjeta',
    document: 'boleta',
    factura: { rut: '', razon: '', giro: '' },
    terms: false,
    userKey: u?.email || null,
  };
}

const rxItems = () => cartItems().filter((x) => x.product.rx !== 'directa');
const needsRx = () => rxItems().length > 0;
const stepCount = () => (needsRx() ? 4 : 3);
const payStep = () => (needsRx() ? 4 : 3);

function shippingFor(t) {
  const d = co.delivery;
  if (d.type === 'retiro') return 0;
  const zone = zoneOf({ region: d.region, comuna: d.comuna });
  return shippingCost({ zone, subtotal: t.total, express: d.speed === 'express', freeCoupon: t.freeShippingCoupon });
}

// ── Paso 1: datos ────────────────────────────────────────────
function stepCustomer() {
  const c = co.customer;
  const done = co.step > 1;
  const u = currentUser();
  return `<section class="co-step ${done ? 'is-done is-collapsed' : ''}" id="co-1">
    <div class="co-step__head"><span class="co-step__n">${done ? icon('check') : 1}</span><h2 class="co-step__title">Tus datos</h2>
      ${done ? `<span class="co-step__summary">${esc(c.nombre)} ${esc(c.apellidos)} · ${esc(c.email)}</span><button type="button" class="btn btn--link btn--sm co-step__edit" data-edit="1">Editar</button>` : ''}</div>
    <div class="co-step__body">
      ${!u ? `<p class="field__hint">¿Ya tienes cuenta? <a href="#/ingresar?volver=%2Fcheckout" data-link>Inicia sesión</a> para usar tus direcciones y precios Club.</p>` : ''}
      <form id="f-customer" class="form-grid" novalidate>
        ${field({ label: 'Nombre', name: 'nombre', value: c.nombre, required: true, autocomplete: 'given-name' })}
        ${field({ label: 'Apellidos', name: 'apellidos', value: c.apellidos, required: true, autocomplete: 'family-name' })}
        ${field({ label: 'RUT', name: 'rut', value: c.rut, required: true, placeholder: '12.345.678-5', hint: 'Lo usamos para tu boleta y para validar recetas.' })}
        ${field({ label: 'Celular', name: 'phone', type: 'tel', value: c.phone ? formatPhone(c.phone) : '', required: true, autocomplete: 'tel', inputmode: 'tel', placeholder: '+56 9 1234 5678', hint: 'Te llamamos o escribimos por WhatsApp si hay algo que coordinar.' })}
        ${field({ label: 'Correo electrónico', name: 'email', type: 'email', value: c.email, required: true, autocomplete: 'email', placeholder: 'tu@correo.cl', full: true, hint: 'Aquí te llegan la confirmación y el seguimiento.' })}
        <div class="full"><button type="submit" class="btn btn--primary btn--lg">Continuar a la entrega ${icon('arrowRight')}</button></div>
      </form>
    </div>
  </section>`;
}

// ── Paso 2: entrega ──────────────────────────────────────────
function stepDelivery(t) {
  const d = co.delivery;
  const locked = co.step < 2;
  const done = co.step > 2;
  const loc = { region: d.region, comuna: d.comuna };
  const del = deliveryInfo(loc, { hasCold: t.hasCold });
  const zone = zoneOf(loc);
  const z = ZONES[zone];
  const u = currentUser();
  const stdCost = shippingCost({ zone, subtotal: t.total, freeCoupon: t.freeShippingCoupon });
  const anyStore = STORES.length > 0;
  if (!anyStore && d.type === 'retiro') d.type = 'despacho';
  const stores = storesNear(loc);
  const items = cartItems();
  if (d.type === 'retiro' && stores.length && (!d.storeId || pickupInfo(stores.find((s) => s.id === d.storeId) || stores[0], items).unavailable)) {
    const firstReady = stores.find((s) => pickupInfo(s, items).ready) || stores.find((s) => !pickupInfo(s, items).unavailable);
    d.storeId = firstReady ? firstReady.id : '';
  }
  // Días que el cliente puede elegir para el despacho estándar
  const dates = del.home.ok ? deliveryDates(del.home.date) : [];
  if (!dates.includes(d.date)) d.date = dates[0] || '';
  const summary = d.type === 'despacho'
    ? `Despacho a ${esc(d.calle)} ${esc(d.numero)}, ${esc(d.comuna)}${d.speed === 'express' ? ' · express hoy' : d.date ? ` · ${esc(dateText(d.date))}` : ''}`
    : `Retiro en ${esc(stores.find((s) => s.id === d.storeId)?.name || '')}`;
  const regionOpts = REGIONS.map((r) => ({ value: r.id, label: regionLabel(r) }));
  const comunas = (regionById(d.region)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es'));

  const despacho = `
    ${u?.addresses?.length ? `<div class="radio-cards" role="radiogroup" aria-label="Direcciones guardadas">${u.addresses.map((a) => `<label class="radio-card"><input type="radio" name="saved-addr" value="${a.id}"><span class="radio-card__main"><span class="radio-card__title">${esc(a.alias || 'Dirección')}</span><span class="radio-card__text">${esc(a.calle)} ${esc(a.numero)}${a.depto ? `, ${esc(a.depto)}` : ''}, ${esc(a.comuna)}</span></span></label>`).join('')}</div><p class="field__hint">O escribe una dirección nueva:</p>` : ''}
    <form id="f-address" class="form-grid" novalidate>
      ${field({ label: 'Región', name: 'region', value: d.region, required: true, options: regionOpts })}
      ${field({ label: 'Comuna', name: 'comuna', value: d.comuna, required: true, options: comunas })}
      ${field({ label: 'Calle', name: 'calle', value: d.calle, required: true, autocomplete: 'address-line1', placeholder: 'Av. Providencia' })}
      ${field({ label: 'Número', name: 'numero', value: d.numero, required: true, inputmode: 'numeric', placeholder: '1234' })}
      ${field({ label: 'Depto., casa u oficina', name: 'depto', value: d.depto, placeholder: 'Depto. 502' })}
      ${field({ label: 'Indicaciones para el repartidor', name: 'indicaciones', value: d.indicaciones, placeholder: 'Ej: dejar en conserjería' })}
      ${u ? checkbox({ name: 'saveAddr', label: 'Guardar esta dirección en mi cuenta', checked: d.saveAddr }) : ''}
    </form>
    ${del.home.ok ? `<div class="radio-cards" role="radiogroup" aria-label="Tipo de despacho">
      <label class="radio-card"><input type="radio" name="speed" value="estandar" ${d.speed !== 'express' ? 'checked' : ''}><span class="radio-card__main"><span class="radio-card__title">Despacho estándar <span class="radio-card__price ${stdCost ? '' : 'is-free'}">${stdCost ? clp(stdCost) : 'Gratis'}</span></span><span class="radio-card__text"><span id="std-when">Llega ${esc(d.date ? dateText(d.date) : del.home.label)}</span> · ${esc(z.name)}${stdCost ? ` · gratis sobre ${clp(z.freeFrom)}` : ''}</span></span></label>
      <label class="radio-card"><input type="radio" name="speed" value="express" ${d.speed === 'express' ? 'checked' : ''} ${del.express.ok ? '' : 'disabled'}><span class="radio-card__main"><span class="radio-card__title">Express en 3 horas <span class="radio-card__price">${clp(shippingCost({ zone, subtotal: 0, express: true }))}</span></span><span class="radio-card__text">${esc(del.express.ok ? del.express.label : (del.express.reason || `No disponible en ${d.comuna}.`))}</span></span></label>
    </div>
    ${dates.length ? `<div class="ddates" id="ddates"${d.speed === 'express' ? ' hidden' : ''}>
      <p class="ddates__label">${icon('calendar')} Elige el día de entrega</p>
      <div class="ddates__list" role="radiogroup" aria-label="Día de entrega">${dates.map((iso) => {
        const p = dayParts(iso);
        return `<label class="ddate"><input type="radio" name="ddate" value="${iso}" ${iso === d.date ? 'checked' : ''}><span class="ddate__box"><small>${p.dow}</small><b>${p.day}</b><small>${p.mon}</small></span><span class="visually-hidden">${esc(dateText(iso))}</span></label>`;
      }).join('')}</div>
      <p class="field__hint">Entregamos de lunes a sábado. Si tuviéramos que cambiar el día, te avisamos en el seguimiento de tu pedido.</p>
    </div>` : ''}` : notice('warn', `${esc(del.home.reason)}${anyStore ? ' <button type="button" class="btn btn--link" data-dtype="retiro">Cambiar a retiro en farmacia</button>' : ''}`)}`;

  const retiro = `${field({ label: 'Región', name: 'region', value: d.region, options: regionOpts, attrs: 'data-pick-region' })}
    ${stores.length ? `<div class="radio-cards" role="radiogroup" aria-label="Farmacia de retiro">${stores.map((s) => {
      const pi = pickupInfo(s, items);
      return `<label class="radio-card"><input type="radio" name="store" value="${s.id}" ${s.id === d.storeId ? 'checked' : ''} ${pi.unavailable ? 'disabled' : ''}><span class="radio-card__main"><span class="radio-card__title">${esc(s.name)}${s.inComuna ? ` <span class="chip chip--info">${esc(s.comuna)}</span>` : ''}</span><span class="radio-card__text">${esc(s.address)}, ${esc(s.comuna)} · ${esc(hoursText(s))}</span><span class="radio-card__text" style="color:${pi.ready ? 'var(--ok)' : pi.unavailable ? 'var(--danger)' : 'var(--warn)'};font-weight:700">${esc(pi.label)}</span></span></label>`;
    }).join('')}</div>` : notice('warn', 'No hay farmacias Piedra en esta región. Elige otra región o despacho a domicilio.')}
    <div class="field"><label>¿Quién retira?</label><div class="seg" role="radiogroup"><button type="button" class="${d.pickupBy === 'yo' ? 'is-on' : ''}" data-pickup-by="yo">Yo</button><button type="button" class="${d.pickupBy === 'otra' ? 'is-on' : ''}" data-pickup-by="otra">Otra persona</button></div></div>
    ${d.pickupBy === 'otra' ? `<form id="f-pickup" class="form-grid" novalidate>${field({ label: 'Nombre de quien retira', name: 'pickupName', value: d.pickupName, required: true })}${field({ label: 'RUT de quien retira', name: 'pickupRut', value: d.pickupRut, required: true, placeholder: '12.345.678-5' })}</form>` : ''}
    ${t.hasRetenida ? notice('warn', 'Recuerda llevar la <b>receta original</b> de los medicamentos de receta retenida.', 'file') : ''}`;

  return `<section class="co-step ${locked ? 'is-locked' : ''} ${done ? 'is-done is-collapsed' : ''}" id="co-2">
    <div class="co-step__head"><span class="co-step__n">${done ? icon('check') : 2}</span><h2 class="co-step__title">Entrega</h2>
      ${done ? `<span class="co-step__summary">${summary}</span><button type="button" class="btn btn--link btn--sm co-step__edit" data-edit="2">Editar</button>` : ''}</div>
    <div class="co-step__body">
      <div class="seg" role="radiogroup" aria-label="Tipo de entrega">
        <button type="button" class="${d.type === 'despacho' ? 'is-on' : ''}" data-dtype="despacho" aria-pressed="${d.type === 'despacho'}">${icon('truck')}Despacho a domicilio</button>
        ${anyStore ? `<button type="button" class="${d.type === 'retiro' ? 'is-on' : ''}" data-dtype="retiro" aria-pressed="${d.type === 'retiro'}">${icon('store')}Retiro en farmacia (gratis)</button>` : ''}
      </div>
      ${d.type === 'despacho' ? despacho : retiro}
      <div><button type="button" class="btn btn--primary btn--lg" data-continue="2">Continuar ${icon('arrowRight')}</button></div>
    </div>
  </section>`;
}

// ── Paso 3: recetas ──────────────────────────────────────────
function stepRx() {
  if (!needsRx()) return '';
  const locked = co.step < 3;
  const done = co.step > 3;
  const u = currentUser();
  const saved = u?.prescriptions || [];
  const items = rxItems();
  return `<section class="co-step ${locked ? 'is-locked' : ''} ${done ? 'is-done is-collapsed' : ''}" id="co-3">
    <div class="co-step__head"><span class="co-step__n">${done ? icon('check') : 3}</span><h2 class="co-step__title">Recetas médicas</h2>
      ${done ? `<span class="co-step__summary">${Object.keys(co.recetas).length} ${Object.keys(co.recetas).length === 1 ? 'receta adjunta' : 'recetas adjuntas'}</span><button type="button" class="btn btn--link btn--sm co-step__edit" data-edit="3">Editar</button>` : ''}</div>
    <div class="co-step__body">
      <p class="field__hint">Adjunta una foto clara o PDF de la receta (máximo 8 MB). Un químico farmacéutico la valida antes de preparar tu pedido. Debe estar vigente y con nombre, RUT y firma del profesional.</p>
      ${items.map(({ product: p }) => {
        const r = co.recetas[p.id];
        return `<div class="rx-upload" data-rx="${p.id}">
          <div class="rx-upload__head"><img src="${productImg(p)}" alt="" width="52" height="52"><div><b>${esc(p.name)}</b><span class="rx rx--${RX[p.rx].tone}">${icon('file')}${esc(RX[p.rx].label)}</span></div></div>
          ${r ? `<div class="rx-upload__file">${r.thumb ? `<img src="${r.thumb}" alt="">` : icon('file')}<span>${esc(r.name)}</span><button type="button" class="btn btn--link btn--sm" data-rx-remove="${p.id}">Cambiar</button></div>`
            : `<label class="rx-upload__drop">${icon('upload')}<span><b>Sube la receta</b> o arrástrala aquí · JPG, PNG o PDF</span><input type="file" accept="image/*,application/pdf" data-rx-file="${p.id}"></label>
            ${saved.length ? `<div class="field"><label for="rx-saved-${p.id}">O usa una receta guardada</label><select id="rx-saved-${p.id}" data-rx-saved="${p.id}"><option value="">Elegir…</option>${saved.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></div>` : ''}`}
          ${p.rx === 'retenida' ? '<p class="field__hint">Receta retenida: además, entrega la receta original al recibir o retirar.</p>' : ''}
        </div>`;
      }).join('')}
      <label class="check"><input type="checkbox" id="rx-declare" ${co.rxDeclare ? 'checked' : ''}><span>Declaro que las recetas son auténticas, están vigentes y fueron emitidas para el paciente que usará los medicamentos.</span></label>
      <p class="field__error" id="rx-error" aria-live="polite"></p>
      <div><button type="button" class="btn btn--primary btn--lg" data-continue="3">Continuar al pago ${icon('arrowRight')}</button></div>
    </div>
  </section>`;
}

// ── Paso final: pago ─────────────────────────────────────────
function stepPay(t, shipping) {
  const n = payStep();
  const locked = co.step < n;
  const total = t.total + shipping;
  const pickup = co.delivery.type === 'retiro';
  if (!pickup && co.payment === 'farmacia') co.payment = 'tarjeta';
  return `<section class="co-step ${locked ? 'is-locked' : ''}" id="co-${n}">
    <div class="co-step__head"><span class="co-step__n">${n}</span><h2 class="co-step__title">Pago</h2></div>
    <div class="co-step__body">
      <div class="radio-cards" role="radiogroup" aria-label="Medio de pago">
        <label class="radio-card"><input type="radio" name="pay" value="tarjeta" ${co.payment === 'tarjeta' ? 'checked' : ''}>${icon('card')}<span class="radio-card__main"><span class="radio-card__title">Tarjeta de débito, crédito o prepago</span><span class="radio-card__text">Pagas en la pasarela de pago segura. No guardamos los datos de tu tarjeta.</span></span></label>
        <label class="radio-card"><input type="radio" name="pay" value="transferencia" ${co.payment === 'transferencia' ? 'checked' : ''}>${icon('bank')}<span class="radio-card__main"><span class="radio-card__title">Transferencia bancaria</span><span class="radio-card__text">Te mostramos los datos al confirmar. Preparamos tu pedido cuando recibimos el pago.</span></span></label>
        ${pickup ? `<label class="radio-card"><input type="radio" name="pay" value="farmacia" ${co.payment === 'farmacia' ? 'checked' : ''}>${icon('cash')}<span class="radio-card__main"><span class="radio-card__title">Pagar al retirar en farmacia</span><span class="radio-card__text">Efectivo o tarjeta en la farmacia de retiro.</span></span></label>` : ''}
      </div>
      <div class="field"><label>Documento tributario</label><div class="seg" role="radiogroup"><button type="button" class="${co.document === 'boleta' ? 'is-on' : ''}" data-doc="boleta">Boleta</button><button type="button" class="${co.document === 'factura' ? 'is-on' : ''}" data-doc="factura">Factura</button></div></div>
      ${co.document === 'factura' ? `<form id="f-factura" class="form-grid" novalidate>
        ${field({ label: 'RUT de la empresa', name: 'rut', value: co.factura.rut, required: true, placeholder: '76.123.456-7' })}
        ${field({ label: 'Razón social', name: 'razon', value: co.factura.razon, required: true })}
        ${field({ label: 'Giro', name: 'giro', value: co.factura.giro, required: true, full: true })}
      </form>` : ''}
      <label class="check"><input type="checkbox" id="co-terms" ${co.terms ? 'checked' : ''}><span>Acepto los <a href="#/legal/terminos" data-link target="_self">términos y condiciones</a> y la <a href="#/legal/privacidad" data-link>política de privacidad</a>.</span></label>
      <p class="field__error" id="pay-error" aria-live="polite"></p>
      ${BRAND.demo ? notice('info', 'Sitio de demostración: el pago es simulado y no se realiza ningún cobro.') : ''}
      <button type="button" class="btn btn--primary btn--lg btn--block" data-pay>${icon('lock')} ${co.payment === 'tarjeta' ? `Pagar ${clp(total)}` : `Confirmar pedido por ${clp(total)}`}</button>
    </div>
  </section>`;
}

function summaryPanel(t, shipping) {
  return `<div class="panel summary">
    <h2 class="panel__title">Tu pedido</h2>
    <div class="mini__lines">${t.lines.map((l) => `<div class="mini__line"><img src="${productImg(l.product)}" alt="" width="58" height="58"><div><a href="#/producto/${l.product.slug}" data-link>${esc(l.product.name)}</a><small>${l.qty} × ${clp(l.info.sale)}</small></div><b>${clp(l.total)}</b></div>`).join('')}</div>
    ${summaryRows(t, { shipping })}
    <a class="btn btn--link btn--sm" href="#/carro" data-link>Modificar carro</a>
  </div>`;
}

function render() {
  const t = totals();
  const shipping = shippingFor(t);
  return `<div class="wrap page page--tight">
    ${stepsHtml(2)}
    <div class="page-head"><h1 class="page-title">Entrega y pago</h1></div>
    <div class="two-col">
      <div class="co">${stepCustomer()}${stepDelivery(t)}${stepRx()}${stepPay(t, shipping)}</div>
      <aside class="sticky-col" id="co-summary" aria-label="Resumen del pedido">${summaryPanel(t, shipping)}</aside>
    </div>
  </div>`;
}

// Copia legible de la receta para el químico farmacéutico (se envía al servidor)
function scaled(img, max, quality) {
  const s = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.width * s));
  c.height = Math.max(1, Math.round(img.height * s));
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(img, 0, 0, c.width, c.height);
  try { return c.toDataURL('image/jpeg', quality); } catch { return ''; }
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    if (file.size > 8 * 1024 * 1024) { reject(new Error('El archivo pesa más de 8 MB.')); return; }
    if (!/^image\//.test(file.type) && file.type !== 'application/pdf') { reject(new Error('Sube una imagen (JPG o PNG) o un PDF.')); return; }
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('No pudimos leer el archivo. Intenta con otro.'));
    if (file.type === 'application/pdf') {
      fr.onload = () => resolve({ name: file.name, size: file.size, type: file.type, thumb: '', pdf: file.size <= 2 * 1024 * 1024 ? String(fr.result) : '' });
      fr.readAsDataURL(file);
      return;
    }
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const thumb = scaled(img, 160, 0.7);
        let image = '';
        for (const [max, q] of [[1600, 0.82], [1400, 0.75], [1100, 0.7], [900, 0.65]]) {
          image = scaled(img, max, q);
          if (image.length <= 900000) break;
        }
        resolve({ name: file.name, size: file.size, type: file.type, thumb, image: image.length <= 900000 ? image : '' });
      };
      img.onerror = () => resolve({ name: file.name, size: file.size, type: file.type, thumb: '' });
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

function gateway(total) {
  return new Promise((resolve) => {
    let result = null;
    openModal({
      title: `${icon('lock')} Pasarela de pago`,
      size: 'sm',
      html: `<div class="gateway">
        <span class="gateway__brand">${icon('shield')} Pago seguro · demostración</span>
        <p class="muted">${esc(BRAND.fullName)}</p>
        <div class="gateway__amount">${clp(total)}</div>
        <p class="ov__text">Aquí se abriría la pasarela de pago de tu banco o proveedor. En esta demostración puedes simular el resultado. <b>No se realiza ningún cobro.</b></p>
        <div class="gateway__actions"><button type="button" class="btn btn--ghost" data-gw="no">Simular pago rechazado</button><button type="button" class="btn btn--primary" data-gw="ok">Simular pago aprobado</button></div>
      </div>`,
      onMount(api) {
        api.el.addEventListener('click', (e) => {
          const b = e.target.closest('[data-gw]');
          if (!b) return;
          if (b.dataset.gw === 'ok') {
            api.setBody('<div class="gateway"><div class="spinner" role="status" aria-label="Procesando pago"></div><p>Procesando tu pago…</p></div>');
            setTimeout(() => { result = true; api.close(); }, 1100);
          } else {
            result = false;
            api.close();
          }
        });
      },
      onClose() { resolve(result); },
    });
  });
}

export function checkoutPage() {
  if (!cartItems().length) {
    return {
      title: 'Entrega y pago',
      html: `<div class="wrap page">${emptyState({ icon: 'bag', title: 'Tu carro está vacío', text: 'Agrega productos para continuar con la compra.', actions: '<a class="btn btn--primary" href="#/" data-link>Ir a la tienda</a>' })}</div>`,
    };
  }
  const u = currentUser();
  if (!co || co.userKey !== (u?.email || null)) co = freshCheckout();
  if (co.step > stepCount()) co.step = stepCount();

  return {
    title: 'Entrega y pago',
    html: render(),
    mount(root) {
      const rerender = (focusSel) => {
        root.innerHTML = render();
        if (focusSel) {
          const el = root.querySelector(focusSel);
          el?.scrollIntoView({ block: 'start', behavior: 'smooth' });
          el?.querySelector('input:not([type=hidden]):not([disabled]), button, select')?.focus({ preventScroll: true });
        }
      };
      const readAddress = () => {
        const f = $('#f-address', root);
        if (!f) return;
        const v = formData(f);
        Object.assign(co.delivery, { region: v.region, comuna: v.comuna, calle: v.calle.trim(), numero: v.numero.trim(), depto: v.depto.trim(), indicaciones: v.indicaciones.trim(), saveAddr: !!v.saveAddr });
      };

      root.addEventListener('submit', (e) => {
        if (e.target.id !== 'f-customer') return;
        e.preventDefault();
        const v = formData(e.target);
        const errors = {};
        if (!v.nombre.trim()) errors.nombre = 'Ingresa tu nombre.';
        if (!v.apellidos.trim()) errors.apellidos = 'Ingresa tus apellidos.';
        if (!validateRut(v.rut)) errors.rut = 'El RUT no es válido. Revisa el dígito verificador.';
        if (!validPhone(v.phone)) errors.phone = 'Ingresa un celular de 9 dígitos que comience con 9.';
        if (!validEmail(v.email)) errors.email = 'Ingresa un correo válido.';
        if (!setErrors(e.target, errors)) return;
        co.customer = { nombre: v.nombre.trim(), apellidos: v.apellidos.trim(), rut: formatRut(v.rut), email: v.email.trim().toLowerCase(), phone: cleanPhone(v.phone) };
        co.step = 2;
        rerender('#co-2');
      });

      root.addEventListener('change', async (e) => {
        const t = e.target;
        if (t.closest('#f-address') && (t.name === 'region' || t.name === 'comuna')) {
          readAddress();
          if (t.name === 'region') co.delivery.comuna = regionById(co.delivery.region).comunas[0];
          co.delivery.speed = 'estandar';
          rerender();
          root.querySelector(`#f-address [name="${t.name}"]`)?.focus();
          return;
        }
        if (t.matches('[data-pick-region]')) {
          co.delivery.region = t.value;
          co.delivery.comuna = regionById(t.value).comunas[0];
          co.delivery.storeId = '';
          rerender();
          return;
        }
        if (t.name === 'saved-addr') {
          const a = currentUser()?.addresses.find((x) => x.id === t.value);
          if (a) {
            const reg = REGIONS.find((r) => r.comunas.includes(a.comuna));
            Object.assign(co.delivery, { region: reg?.id || co.delivery.region, comuna: a.comuna, calle: a.calle, numero: a.numero, depto: a.depto || '', indicaciones: a.indicaciones || '', saveAddr: false });
            rerender();
          }
          return;
        }
        if (t.name === 'speed') {
          readAddress();
          co.delivery.speed = t.value;
          const dd = $('#ddates', root);
          if (dd) dd.hidden = t.value === 'express';
          updateSummary();
          return;
        }
        if (t.name === 'ddate') {
          co.delivery.date = t.value;
          const w = $('#std-when', root);
          if (w) w.textContent = `Llega ${dateText(t.value)}`;
          return;
        }
        if (t.name === 'store') { co.delivery.storeId = t.value; return; }
        if (t.name === 'pay') { co.payment = t.value; rerenderPay(); return; }
        if (t.id === 'co-terms') { co.terms = t.checked; return; }
        if (t.id === 'rx-declare') { co.rxDeclare = t.checked; return; }
        if (t.matches('[data-rx-file]')) {
          const file = t.files?.[0];
          if (!file) return;
          try {
            co.recetas[t.dataset.rxFile] = await readFile(file);
            rerender('#co-3');
          } catch (err) {
            toast(esc(err.message), { tone: 'warn' });
            t.value = '';
          }
          return;
        }
        if (t.matches('[data-rx-saved]')) {
          const s = currentUser()?.prescriptions.find((x) => x.id === t.value);
          if (s) { co.recetas[t.dataset.rxSaved] = { name: s.name, thumb: s.thumb || '', saved: true }; rerender('#co-3'); }
        }
      });

      // Arrastrar y soltar recetas
      root.addEventListener('dragover', (e) => { const d = e.target.closest('.rx-upload__drop'); if (d) { e.preventDefault(); d.classList.add('is-drag'); } });
      root.addEventListener('dragleave', (e) => { e.target.closest('.rx-upload__drop')?.classList.remove('is-drag'); });
      root.addEventListener('drop', async (e) => {
        const d = e.target.closest('.rx-upload__drop');
        if (!d) return;
        e.preventDefault();
        const input = $('input[type=file]', d);
        const file = e.dataTransfer?.files?.[0];
        if (!file || !input) return;
        try {
          co.recetas[input.dataset.rxFile] = await readFile(file);
          rerender('#co-3');
        } catch (err) { toast(esc(err.message), { tone: 'warn' }); }
      });

      function updateSummary() {
        const t = totals();
        const box = $('#co-summary', root);
        if (box) box.innerHTML = summaryPanel(t, shippingFor(t));
        const payBtn = $('[data-pay]', root);
        if (payBtn) payBtn.innerHTML = `${icon('lock')} ${co.payment === 'tarjeta' ? `Pagar ${clp(t.total + shippingFor(t))}` : `Confirmar pedido por ${clp(t.total + shippingFor(t))}`}`;
      }
      function rerenderPay() { updateSummary(); rerender(); }

      root.addEventListener('click', async (e) => {
        const edit = e.target.closest('[data-edit]');
        if (edit) { co.step = Number(edit.dataset.edit); rerender(`#co-${co.step}`); return; }
        const dt = e.target.closest('[data-dtype]');
        if (dt) { readAddress(); co.delivery.type = dt.dataset.dtype; rerender('#co-2'); return; }
        const pb = e.target.closest('[data-pickup-by]');
        if (pb) { co.delivery.pickupBy = pb.dataset.pickupBy; rerender('#co-2'); return; }
        const doc = e.target.closest('[data-doc]');
        if (doc) { co.document = doc.dataset.doc; rerender(`#co-${payStep()}`); return; }
        const rrm = e.target.closest('[data-rx-remove]');
        if (rrm) { delete co.recetas[rrm.dataset.rxRemove]; rerender('#co-3'); return; }

        const cont = e.target.closest('[data-continue]');
        if (cont && cont.dataset.continue === '2') {
          const t = totals();
          if (co.delivery.type === 'despacho') {
            readAddress();
            const f = $('#f-address', root);
            const errors = {};
            if (!co.delivery.calle) errors.calle = 'Ingresa la calle.';
            if (!co.delivery.numero) errors.numero = 'Ingresa el número.';
            if (!setErrors(f, errors)) return;
            const del = deliveryInfo({ region: co.delivery.region, comuna: co.delivery.comuna }, { hasCold: t.hasCold });
            if (!del.home.ok) { toast(esc(del.home.reason), { tone: 'warn' }); return; }
            const short = deliveryShortages(cartItems(), zoneOf({ region: co.delivery.region, comuna: co.delivery.comuna }));
            if (short.length) {
              toast(`No hay stock suficiente para despacho: ${short.map((x) => `<b>${esc(x.product.name)}</b> (${x.available ? `quedan ${x.available}` : 'agotado'})`).join(', ')}. Ajusta la cantidad en el carro o elige retiro en farmacia.`, { tone: 'warn', timeout: 8000 });
              return;
            }
            if (co.delivery.speed === 'express' && !del.express.ok) co.delivery.speed = 'estandar';
          } else {
            if (!co.delivery.storeId) { toast('Elige la farmacia donde retirarás.', { tone: 'warn' }); return; }
            const chosen = storesNear({ region: co.delivery.region, comuna: co.delivery.comuna }).find((x) => x.id === co.delivery.storeId);
            const pi = chosen ? pickupInfo(chosen, cartItems()) : null;
            if (!pi || pi.unavailable) { toast(pi ? esc(pi.label) : 'Elige la farmacia donde retirarás.', { tone: 'warn', timeout: 7000 }); return; }
            if (co.delivery.pickupBy === 'otra') {
              const f = $('#f-pickup', root);
              const v = formData(f);
              const errors = {};
              if (!v.pickupName.trim()) errors.pickupName = 'Ingresa el nombre de quien retira.';
              if (!validateRut(v.pickupRut)) errors.pickupRut = 'Ingresa un RUT válido.';
              if (!setErrors(f, errors)) return;
              co.delivery.pickupName = v.pickupName.trim();
              co.delivery.pickupRut = formatRut(v.pickupRut);
            }
          }
          co.step = needsRx() ? 3 : payStep();
          rerender(`#co-${co.step}`);
          return;
        }
        if (cont && cont.dataset.continue === '3') {
          const missing = rxItems().filter(({ product }) => !co.recetas[product.id]);
          const err = $('#rx-error', root);
          $$('.rx-upload', root).forEach((x) => x.classList.toggle('is-invalid', !co.recetas[x.dataset.rx]));
          if (missing.length) { err.textContent = `Falta adjuntar la receta de: ${missing.map((m) => m.product.name).join(', ')}.`; return; }
          if (!co.rxDeclare) { err.textContent = 'Debes confirmar la declaración sobre tus recetas.'; return; }
          co.step = payStep();
          rerender(`#co-${co.step}`);
          return;
        }

        if (e.target.closest('[data-pay]')) {
          const err = $('#pay-error', root);
          err.textContent = '';
          if (co.document === 'factura') {
            const f = $('#f-factura', root);
            const v = formData(f);
            const errors = {};
            if (!validateRut(v.rut)) errors.rut = 'Ingresa un RUT de empresa válido.';
            if (!v.razon.trim()) errors.razon = 'Ingresa la razón social.';
            if (!v.giro.trim()) errors.giro = 'Ingresa el giro.';
            if (!setErrors(f, errors)) return;
            co.factura = { rut: formatRut(v.rut), razon: v.razon.trim(), giro: v.giro.trim() };
          }
          if (!$('#co-terms', root)?.checked) { err.textContent = 'Debes aceptar los términos y condiciones para continuar.'; return; }
          const t = totals();
          const shipping = shippingFor(t);
          if (co.payment === 'tarjeta') {
            const ok = await gateway(t.total + shipping);
            if (ok === null) return;
            if (!ok) { toast('El pago fue rechazado y no se realizó ningún cargo. Puedes intentarlo de nuevo o elegir otro medio de pago.', { tone: 'warn', timeout: 6000 }); return; }
          }
          await finish(t, shipping, e.target.closest('[data-pay]'));
        }
      });
      return null;
    },
    onState(evt) {
      if (evt === 'cart' || evt === 'catalog') {
        if (!cartItems().length) return false;
        const t = totals();
        const box = document.getElementById('co-summary');
        if (box) box.innerHTML = summaryPanel(t, shippingFor(t));
        return true;
      }
      if (evt === 'location') return true;
      return false;
    },
  };
}

const PAY_LABELS = { tarjeta: 'Tarjeta (pasarela de pago)', transferencia: 'Transferencia bancaria', farmacia: 'Pago al retirar en farmacia' };

// Sitio oficial: el pedido lo valida y lo guarda el servidor (que también
// descuenta el stock). El cliente se queda con una copia para seguirlo.
async function finishRemote(t, shipping, btn) {
  const d = co.delivery;
  const ctx = priceCtx();
  const payload = {
    items: cartItems().map(({ product, qty }) => ({ id: product.id, qty })),
    customer: co.customer,
    delivery: {
      type: d.type, region: d.region, comuna: d.comuna, calle: d.calle, numero: d.numero, depto: d.depto,
      indicaciones: d.indicaciones, speed: d.speed, date: d.speed === 'express' ? '' : d.date, storeId: d.storeId, pickupBy: d.pickupBy, pickupName: d.pickupName, pickupRut: d.pickupRut,
    },
    payment: { method: co.payment, approved: co.payment === 'tarjeta' },
    document: co.document === 'factura' ? { type: 'factura', ...co.factura } : { type: 'boleta' },
    coupon: state.coupon || null,
    ctx: { member: !!ctx.member, treatment: [...(ctx.treatment || [])], ordersCount: ctx.ordersCount || 0 },
    rxDeclare: !!co.rxDeclare,
    prescriptions: Object.entries(co.recetas).map(([pid, r]) => ({ productId: pid, fileName: r.name, file: r.image || r.pdf || '' })),
    expectTotal: t.total + shipping,
    userEmail: state.session || null,
  };
  const label = btn?.innerHTML;
  if (btn) { btn.disabled = true; btn.innerHTML = `${icon('refresh')} Enviando tu pedido…`; }
  try {
    const r = await submitOrder(payload);
    const u = currentUser();
    if (u) {
      for (const [, rx] of Object.entries(co.recetas)) if (!rx.saved) savePrescription({ name: rx.name, thumb: rx.thumb || '' });
      if (d.type === 'despacho' && d.saveAddr && !u.addresses.some((a) => a.calle === d.calle && a.numero === d.numero && a.comuna === d.comuna)) {
        addAddress({ alias: `Dirección ${u.addresses.length + 1}`, calle: d.calle, numero: d.numero, depto: d.depto, comuna: d.comuna, indicaciones: d.indicaciones });
      }
    }
    const order = syncRemoteOrder(r.order);
    refreshCatalog(); // el stock bajó con esta compra
    co = null;
    clearCart();
    clearToasts();
    go(`/pedido/${order.id}?nuevo=1`);
  } catch (err) {
    if (btn && btn.isConnected) { btn.disabled = false; btn.innerHTML = label; }
    if (err.code === 'stock' || err.code === 'price_changed' || err.code === 'unavailable') await refreshCatalog();
    toast(esc(err.message), { tone: 'warn', timeout: 8000 });
  }
}

async function finish(t, shipping, btn) {
  if (remote()) { await finishRemote(t, shipping, btn); return; }
  const d = co.delivery;
  const u = currentUser();
  let delivery;
  if (d.type === 'despacho') {
    const del = deliveryInfo({ region: d.region, comuna: d.comuna }, { hasCold: t.hasCold });
    delivery = {
      type: 'despacho', region: d.region, regionName: regionLabel(regionById(d.region)), comuna: d.comuna,
      address: `${d.calle} ${d.numero}${d.depto ? `, ${d.depto}` : ''}`, indicaciones: d.indicaciones,
      express: d.speed === 'express', eta: d.speed === 'express' ? del.express.label : `Llega ${del.home.label}`,
      date: d.speed === 'express' ? todayIso() : (deliveryDates(del.home.date).includes(d.date) ? d.date : deliveryDates(del.home.date)[0]),
      window: d.speed === 'express' ? del.express.label.replace(/^Hoy\s+/i, '') : '',
    };
    if (u && d.saveAddr && !u.addresses.some((a) => a.calle === d.calle && a.numero === d.numero && a.comuna === d.comuna)) {
      addAddress({ alias: `Dirección ${u.addresses.length + 1}`, calle: d.calle, numero: d.numero, depto: d.depto, comuna: d.comuna, indicaciones: d.indicaciones });
    }
  } else {
    const store = storesNear({ region: d.region, comuna: d.comuna }).find((s) => s.id === d.storeId);
    const pi = pickupInfo(store, cartItems());
    delivery = { type: 'retiro', storeId: store.id, storeName: store.name, storeAddress: `${store.address}, ${store.comuna}`, comuna: store.comuna, eta: pi.label, date: pi.date || '', from: pi.from || '', fromStock: !!pi.fromStock, pickupBy: d.pickupBy, pickupName: d.pickupName, pickupRut: d.pickupRut };
  }
  const stockMoves = stockMovesFor(cartItems(), d.type === 'despacho' ? { type: 'despacho', zone: zoneOf({ region: d.region, comuna: d.comuna }) } : { type: 'retiro', storeId: d.storeId });
  const labels = PAY_LABELS;
  const prescriptions = Object.entries(co.recetas).map(([pid, r]) => ({ productId: pid, fileName: r.name }));
  if (u) for (const [, r] of Object.entries(co.recetas)) if (!r.saved) savePrescription({ name: r.name, thumb: r.thumb || '' });
  const order = createOrder({
    customer: co.customer,
    delivery,
    payment: { method: co.payment, label: labels[co.payment], status: co.payment === 'tarjeta' ? 'aprobado' : 'pendiente' },
    totals: t,
    shipping,
    prescriptions,
    document: co.document === 'factura' ? { type: 'factura', ...co.factura } : { type: 'boleta' },
    stockMoves,
  });
  co = null;
  clearCart();
  clearToasts();
  go(`/pedido/${order.id}?nuevo=1`);
}

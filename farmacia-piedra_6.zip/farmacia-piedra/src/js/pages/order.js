// Confirmación de pedido y seguimiento.

import { $, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { breadcrumbs, notice, emptyState, field } from '../ui/components.js';
import { stepsHtml } from './cart.js';
import { findOrder, orderTimeline, cancelOrder, statusLabel, syncRemoteOrder } from '../engine/orders.js';
import { remote, fetchRemoteOrder, cancelRemoteOrder, refreshRemoteOrders } from '../engine/datasource.js';
import { byId } from '../engine/catalog.js';
import { state, currentUser } from '../engine/state.js';
import { BRAND } from '../config.js';
import { clp, dateTime, shortDate } from '../engine/format.js';
import { formatPhone } from '../engine/rut.js';
import { isManaged, deliveryWhen, statusOf, progressKey } from '../engine/orderflow.js';
import { confirmDialog, toast } from '../ui/overlay.js';
import { go } from '../router.js';

function timelineHtml(o) {
  const tl = orderTimeline(o);
  return `<ol class="timeline">${tl.steps.map((s) => `<li class="${s.done ? 'is-done' : ''} ${s.current ? 'is-current' : ''} ${s.key === 'anulado' ? 'is-cancel' : ''}">
    <span class="timeline__dot">${s.done ? icon(s.key === 'anulado' ? 'x' : 'check') : icon('clock')}</span>
    <div><b>${esc(s.done || !s.wait ? s.label : s.wait)}</b><span>${s.done && s.at ? esc(dateTime(s.at)) : s.current ? 'En curso' : 'Pendiente'}</span></div>
  </li>`).join('')}</ol>`;
}

// Mensajes de la farmacia (los más nuevos arriba)
function messagesHtml(o) {
  const list = (o.messages || []).slice().reverse();
  if (!list.length) return '';
  return `<div class="panel omsgs" id="omsgs"><h2 class="panel__title">${icon('chat')} Mensajes de la farmacia</h2>
    <ol class="omsgs__list">${list.map((m, i) => `<li class="omsgs__item${i === 0 ? ' is-new' : ''}"><b>${esc(m.title)}</b><span>${esc(m.text)}</span><small>${esc(dateTime(m.at))}</small></li>`).join('')}</ol></div>`;
}

// Fecha de entrega o de retiro, destacada
function whenHtml(o) {
  const when = deliveryWhen(o);
  if (!when || o.cancelled) return '';
  const pickup = o.delivery?.type === 'retiro';
  const changed = (o.messages || []).some((m) => m.kind === 'fecha');
  const done = statusOf(o) === 'entregado' && isManaged(o);
  return `<div class="owhen${done ? ' is-done' : ''}" id="owhen">${icon(pickup ? 'store' : 'truck')}<div><small>${done ? (pickup ? 'Retirado' : 'Entregado') : pickup ? 'Fecha de retiro' : 'Fecha de entrega'}${changed && !done ? ' <span class="chip chip--info">Actualizada</span>' : ''}</small><b>${esc(when)}</b></div></div>`;
}

export function orderSummaryHtml(o) {
  const d = o.delivery;
  return `<div class="panel summary">
    <h2 class="panel__title">Productos</h2>
    <div class="mini__lines">${o.items.map((it) => {
      const p = byId.get(it.id);
      return `<div class="mini__line">${p ? `<img src="${productImg(p)}" alt="" width="58" height="58">` : '<span></span>'}<div>${p ? `<a href="#/producto/${p.slug}" data-link>${esc(it.name)}</a>` : esc(it.name)}<small>${it.qty} × ${clp(it.unit)}${it.total < it.qty * it.unit ? ' · con descuento' : ''}</small></div><b>${clp(it.total)}</b></div>`;
    }).join('')}</div>
    <div class="summary__rows">
      <div class="summary__row"><span>Productos</span><span>${clp(o.totals.listTotal)}</span></div>
      ${o.totals.offerOff ? `<div class="summary__row save"><span>Descuentos de internet</span><span>-${clp(o.totals.offerOff)}</span></div>` : ''}
      ${o.totals.promoOff ? `<div class="summary__row save"><span>Promociones</span><span>-${clp(o.totals.promoOff)}</span></div>` : ''}
      ${o.totals.clubOff ? `<div class="summary__row club"><span>Club Piedra</span><span>-${clp(o.totals.clubOff)}</span></div>` : ''}
      ${o.totals.couponOff ? `<div class="summary__row save"><span>Cupón ${esc(o.totals.coupon)}</span><span>-${clp(o.totals.couponOff)}</span></div>` : ''}
      <div class="summary__row"><span>${d.type === 'retiro' ? 'Retiro en farmacia' : 'Despacho'}</span><span>${o.totals.shipping ? clp(o.totals.shipping) : '<b style="color:var(--ok)">Gratis</b>'}</span></div>
    </div>
    <div class="summary__total"><span>${o.payment.status === 'aprobado' ? 'Total pagado' : 'Total a pagar'}</span><b>${clp(o.totals.total)}</b></div>
  </div>`;
}

export function orderPage(params, query) {
  const o = findOrder(params.id);
  if (!o) {
    return {
      title: 'Pedido no encontrado',
      html: `<div class="wrap page">${emptyState({ icon: 'box', title: 'No encontramos ese pedido', text: 'Revisa el número de pedido o búscalo en Sigue tu pedido.', actions: '<a class="btn btn--primary" href="#/seguimiento" data-link>Sigue tu pedido</a>' })}</div>`,
    };
  }
  const isNew = query.nuevo === '1';
  const d = o.delivery;
  const tl = orderTimeline(o);
  const html = `<div class="wrap page page--tight">
    ${isNew ? stepsHtml(3) : breadcrumbs([{ label: 'Inicio', href: '/' }, { label: currentUser() ? 'Mis pedidos' : 'Seguimiento', href: currentUser() ? '/cuenta/pedidos' : '/seguimiento' }, { label: o.id }])}
    ${isNew ? `<div class="thanks">
      <span class="thanks__badge">${icon('checkCircle')}</span>
      <h1 class="page-title">¡Gracias, ${esc(o.customer.nombre)}! Recibimos tu pedido</h1>
      <p class="page-sub">Te enviamos la confirmación a <b>${esc(o.customer.email)}</b>. Guarda tu número de pedido para hacer el seguimiento.</p>
      <span class="order-no">${icon('box')} ${esc(o.id)}</span>
    </div>` : `<div class="page-head"><h1 class="page-title">Pedido ${esc(o.id)}</h1><p class="page-sub">Realizado el ${esc(dateTime(o.createdAt))}</p></div>`}
    ${o.payment.method === 'transferencia' && !o.cancelled && (!isManaged(o) || statusOf(o) === 'recibido') ? notice('warn', `<b>Paga con transferencia</b> para que preparemos tu pedido: Banco de ejemplo · Cuenta corriente 00-000-00000-00 · ${esc(BRAND.legalName)} · RUT 76.000.000-0 · ${esc(BRAND.email)}. Indica el número <b>${esc(o.id)}</b> en el comentario. (Datos de demostración.)`, 'bank') : ''}
    ${whenHtml(o)}
    ${o.hasRx && !o.cancelled && (!isManaged(o) || statusOf(o) === 'recibido') ? notice('info', `Un químico farmacéutico validará tu${o.prescriptions.length > 1 ? 's' : ''} receta${o.prescriptions.length > 1 ? 's' : ''} antes de preparar el pedido.${o.hasRetenida ? ' Ten a mano la <b>receta original</b> de los medicamentos de receta retenida.' : ''}`, 'file') : ''}
    <div class="two-col">
      <div style="display:grid;gap:16px">
        <div class="panel"><h2 class="panel__title">Estado del pedido</h2><div id="tl">${timelineHtml(o)}</div>
          ${isManaged(o) ? (tl.canCancel ? '<p class="field__hint">Puedes anular tu pedido mientras la farmacia no lo haya confirmado.</p>' : '') : '<p class="field__hint">En este sitio de demostración el seguimiento avanza solo, en pocos minutos.</p>'}
          ${tl.canCancel ? '<button type="button" class="btn btn--ghost btn--sm" data-cancel style="margin-top:12px">Anular pedido</button>' : ''}
        </div>
        ${messagesHtml(o)}
        <div class="panel"><h2 class="panel__title">${d.type === 'retiro' ? 'Retiro en farmacia' : 'Despacho a domicilio'}</h2>
          <dl class="kv">
            ${d.type === 'retiro'
              ? `<dt>Farmacia</dt><dd>${esc(d.storeName)}</dd><dt>Dirección</dt><dd>${esc(d.storeAddress)}</dd><dt>Cuándo</dt><dd>${esc(deliveryWhen(o))}</dd><dt>Retira</dt><dd>${d.pickupBy === 'otra' ? `${esc(d.pickupName)} (${esc(d.pickupRut)})` : `${esc(o.customer.nombre)} ${esc(o.customer.apellidos)}`}</dd>`
              : `<dt>Dirección</dt><dd>${esc(d.address)}, ${esc(d.comuna)}</dd><dt>Región</dt><dd>${esc(d.regionName)}</dd><dt>Entrega</dt><dd>${esc(deliveryWhen(o))}${d.express ? ' (express)' : ''}</dd>${d.indicaciones ? `<dt>Indicaciones</dt><dd>${esc(d.indicaciones)}</dd>` : ''}`}
            <dt>Contacto</dt><dd>${esc(formatPhone(o.customer.phone))} · ${esc(o.customer.email)}</dd>
            <dt>Pago</dt><dd>${esc(o.payment.label)}</dd>
            <dt>Documento</dt><dd>${o.document.type === 'factura' ? `Factura a ${esc(o.document.razon)} (${esc(o.document.rut)})` : `Boleta a ${esc(o.customer.rut)}`}</dd>
            ${o.prescriptions.length ? `<dt>Recetas</dt><dd>${o.prescriptions.map((r) => esc(r.fileName)).join(', ')}</dd>` : ''}
          </dl>
        </div>
      </div>
      <aside class="sticky-col">${orderSummaryHtml(o)}
        <a class="btn btn--primary btn--block" href="#/" data-link>Seguir comprando</a>
        ${currentUser() ? '<a class="btn btn--ghost btn--block" href="#/cuenta/pedidos" data-link>Ver mis pedidos</a>' : ''}
      </aside>
    </div>
  </div>`;
  return {
    title: `Pedido ${o.id}`,
    html,
    mount(root) {
      const timer = setInterval(() => {
        const box = $('#tl', root);
        if (box && !isManaged(o)) box.innerHTML = timelineHtml(o);
      }, 20000);
      // Pedido del servidor: se revisa si la farmacia lo avanzó, cambió la fecha o lo anuló
      // (al abrirlo, cada minuto y al volver a la pestaña)
      let poll = null;
      let onVisible = null;
      if (o.remote && remote()) {
        const check = () => fetchRemoteOrder(o.id, o.customer.email).then((r) => {
          if (r?.order && progressKey(r.order) !== progressKey(o)) {
            syncRemoteOrder(r.order);
            go(`/pedido/${o.id}${isNew ? '?nuevo=1' : ''}`, { replace: true, scroll: false });
          }
        }).catch(() => {});
        check();
        poll = setInterval(() => { if (!document.hidden) check(); }, 60000);
        onVisible = () => { if (!document.hidden) check(); };
        document.addEventListener('visibilitychange', onVisible);
      }
      root.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-cancel]');
        if (!btn) return;
        if (!(await confirmDialog({ title: '¿Anular el pedido?', text: `Se anulará el pedido <b>${esc(o.id)}</b>. Si pagaste con tarjeta, se devolverá el monto completo.`, confirmText: 'Anular pedido', danger: true }))) return;
        if (o.remote && remote()) {
          btn.disabled = true;
          try {
            const r = await cancelRemoteOrder(o.id, o.customer.email);
            syncRemoteOrder(r.order);
            toast('Anulamos tu pedido.', { tone: 'info' });
            go(`/pedido/${o.id}`, { replace: true });
          } catch (err) {
            btn.disabled = false;
            toast(esc(err.message), { tone: 'warn', timeout: 7000 });
          }
          return;
        }
        if (cancelOrder(o.id)) { toast('Anulamos tu pedido.', { tone: 'info' }); go(`/pedido/${o.id}`, { replace: true }); }
        else toast('Tu pedido ya está en preparación y no se puede anular. Escríbenos y te ayudamos.', { tone: 'warn' });
      });
      return () => {
        clearInterval(timer);
        if (poll) clearInterval(poll);
        if (onVisible) document.removeEventListener('visibilitychange', onVisible);
      };
    },
  };
}

export function trackingPage(params, query) {
  const mine = state.orders.slice(0, 6);
  const html = `<div class="wrap page page--tight" style="max-width:860px">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Sigue tu pedido' }])}
    <div class="page-head"><h1 class="page-title">Sigue tu pedido</h1><p class="page-sub">Ingresa el número de pedido (empieza con PD) y el correo con el que compraste.</p></div>
    <form class="panel form-grid" id="track-form" novalidate>
      ${field({ label: 'Número de pedido', name: 'pedido', value: query.id || '', required: true, placeholder: 'PD12345678', autocomplete: 'off' })}
      ${field({ label: 'Correo electrónico', name: 'email', type: 'email', required: true, autocomplete: 'email', placeholder: 'tu@correo.cl' })}
      <div class="full"><button class="btn btn--primary btn--lg" type="submit">${icon('search')} Buscar pedido</button></div>
    </form>
    ${mine.length ? `<section style="display:grid;gap:10px"><h2 class="sec-title" style="font-size:20px">Pedidos hechos en este navegador</h2>
      ${mine.map((o) => {
        const st = statusLabel(o);
        const when = o.cancelled ? '' : deliveryWhen(o);
        return `<a class="order-card" href="#/pedido/${o.id}" data-link style="text-decoration:none;color:inherit"><div><b>${esc(o.id)}</b> · <span class="muted">${esc(shortDate(o.createdAt))}</span><br><span class="chip chip--${st.tone}">${esc(st.text)}</span>${when ? ` <span class="muted order-card__when">${esc(when)}</span>` : ''}</div><b>${clp(o.totals.total)}</b></a>`;
      }).join('')}</section>` : ''}
  </div>`;
  return {
    title: 'Sigue tu pedido',
    html,
    rerender: ['orders'],
    mount(root) {
      refreshRemoteOrders(mine);
      root.addEventListener('submit', async (e) => {
        if (!e.target.matches('#track-form')) return;
        e.preventDefault();
        const f = e.target;
        const v = formData(f);
        const id = v.pedido.trim().toUpperCase();
        const email = v.email.trim().toLowerCase();
        const o = findOrder(id);
        const errors = {};
        if (!id) errors.pedido = 'Escribe el número de pedido.';
        if (!email) errors.email = 'Escribe el correo con el que compraste.';
        if (!setErrors(f, errors)) return;
        if (o && o.customer.email === email) { go(`/pedido/${o.id}`); return; }
        // Sitio oficial: se busca en el servidor (pedidos hechos desde otro equipo)
        if (remote()) {
          const btn = f.querySelector('button[type=submit]');
          btn.disabled = true;
          try {
            const r = await fetchRemoteOrder(id, email);
            syncRemoteOrder(r.order);
            go(`/pedido/${r.order.id}`);
          } catch (err) {
            setErrors(f, { pedido: err.code === 'http_404' || err.code === 'not_found' ? 'No encontramos un pedido con ese número y ese correo. Revisa que estén bien escritos.' : err.message });
          } finally {
            btn.disabled = false;
          }
          return;
        }
        setErrors(f, o ? { email: 'El correo no coincide con el del pedido.' } : { pedido: 'No encontramos un pedido con ese número en este navegador. Revisa que esté bien escrito.' });
      });
      return null;
    },
  };
}

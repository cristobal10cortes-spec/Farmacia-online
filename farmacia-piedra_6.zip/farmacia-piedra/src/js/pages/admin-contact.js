// Panel → ficha de un pedido: datos del cliente y botones para contactarlo
// (correo, WhatsApp o llamada) con un mensaje listo según el motivo.

import { $, $$, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { toast } from '../ui/overlay.js';
import { contactTemplates, suggestedTemplate, mailtoHref, whatsappHref, telHref, formatPhone } from '../engine/contact.js';

/** Copia un texto (con respaldo para navegadores sin acceso al portapapeles). */
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
    document.body.append(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}

export function contactPanelHtml(o) {
  const c = o.customer || {};
  const tpls = contactTemplates(o);
  // Primero, el aviso de la etapa en que está el pedido
  const first = tpls.find((t) => t.id === suggestedTemplate(o)) || tpls[0];
  const mail = mailtoHref(c.email, first.subject, first.body);
  const wa = whatsappHref(c.phone, first.body);
  const tel = telHref(c.phone);
  const phone = c.phone ? formatPhone(c.phone) : '';
  const line = (ic, label, value, copy, href) => `<div class="ccontact__line">
      <span class="ccontact__ico" aria-hidden="true">${icon(ic)}</span>
      <div><small>${label}</small>${value ? (href ? `<a href="${esc(href)}" class="ccontact__val">${esc(value)}</a>` : `<b class="ccontact__val">${esc(value)}</b>`) : '<b class="ccontact__val muted">No lo dejó</b>'}</div>
      ${value ? `<button type="button" class="icon-btn ccontact__copy" data-copy="${esc(copy)}" aria-label="Copiar ${label.toLowerCase()}" title="Copiar">${icon('copy')}</button>` : ''}
    </div>`;
  return `<section class="panel ccontact" id="ccontact">
    <h2 class="panel__title">Cliente</h2>
    <dl class="kv"><dt>Nombre</dt><dd>${esc(`${c.nombre || ''} ${c.apellidos || ''}`)}</dd><dt>RUT</dt><dd>${esc(c.rut || '')}</dd></dl>
    <div class="ccontact__lines">
      ${line('mail', 'Correo', c.email || '', c.email || '', '')}
      ${line('phone', 'Celular', phone, phone, tel)}
    </div>
    <div class="ccontact__box">
      <h3 class="ccontact__title">${icon('chat')} Contactar al cliente</h3>
      <div class="field"><label for="cc-reason">Motivo</label>
        <select id="cc-reason">${tpls.map((t) => `<option value="${esc(t.id)}"${t === first ? ' selected' : ''}>${esc(t.label)}</option>`).join('')}</select></div>
      <div class="field"><label for="cc-msg">Mensaje <span class="field__opt">(puedes cambiarlo)</span></label>
        <textarea id="cc-msg" rows="7" maxlength="1500">${esc(first.body)}</textarea></div>
      <div class="ccontact__btns">
        ${mail ? `<a class="btn btn--primary btn--sm" id="cc-mail" href="${esc(mail)}">${icon('mail')} Enviar correo</a>` : ''}
        ${wa ? `<a class="btn btn--soft btn--sm" id="cc-wa" href="${esc(wa)}" target="_blank" rel="noopener noreferrer">${icon('chat')} WhatsApp</a>` : ''}
        ${tel ? `<a class="btn btn--ghost btn--sm" id="cc-tel" href="${esc(tel)}">${icon('phone')} Llamar</a>` : ''}
        <button type="button" class="btn btn--ghost btn--sm" data-copy-msg>${icon('copy')} Copiar mensaje</button>
      </div>
      <p class="field__hint">Se abre tu correo o WhatsApp con el mensaje listo: revísalo y envíalo desde ahí. El cliente dejó estos datos al comprar para que lo contactemos por su pedido.</p>
    </div>
  </section>`;
}

export function mountContact(root, o) {
  const box = $('#ccontact', root);
  if (!box) return;
  const c = o.customer || {};
  const tpls = contactTemplates(o);
  const reason = $('#cc-reason', box);
  const msg = $('#cc-msg', box);
  let subject = (tpls.find((t) => t.id === reason.value) || tpls[0]).subject;
  const sync = () => {
    const body = msg.value;
    const mail = $('#cc-mail', box);
    const wa = $('#cc-wa', box);
    if (mail) mail.href = mailtoHref(c.email, subject, body);
    if (wa) wa.href = whatsappHref(c.phone, body);
  };
  reason.addEventListener('change', () => {
    box.dataset.dirty = '1';
    const t = tpls.find((x) => x.id === reason.value) || tpls[0];
    subject = t.subject;
    msg.value = t.body;
    sync();
  });
  msg.addEventListener('input', () => { box.dataset.dirty = '1'; sync(); });
  box.addEventListener('click', async (e) => {
    const cp = e.target.closest('[data-copy]');
    const cm = e.target.closest('[data-copy-msg]');
    if (!cp && !cm) return;
    const text = cp ? cp.dataset.copy : msg.value;
    const ok = await copyText(text);
    toast(ok ? (cp ? `Copiado: <b>${esc(text)}</b>` : 'Copiaste el mensaje.') : 'No se pudo copiar. Selecciónalo y cópialo a mano.', { tone: ok ? 'ok' : 'warn' });
  });
  $$('a', box).forEach((a) => a.addEventListener('click', () => sync()));
}

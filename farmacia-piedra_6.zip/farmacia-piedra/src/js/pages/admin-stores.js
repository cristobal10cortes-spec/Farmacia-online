// Panel de administración: farmacias (agregar, editar y eliminar).
// Lo que se guarda aquí aparece en la tienda: página de farmacias, horarios,
// turnos, retiro de pedidos y stock por farmacia.

import { $, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { field, checkbox, emptyState } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { go } from '../router.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { STORES, storeById } from '../data/stores.js';
import { storeStatus, hoursText, isoToday } from '../engine/inventory.js';
import { cleanStore, timeToHours, hoursToTime } from '../engine/storedef.js';
import { adminShell, adminGuard, saveError } from './admin.js';
import { createStore, updateStore, deleteStore } from '../admin/api.js';

const DAYS = [['wk', 'Lunes a viernes'], ['sat', 'Sábado'], ['sun', 'Domingo']];
const DEFAULT_HOURS = { wk: [9, 21], sat: [10, 21], sun: [10, 20] };
// '2026-10-09' → 'vie, 9 de oct.'
function fmtDay(iso) {
  const d = new Date(`${iso}T12:00:00-04:00`);
  try { return new Intl.DateTimeFormat('es-CL', { timeZone: 'America/Santiago', weekday: 'short', day: 'numeric', month: 'short' }).format(d); } catch { return iso; }
}

function statusChips(st) {
  const s = storeStatus(st);
  const next = st.turnos.filter((d) => d >= isoToday()).slice(0, 1)[0];
  return `<span class="chip chip--${s.open ? 'ok' : 'danger'}">${icon('clock')}${esc(s.label)}</span>
    ${st.h24 ? `<span class="chip chip--info">${icon('clock')}24 horas</span>` : ''}
    ${s.turno ? `<span class="chip chip--club">${icon('moon')}De turno hoy</span>` : next ? `<span class="chip">${icon('moon')}Próximo turno: ${esc(fmtDay(next))}</span>` : ''}
    ${st.services.includes('recetario') ? `<span class="chip">${icon('file')}Recetario magistral</span>` : ''}`;
}

// ── Lista ────────────────────────────────────────────────────
export function adminStoresPage() {
  const guard = adminGuard();
  if (guard) return guard;
  const list = STORES.slice();
  const add = `<a class="btn btn--primary btn--sm" href="#/admin/farmacias/nueva" data-link>${icon('plus')} Agregar farmacia</a>`;
  const body = list.length
    ? `<p class="toolbar__count"><b>${list.length}</b> ${list.length === 1 ? 'farmacia' : 'farmacias'}</p>
      <ul class="slist">${list.map((st) => `<li class="scard">
        <div class="scard__main">
          <h2 class="scard__name">${esc(st.name)}</h2>
          <p class="muted">${icon('pin', 'inline-ico')} ${esc(st.address)}, ${esc(st.comuna)} · ${esc(regionLabel(regionById(st.region)) || '')}</p>
          ${st.phone ? `<p class="muted">${icon('phone', 'inline-ico')} ${esc(st.phone)}</p>` : ''}
          <p class="scard__hours">${esc(hoursText(st))}</p>
          <div class="scard__chips">${statusChips(st)}</div>
        </div>
        <div class="scard__act"><a class="btn btn--soft btn--sm" href="#/admin/farmacias/${esc(st.id)}" data-link>${icon('edit')} Editar</a></div>
      </li>`).join('')}</ul>`
    : emptyState({ icon: 'store', title: 'Aún no hay farmacias', text: 'Mientras no agregues farmacias, la tienda vende solo con despacho a domicilio. Al agregar una, aparece en la tienda con su horario, sus turnos y el retiro de pedidos.', actions: '<a class="btn btn--primary" href="#/admin/farmacias/nueva" data-link>Agregar la primera farmacia</a>' });
  return {
    title: 'Farmacias · Administración',
    rerender: ['backoffice'],
    html: adminShell('farmacias', 'Farmacias', body, { sub: 'Aparecen en la tienda: horarios, turnos, retiro de pedidos y stock por farmacia.', actions: list.length ? add : '' }),
  };
}

// ── Ficha (nueva o editar) ───────────────────────────────────
function hoursRows(st) {
  const hours = st?.hours || DEFAULT_HOURS;
  return DAYS.map(([k, label]) => {
    const h = st ? hours[k] : DEFAULT_HOURS[k];
    const off = !h;
    const [a, b] = h || DEFAULT_HOURS[k];
    return `<div class="shours__row${off ? ' is-off' : ''}" data-day="${k}">
      <span class="shours__day">${esc(label)}</span>
      <label class="shours__t"><span>Abre</span><input type="time" id="sf-${k}-a" value="${hoursToTime(a)}" step="900" ${off ? 'disabled' : ''}></label>
      <label class="shours__t"><span>Cierra</span><input type="time" id="sf-${k}-b" value="${hoursToTime(b)}" step="900" ${off ? 'disabled' : ''}></label>
      <label class="check shours__off"><input type="checkbox" id="sf-${k}-off" ${off ? 'checked' : ''}><span>Cerrado</span></label>
    </div>`;
  }).join('');
}

function storeForm(st, isNew) {
  const region = st?.region || 'RM';
  const comunas = (regionById(region)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es'));
  return `<form id="sform" class="sform" novalidate>
    <fieldset class="panel form-grid"><legend class="panel__title">Datos de la farmacia</legend>
      ${field({ label: 'Nombre', name: 'name', value: st?.name || '', required: true, full: true, placeholder: 'Ej: Farmacia Piedra Centro', attrs: 'maxlength="60"' })}
      ${field({ label: 'Dirección (calle y número)', name: 'address', value: st?.address || '', required: true, full: true, placeholder: 'Ej: Av. Libertador Bernardo O\'Higgins 1302', attrs: 'maxlength="100"' })}
      ${field({ label: 'Región', name: 'region', value: region, required: true, options: REGIONS.map((r) => ({ value: r.id, label: regionLabel(r) })) })}
      ${field({ label: 'Comuna', name: 'comuna', value: st?.comuna || '', required: true, options: comunas })}
      ${field({ label: 'Teléfono', name: 'phone', type: 'tel', value: st?.phone || '', placeholder: 'Ej: +56 2 2345 6789', attrs: 'maxlength="20"' })}
    </fieldset>
    <fieldset class="panel"><legend class="panel__title">Horario</legend>
      ${checkbox({ name: 'h24', label: '<b>Abierta las 24 horas</b>, todos los días', checked: !!st?.h24 })}
      <div class="shours" id="sf-hours"${st?.h24 ? ' hidden' : ''}>${hoursRows(st)}</div>
      <p class="sform__error" id="sf-hours-error" role="alert"></p>
    </fieldset>
    <fieldset class="panel" id="sf-turnos-box"${st?.h24 ? ' hidden' : ''}><legend class="panel__title">Días de turno</legend>
      <p class="muted">Los días de turno la farmacia atiende toda la noche y aparece en «Farmacias de turno». Agrega los días que te asignaron.</p>
      <div class="sturnos__add"><label class="visually-hidden" for="sf-turno">Día de turno</label><input type="date" id="sf-turno" min="${isoToday()}"><button type="button" class="btn btn--soft btn--sm" data-add-turno>${icon('plus')} Agregar día</button></div>
      <ul class="sturnos" id="sf-turnos"></ul>
    </fieldset>
    <fieldset class="panel"><legend class="panel__title">Servicios</legend>
      ${checkbox({ name: 'recetario', label: '<b>Recetario magistral</b> (prepara fórmulas)', checked: !!st?.services?.includes('recetario') })}
      <p class="field__hint">Todas las farmacias permiten retirar los pedidos de la tienda online.</p>
    </fieldset>
    ${isNew ? `<fieldset class="panel form-grid"><legend class="panel__title">Stock inicial</legend>
      ${field({ label: 'Unidades de cada producto', name: 'initial', type: 'number', value: '0', inputmode: 'numeric', attrs: 'min="0" max="99999" step="1"', hint: 'Se cargan en esta farmacia para todos los productos del catálogo. Puedes dejarlo en 0 y ajustarlo después en Productos y stock.' })}
    </fieldset>` : ''}
    <div class="pform__actions"><button class="btn btn--primary btn--lg" type="submit">${isNew ? `${icon('plus')} Agregar farmacia` : 'Guardar cambios'}</button><a class="btn btn--ghost btn--lg" href="#/admin/farmacias" data-link>Cancelar</a>${isNew ? '' : `<button type="button" class="btn btn--ghost btn--lg sform__del" data-sdel>${icon('trash')} Eliminar</button>`}</div>
  </form>`;
}

function readHours(f) {
  const hours = {};
  for (const [k, label] of DAYS) {
    if ($(`#sf-${k}-off`, f).checked) { hours[k] = null; continue; }
    const a = timeToHours($(`#sf-${k}-a`, f).value);
    const b = timeToHours($(`#sf-${k}-b`, f).value, { closing: true });
    if (a == null || b == null) return { error: `Completa el horario de ${label.toLowerCase()} o márcalo como cerrado.` };
    if (!(a < b)) return { error: `${label}: la hora de cierre debe ser después de la de apertura (para cerrar a medianoche, usa 00:00).` };
    hours[k] = [a, b];
  }
  return { hours };
}

function previewHtml(draft) {
  if (!draft.name) return '<p class="muted">Escribe el nombre y la dirección para ver la vista previa.</p>';
  const st = { ...draft, id: 'VISTA', services: draft.recetario ? ['retiro', 'recetario'] : ['retiro'], turnos: draft.turnos || [] };
  return `<article class="store">
    <div style="display:grid;gap:6px;min-width:0">
      <h2 class="store__name">${esc(st.name)}</h2>
      <p class="store__addr">${icon('pin', 'inline-ico')} ${esc(st.address || 'Dirección')}, ${esc(st.comuna || '')}</p>
      ${st.phone ? `<p class="store__addr">${icon('phone', 'inline-ico')} ${esc(st.phone)}</p>` : ''}
      <p class="store__hours">${esc(hoursText(st))}</p>
      <div class="store__chips">${statusChips(st)}</div>
    </div>
  </article>`;
}

export function adminStorePage(params) {
  const guard = adminGuard();
  if (guard) return guard;
  const isNew = params.id === 'nueva';
  const st = isNew ? null : storeById(params.id);
  if (!isNew && !st) {
    return { title: 'Farmacia no encontrada', html: adminShell('farmacias', 'Farmacia no encontrada', emptyState({ icon: 'store', title: 'No encontramos esa farmacia', text: 'Puede que se haya eliminado.', actions: '<a class="btn btn--primary" href="#/admin/farmacias" data-link>Volver a farmacias</a>' })) };
  }
  const body = `<div class="pform-layout">${storeForm(st, isNew)}<aside class="sticky-col pform__side"><p class="eyebrow">Así se verá en la tienda</p><div id="sf-preview"></div></aside></div>`;
  return {
    title: `${isNew ? 'Nueva farmacia' : st.name} · Administración`,
    html: adminShell('farmacias', isNew ? 'Nueva farmacia' : 'Editar farmacia', body, { actions: `<a class="btn btn--ghost btn--sm" href="#/admin/farmacias" data-link>${icon('arrowLeft')} Farmacias</a>` }),
    onState: () => true, // no repintar mientras se escribe
    mount(root) {
      const f = $('#sform', root);
      let turnos = (st?.turnos || []).filter((d) => d >= isoToday()).slice();
      const hoursBox = $('#sf-hours', root);
      const err = $('#sf-hours-error', root);
      const renderTurnos = () => {
        turnos.sort();
        $('#sf-turnos', root).innerHTML = turnos.length
          ? turnos.map((d) => `<li><span>${esc(fmtDay(d))}</span><button type="button" class="icon-btn" data-del-turno="${d}" aria-label="Quitar el turno del ${esc(fmtDay(d))}">${icon('x')}</button></li>`).join('')
          : '<li class="muted">Sin días de turno.</li>';
      };
      const draft = () => {
        const v = formData(f);
        const h = readHours(f);
        return { name: v.name.trim(), address: v.address.trim(), region: v.region, comuna: v.comuna, phone: v.phone.trim(), h24: !!v.h24, recetario: !!v.recetario, hours: h.hours || DEFAULT_HOURS, turnos };
      };
      const refresh = () => { $('#sf-preview', root).innerHTML = previewHtml(draft()); };
      renderTurnos();
      refresh();
      f.addEventListener('input', refresh);
      f.addEventListener('change', (e) => {
        const t = e.target;
        if (t.name === 'region') {
          const comunas = (regionById(t.value)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es'));
          f.comuna.innerHTML = comunas.map((c) => `<option>${esc(c)}</option>`).join('');
        }
        if (t.name === 'h24') {
          hoursBox.hidden = t.checked;
          $('#sf-turnos-box', root).hidden = t.checked;
        }
        const day = /^sf-(wk|sat|sun)-off$/.exec(t.id || '');
        if (day) {
          const row = t.closest('.shours__row');
          row.classList.toggle('is-off', t.checked);
          row.querySelectorAll('input[type=time]').forEach((i) => { i.disabled = t.checked; });
        }
        refresh();
      });
      root.addEventListener('click', async (e) => {
        if (e.target.closest('[data-add-turno]')) {
          const v = $('#sf-turno', root).value;
          if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) { toast('Elige un día en el calendario.', { tone: 'warn' }); return; }
          if (v < isoToday()) { toast('Elige un día de hoy en adelante.', { tone: 'warn' }); return; }
          if (!turnos.includes(v)) turnos.push(v);
          $('#sf-turno', root).value = '';
          renderTurnos();
          refresh();
          return;
        }
        const del = e.target.closest('[data-del-turno]');
        if (del) {
          turnos = turnos.filter((d) => d !== del.dataset.delTurno);
          renderTurnos();
          refresh();
          return;
        }
        if (e.target.closest('[data-sdel]')) {
          if (!(await confirmDialog({ title: '¿Eliminar esta farmacia?', text: `<b>${esc(st.name)}</b> dejará de aparecer en la tienda y se borrará su stock. Los pedidos anteriores no cambian.`, confirmText: 'Eliminar farmacia', danger: true }))) return;
          try {
            await deleteStore(st.id);
            toast('Eliminaste la farmacia.', { tone: 'info' });
            go('/admin/farmacias', { replace: true });
          } catch (er) { saveError(er); }
        }
      });
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        err.textContent = '';
        const v = formData(f);
        const errors = {};
        if (!v.name.trim()) errors.name = 'Escribe el nombre de la farmacia.';
        if (!v.address.trim()) errors.address = 'Escribe la dirección (calle y número).';
        if (!v.comuna) errors.comuna = 'Elige la comuna.';
        if (v.phone.trim() && !/^[+\d ()-]{6,20}$/.test(v.phone.trim())) errors.phone = 'Usa solo números, espacios y el signo +.';
        if (isNew && !(Number(v.initial) >= 0)) errors.initial = 'Ingresa 0 o más unidades.';
        const h = v.h24 ? { hours: { wk: null, sat: null, sun: null } } : readHours(f);
        if (!setErrors(f, errors)) return;
        if (h.error) { err.textContent = h.error; return; }
        const input = { name: v.name, address: v.address, region: v.region, comuna: v.comuna, phone: v.phone, h24: !!v.h24, recetario: !!v.recetario, hours: h.hours, turnos };
        const check = cleanStore(input, { today: isoToday() });
        if (check.error) { err.textContent = check.error; return; }
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        try {
          if (isNew) {
            await createStore(input, Math.max(0, Math.round(Number(v.initial) || 0)));
            toast(`Agregaste <b>${esc(check.store.name)}</b>. Ya aparece en la tienda.`);
          } else {
            await updateStore(st.id, input);
            toast('Guardamos los cambios de la farmacia.');
          }
          go('/admin/farmacias');
        } catch (er) {
          saveError(er);
        } finally {
          btn.disabled = false;
        }
      });
      return null;
    },
  };
}

// Listados: resultados de búsqueda, categorías y ofertas (filtros, orden y páginas).

import { $, $$, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productGrid, breadcrumbs, pagination, emptyState, notice } from '../ui/components.js';
import { noteHtml } from '../ui/searchui.js';
import { listProducts, SORTS, PRICE_RANGES, PRODUCTS, catalogVersion, subsOf } from '../engine/catalog.js';
import { CATEGORIES, categoryById, subById } from '../data/categories.js';
import { RX, POPULAR_SEARCHES } from '../config.js';
import { fold } from '../engine/text.js';
import { state } from '../engine/state.js';
import { productAvailability } from '../engine/inventory.js';
import { go, href } from '../router.js';
import { openDrawer } from '../ui/overlay.js';
import { num } from '../engine/format.js';

const LIST_KEYS = ['marca', 'venta', 'formato', 'activo', 'sub'];
const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

function readFilters(query) {
  const f = {};
  for (const k of LIST_KEYS) f[k] = query[k] ? query[k].split('|').filter(Boolean) : [];
  f.be = query.be === '1';
  f.oferta = query.oferta === '1';
  f.stock = query.stock === '1';
  f.precio = query.precio || '';
  return f;
}

// Nombre "bonito" de cada principio activo (se recalcula si cambia el catálogo)
let ingCache = { v: -1, m: new Map() };
function ingredientName(key) {
  if (ingCache.v !== catalogVersion) {
    const m = new Map();
    for (const p of PRODUCTS) for (const i of p.ingredients) if (!m.has(fold(i))) m.set(fold(i), i);
    ingCache = { v: catalogVersion, m };
  }
  return ingCache.m.get(key) || key;
}

const subLabel = (key) => {
  const [c, s] = key.split('/');
  return subById(c, s)?.name || key;
};

function facetGroups(res, f, view) {
  const groups = [];
  if (res.facets.sub.length > 1 || f.sub.length) {
    groups.push({ key: 'sub', title: 'Categoría', opts: res.facets.sub.map((o) => ({ value: o.key, label: subLabel(o.key), count: o.count })) });
  }
  groups.push({ key: 'venta', title: 'Condición de venta', opts: res.facets.venta.map((o) => ({ value: o.key, label: RX[o.key]?.label || o.key, count: o.count })) });
  groups.push({ key: 'marca', title: 'Marca o laboratorio', opts: res.facets.marca.map((o) => ({ value: o.key, label: o.key, count: o.count })) });
  if (res.facets.activo.length) groups.push({ key: 'activo', title: 'Principio activo', opts: res.facets.activo.map((o) => ({ value: o.key, label: cap(ingredientName(o.key)), count: o.count })) });
  groups.push({ key: 'formato', title: 'Formato', opts: res.facets.formato.map((o) => ({ value: o.key, label: o.key, count: o.count })) });
  groups.push({ key: 'precio', title: 'Precio', single: true, opts: PRICE_RANGES.map((r) => ({ value: r.id, label: r.label, count: res.facets.precio.find((x) => x.key === r.id)?.count || 0 })).filter((o) => o.count || f.precio === o.value) });
  const extras = [];
  if (view !== 'bioequivalentes') extras.push({ key: 'be', label: 'Solo bioequivalentes', count: res.facets.be });
  if (view !== 'ofertas') extras.push({ key: 'oferta', label: 'Con descuento o promoción', count: res.facets.oferta });
  extras.push({ key: 'stock', label: `Con despacho a ${state.location.comuna}`, count: null });
  return { groups, extras };
}

function filtersHtml(res, f, view, idp = 'f') {
  const { groups, extras } = facetGroups(res, f, view);
  const optHtml = (g, o, i) => {
    const checked = g.single ? f[g.key] === o.value : f[g.key].includes(o.value);
    return `<label class="fopt"${i >= 7 && !checked ? ' data-more hidden' : ''}><input type="${g.single ? 'radio' : 'checkbox'}" id="${idp}-${g.key}-${i}" name="${idp}-${g.key}" data-filter="${g.key}" value="${esc(o.value)}" ${checked ? 'checked' : ''}><span>${esc(o.label)}</span><small>${num(o.count)}</small></label>`;
  };
  return `<div class="filters__head"><h2>Filtrar por</h2>${anyFilter(f) ? `<button type="button" class="btn btn--link btn--sm" data-clear-filters>Limpiar todo</button>` : ''}</div>
    <details class="fgroup" open><summary>Destacados ${icon('chevronDown')}</summary><div class="fgroup__list">
      ${extras.map((x) => `<label class="fopt"><input type="checkbox" id="${idp}-${x.key}" data-filter="${x.key}" value="1" ${f[x.key] ? 'checked' : ''}><span>${esc(x.label)}</span>${x.count !== null ? `<small>${num(x.count)}</small>` : ''}</label>`).join('')}
    </div></details>
    ${groups.filter((g) => g.opts.length).map((g, gi) => `<details class="fgroup"${gi < 3 || f[g.key]?.length || (g.single && f[g.key]) ? ' open' : ''}><summary>${esc(g.title)} ${icon('chevronDown')}</summary><div class="fgroup__list">
      ${g.single ? `<label class="fopt"><input type="radio" name="${idp}-${g.key}" data-filter="${g.key}" value="" ${!f[g.key] ? 'checked' : ''}><span>Todos</span></label>` : ''}
      ${g.opts.map((o, i) => optHtml(g, o, i)).join('')}
      ${g.opts.length > 7 ? `<button type="button" class="fgroup__more" data-more-toggle data-count="${g.opts.length - 7}">Ver ${g.opts.length - 7} más</button>` : ''}
    </div></details>`).join('')}`;
}

const anyFilter = (f) => LIST_KEYS.some((k) => f[k].length) || f.be || f.oferta || f.stock || f.precio;

function activeChips(f) {
  const chips = [];
  for (const k of LIST_KEYS) for (const v of f[k]) {
    const label = k === 'sub' ? subLabel(v) : k === 'venta' ? RX[v]?.label : k === 'activo' ? cap(ingredientName(v)) : v;
    chips.push({ k, v, label });
  }
  if (f.be) chips.push({ k: 'be', v: '1', label: 'Bioequivalentes' });
  if (f.oferta) chips.push({ k: 'oferta', v: '1', label: 'Con descuento' });
  if (f.stock) chips.push({ k: 'stock', v: '1', label: 'Con despacho' });
  if (f.precio) chips.push({ k: 'precio', v: f.precio, label: PRICE_RANGES.find((r) => r.id === f.precio)?.label || f.precio });
  if (!chips.length) return '';
  return `<div class="active-filters">${chips.map((c) => `<button type="button" data-unfilter="${c.k}" data-value="${esc(c.v)}" aria-label="Quitar filtro ${esc(c.label)}">${esc(c.label)}${icon('x')}</button>`).join('')}<button type="button" class="btn btn--link btn--sm" data-clear-filters>Limpiar filtros</button></div>`;
}

/**
 * kind: 'search' | 'category' | 'ofertas' | 'bioequivalentes'
 */
export function listingPage({ kind, params = {}, query = {}, basePath }) {
  const f = readFilters(query);
  const cat = kind === 'category' ? categoryById(params.cat) : null;
  const sub = cat && params.sub ? subById(cat.id, params.sub) : null;
  if (kind === 'category' && (!cat || (params.sub && !sub))) return null;
  const view = kind === 'ofertas' ? 'ofertas' : kind === 'bioequivalentes' ? 'bioequivalentes' : '';
  const q = kind === 'search' ? (query.q || '') : '';
  const res = listProducts({
    q, cat: cat?.id, sub: sub?.id, view,
    filters: f, sort: query.orden, page: query.pag, size: query.ver,
    isAvailable: (p) => productAvailability(p, state.location).delivery.ok,
  });
  const s = res.search;
  const shownQ = s?.corrected || q;

  // Encabezado
  let title;
  let crumbs;
  const brandOnly = kind === 'search' && !q && f.marca.length === 1;
  if (brandOnly) {
    title = f.marca[0];
    crumbs = [{ label: 'Inicio', href: '/' }, { label: 'Marcas', href: '/marcas' }, { label: f.marca[0] }];
  } else if (kind === 'search') {
    title = q ? `Resultados para “${shownQ}”` : 'Todos los productos';
    crumbs = [{ label: 'Inicio', href: '/' }, { label: 'Búsqueda' }];
  } else if (kind === 'category') {
    title = sub ? sub.name : cat.name;
    crumbs = [{ label: 'Inicio', href: '/' }, { label: cat.name, href: sub ? `/categoria/${cat.id}` : '' }, ...(sub ? [{ label: sub.name }] : [])];
  } else if (kind === 'ofertas') {
    title = 'Ofertas';
    crumbs = [{ label: 'Inicio', href: '/' }, { label: 'Ofertas' }];
  } else {
    title = 'Productos bioequivalentes';
    crumbs = [{ label: 'Inicio', href: '/' }, { label: 'Bioequivalentes', href: '/bioequivalentes' }, { label: 'Todos' }];
  }

  const keep = { ...query };
  const make = (patch) => href(basePath, { ...keep, ...patch });

  const notes = [];
  if (s?.corrected) notes.push(notice('club', `Mostrando resultados para <b>${esc(s.corrected)}</b>. Buscaste “${esc(q)}”.`, 'sparkle'));
  for (const n of s?.notes || []) notes.push(notice('info', noteHtml(n)));
  if (s?.partial && res.total) notes.push(notice('warn', `No encontramos productos con todas las palabras de “${esc(q)}”. Te mostramos los más parecidos.`));

  const sortOpts = SORTS.filter((o) => !o.needsQuery || q);
  const subChips = cat ? `<div class="sub-chips"><a href="#/categoria/${cat.id}" data-link class="${!sub ? 'is-on' : ''}">Todo</a>${subsOf(cat).map((x) => `<a href="#/categoria/${cat.id}/${x.id}" data-link class="${sub?.id === x.id ? 'is-on' : ''}">${esc(x.name)}</a>`).join('')}</div>` : '';

  const body = res.total
    ? `${productGrid(res.items)}${pagination(res.page, res.pages, (n) => make({ pag: n === 1 ? '' : n }))}`
    : emptyState({
      icon: 'search',
      title: anyFilter(f) ? 'Ningún producto calza con estos filtros' : q ? `No encontramos “${q}”` : 'No hay productos aquí todavía',
      text: anyFilter(f) ? 'Quita algún filtro para ver más resultados.' : 'Revisa cómo se escribe, prueba con el principio activo (por ejemplo "paracetamol") o con un síntoma ("dolor de cabeza").',
      actions: anyFilter(f)
        ? '<button type="button" class="btn btn--primary" data-clear-filters>Limpiar filtros</button>'
        : `${POPULAR_SEARCHES.slice(0, 5).map((p) => `<a class="chip" href="#/buscar?q=${encodeURIComponent(p)}" data-link>${esc(p)}</a>`).join('')}<a class="btn btn--soft" href="#/cotizar-receta" data-link>Cotizar mi receta</a>`,
    });

  const html = `<div class="wrap page page--tight">
    ${breadcrumbs(crumbs)}
    <div class="page-head">
      <h1 class="page-title">${esc(title)}</h1>
      ${kind === 'ofertas' ? '<p class="page-sub">Precios de internet y promociones por cantidad en productos de venta directa. Válidos hasta agotar stock.</p>' : ''}
      ${kind === 'bioequivalentes' ? '<p class="page-sub">Medicamentos con sello BE: demostraron ante el ISP la misma eficacia que el medicamento de referencia.</p>' : ''}
      ${subChips}
    </div>
    ${notes.length ? `<div class="search-note">${notes.join('')}</div>` : ''}
    <div class="listing">
      <aside class="filters" id="filters" aria-label="Filtros">${filtersHtml(res, f, view)}</aside>
      <div class="listing__main">
        <div>
          <div class="toolbar">
            <p class="toolbar__count" aria-live="polite"><b>${num(res.total)}</b> ${res.total === 1 ? 'producto' : 'productos'}</p>
            <div class="toolbar__ctrls">
              <button type="button" class="btn btn--ghost btn--sm filters-btn" data-open-filters>${icon('filter')} Filtrar</button>
              <label class="tb-sort"><span class="tb-lbl">Ordenar</span> <select id="sort" aria-label="Ordenar por">${sortOpts.map((o) => `<option value="${o.id}"${o.id === res.sort ? ' selected' : ''}>${esc(o.label)}</option>`).join('')}</select></label>
              <label class="tb-size">Mostrar <select id="size" aria-label="Productos por página">${[12, 24, 48].map((n) => `<option${n === res.size ? ' selected' : ''}>${n}</option>`).join('')}</select></label>
            </div>
          </div>
          ${activeChips(f)}
        </div>
        ${body}
      </div>
    </div>
  </div>`;

  const titleTag = brandOnly ? `${title}: productos` : kind === 'search' ? (q ? `Resultados para ${shownQ}` : 'Productos') : title;
  return {
    title: titleTag,
    html,
    searchValue: q,
    mount(root) {
      const navigate = (patch) => {
        const focusId = document.activeElement?.id;
        go(make({ ...patch, pag: '' }), { replace: true, scroll: false });
        if (focusId) requestAnimationFrame(() => document.getElementById(focusId)?.focus({ preventScroll: true }));
      };
      const onFilterChange = (input) => {
        const key = input.dataset.filter;
        if (['be', 'oferta', 'stock'].includes(key)) { navigate({ [key]: input.checked ? '1' : '' }); return; }
        if (key === 'precio') { navigate({ precio: input.value }); return; }
        const cur = new Set(f[key]);
        if (input.checked) cur.add(input.value); else cur.delete(input.value);
        navigate({ [key]: [...cur] });
      };
      const clearAll = () => {
        const patch = {};
        for (const k of [...LIST_KEYS, 'be', 'oferta', 'stock', 'precio']) patch[k] = '';
        navigate(patch);
      };
      root.addEventListener('change', (e) => {
        const t = e.target;
        if (t.matches('[data-filter]')) onFilterChange(t);
        if (t.id === 'sort') go(make({ orden: t.value, pag: '' }), { replace: true, scroll: false });
        if (t.id === 'size') go(make({ ver: t.value === '24' ? '' : t.value, pag: '' }), { replace: true, scroll: false });
      });
      root.addEventListener('click', (e) => {
        const un = e.target.closest('[data-unfilter]');
        if (un) {
          const k = un.dataset.unfilter;
          if (LIST_KEYS.includes(k)) navigate({ [k]: f[k].filter((v) => v !== un.dataset.value) });
          else navigate({ [k]: '' });
          return;
        }
        if (e.target.closest('[data-clear-filters]')) { clearAll(); return; }
        const more = e.target.closest('[data-more-toggle]');
        if (more) {
          const open = more.dataset.open === '1';
          $$('[data-more]', more.parentElement).forEach((x) => { x.hidden = open; });
          more.dataset.open = open ? '' : '1';
          more.textContent = open ? `Ver ${more.dataset.count} más` : 'Ver menos';
          return;
        }
        if (e.target.closest('[data-open-filters]')) {
          openDrawer({
            side: 'left',
            title: `${icon('filter')} Filtrar`,
            html: `<div class="filters" style="position:static;max-height:none;overflow:visible">${filtersHtml(res, f, view, 'm')}</div><div style="position:sticky;bottom:-20px;background:var(--surface);padding:12px 0"><button type="button" class="btn btn--primary btn--block btn--lg" data-ov-close>Ver ${num(res.total)} productos</button></div>`,
            onMount(api) {
              api.el.addEventListener('change', (ev) => {
                if (ev.target.matches('[data-filter]')) { api.close(); onFilterChange(ev.target); }
              });
              api.el.addEventListener('click', (ev) => { if (ev.target.closest('[data-clear-filters]')) { api.close(); clearAll(); } });
            },
          });
        }
      });
      return null;
    },
  };
}

export { CATEGORIES };

// Ingreso, registro y Mi cuenta.

import { $, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { field, checkbox, notice, emptyState, productGrid, pebbles, breadcrumbs } from '../ui/components.js';
import { PREVISIONES } from '../data/content.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { CLUB, BRAND } from '../config.js';
import { state, currentUser } from '../engine/state.js';
import { register, login, logout, updateUser, joinClub, toggleTreatment, addAddress, removeAddress, savePrescription, removePrescription, passwordIssues } from '../engine/account.js';
import { statusLabel } from '../engine/orders.js';
import { deliveryWhen } from '../engine/orderflow.js';
import { refreshRemoteOrders } from '../engine/datasource.js';
import { byId, PRODUCTS } from '../engine/catalog.js';
import { treatmentEligible, priceInfo } from '../engine/pricing.js';
import { priceCtx } from '../engine/shop.js';
import { clp, shortDate } from '../engine/format.js';
import { validPhone, cleanPhone, formatPhone } from '../engine/rut.js';
import { openModal, toast, confirmDialog } from '../ui/overlay.js';
import { go } from '../router.js';

const sideBenefits = `<div class="auth__side">
  <h2>Tu cuenta Piedra</h2>
  <ul>
    <li>${icon('star')}Precios Club y campañas por día</li>
    <li>${icon('refresh')}Mi Tratamiento: ${CLUB.treatmentPct}% en tus remedios crónicos</li>
    <li>${icon('file')}Tus recetas guardadas para comprar más rápido</li>
    <li>${icon('box')}Seguimiento de todos tus pedidos</li>
  </ul>
  ${pebbles()}
</div>`;

const safeBack = (v) => (v && v.startsWith('/') && !v.startsWith('//') ? v : '/cuenta');

export function loginPage(params, query) {
  if (currentUser()) return { redirect: safeBack(query.volver) };
  const back = safeBack(query.volver);
  return {
    title: 'Ingresar',
    html: `<div class="wrap page"><div class="auth">${sideBenefits}
      <div class="auth__main">
        <h1 class="page-title">Ingresa a tu cuenta</h1>
        <form id="login-form" class="form-grid" novalidate>
          ${field({ label: 'Correo electrónico', name: 'email', type: 'email', required: true, autocomplete: 'email', full: true })}
          ${field({ label: 'Contraseña', name: 'password', type: 'password', required: true, autocomplete: 'current-password', full: true })}
          <p class="field__error full" id="login-error" aria-live="polite"></p>
          <div class="full" style="display:grid;gap:10px"><button class="btn btn--primary btn--lg btn--block" type="submit">Ingresar</button>
          <button type="button" class="btn btn--link" data-forgot style="justify-self:start">¿Olvidaste tu contraseña?</button></div>
        </form>
        <div class="notice notice--info">${icon('user')}<span>¿No tienes cuenta? <a href="#/registro${back !== '/cuenta' ? `?volver=${encodeURIComponent(back)}` : ''}" data-link>Créala gratis</a> y únete al Club Piedra.</span></div>
        ${BRAND.demo ? '<p class="field__hint">Sitio de demostración: las cuentas se guardan solo en este navegador.</p>' : ''}
      </div></div></div>`,
    mount(root) {
      root.addEventListener('submit', async (e) => {
        if (e.target.id !== 'login-form') return;
        e.preventDefault();
        const v = formData(e.target);
        const r = await login(v.email, v.password);
        if (!r.ok) { $('#login-error', root).textContent = r.error; return; }
        toast(`Hola de nuevo, <b>${esc(currentUser().nombre)}</b>.`);
        go(back, { replace: true });
      });
      root.addEventListener('click', (e) => {
        if (!e.target.closest('[data-forgot]')) return;
        openModal({
          title: 'Recuperar contraseña',
          size: 'sm',
          html: `<form id="forgot" class="form-grid" novalidate>${field({ label: 'Correo de tu cuenta', name: 'email', type: 'email', required: true, full: true })}<div class="full"><button class="btn btn--primary btn--block" type="submit">Enviar instrucciones</button></div></form>`,
          onMount(api) {
            $('#forgot', api.el).addEventListener('submit', (ev) => {
              ev.preventDefault();
              api.setBody(notice('ok', 'Si el correo tiene una cuenta, te enviamos un enlace para crear una nueva contraseña. (En esta demostración no se envían correos.)'));
            });
          },
        });
      });
      return null;
    },
  };
}

export function registerPage(params, query) {
  if (currentUser()) return { redirect: safeBack(query.volver) };
  const back = safeBack(query.volver);
  return {
    title: 'Crear cuenta',
    html: `<div class="wrap page"><div class="auth">${sideBenefits}
      <div class="auth__main">
        <h1 class="page-title">Crea tu cuenta</h1>
        <p class="page-sub">Con tu RUT accedes a los descuentos del Club Piedra también en farmacias.</p>
        <form id="reg-form" class="form-grid" novalidate>
          ${field({ label: 'RUT', name: 'rut', required: true, placeholder: '12.345.678-5' })}
          ${field({ label: 'Nombre', name: 'nombre', required: true, autocomplete: 'given-name' })}
          ${field({ label: 'Apellido paterno', name: 'apellidoP', required: true, autocomplete: 'family-name' })}
          ${field({ label: 'Apellido materno', name: 'apellidoM' })}
          ${field({ label: 'Correo electrónico', name: 'email', type: 'email', required: true, autocomplete: 'email' })}
          ${field({ label: 'Celular', name: 'phone', type: 'tel', required: true, inputmode: 'tel', placeholder: '+56 9 1234 5678', autocomplete: 'tel' })}
          ${field({ label: 'Fecha de nacimiento', name: 'birth', type: 'date' })}
          ${field({ label: 'Previsión de salud', name: 'prevision', options: [{ value: '', label: 'Elegir…' }, ...PREVISIONES] })}
          ${field({ label: 'Contraseña', name: 'password', type: 'password', required: true, autocomplete: 'new-password', hint: 'Mínimo 8 caracteres, con letras y números.' })}
          ${field({ label: 'Repite la contraseña', name: 'password2', type: 'password', required: true, autocomplete: 'new-password' })}
          ${checkbox({ name: 'club', label: `<b>Quiero ser parte del Club Piedra</b> (gratis): precios Club, campañas semanales y Mi Tratamiento.`, checked: true })}
          ${checkbox({ name: 'marketing', label: 'Quiero recibir ofertas y consejos de salud por correo.' })}
          ${checkbox({ name: 'terms', label: 'Acepto los <a href="#/legal/terminos" data-link>términos y condiciones</a> y la <a href="#/legal/privacidad" data-link>política de privacidad</a>, incluido el uso de mis datos de salud para dispensar mis medicamentos.', required: true })}
          <div class="full"><button class="btn btn--primary btn--lg btn--block" type="submit">Crear cuenta</button></div>
        </form>
        <p class="field__hint">¿Ya tienes cuenta? <a href="#/ingresar" data-link>Ingresa aquí</a>.</p>
      </div></div></div>`,
    mount(root) {
      root.addEventListener('submit', async (e) => {
        if (e.target.id !== 'reg-form') return;
        e.preventDefault();
        const v = formData(e.target);
        const r = await register(v);
        if (!r.ok) { setErrors(e.target, r.errors); return; }
        toast(`¡Bienvenido, <b>${esc(currentUser().nombre)}</b>!${currentUser().club ? ' Ya eres socio del Club Piedra.' : ''}`);
        go(back, { replace: true });
      });
      root.addEventListener('input', (e) => {
        if (e.target.name !== 'password') return;
        const issues = passwordIssues(e.target.value);
        const hint = e.target.closest('.field').querySelector('.field__hint');
        hint.textContent = issues.length ? `Falta: ${issues.join(', ')}.` : 'Contraseña segura.';
        hint.style.color = issues.length ? '' : 'var(--ok)';
      });
      return null;
    },
  };
}

const TABS = [
  ['', 'Resumen', 'home'],
  ['pedidos', 'Mis pedidos', 'box'],
  ['recetas', 'Mis recetas', 'file'],
  ['direcciones', 'Direcciones', 'pin'],
  ['favoritos', 'Favoritos', 'heart'],
  ['tratamiento', 'Mi Tratamiento', 'refresh'],
  ['datos', 'Mis datos', 'user'],
];

function orderList(orders) {
  if (!orders.length) return emptyState({ icon: 'box', title: 'Aún no tienes pedidos', text: 'Cuando compres, aquí verás el estado de cada pedido.', actions: '<a class="btn btn--primary" href="#/" data-link>Ir a la tienda</a>' });
  return `<div style="display:grid;gap:10px">${orders.map((o) => {
    const st = statusLabel(o);
    return `<a class="order-card" href="#/pedido/${o.id}" data-link style="text-decoration:none;color:inherit">
      <div style="display:grid;gap:6px"><div><b>${esc(o.id)}</b> · <span class="muted">${esc(shortDate(o.createdAt))} · ${o.items.reduce((a, i) => a + i.qty, 0)} productos</span></div>
        <div class="order-card__thumbs">${o.items.slice(0, 5).map((i) => (byId.get(i.id) ? `<img src="${productImg(byId.get(i.id))}" alt="">` : '')).join('')}</div>
        <span class="order-card__state"><span class="chip chip--${st.tone}">${esc(st.text)}</span>${o.cancelled ? '' : ` <span class="muted order-card__when">${esc(deliveryWhen(o))}</span>`}</span></div>
      <b>${clp(o.totals.total)}</b></a>`;
  }).join('')}</div>`;
}

function tabContent(tab, u) {
  const orders = state.orders.filter((o) => o.userEmail === u.email);
  if (tab === 'pedidos') return `<h2 class="sec-title">Mis pedidos</h2>${orderList(orders)}`;
  if (tab === 'favoritos') {
    const favs = state.favorites.map((id) => byId.get(id)).filter(Boolean);
    return `<h2 class="sec-title">Favoritos</h2>${favs.length ? productGrid(favs) : emptyState({ icon: 'heart', title: 'Aún no guardas favoritos', text: 'Toca el corazón de un producto para guardarlo aquí.' })}`;
  }
  if (tab === 'recetas') {
    return `<h2 class="sec-title">Mis recetas</h2>
      <p class="page-sub">Guarda tus recetas para adjuntarlas rápido en tus próximas compras. Solo un químico farmacéutico puede verlas.</p>
      <label class="rx-upload__drop" style="position:relative">${icon('upload')}<span><b>Subir una receta</b> · JPG, PNG o PDF hasta 8 MB</span><input type="file" accept="image/*,application/pdf" data-save-rx></label>
      ${u.prescriptions.length ? `<div style="display:grid;gap:10px">${u.prescriptions.map((r) => `<div class="order-card"><div style="display:flex;gap:12px;align-items:center">${r.thumb ? `<img src="${r.thumb}" alt="" style="width:52px;height:52px;object-fit:cover;border-radius:10px">` : `<span class="cat-tile__ico" style="width:52px;height:52px">${icon('file')}</span>`}<div><b>${esc(r.name)}</b><br><span class="muted">Guardada el ${esc(shortDate(r.date))}</span></div></div><button type="button" class="btn btn--link btn--sm" data-del-rx="${r.id}">Eliminar</button></div>`).join('')}</div>` : '<p class="muted">Aún no tienes recetas guardadas.</p>'}`;
  }
  if (tab === 'direcciones') {
    const regionOpts = REGIONS.map((r) => ({ value: r.id, label: regionLabel(r) }));
    return `<h2 class="sec-title">Direcciones</h2>
      ${u.addresses.length ? `<div style="display:grid;gap:10px">${u.addresses.map((a) => `<div class="order-card"><div><b>${esc(a.alias)}</b><br><span class="muted">${esc(a.calle)} ${esc(a.numero)}${a.depto ? `, ${esc(a.depto)}` : ''}, ${esc(a.comuna)}</span></div><button type="button" class="btn btn--link btn--sm" data-del-addr="${a.id}">Eliminar</button></div>`).join('')}</div>` : '<p class="muted">Aún no tienes direcciones guardadas.</p>'}
      <form class="panel form-grid" id="addr-form" novalidate>
        <h3 class="panel__title full" style="margin:0">Agregar dirección</h3>
        ${field({ label: 'Nombre de la dirección', name: 'alias', placeholder: 'Casa, trabajo…', required: true })}
        ${field({ label: 'Región', name: 'region', value: state.location.region, options: regionOpts, required: true })}
        ${field({ label: 'Comuna', name: 'comuna', value: state.location.comuna, options: (regionById(state.location.region)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es')), required: true })}
        ${field({ label: 'Calle', name: 'calle', required: true })}
        ${field({ label: 'Número', name: 'numero', required: true, inputmode: 'numeric' })}
        ${field({ label: 'Depto., casa u oficina', name: 'depto' })}
        <div class="full"><button class="btn btn--primary" type="submit">Guardar dirección</button></div>
      </form>`;
  }
  if (tab === 'tratamiento') {
    const enrolled = u.treatment.map((id) => byId.get(id)).filter(Boolean);
    const eligible = PRODUCTS.filter((p) => treatmentEligible(p) && !u.treatment.includes(p.id)).sort((a, b) => b.popularity - a.popularity).slice(0, 12);
    return `<h2 class="sec-title">Mi Tratamiento</h2>
      <p class="page-sub">Inscribe hasta ${CLUB.treatmentMax} medicamentos de uso crónico con receta simple y paga siempre ${CLUB.treatmentPct}% menos. Beneficio para socios Club.</p>
      ${!u.club ? `<div class="treat"><b>${icon('star')} Necesitas ser socio del Club Piedra</b><p>Inscribirte es gratis y toma un segundo.</p><button type="button" class="btn btn--club" data-join>Unirme al Club</button></div>` : ''}
      <h3 style="font-size:17px">Inscritos (${enrolled.length}/${CLUB.treatmentMax})</h3>
      ${enrolled.length ? `<div style="display:grid;gap:10px">${enrolled.map((p) => `<div class="order-card"><a href="#/producto/${p.slug}" data-link style="display:flex;gap:12px;align-items:center;text-decoration:none;color:inherit"><img src="${productImg(p)}" alt="" style="width:52px;height:52px;border-radius:10px;background:var(--tile)"><span><b>${esc(p.name)}</b><br><span class="muted">${esc(p.brand)} · ${clp(priceInfo(p, priceCtx()).clubPrice || p.price)} con ${CLUB.treatmentPct}%</span></span></a><button type="button" class="btn btn--link btn--sm" data-treat="${p.id}">Quitar</button></div>`).join('')}</div>` : '<p class="muted">Aún no inscribes productos.</p>'}
      ${u.club ? `<h3 style="font-size:17px">Puedes inscribir</h3><div style="display:grid;gap:10px">${eligible.map((p) => `<div class="order-card"><a href="#/producto/${p.slug}" data-link style="display:flex;gap:12px;align-items:center;text-decoration:none;color:inherit"><img src="${productImg(p)}" alt="" style="width:52px;height:52px;border-radius:10px;background:var(--tile)"><span><b>${esc(p.name)}</b><br><span class="muted">${esc(p.brand)} · ${clp(p.offer || p.price)}</span></span></a><button type="button" class="btn btn--club btn--sm" data-treat="${p.id}" ${u.treatment.length >= CLUB.treatmentMax ? 'disabled' : ''}>Inscribir</button></div>`).join('')}</div>` : ''}`;
  }
  if (tab === 'datos') {
    return `<h2 class="sec-title">Mis datos</h2>
      <form class="panel form-grid" id="data-form" novalidate>
        ${field({ label: 'RUT', name: 'rut', value: u.rut, attrs: 'readonly', hint: 'Para cambiar tu RUT o correo, contáctanos.' })}
        ${field({ label: 'Correo electrónico', name: 'email', value: u.email, attrs: 'readonly' })}
        ${field({ label: 'Nombre', name: 'nombre', value: u.nombre, required: true })}
        ${field({ label: 'Apellido paterno', name: 'apellidoP', value: u.apellidoP, required: true })}
        ${field({ label: 'Apellido materno', name: 'apellidoM', value: u.apellidoM })}
        ${field({ label: 'Celular', name: 'phone', type: 'tel', value: formatPhone(u.phone), required: true })}
        ${field({ label: 'Previsión de salud', name: 'prevision', value: u.prevision, options: [{ value: '', label: 'Elegir…' }, ...PREVISIONES] })}
        ${field({ label: 'Fecha de nacimiento', name: 'birth', type: 'date', value: u.birth })}
        ${checkbox({ name: 'marketing', label: 'Quiero recibir ofertas y consejos de salud por correo.', checked: u.marketing })}
        <div class="full"><button class="btn btn--primary" type="submit">Guardar cambios</button></div>
      </form>`;
  }
  // Resumen
  const savings = orders.filter((o) => !o.cancelled).reduce((a, o) => a + o.totals.offerOff + o.totals.promoOff + o.totals.clubOff + o.totals.couponOff, 0);
  return `<div class="acct-hello"><span class="avatar">${esc((u.nombre[0] || '') + (u.apellidoP[0] || ''))}</span><div><h2 class="sec-title">Hola, ${esc(u.nombre)}</h2><p class="muted">${esc(u.email)} · RUT ${esc(u.rut)}</p></div><button type="button" class="btn btn--ghost btn--sm" data-logout style="margin-left:auto">${icon('logout')} Cerrar sesión</button></div>
    ${u.club ? `<div class="club-card"><small>Socio Club Piedra</small><b>${esc(u.nombre)} ${esc(u.apellidoP)}</b><span>RUT ${esc(u.rut)} · Precios Club en web y farmacias</span>${pebbles()}</div>`
      : `<div class="treat"><b>${icon('star')} Únete al Club Piedra</b><p>Accede a precios Club, campañas por día y al programa Mi Tratamiento. Es gratis.</p><button type="button" class="btn btn--club" data-join>Unirme al Club</button></div>`}
    <div class="stats"><div class="stat"><b>${orders.length}</b><span>Pedidos</span></div><div class="stat"><b>${clp(savings)}</b><span>Ahorro en tus compras</span></div><div class="stat"><b>${u.treatment.length}</b><span>Productos en Mi Tratamiento</span></div></div>
    <h3 style="font-size:18px">Pedidos recientes</h3>${orderList(orders.slice(0, 3))}`;
}

export function accountPage(params) {
  const tab = params.tab || '';
  const u = currentUser();
  if (!u) {
    if (tab === 'favoritos') {
      const favs = state.favorites.map((id) => byId.get(id)).filter(Boolean);
      return {
        title: 'Favoritos',
        rerender: ['favorites', 'user', 'location'],
        html: `<div class="wrap page page--tight">${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Favoritos' }])}<h1 class="page-title">Favoritos</h1>
          ${notice('info', '<a href="#/ingresar?volver=%2Fcuenta%2Ffavoritos" data-link>Inicia sesión</a> para ver también tus pedidos, recetas y beneficios Club.')}
          ${favs.length ? productGrid(favs) : emptyState({ icon: 'heart', title: 'Aún no guardas favoritos', text: 'Toca el corazón de un producto para guardarlo aquí.' })}</div>`,
      };
    }
    return loginPage({}, { volver: `/cuenta${tab ? `/${tab}` : ''}` });
  }
  if (!TABS.some(([id]) => id === tab)) return null;
  const html = `<div class="wrap page page--tight">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Mi cuenta', href: tab ? '/cuenta' : '' }, ...(tab ? [{ label: TABS.find(([id]) => id === tab)[1] }] : [])])}
    <div class="acct">
      <nav class="acct__nav" aria-label="Mi cuenta">${TABS.map(([id, label, ic]) => `<a href="#/cuenta${id ? `/${id}` : ''}" data-link class="${id === tab ? 'is-on' : ''}"${id === tab ? ' aria-current="page"' : ''}>${icon(ic)}${esc(label)}</a>`).join('')}<a href="#/cuenta" data-logout>${icon('logout')}Cerrar sesión</a></nav>
      <div class="acct__main">${tabContent(tab, u)}</div>
    </div>
  </div>`;
  return {
    title: 'Mi cuenta',
    rerender: ['user', 'orders', 'favorites', 'location'],
    html,
    mount(root) {
      // Los pedidos se actualizan con lo que marcó la farmacia (etapas, fechas, mensajes)
      if (tab === '' || tab === 'pedidos') refreshRemoteOrders(state.orders.filter((o) => o.userEmail === u.email));
      root.addEventListener('click', async (e) => {
        if (e.target.closest('[data-logout]')) {
          e.preventDefault();
          logout();
          toast('Cerraste sesión.', { tone: 'info' });
          go('/', { replace: true });
          return;
        }
        if (e.target.closest('[data-join]')) { joinClub(); toast('¡Ya eres socio del Club Piedra!'); return; }
        const tr = e.target.closest('[data-treat]');
        if (tr) { const r = toggleTreatment(tr.dataset.treat); if (!r.ok) toast(r.error, { tone: 'warn' }); return; }
        const da = e.target.closest('[data-del-addr]');
        if (da && await confirmDialog({ title: '¿Eliminar dirección?', text: 'Esta dirección se borrará de tu cuenta.', confirmText: 'Eliminar', danger: true })) { removeAddress(da.dataset.delAddr); return; }
        const dr = e.target.closest('[data-del-rx]');
        if (dr && await confirmDialog({ title: '¿Eliminar receta?', text: 'La receta se borrará de tu cuenta.', confirmText: 'Eliminar', danger: true })) { removePrescription(dr.dataset.delRx); }
      });
      root.addEventListener('change', (e) => {
        const t = e.target;
        if (t.matches('[data-save-rx]') && t.files?.[0]) {
          const file = t.files[0];
          if (file.size > 8 * 1024 * 1024) { toast('El archivo pesa más de 8 MB.', { tone: 'warn' }); return; }
          const done = (thumb) => { savePrescription({ name: file.name, thumb }); toast('Receta guardada.'); };
          if (!file.type.startsWith('image/')) { done(''); return; }
          const fr = new FileReader();
          fr.onload = () => {
            const img = new Image();
            img.onload = () => {
              const s = Math.min(1, 160 / Math.max(img.width, img.height));
              const c = document.createElement('canvas');
              c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
              c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
              let th = '';
              try { th = c.toDataURL('image/jpeg', 0.7); } catch { th = ''; }
              done(th);
            };
            img.onerror = () => done('');
            img.src = fr.result;
          };
          fr.readAsDataURL(file);
          return;
        }
        if (t.closest('#addr-form') && t.name === 'region') {
          const f = t.form;
          f.comuna.innerHTML = (regionById(t.value)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es')).map((c) => `<option>${esc(c)}</option>`).join('');
        }
      });
      root.addEventListener('submit', (e) => {
        const f = e.target;
        if (f.id === 'addr-form') {
          e.preventDefault();
          const v = formData(f);
          const errors = {};
          if (!v.alias.trim()) errors.alias = 'Ponle un nombre (por ejemplo, Casa).';
          if (!v.calle.trim()) errors.calle = 'Ingresa la calle.';
          if (!v.numero.trim()) errors.numero = 'Ingresa el número.';
          if (!setErrors(f, errors)) return;
          addAddress({ alias: v.alias.trim(), calle: v.calle.trim(), numero: v.numero.trim(), depto: v.depto.trim(), comuna: v.comuna });
          toast('Dirección guardada.');
        }
        if (f.id === 'data-form') {
          e.preventDefault();
          const v = formData(f);
          const errors = {};
          if (!v.nombre.trim()) errors.nombre = 'Ingresa tu nombre.';
          if (!v.apellidoP.trim()) errors.apellidoP = 'Ingresa tu apellido paterno.';
          if (!validPhone(v.phone)) errors.phone = 'Ingresa un celular de 9 dígitos que comience con 9.';
          if (!setErrors(f, errors)) return;
          updateUser({ nombre: v.nombre.trim(), apellidoP: v.apellidoP.trim(), apellidoM: v.apellidoM.trim(), phone: cleanPhone(v.phone), prevision: v.prevision, birth: v.birth, marketing: !!v.marketing });
          toast('Guardamos tus datos.');
        }
      });
      return null;
    },
  };
}

// Panel → Seguridad: verificación en dos pasos, contraseña, sesiones abiertas,
// registro de ingresos y una revisión de lo que falta para publicar seguro.

import { $, esc, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice } from '../ui/components.js';
import { openModal, toast, confirmDialog } from '../ui/overlay.js';
import { dateTime } from '../engine/format.js';
import { adminShell, adminGuard, openChangePassword } from './admin.js';
import { passField, toggleEye } from '../admin/login.js';
import { qrSvg } from '../admin/qr.js';
import { bo, securityInfo, start2fa, enable2fa, disable2fa, newRecoveryCodes, closeOtherSessions } from '../admin/api.js';

const EVENTS = {
  login: ['Ingreso', 'ok'],
  login_recovery: ['Ingreso con código de respaldo', 'warn'],
  login_fail: ['Contraseña incorrecta', 'danger'],
  '2fa_fail': ['Código de verificación incorrecto', 'danger'],
  logout: ['Salida', ''],
  setup: ['Creó el primer administrador', 'info'],
  password: ['Cambió la contraseña', 'info'],
  password_reset: ['Contraseña cambiada en el servidor', 'warn'],
  '2fa_on': ['Activó la verificación en dos pasos', 'ok'],
  '2fa_off': ['Desactivó la verificación en dos pasos', 'warn'],
  '2fa_reset': ['Verificación desactivada en el servidor', 'warn'],
  recovery_new: ['Creó nuevos códigos de respaldo', 'info'],
  close_sessions: ['Cerró las demás sesiones', 'info'],
};

/** "Chrome en Windows" a partir del navegador que usó. */
export function deviceLabel(ua = '') {
  const u = String(ua);
  const browser = /Edg\//.test(u) ? 'Edge' : /OPR\/|Opera/.test(u) ? 'Opera' : /SamsungBrowser/.test(u) ? 'Samsung Internet' : /Firefox\//.test(u) ? 'Firefox' : /Chrome\/|CriOS/.test(u) ? 'Chrome' : /Safari\//.test(u) ? 'Safari' : '';
  const os = /iPhone/.test(u) ? 'iPhone' : /iPad/.test(u) ? 'iPad' : /Android/.test(u) ? 'Android' : /Windows/.test(u) ? 'Windows' : /Mac OS X|Macintosh/.test(u) ? 'Mac' : /Linux/.test(u) ? 'Linux' : '';
  if (!browser && !os) return u ? 'Otro equipo' : '—';
  return [browser, os].filter(Boolean).join(' en ');
}

const groups = (secret) => String(secret).replace(/(.{4})/g, '$1 ').trim();

function checksHtml(info) {
  const c = info.checks || {};
  const item = (ok, title, text, tone) => `<li class="schk__item schk__item--${tone || (ok ? 'ok' : 'warn')}">${icon(ok ? 'checkCircle' : tone === 'info' ? 'info' : 'alert')}<div><b>${title}</b><span>${text}</span></div></li>`;
  return `<ul class="schk">
    ${c.proxyWithoutTrust ? item(false, 'Falta TRUST_PROXY=1', 'Las visitas llegan a través de un proxy (Caddy, Nginx o el hosting), pero el servidor no lo sabe: define TRUST_PROXY=1 en .env para que reconozca https y la IP real de cada visita.') : ''}
    ${c.https
      ? item(true, 'Conexión cifrada (https)', 'Todo lo que viaja entre el navegador y el servidor va cifrado.')
      : c.local
        ? item(false, 'Conexión cifrada (https)', 'Ahora estás en este computador o en tu red, donde no hace falta. Al publicar la página en internet, el panel solo abrirá con https (ver README).', 'info')
        : item(false, 'Conexión cifrada (https)', 'Esta conexión no está cifrada. Configura https antes de usar el panel desde internet (ver README).')}
    ${item(true, 'Datos de clientes y recetas cifrados', 'Se guardan cifrados en la base de datos: sin la llave, un respaldo robado no se puede leer.')}
    ${item(true, 'Contraseñas protegidas', 'Nunca se guardan tal cual, y tras 5 intentos fallidos el ingreso se bloquea 15 minutos.')}
    ${info.twoFactor
      ? item(true, 'Verificación en dos pasos', 'Activa en tu cuenta: aunque alguien sepa tu contraseña, sin tu celular no entra.')
      : item(false, 'Verificación en dos pasos', 'Recomendado: actívala abajo. Así nadie entra solo con tu contraseña.')}
    ${c.adminHost || c.adminPath
      ? item(true, 'Dirección del panel', c.adminHost ? 'El panel está en su propio subdominio, separado de la tienda.' : 'El panel usa una dirección propia, difícil de adivinar.')
      : item(false, 'Dirección del panel', 'Al publicarla, usa una dirección propia (ADMIN_PATH) o un subdominio (ADMIN_HOST) para que los robots no encuentren el ingreso.', 'info')}
    ${c.adminIps ? item(true, 'Acceso por dirección IP', 'Solo las direcciones autorizadas pueden abrir el panel.') : ''}
  </ul>`;
}

function twoFactorHtml(info) {
  if (info.twoFactor) {
    return `<div class="tfa tfa--on">
      <p class="tfa__status">${icon('checkCircle')}<span><b>Activa.</b> Al ingresar se pide el código de 6 números de la app de tu celular.</span></p>
      <p class="muted">Códigos de respaldo disponibles: <b id="tfa-left">${info.recoveryLeft}</b> de 10. Úsalos si no tienes el celular (cada uno sirve una vez).</p>
      ${info.recoveryLeft <= 3 ? notice('warn', 'Te quedan pocos códigos de respaldo. Crea nuevos y guárdalos en un lugar seguro.') : ''}
      <div class="tfa__btns">
        <button type="button" class="btn btn--soft btn--sm" data-tfa="recovery">${icon('refresh')} Crear nuevos códigos de respaldo</button>
        <button type="button" class="btn btn--ghost btn--sm" data-tfa="disable">${icon('x')} Desactivar</button>
      </div>
    </div>`;
  }
  return `<div class="tfa">
    <p class="tfa__status tfa__status--off">${icon('alert')}<span><b>Desactivada.</b> Hoy basta con tu usuario y contraseña para entrar.</span></p>
    <p>Con la verificación en dos pasos, además de la contraseña se pide un código que cambia cada 30 segundos en una app gratuita de tu celular (<b>Google Authenticator</b> o <b>Microsoft Authenticator</b>). Aunque alguien consiga tu contraseña, sin tu celular no puede entrar.</p>
    <button type="button" class="btn btn--primary" data-tfa="start">${icon('shield')} Activar verificación en dos pasos</button>
  </div>`;
}

function recoveryHtml(codes) {
  return `<div class="rcodes">
    ${notice('warn', '<b>Guarda estos códigos de respaldo</b> en un lugar seguro (imprímelos o guárdalos en tu correo personal). Si pierdes el celular, cada código te deja entrar <b>una vez</b>. No se volverán a mostrar.')}
    <ol class="rcodes__list">${codes.map((c) => `<li><code>${esc(c)}</code></li>`).join('')}</ol>
    <div class="rcodes__btns">
      <button type="button" class="btn btn--soft btn--sm" data-rc="copy">${icon('copy')} Copiar</button>
      <button type="button" class="btn btn--soft btn--sm" data-rc="download">${icon('arrowDown')} Descargar (.txt)</button>
    </div>
  </div>`;
}

function wireRecovery(box, codes) {
  const text = `Farmacias Piedra · Códigos de respaldo del panel (usuario ${bo.user})\nCada código sirve una sola vez.\n\n${codes.join('\n')}\n`;
  box.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-rc]');
    if (!b) return;
    if (b.dataset.rc === 'copy') {
      try { await navigator.clipboard.writeText(text); toast('Copiaste los códigos de respaldo.'); } catch { toast('No se pudo copiar. Selecciónalos y cópialos a mano.', { tone: 'warn' }); }
    } else {
      const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = 'codigos-respaldo-farmacias-piedra.txt';
      document.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }
  });
}

/** Ventana que pide contraseña + código (para desactivar o crear códigos nuevos). */
function confirmWithCode({ title, text, button, danger = false, run }) {
  openModal({
    title: `${icon('lock')} ${esc(title)}`,
    size: 'sm',
    html: `<form id="tfx-form" class="form-grid form-grid--1" novalidate>
      <p>${text}</p>
      ${passField('tfx-pass', 'Tu contraseña', 'current-password')}
      <div class="field"><label for="f-tfx-code">Código de la app (o un código de respaldo)</label><input id="f-tfx-code" name="code" type="text" autocomplete="one-time-code" maxlength="12" required placeholder="123456"><p class="field__error" aria-live="polite"></p></div>
      <div class="full"><button class="btn ${danger ? 'btn--danger' : 'btn--primary'} btn--block" type="submit">${esc(button)}</button></div>
    </form><div id="tfx-out"></div>`,
    onMount(api) {
      const f = $('#tfx-form', api.el);
      api.el.addEventListener('click', (e) => { const eye = e.target.closest('[data-eye]'); if (eye) toggleEye(eye); });
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = formData(f);
        const errors = {};
        if (!v['tfx-pass']) errors['tfx-pass'] = 'Escribe tu contraseña.';
        if (!v.code.trim()) errors.code = 'Escribe el código.';
        if (!setErrors(f, errors)) return;
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        const r = await run(v['tfx-pass'], v.code.trim());
        btn.disabled = false;
        if (!r.ok) { setErrors(f, r.code === 'bad_credentials' ? { 'tfx-pass': r.error } : { code: r.error }); return; }
        r.after?.(api);
      });
    },
  });
}

export function adminSecurityPage() {
  const guard = adminGuard();
  if (guard) return guard;
  const body = `<div id="sec-root"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Cargando la seguridad de tu cuenta…</p></div></div>`;
  return {
    title: 'Seguridad · Administración',
    html: adminShell('seguridad', 'Seguridad', body, { sub: 'Protege el ingreso al panel y revisa quién entró y desde dónde.' }),
    onState: () => true, // se actualiza sola después de cada cambio
    mount(root) {
      const box = $('#sec-root', root);
      let info = null;

      async function load() {
        try {
          info = await securityInfo();
        } catch (e) {
          box.innerHTML = notice('warn', esc(e.message));
          return;
        }
        render();
      }

      function render() {
        const sessions = info.sessions || [];
        const log = info.log || [];
        box.innerHTML = `<div class="sec-grid">
          <section class="panel sec-card sec-card--wide"><h2 class="panel__title">Revisión de seguridad</h2>${checksHtml(info)}</section>
          <section class="panel sec-card" id="tfa-card"><h2 class="panel__title">${icon('shield')} Verificación en dos pasos</h2><div id="tfa-body">${twoFactorHtml(info)}</div></section>
          <section class="panel sec-card"><h2 class="panel__title">${icon('lock')} Contraseña</h2>
            <p>Usa una contraseña larga que no uses en otros sitios. Al cambiarla se cierran las sesiones abiertas en otros equipos.</p>
            <button type="button" class="btn btn--soft" data-sec="password">${icon('lock')} Cambiar contraseña</button></section>
          <section class="panel sec-card sec-card--wide"><div class="panel__head"><h2 class="panel__title">Sesiones abiertas</h2>${sessions.length > 1 ? '<button type="button" class="btn btn--ghost btn--sm" data-sec="close-others">Cerrar las demás sesiones</button>' : ''}</div>
            <ul class="sess">${sessions.map((x) => `<li class="sess__item"><span class="sess__ico" aria-hidden="true">${icon('user')}</span><div><b>${esc(deviceLabel(x.ua))}</b>${x.current ? ' <span class="chip chip--ok">Este equipo</span>' : ''}<small>IP ${esc(x.ip || '—')} · última actividad ${esc(dateTime(x.lastSeen))}</small></div></li>`).join('')}</ul>
            <p class="field__hint">Si ves una sesión que no reconoces, ciérrala y cambia tu contraseña.</p></section>
          <section class="panel sec-card sec-card--wide"><h2 class="panel__title">Registro de ingresos</h2>
            ${log.length ? `<div class="atable atable--log" role="table" aria-label="Registro de ingresos">
              <div class="atable__row atable__row--head" role="row"><span role="columnheader">Fecha</span><span role="columnheader">Usuario</span><span role="columnheader">Qué pasó</span><span role="columnheader">Desde</span></div>
              ${log.map((l) => { const [label, tone] = EVENTS[l.event] || [l.event, '']; return `<div class="atable__row" role="row"><span role="cell">${esc(dateTime(l.at))}</span><span role="cell">${esc(l.user || '—')}</span><span role="cell"><span class="chip${tone ? ` chip--${tone}` : ''}">${esc(label)}</span></span><span role="cell">${esc(l.ip || '—')}<small>${esc(deviceLabel(l.ua))}</small></span></div>`; }).join('')}
            </div>` : '<p class="muted">Aún no hay ingresos registrados.</p>'}
            <p class="field__hint">Muchos «Contraseña incorrecta» seguidos pueden ser alguien intentando adivinarla: tras 5 intentos el ingreso se bloquea por 15 minutos.</p></section>
        </div>`;
      }

      function startFlow() {
        const tb = $('#tfa-body', box);
        tb.innerHTML = '<div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div></div>';
        start2fa().then((r) => {
          if (!r.ok) { tb.innerHTML = notice('warn', esc(r.error)); return; }
          tb.innerHTML = `<ol class="tfa-steps">
            <li><b>Instala una app de verificación</b> en tu celular: Google Authenticator o Microsoft Authenticator (gratis en App Store y Google Play).</li>
            <li><b>Escanea este código</b> con la app (botón «+» → «Escanear código QR»).
              <div class="tfa-qr">${qrSvg(r.uri, { label: 'Código QR para la app de verificación' })}</div>
              <details class="tfa-manual"><summary>¿No puedes escanearlo? Escribe la clave a mano</summary><p>En la app elige «Ingresar clave de configuración» y escribe:</p><code class="tfa-key" id="tfa-key">${esc(groups(r.secret))}</code><p class="field__hint">Nombre: Farmacias Piedra · Tipo: basada en el tiempo.</p></details></li>
            <li><b>Escribe el código de 6 números</b> que muestra la app y tu contraseña para confirmar.
              <form id="tfa-form" class="form-grid form-grid--1 tfa-form" novalidate>
                <div class="field"><label for="f-tfa-code">Código de la app</label><input id="f-tfa-code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="9" required placeholder="123456"><p class="field__error" aria-live="polite"></p></div>
                ${passField('tfa-pass', 'Tu contraseña', 'current-password')}
                <div class="tfa__btns"><button class="btn btn--primary" type="submit">${icon('checkCircle')} Activar</button><button type="button" class="btn btn--ghost" data-tfa="cancel">Cancelar</button></div>
              </form></li>
          </ol>`;
          const f = $('#tfa-form', tb);
          f.addEventListener('submit', async (e) => {
            e.preventDefault();
            const v = formData(f);
            const errors = {};
            if (!/^\d{6}$/.test(v.code.replace(/\s/g, ''))) errors.code = 'Escribe los 6 números que muestra la app.';
            if (!v['tfa-pass']) errors['tfa-pass'] = 'Escribe tu contraseña.';
            if (!setErrors(f, errors)) return;
            const btn = $('button[type=submit]', f);
            btn.disabled = true;
            const res = await enable2fa(v['tfa-pass'], v.code.replace(/\s/g, ''));
            btn.disabled = false;
            if (!res.ok) {
              if (res.code === 'setup_expired') { toast(esc(res.error), { tone: 'warn' }); startFlow(); return; }
              setErrors(f, res.code === 'bad_credentials' ? { 'tfa-pass': res.error } : { code: res.error });
              return;
            }
            bo.twoFactor = true;
            tb.innerHTML = `${notice('ok', `<b>¡Listo! La verificación en dos pasos quedó activa.</b> Desde ahora, al ingresar se pide el código de tu celular.${res.closedSessions ? ` Cerramos ${res.closedSessions === 1 ? 'otra sesión abierta' : `${res.closedSessions} sesiones abiertas`} por seguridad.` : ''}`)}
              ${recoveryHtml(res.recovery)}
              <button type="button" class="btn btn--primary" data-tfa="done">Ya guardé los códigos</button>`;
            wireRecovery(tb, res.recovery);
          });
          requestAnimationFrame(() => $('#f-tfa-code', tb)?.focus({ preventScroll: true }));
        });
      }

      box.addEventListener('click', async (e) => {
        const eye = e.target.closest('[data-eye]');
        if (eye) { toggleEye(eye); return; }
        const t = e.target.closest('[data-tfa], [data-sec]');
        if (!t) return;
        const act = t.dataset.tfa || t.dataset.sec;
        if (act === 'start') startFlow();
        else if (act === 'cancel' || act === 'done') load();
        else if (act === 'password') openChangePassword();
        else if (act === 'disable') {
          confirmWithCode({
            title: 'Desactivar la verificación en dos pasos',
            text: 'Tu cuenta quedará protegida solo con la contraseña. Para confirmar, escribe tu contraseña y un código de la app.',
            button: 'Desactivar',
            danger: true,
            run: async (pw, code) => {
              const r = await disable2fa(pw, code);
              if (r.ok) r.after = (api) => { api.close(); bo.twoFactor = false; toast('Desactivaste la verificación en dos pasos.', { tone: 'info' }); load(); };
              return r;
            },
          });
        } else if (act === 'recovery') {
          confirmWithCode({
            title: 'Crear nuevos códigos de respaldo',
            text: 'Los códigos anteriores dejarán de servir. Para confirmar, escribe tu contraseña y un código de la app.',
            button: 'Crear códigos nuevos',
            run: async (pw, code) => {
              const r = await newRecoveryCodes(pw, code);
              if (r.ok) {
                r.after = (api) => {
                  api.setBody(`${recoveryHtml(r.recovery)}<button type="button" class="btn btn--primary btn--block" data-ov-close>Ya guardé los códigos</button>`);
                  wireRecovery(api.body, r.recovery);
                  load();
                };
              }
              return r;
            },
          });
        } else if (act === 'close-others') {
          if (!(await confirmDialog({ title: '¿Cerrar las demás sesiones?', text: 'Se cerrará el panel en todos los otros equipos donde esté abierto. Este equipo sigue dentro.', confirmText: 'Cerrar sesiones' }))) return;
          const r = await closeOtherSessions();
          if (!r.ok) { toast(esc(r.error), { tone: 'warn' }); return; }
          toast(r.closed ? `Cerraste ${r.closed === 1 ? '1 sesión' : `${r.closed} sesiones`}.` : 'No había otras sesiones abiertas.', { tone: 'info' });
          load();
        }
      });

      load();
      return null;
    },
  };
}

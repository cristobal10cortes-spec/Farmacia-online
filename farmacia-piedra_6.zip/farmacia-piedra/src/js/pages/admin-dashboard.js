// Resumen del panel: ventas realizadas en la página con gráfico acumulado
// (Mes, Año completo, Histórico), indicadores, productos más vendidos,
// stock bajo y últimos pedidos.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { notice } from '../ui/components.js';
import { mountLineChart } from '../ui/linechart.js';
import { href } from '../router.js';
import { adminShell, adminGuard, levelChip, openQuickStock } from './admin.js';
import { bo, adminOrders, lowStock } from '../admin/api.js';
import { PRODUCTS, byId, salePrice } from '../engine/catalog.js';
import { state, emit } from '../engine/state.js';
import { statusLabel } from '../engine/orders.js';
import { clp, num, dateTime, MONTHS } from '../engine/format.js';

const RANGES = [['mes', 'Mes'], ['anio', 'Año completo'], ['historico', 'Histórico']];
const MON = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const capFirst = (s) => s.charAt(0).toUpperCase() + s.slice(1);

// ── Fechas en hora de Chile (con caché por hora: es rápido con miles de pedidos)
const dtf = (() => {
  try { return new Intl.DateTimeFormat('en-US', { timeZone: 'America/Santiago', year: 'numeric', month: 'numeric', day: 'numeric' }); } catch { return null; }
})();
const ymdCache = new Map();
function ymd(ts) {
  const k = Math.floor(ts / 3600000);
  let v = ymdCache.get(k);
  if (!v) {
    if (dtf) {
      const parts = dtf.formatToParts(new Date(ts));
      const g = (t) => +parts.find((x) => x.type === t).value;
      v = { y: g('year'), m: g('month'), d: g('day') };
    } else {
      const d = new Date(ts);
      v = { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() };
    }
    if (ymdCache.size > 50000) ymdCache.clear();
    ymdCache.set(k, v);
  }
  return v;
}
const daysIn = (y, m) => new Date(y, m, 0).getDate();
const prevMonth = (y, m) => (m === 1 ? { y: y - 1, m: 12 } : { y, m: m - 1 });

// ── Ventas de ejemplo (solo para ver cómo se ve el panel; no se guardan) ──
function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function poisson(l, rnd) {
  const L = Math.exp(-l);
  let k = 0;
  let p = 1;
  do { k++; p *= rnd(); } while (p > L);
  return k - 1;
}
let demoCache = null;
function exampleOrders() {
  const now = Date.now();
  const key = Math.floor(now / 3600000);
  if (demoCache && demoCache.key === key) return demoCache.list;
  const rnd = mulberry32(73021);
  const pool = PRODUCTS.filter((p) => p.rx !== 'cheque').sort((a, b) => b.popularity - a.popularity).slice(0, 90);
  const weights = pool.map((p) => p.popularity);
  const wsum = weights.reduce((a, b) => a + b, 0);
  const pick = () => {
    let r = rnd() * wsum;
    for (let i = 0; i < pool.length; i++) { r -= weights[i]; if (r <= 0) return pool[i]; }
    return pool[0];
  };
  const SPAN = 548;
  const SEASON = [0.92, 0.88, 1, 1.03, 1.1, 1.18, 1.22, 1.12, 1.02, 1.02, 1.06, 1.3];
  const list = [];
  for (let k = SPAN; k >= 0; k--) {
    const dayTs = now - k * 86400000;
    const { m } = ymd(dayTs);
    const wd = new Date(dayTs).getDay();
    const lambda = (2.2 + 6.8 * (1 - k / SPAN)) * SEASON[m - 1] * (wd === 0 ? 0.7 : wd === 6 ? 0.86 : 1.05);
    const n = poisson(lambda, rnd);
    for (let j = 0; j < n; j++) {
      const lines = 1 + (rnd() < 0.45 ? 1 : 0) + (rnd() < 0.15 ? 1 : 0);
      const items = [];
      for (let q = 0; q < lines; q++) {
        const p = pick();
        if (items.some((it) => it.id === p.id)) continue;
        const qty = rnd() < 0.8 ? 1 : 2;
        items.push({ id: p.id, name: p.name, qty, unit: salePrice(p), total: salePrice(p) * qty });
      }
      const sub = items.reduce((a, it) => a + it.total, 0);
      const despacho = rnd() < 0.68;
      list.push({
        id: `EJ${list.length + 1}`,
        demo: true,
        createdAt: Math.min(now, dayTs - Math.floor(rnd() * 11 * 3600000)),
        items,
        totals: { total: sub + (despacho && sub < 29990 ? 2990 : 0) },
        delivery: { type: despacho ? 'despacho' : 'retiro' },
        cancelled: rnd() < 0.03,
      });
    }
  }
  demoCache = { key, list };
  return list;
}

// ── Agregación ───────────────────────────────────────────────
function salesOrders(withDemo) {
  const real = adminOrders().filter((o) => !o.cancelled && o.totals && o.createdAt);
  return withDemo ? [...real, ...exampleOrders().filter((o) => !o.cancelled)] : real;
}

function bucket(orders) {
  const day = new Map();
  const month = new Map();
  for (const o of orders) {
    const { y, m, d } = ymd(o.createdAt);
    const units = (o.items || []).reduce((a, it) => a + (it.qty || 0), 0);
    for (const [map, k] of [[day, `${y}-${m}-${d}`], [month, `${y}-${m}`]]) {
      const cur = map.get(k) || { sum: 0, count: 0, units: 0 };
      cur.sum += o.totals.total || 0;
      cur.count += 1;
      cur.units += units;
      map.set(k, cur);
    }
  }
  return { day, month };
}

const ZERO = { sum: 0, count: 0, units: 0 };
const cumulate = (arr) => { let s = 0; return arr.map((v) => (s += v)); };
const kpiOf = (list) => list.reduce((a, b) => ({ sum: a.sum + b.sum, count: a.count + b.count, units: a.units + b.units }), { ...ZERO });

function buildView(range, orders) {
  const today = ymd(Date.now());
  const { day, month } = bucket(orders);
  const dayAt = (y, m, d) => day.get(`${y}-${m}-${d}`) || ZERO;
  const monthAt = (y, m) => month.get(`${y}-${m}`) || ZERO;

  if (range === 'mes') {
    const D = daysIn(today.y, today.m);
    const pm = prevMonth(today.y, today.m);
    const PD = daysIn(pm.y, pm.m);
    const cur = Array.from({ length: today.d }, (_, i) => dayAt(today.y, today.m, i + 1));
    const prev = Array.from({ length: Math.min(PD, D) }, (_, i) => dayAt(pm.y, pm.m, i + 1));
    const curC = cumulate(cur.map((x) => x.sum));
    const prevC = cumulate(prev.map((x) => x.sum));
    const inPeriod = (o) => { const t = ymd(o.createdAt); return t.y === today.y && t.m === today.m; };
    const prevSame = prev.slice(0, Math.min(today.d, PD));
    return {
      count: D,
      title: `${capFirst(MONTHS[today.m - 1])} ${today.y}`,
      sub: `Del 1 al ${today.d} de ${MONTHS[today.m - 1]} · comparado con ${MONTHS[pm.m - 1]}`,
      curLabel: `${capFirst(MONTHS[today.m - 1])}`,
      prevLabel: `${capFirst(MONTHS[pm.m - 1])}`,
      series: [{ label: capFirst(MONTHS[pm.m - 1]), values: prevC, tone: 'muted' }, { label: capFirst(MONTHS[today.m - 1]), values: curC, tone: 'main' }],
      xTick: (i) => ((i + 1) === 1 || (i + 1) % 5 === 0 || i + 1 === D ? `${i + 1} ${MON[today.m - 1]}` : ''),
      tooltip: (i) => {
        const rows = [];
        if (i < cur.length) {
          rows.push({ label: 'acumulado del mes', value: clp(curC[i]), tone: 'main' });
          rows.push({ label: `vendido ese día · ${cur[i].count} ${cur[i].count === 1 ? 'pedido' : 'pedidos'}`, value: clp(cur[i].sum) });
        }
        if (i < prevC.length) rows.push({ label: `al ${i + 1} de ${MONTHS[pm.m - 1]}`, value: clp(prevC[i]), tone: 'muted' });
        return { title: `${i + 1} de ${MONTHS[today.m - 1]}${i + 1 > today.d ? ' (aún no llega)' : ''}`, rows };
      },
      table: cur.map((x, i) => ({ label: `${i + 1} de ${MONTHS[today.m - 1]}`, ...x, acc: curC[i] })),
      kpi: kpiOf(cur),
      prevKpi: kpiOf(prevSame),
      compareText: `vs. ${MONTHS[pm.m - 1]} (mismos días)`,
      inPeriod,
    };
  }

  if (range === 'anio') {
    const cur = Array.from({ length: today.m }, (_, i) => monthAt(today.y, i + 1));
    const prev = Array.from({ length: 12 }, (_, i) => monthAt(today.y - 1, i + 1));
    const curC = cumulate(cur.map((x) => x.sum));
    const prevC = cumulate(prev.map((x) => x.sum));
    // Mismo período del año anterior: enero hasta el mismo día
    const prevSame = [...prev.slice(0, today.m - 1)];
    let lastPart = { ...ZERO };
    for (let d = 1; d <= Math.min(today.d, daysIn(today.y - 1, today.m)); d++) {
      const x = dayAt(today.y - 1, today.m, d);
      lastPart = { sum: lastPart.sum + x.sum, count: lastPart.count + x.count, units: lastPart.units + x.units };
    }
    prevSame.push(lastPart);
    const inPeriod = (o) => ymd(o.createdAt).y === today.y;
    return {
      count: 12,
      title: `${today.y}`,
      sub: `De enero a ${MONTHS[today.m - 1]} de ${today.y} · comparado con ${today.y - 1}`,
      series: [{ label: `${today.y - 1}`, values: prevC, tone: 'muted' }, { label: `${today.y}`, values: curC, tone: 'main' }],
      xTick: (i) => MON[i],
      tooltip: (i) => {
        const rows = [];
        if (i < cur.length) {
          rows.push({ label: 'acumulado del año', value: clp(curC[i]), tone: 'main' });
          rows.push({ label: `vendido en el mes · ${num(cur[i].count)} ${cur[i].count === 1 ? 'pedido' : 'pedidos'}`, value: clp(cur[i].sum) });
        }
        rows.push({ label: `acumulado a ${MONTHS[i]} ${today.y - 1}`, value: clp(prevC[i]), tone: 'muted' });
        return { title: `${capFirst(MONTHS[i])} ${today.y}${i + 1 > today.m ? ' (aún no llega)' : ''}`, rows };
      },
      table: cur.map((x, i) => ({ label: `${capFirst(MONTHS[i])} ${today.y}`, ...x, acc: curC[i] })),
      kpi: kpiOf(cur),
      prevKpi: kpiOf(prevSame),
      compareText: `vs. ${today.y - 1} (mismo período)`,
      inPeriod,
    };
  }

  // Histórico: desde el primer mes con ventas
  let first = { y: today.y, m: today.m };
  for (const o of orders) {
    const t = ymd(o.createdAt);
    if (t.y < first.y || (t.y === first.y && t.m < first.m)) first = { y: t.y, m: t.m };
  }
  const months = [];
  for (let y = first.y, m = first.m; y < today.y || (y === today.y && m <= today.m);) {
    months.push({ y, m });
    m++;
    if (m > 12) { m = 1; y++; }
  }
  const cur = months.map(({ y, m }) => monthAt(y, m));
  const curC = cumulate(cur.map((x) => x.sum));
  const long = months.length > 30;
  return {
    count: months.length,
    title: 'Histórico',
    sub: `Desde ${MONTHS[first.m - 1]} de ${first.y} hasta hoy`,
    series: [{ label: 'Histórico', values: curC, tone: 'main' }],
    xTick: (i) => {
      const { y, m } = months[i];
      if (long) return m === 1 || i === 0 ? (i === 0 && m !== 1 ? `${MON[m - 1]} ${String(y).slice(2)}` : `${y}`) : '';
      return i === 0 || m === 1 ? `${MON[m - 1]} ${String(y).slice(2)}` : MON[m - 1];
    },
    tooltip: (i) => {
      const { y, m } = months[i];
      return { title: `${capFirst(MONTHS[m - 1])} ${y}`, rows: [{ label: 'acumulado histórico', value: clp(curC[i]), tone: 'main' }, { label: `vendido en el mes · ${num(cur[i].count)} ${cur[i].count === 1 ? 'pedido' : 'pedidos'}`, value: clp(cur[i].sum) }] };
    },
    table: cur.map((x, i) => ({ label: `${capFirst(MONTHS[months[i].m - 1])} ${months[i].y}`, ...x, acc: curC[i] })),
    kpi: kpiOf(cur),
    prevKpi: null,
    compareText: '',
    inPeriod: () => true,
  };
}

function compactClp(v) {
  if (v >= 1e6) return `$${(v / 1e6).toLocaleString('es-CL', { maximumFractionDigits: v >= 1e7 ? 0 : 1 })} M`;
  if (v >= 1e3) return `$${Math.round(v / 1e3).toLocaleString('es-CL')} mil`;
  return `$${Math.round(v)}`;
}

function delta(cur, prev) {
  if (prev === null || prev === undefined) return '';
  if (!prev) return cur ? `<span class="kdelta is-up">${icon('arrowRight', 'kdelta__ico')}Nuevo</span>` : '';
  const pct = Math.round(((cur - prev) / prev) * 100);
  if (pct === 0) return '<span class="kdelta">Igual</span>';
  return `<span class="kdelta ${pct > 0 ? 'is-up' : 'is-down'}">${icon('arrowRight', 'kdelta__ico')}${pct > 0 ? '+' : '−'}${Math.abs(pct)}%</span>`;
}

// ── Página ───────────────────────────────────────────────────
export function adminDashboardPage(params, query) {
  const guard = adminGuard();
  if (guard) return guard;
  const range = RANGES.some(([id]) => id === query.rango) ? query.rango : 'mes';
  const withDemo = !!state.adminPrefs?.demoSales;
  const orders = salesOrders(withDemo);
  const realCount = adminOrders().length;
  const v = buildView(range, orders);
  const k = v.kpi;
  const pk = v.prevKpi;
  const avg = k.count ? k.sum / k.count : 0;
  const pavg = pk ? (pk.count ? pk.sum / pk.count : 0) : null;
  const hasData = v.series.some((s) => s.values.some((x) => x > 0));

  // Productos más vendidos y entregas del período
  const periodOrders = orders.filter(v.inPeriod);
  const prodMap = new Map();
  let desp = 0;
  let ret = 0;
  for (const o of periodOrders) {
    if (o.delivery?.type === 'retiro') ret++; else desp++;
    for (const it of o.items || []) {
      const cur = prodMap.get(it.id) || { id: it.id, name: it.name, sum: 0, units: 0 };
      cur.sum += it.total || 0;
      cur.units += it.qty || 0;
      prodMap.set(it.id, cur);
    }
  }
  const top = [...prodMap.values()].sort((a, b) => b.sum - a.sum).slice(0, 6);
  const topMax = top[0]?.sum || 1;
  const low = lowStock(6);
  const recent = adminOrders().slice(0, 5);
  const make = (patch) => href('/admin', { rango: range, ...patch });

  const tiles = [
    ['Ventas', clp(k.sum), delta(k.sum, pk?.sum)],
    ['Pedidos', num(k.count), delta(k.count, pk?.count)],
    ['Ticket promedio', clp(avg), delta(avg, pavg)],
    ['Unidades vendidas', num(k.units), delta(k.units, pk?.units)],
  ];

  const body = `${bo.twoFactor === false ? notice('info', `<b>Protege tu cuenta:</b> activa la verificación en dos pasos para que nadie pueda entrar solo con tu contraseña. <a href="#/admin/seguridad" data-link>Ir a Seguridad</a>`, 'shield') : ''}
    <div class="dash-filters">
      <div class="seg seg--range" role="group" aria-label="Período">${RANGES.map(([id, label]) => `<a href="#${make({ rango: id === 'mes' ? '' : id })}" data-link class="${id === range ? 'is-on' : ''}" aria-current="${id === range}">${esc(label)}</a>`).join('')}</div>
      <label class="switch switch--sm"><input type="checkbox" id="demo-sales" ${withDemo ? 'checked' : ''}><span class="switch__track" aria-hidden="true"></span><span><b>Incluir ventas de ejemplo</b></span></label>
    </div>
    ${withDemo ? notice('warn', 'Estás viendo <b>ventas de ejemplo</b> sumadas a las reales, solo para ver cómo funciona el panel. No se guardan ni afectan el stock.') : ''}

    <div class="kpis">${tiles.map(([label, value, d]) => `<div class="kpi"><span class="kpi__label">${esc(label)}</span><b class="kpi__value">${value}</b>${d ? `<span class="kpi__delta">${d}<small>${esc(v.compareText)}</small></span>` : ''}</div>`).join('')}</div>

    <section class="panel chart-card">
      <div class="chart-card__head">
        <div><h2 class="panel__title">Ventas acumuladas · ${esc(v.title)}</h2><p class="muted">${esc(v.sub)}</p></div>
        <div class="chart-card__hero"><b>${clp(k.sum)}</b>${pk ? delta(k.sum, pk.sum) : ''}</div>
      </div>
      ${v.series.length > 1 && hasData ? `<ul class="chart-legend">${[...v.series].reverse().map((s) => `<li class="is-${s.tone}"><i aria-hidden="true"></i>${esc(s.label)}</li>`).join('')}</ul>` : ''}
      ${hasData ? '<div id="sales-chart" class="chart-box"></div>' : `<div class="chart-empty">${icon('chart')}<p><b>Aún no hay ventas en este período.</b><br>Cuando alguien compre en la página, aquí verás cómo sube la línea.</p><div class="btn-row"><button type="button" class="btn btn--soft btn--sm" data-demo-on>Ver con ventas de ejemplo</button><a class="btn btn--ghost btn--sm" href="#/" data-link>Ir a la tienda</a></div></div>`}
      ${hasData ? `<details class="chart-table"><summary>${icon('list')} Ver los datos como tabla</summary>
        <div class="table-wrap"><table class="table"><thead><tr><th>Período</th><th class="num">Pedidos</th><th class="num">Ventas</th><th class="num">Acumulado</th></tr></thead>
        <tbody>${v.table.map((r) => `<tr><td>${esc(r.label)}</td><td class="num">${num(r.count)}</td><td class="num">${clp(r.sum)}</td><td class="num">${clp(r.acc)}</td></tr>`).join('')}</tbody></table></div></details>` : ''}
    </section>

    <div class="dash-grid">
      <section class="panel">
        <div class="panel__head"><h2 class="panel__title">Productos más vendidos</h2><span class="muted">${esc(v.title)}</span></div>
        ${top.length ? `<ol class="hbars">${top.map((t) => {
          const p = byId.get(t.id);
          return `<li><div class="hbars__row"><span class="hbars__name">${p ? `<a href="#/admin/productos/${p.id}" data-link>${esc(t.name)}</a>` : esc(t.name)}</span><b>${clp(t.sum)}</b></div><div class="hbars__track"><span style="width:${Math.max(2, (t.sum / topMax) * 100).toFixed(1)}%"></span></div><small>${num(t.units)} ${t.units === 1 ? 'unidad' : 'unidades'}</small></li>`;
        }).join('')}</ol>` : '<p class="muted">Sin ventas en este período.</p>'}
        ${periodOrders.length ? `<p class="dash-split">${icon('truck')} Despacho <b>${num(desp)}</b> · ${icon('store')} Retiro en farmacia <b>${num(ret)}</b></p>` : ''}
      </section>
      <section class="panel">
        <div class="panel__head"><h2 class="panel__title">Stock para reponer</h2><a class="link-more" href="#/admin/productos?estado=bajo" data-link>Ver todos ${icon('arrowRight')}</a></div>
        ${low.length ? `<ul class="lowlist">${low.map(({ p, t }) => `<li><img src="${productImg(p)}" alt="" width="40" height="40"><span><a href="#/admin/productos/${p.id}" data-link>${esc(p.name)}</a><small>${num(t.online)} en bodegas · ${num(t.stores)} en farmacias</small></span>${levelChip(p, t)}<button type="button" class="btn btn--soft btn--sm" data-qstock="${p.id}">${icon('plus')}<span class="visually-hidden">Agregar stock de ${esc(p.name)}</span></button></li>`).join('')}</ul>` : `<p class="muted">${icon('checkCircle', 'inline-ico')} Todo el catálogo tiene stock suficiente.</p>`}
      </section>
      <section class="panel">
        <div class="panel__head"><h2 class="panel__title">Últimos pedidos</h2><a class="link-more" href="#/admin/pedidos" data-link>Ver todos ${icon('arrowRight')}</a></div>
        ${recent.length ? `<ul class="olist">${recent.map((o) => { const st = statusLabel(o); return `<li><a href="#/admin/pedidos/${o.id}" data-link><b>${esc(o.id)}</b><small>${esc(dateTime(o.createdAt))}</small></a><span class="chip chip--${st.tone}">${esc(st.text)}</span><b>${clp(o.totals?.total)}</b></li>`; }).join('')}</ul>` : `<p class="muted">Aún no hay pedidos${realCount ? '' : ' reales'}. Haz una compra de prueba en la tienda para verla aquí.</p>`}
      </section>
    </div>`;

  let unmount = null;
  return {
    title: 'Resumen de ventas · Administración',
    rerender: ['backoffice'],
    html: adminShell('', 'Resumen de ventas', body, { sub: 'Ventas realizadas en la página, stock y pedidos de un vistazo.' }),
    mount(root) {
      const box = $('#sales-chart', root);
      if (box) {
        unmount = mountLineChart(box, {
          count: v.count,
          series: v.series,
          xTick: v.xTick,
          yTick: compactClp,
          tooltip: v.tooltip,
          height: 300,
          label: `Ventas acumuladas ${v.title}: ${clp(k.sum)}. Usa las flechas para recorrer el gráfico.`,
        });
      }
      root.addEventListener('change', (e) => {
        if (e.target.id !== 'demo-sales') return;
        state.adminPrefs = { ...(state.adminPrefs || {}), demoSales: e.target.checked };
        emit('backoffice');
      });
      root.addEventListener('click', (e) => {
        if (e.target.closest('[data-demo-on]')) {
          state.adminPrefs = { ...(state.adminPrefs || {}), demoSales: true };
          emit('backoffice');
          return;
        }
        const b = e.target.closest('[data-qstock]');
        if (b) { const p = byId.get(b.dataset.qstock); if (p) openQuickStock(p); }
      });
      return () => unmount?.();
    },
  };
}

export { buildView, exampleOrders };

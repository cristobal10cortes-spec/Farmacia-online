// Farmacias: búsqueda por región y comuna, abiertas ahora, de turno y 24 horas.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { breadcrumbs, emptyState, notice } from '../ui/components.js';
import { STORES } from '../data/stores.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { storeStatus, hoursText } from '../engine/inventory.js';
import { fold } from '../engine/text.js';
import { state } from '../engine/state.js';
import { DAYS, MONTHS, santiago } from '../engine/format.js';
import { go, href } from '../router.js';
import { setLocation } from '../engine/shop.js';
import { toast } from '../ui/overlay.js';

export function storesPage(params, query) {
  // Aún no hay farmacias: la tienda vende con despacho a domicilio
  if (!STORES.length) {
    return {
      title: 'Farmacias',
      html: `<div class="wrap page page--tight">
        ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Farmacias' }])}
        ${emptyState({ icon: 'store', title: 'Pronto podrás visitarnos', text: 'Por ahora vendemos online, con despacho a domicilio a todo Chile. Aquí verás nuestras farmacias, sus horarios y turnos cuando abran.', actions: '<a class="btn btn--primary" href="#/ayuda/despacho" data-link>Cómo funciona el despacho</a><a class="btn btn--ghost" href="#/" data-link>Ir a la tienda</a>' })}
      </div>`,
    };
  }
  const region = regionById(query.region) ? query.region : state.location.region;
  const comuna = query.comuna || '';
  const text = query.q || '';
  const onlyOpen = query.abiertas === '1';
  const onlyTurno = query.turno === '1';
  const only24 = query.h24 === '1';
  const now = new Date();
  const s = santiago(now);

  const all = STORES.filter((st) => st.region === region).map((st) => ({ ...st, status: storeStatus(st, now) }));
  let list = all;
  if (comuna) list = list.filter((st) => st.comuna === comuna);
  if (text) {
    const f = fold(text);
    list = list.filter((st) => fold(`${st.name} ${st.address} ${st.comuna}`).includes(f));
  }
  if (onlyOpen) list = list.filter((st) => st.status.open);
  if (onlyTurno) list = list.filter((st) => st.status.turno || st.h24);
  if (only24) list = list.filter((st) => st.h24);
  list.sort((a, b) => (b.comuna === state.location.comuna) - (a.comuna === state.location.comuna) || (b.status.open - a.status.open) || a.name.localeCompare(b.name, 'es'));

  const comunasWithStores = [...new Set(all.map((st) => st.comuna))].sort((a, b) => a.localeCompare(b, 'es'));
  const mapUrl = (st) => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${st.address}, ${st.comuna}, Chile`)}`;

  const html = `<div class="wrap page page--tight">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Farmacias' }])}
    <div class="page-head">
      <h1 class="page-title">${onlyTurno ? 'Farmacias de turno' : 'Farmacias Piedra'}</h1>
      <p class="page-sub">${onlyTurno ? `Turnos de hoy, ${DAYS[s.weekday]} ${s.day} de ${MONTHS[s.month - 1]}. Las farmacias de turno atienden toda la noche.` : 'Encuentra tu farmacia, revisa su horario y si está abierta ahora.'}</p>
    </div>
    <div class="stores">
      <form class="panel stores__filters" id="stores-form" novalidate>
        <div class="field"><label for="s-region">Región</label><select id="s-region" name="region">${REGIONS.map((r) => `<option value="${r.id}"${r.id === region ? ' selected' : ''}>${esc(regionLabel(r))}</option>`).join('')}</select></div>
        <div class="field"><label for="s-comuna">Comuna</label><select id="s-comuna" name="comuna"><option value="">Todas las comunas</option>${comunasWithStores.map((c) => `<option${c === comuna ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
        <div class="field"><label for="s-q">Buscar por nombre o dirección</label><input id="s-q" name="q" value="${esc(text)}" placeholder="Ej: Providencia"></div>
        <label class="check"><input type="checkbox" name="abiertas" ${onlyOpen ? 'checked' : ''}><span>Abiertas ahora</span></label>
        <label class="check"><input type="checkbox" name="turno" ${onlyTurno ? 'checked' : ''}><span>De turno hoy</span></label>
        <label class="check"><input type="checkbox" name="h24" ${only24 ? 'checked' : ''}><span>Abiertas 24 horas</span></label>
        <button type="submit" class="btn btn--primary">${icon('search')} Buscar</button>
      </form>
      <div style="display:grid;gap:14px;min-width:0">
        <p class="toolbar__count"><b>${list.length}</b> ${list.length === 1 ? 'farmacia' : 'farmacias'} en ${esc(comuna || regionLabel(regionById(region)))}</p>
        ${list.length ? `<div class="store-list">${list.map((st) => `<article class="store">
          <div style="display:grid;gap:6px;min-width:0">
            <h2 class="store__name">${esc(st.name)}</h2>
            <p class="store__addr">${icon('pin', 'inline-ico')} ${esc(st.address)}, ${esc(st.comuna)}</p>
            ${st.phone ? `<p class="store__addr">${icon('phone', 'inline-ico')} ${esc(st.phone)}</p>` : ''}
            <p class="store__hours">${esc(hoursText(st))}</p>
            <div class="store__chips">
              <span class="chip chip--${st.status.open ? 'ok' : 'danger'}">${icon('clock')}${esc(st.status.label)}</span>
              ${st.status.turno ? `<span class="chip chip--club">${icon('moon')}De turno hoy</span>` : ''}
              ${st.h24 ? `<span class="chip chip--info">${icon('clock')}24 horas</span>` : ''}
              ${st.services.includes('recetario') ? `<span class="chip">${icon('file')}Recetario magistral</span>` : ''}
            </div>
          </div>
          <div class="store__side">
            <a class="btn btn--ghost btn--sm" href="${mapUrl(st)}" target="_blank" rel="noopener">${icon('route')} Cómo llegar</a>
            <button type="button" class="btn btn--soft btn--sm" data-set-loc="${st.region}|${esc(st.comuna)}">Ver stock de ${esc(st.comuna)}</button>
          </div>
        </article>`).join('')}</div>` : all.length
          ? emptyState({ icon: 'store', title: 'No hay farmacias con esos filtros', text: 'Prueba con otra comuna o quita algún filtro.', actions: `<a class="btn btn--primary" href="#${href('/farmacias', { region })}" data-link>Ver todas en la región</a>` })
          : emptyState({ icon: 'store', title: `Aún no hay farmacias en ${regionLabel(regionById(region))}`, text: `Elige otra región: tenemos farmacias en ${[...new Set(STORES.map((x) => regionLabel(regionById(x.region))))].join(', ')}.` })}
        ${notice('info', 'Antes de ir, revisa el horario: los días de turno la farmacia atiende toda la noche.')}
      </div>
    </div>
  </div>`;

  return {
    title: onlyTurno ? 'Farmacias de turno' : 'Farmacias',
    html,
    mount(root) {
      const f = $('#stores-form', root);
      const apply = (patch = {}) => {
        const v = { region: f.region.value, comuna: f.comuna.value, q: f.q.value.trim(), abiertas: f.abiertas.checked ? '1' : '', turno: f.turno.checked ? '1' : '', h24: f.h24.checked ? '1' : '', ...patch };
        go(href('/farmacias', v), { replace: true, scroll: false });
      };
      f.addEventListener('submit', (e) => { e.preventDefault(); apply(); });
      f.addEventListener('change', (e) => {
        if (e.target.name === 'region') apply({ comuna: '' });
        else if (e.target.name !== 'q') apply();
      });
      root.addEventListener('click', (e) => {
        const b = e.target.closest('[data-set-loc]');
        if (!b) return;
        const [r, c] = b.dataset.setLoc.split('|');
        setLocation(r, c);
        toast(`Te mostramos stock y entregas para <b>${esc(c)}</b>.`);
      });
      return null;
    },
  };
}


// Panel: «Servicios Piedra», los recuadros de servicios de la portada
// (Farmacias y turnos, Cotiza tu receta, Mi Tratamiento…). Se edita la
// sección completa y se guarda de una vez.

import { $, $$, esc, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { adminShell, adminGuard, saveError } from './admin.js';
import { destOf, destSelect, destTo, destErrors, productOptions } from './admin-banners.js';
import { stageHtml, mountStages } from '../admin/imgdrop.js';
import { bo, adminServices, saveServices, SERVICE_ICONS, MAX_SERVICES, SERVICE_LIMITS } from '../admin/api.js';

const TITLE = 'Servicios Piedra · Administración';

function servicesWait() {
  if (bo.ready) return null;
  return {
    title: TITLE,
    rerender: ['backoffice'],
    html: '<div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Cargando los servicios…</p></div></div>',
  };
}

/** La sección tal como se ve en la portada de la tienda. */
function sectionHtml(title, items) {
  const shown = items.filter((x) => x.active !== false);
  if (!shown.length) return `<div class="chart-empty">${icon('sparkle')}<p><b>No hay servicios visibles.</b><br>La portada se muestra sin esta sección hasta que dejes alguno visible.</p></div>`;
  return `<section style="display:grid;gap:14px"><h2 class="sec-title">${esc(title || 'Servicios Piedra')}</h2>
    <div class="services" style="--cols:${Math.min(6, shown.length)}">${shown.map((s) => `<a class="service" href="#${esc(s.to || '/')}" data-svc="${esc(s.id)}">${icon(s.icon)}<b>${esc(s.title || 'Título del servicio')}</b>${s.text ? `<span>${esc(s.text)}</span>` : ''}</a>`).join('')}</div>
  </section>`;
}

const counter = (name, val) => `<span class="field__count" data-count="${name}">${String(val || '').length}/${SERVICE_LIMITS[name]}</span>`;

function rowHtml(s, i, n) {
  const d = destOf(s.to);
  const k = s.key;
  return `<li class="srow${s.active === false ? ' is-off' : ''}" data-key="${k}">
    <div class="srow__head">
      <span class="bcard__pos">${i + 1}</span>
      <span class="srow__ico" aria-hidden="true">${icon(s.icon)}</span>
      <b class="srow__name">${esc(s.title || 'Servicio nuevo')}</b>
      <div class="srow__act">
        <button type="button" class="icon-btn" data-smove="-1" aria-label="Subir ${esc(s.title)}"${i === 0 ? ' disabled' : ''}>${icon('arrowUp')}</button>
        <button type="button" class="icon-btn" data-smove="1" aria-label="Bajar ${esc(s.title)}"${i === n - 1 ? ' disabled' : ''}>${icon('arrowDown')}</button>
        <label class="switch switch--sm"><input type="checkbox" name="active"${s.active === false ? '' : ' checked'}><span class="switch__track" aria-hidden="true"></span><span><b>Visible</b></span></label>
        <button type="button" class="btn btn--ghost btn--sm srow__del" data-sdel aria-label="Quitar ${esc(s.title)}">${icon('trash')}</button>
      </div>
    </div>
    <div class="srow__body form-grid">
      <div class="field"><label for="s${k}-title">Título</label><input id="s${k}-title" name="title" maxlength="${SERVICE_LIMITS.title}" value="${esc(s.title)}" placeholder="Ej: Farmacia de turno">${counter('title', s.title)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="s${k}-icon">Ícono</label><select id="s${k}-icon" name="icon">${Object.entries(SERVICE_ICONS).map(([v, l]) => `<option value="${v}"${v === s.icon ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
      <div class="field field--full"><label for="s${k}-text">Texto <span class="field__opt">(opcional)</span></label><input id="s${k}-text" name="text" maxlength="${SERVICE_LIMITS.text}" value="${esc(s.text)}" placeholder="Una frase corta, por ejemplo: Horarios y farmacias abiertas ahora.">${counter('text', s.text)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="s${k}-dest">Al hacer clic lleva a</label>${destSelect(d, `s${k}`)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="search"${d.dest === 'search' ? '' : ' hidden'}><label for="s${k}-q">Palabra a buscar</label><input id="s${k}-q" name="q" value="${esc(d.q || '')}" placeholder="Ej: vacuna"><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="product"${d.dest === 'product' ? '' : ' hidden'}><label for="s${k}-dprod">Producto</label><select id="s${k}-dprod" name="dprod"><option value="">Elegir producto…</option>${d.dest === 'product' ? productOptions(d.dprod) : ''}</select><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="custom"${d.dest === 'custom' ? '' : ' hidden'}><label for="s${k}-path">Dirección (empieza con /)</label><input id="s${k}-path" name="path" value="${esc(d.path || '')}" placeholder="Ej: /ayuda/contacto"><p class="field__error" aria-live="polite"></p></div>
    </div>
  </li>`;
}

export function adminServicesPage() {
  const guard = adminGuard() || servicesWait();
  if (guard) return guard;
  const saved = adminServices();
  let seq = 0;
  const withKeys = (list) => list.map((x) => ({ ...x, key: ++seq }));
  const state = { title: saved.title, items: withKeys(saved.items), builtin: saved.builtin, dirty: false };

  const body = `<section class="panel snow">
      <div class="panel__head"><h2 class="panel__title">Así se ve hoy en la portada</h2><a class="link-more" href="#/" data-link>Ir a la portada ${icon('arrowRight')}</a></div>
      <p class="bnow__sizes">${icon('info')}<span>Toca un recuadro para ir a editarlo. Los cambios se ven aquí al tiro, pero llegan a la tienda cuando tocas <b>Guardar servicios</b>.</span></p>
      ${stageHtml(sectionHtml(state.title, state.items), { width: 1232, id: 'spreview' })}
    </section>
    <div id="s-builtin">${state.builtin ? notice('info', 'Estos son los <b>servicios de ejemplo</b>. Cuando guardes, pasan a ser tuyos.') : ''}</div>
    <form id="sform" class="bform" novalidate>
      <fieldset class="panel form-grid"><legend class="panel__title">Título de la sección</legend>
        <div class="field field--full"><label for="s-title">Título</label><input id="s-title" name="stitle" maxlength="${SERVICE_LIMITS.section}" value="${esc(state.title)}" required>${counter('section', state.title)}<p class="field__error" aria-live="polite"></p></div>
      </fieldset>
      <section class="panel">
        <div class="panel__head"><h2 class="panel__title">Servicios</h2><span class="muted">Se muestran en este orden · hasta ${MAX_SERVICES}</span></div>
        <ol class="slist" id="slist"></ol>
        <div class="blist__more"><button type="button" class="btn btn--soft" id="s-add">${icon('plus')} Agregar servicio</button><span class="muted" id="s-max" hidden>Llegaste al máximo de ${MAX_SERVICES}.</span></div>
      </section>
      <div class="pform__actions sform__actions"><button class="btn btn--primary btn--lg" type="submit">Guardar servicios</button><button type="button" class="btn btn--ghost btn--lg" id="s-undo" disabled>Deshacer cambios</button><span class="sform__dirty" id="s-dirty" hidden>${icon('alert')} Tienes cambios sin guardar</span></div>
    </form>`;

  return {
    title: TITLE,
    html: adminShell('servicios', 'Servicios Piedra', body, {
      sub: 'Los recuadros de servicios de la portada: Farmacias y turnos, Cotiza tu receta, Mi Tratamiento… Cambia el título, el texto, el ícono y a dónde lleva cada uno; ordénalos, ocúltalos o agrega nuevos.',
    }),
    onState: () => true, // no repintar mientras se edita
    mount(root) {
      const f = $('#sform', root);
      const listEl = $('#slist', root);
      const prev = $('#spreview .pstage__in', root);
      const unstage = mountStages(root);

      const preview = () => { prev.innerHTML = sectionHtml(state.title, state.items); };
      const markDirty = (on = true) => {
        state.dirty = on;
        $('#s-dirty', root).hidden = !on;
        $('#s-undo', root).disabled = !on;
      };
      const draw = () => {
        listEl.innerHTML = state.items.map((s, i) => rowHtml(s, i, state.items.length)).join('');
        const full = state.items.length >= MAX_SERVICES;
        $('#s-add', root).disabled = full;
        $('#s-max', root).hidden = !full;
        preview();
      };
      const itemOf = (el) => {
        const row = el.closest('.srow');
        return row ? { row, item: state.items.find((x) => String(x.key) === row.dataset.key) } : {};
      };
      // Lee una fila y actualiza su servicio (y la vista previa)
      const readRow = (row, item) => {
        const v = Object.fromEntries(['title', 'text', 'icon', 'dest', 'q', 'dprod', 'path'].map((n) => [n, row.querySelector(`[name=${n}]`)?.value || '']));
        item.title = v.title.trim();
        item.text = v.text.trim();
        item.icon = v.icon;
        item.active = row.querySelector('[name=active]').checked;
        item.dest = v;
        const ok = !Object.keys(destErrors(v)).length && (v.dest !== 'product' || v.dprod);
        if (ok) item.to = destTo(v);
        row.classList.toggle('is-off', !item.active);
        $('.srow__name', row).textContent = item.title || 'Servicio nuevo';
        $('.srow__ico', row).innerHTML = icon(item.icon);
        $$('[data-dest]', row).forEach((el) => { el.hidden = el.dataset.dest !== v.dest; });
        $$('[data-count]', row).forEach((el) => { el.textContent = `${(v[el.dataset.count] || '').length}/${SERVICE_LIMITS[el.dataset.count]}`; });
        // La lista de productos se llena solo si se elige «Un producto…» (así la página es liviana)
        const prod = row.querySelector('[name=dprod]');
        if (v.dest === 'product' && prod.options.length <= 1) prod.insertAdjacentHTML('beforeend', productOptions(''));
      };
      const onEdit = debounce(() => preview(), 120);

      f.addEventListener('input', (e) => {
        if (e.target.name === 'stitle') {
          state.title = e.target.value.trim();
          $('[data-count="section"]', f).textContent = `${e.target.value.length}/${SERVICE_LIMITS.section}`;
        } else {
          const { row, item } = itemOf(e.target);
          if (item) readRow(row, item);
        }
        markDirty();
        onEdit();
      });
      f.addEventListener('change', (e) => {
        const { row, item } = itemOf(e.target);
        if (item) readRow(row, item);
        markDirty();
        preview();
      });
      f.addEventListener('click', async (e) => {
        const mv = e.target.closest('[data-smove]');
        const del = e.target.closest('[data-sdel]');
        if (!mv && !del) return;
        const { item } = itemOf(e.target);
        const i = state.items.indexOf(item);
        if (i < 0) return;
        if (mv) {
          const j = i + Number(mv.dataset.smove);
          if (j < 0 || j >= state.items.length) return;
          [state.items[i], state.items[j]] = [state.items[j], state.items[i]];
        } else {
          if (!(await confirmDialog({ title: '¿Quitar este servicio?', text: `Se quitará <b>${esc(item.title || 'este servicio')}</b> de la portada cuando guardes. Si solo quieres esconderlo por un tiempo, apaga «Visible».`, confirmText: 'Quitar servicio', danger: true }))) return;
          state.items.splice(i, 1);
        }
        markDirty();
        draw();
        if (mv) listEl.querySelector(`[data-key="${item.key}"] [data-smove="${mv.dataset.smove}"]`)?.focus();
      });
      $('#s-add', root).addEventListener('click', () => {
        if (state.items.length >= MAX_SERVICES) return;
        const item = { key: ++seq, id: '', icon: 'star', title: '', text: '', to: '/ofertas', active: true };
        state.items.push(item);
        markDirty();
        draw();
        const t = listEl.querySelector(`[data-key="${item.key}"] [name=title]`);
        t?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        t?.focus({ preventScroll: true });
      });
      $('#s-undo', root).addEventListener('click', () => {
        const s = adminServices();
        state.title = s.title;
        state.items = withKeys(s.items);
        $('#s-title', root).value = s.title;
        $('[data-count="section"]', f).textContent = `${s.title.length}/${SERVICE_LIMITS.section}`;
        markDirty(false);
        draw();
      });
      // En la vista previa, tocar un servicio lleva a su fila (no abre la tienda)
      root.addEventListener('click', (e) => {
        const a = e.target.closest('#spreview a');
        if (!a) return;
        e.preventDefault();
        e.stopPropagation();
        const i = $$('#spreview .service', root).indexOf(a);
        const shown = state.items.filter((x) => x.active !== false);
        const row = shown[i] && listEl.querySelector(`[data-key="${shown[i].key}"]`);
        if (row) {
          row.scrollIntoView({ behavior: 'smooth', block: 'center' });
          row.querySelector('[name=title]')?.focus({ preventScroll: true });
          row.classList.add('is-flash');
          setTimeout(() => row.classList.remove('is-flash'), 1200);
        }
      }, true);

      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        // Revisión fila por fila (con el mensaje junto al campo)
        $$('.field', f).forEach((el) => { el.classList.remove('is-invalid'); const m = $('.field__error', el); if (m) m.textContent = ''; });
        let first = null;
        const fail = (input, msg) => {
          const fld = input?.closest('.field');
          if (!fld) return;
          fld.classList.add('is-invalid');
          $('.field__error', fld).textContent = msg;
          first = first || input;
        };
        if (!state.title) fail($('#s-title', f), 'Escribe el título de la sección.');
        for (const item of state.items) {
          const row = listEl.querySelector(`[data-key="${item.key}"]`);
          const v = item.dest || { q: '', dprod: '', path: '', ...destOf(item.to) };
          if (!item.title) fail(row.querySelector('[name=title]'), 'Escribe el título del servicio.');
          const de = destErrors({ q: '', dprod: '', path: '', ...v });
          for (const [n, msg] of Object.entries(de)) fail(row.querySelector(`[name=${n}]`), msg);
        }
        if (first) { first.focus(); return; }
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        try {
          await saveServices({ title: state.title, items: state.items.map(({ id, icon: ic, title, text, to, active }) => ({ id, icon: ic, title, text, to, active })) });
          toast('Guardamos los servicios. Ya se ven así en la portada.');
          // Lo guardado pasa a ser el punto de partida (con los identificadores del servidor)
          const s = adminServices();
          state.title = s.title;
          state.items = withKeys(s.items);
          state.builtin = false;
          $('#s-builtin', root).innerHTML = '';
          markDirty(false);
          draw();
        } catch (err) {
          saveError(err);
        } finally {
          btn.disabled = false;
        }
      });

      draw();
      return () => unstage();
    },
  };
}

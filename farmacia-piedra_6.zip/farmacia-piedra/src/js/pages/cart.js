// Carro de compras.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { rxChip, stepper, notice, rail, emptyState, promoBadge } from '../ui/components.js';
import { totals, priceCtx, setCoupon, removeFromCart, cartItems } from '../engine/shop.js';
import { evaluateCoupon, freeShippingFrom, PROMO_LABEL } from '../engine/pricing.js';
import { zoneOf } from '../engine/inventory.js';
import { bestSellers, relatedTo } from '../engine/catalog.js';
import { state, currentUser } from '../engine/state.js';
import { clp } from '../engine/format.js';
import { confirmDialog, toast } from '../ui/overlay.js';

export function stepsHtml(active) {
  const steps = ['Carro', 'Entrega y pago', 'Confirmación'];
  return `<ol class="steps" aria-label="Pasos de la compra">${steps.map((s, i) => {
    const n = i + 1;
    const cls = n < active ? 'is-done' : n === active ? 'is-on' : '';
    return `<li class="${cls}"${n === active ? ' aria-current="step"' : ''}><span class="steps__n">${n < active ? icon('check') : n}</span><span class="steps__label">${s}</span></li>`;
  }).join('')}</ol>`;
}

export function summaryRows(t, { shipping = null, shippingLabel = 'Se calcula en el siguiente paso' } = {}) {
  const row = (label, value, cls = '') => `<div class="summary__row ${cls}"><span>${label}</span><span>${value}</span></div>`;
  const total = t.total + (shipping || 0);
  return `<div class="summary__rows">
    ${row(`Productos (${t.count})`, clp(t.listTotal))}
    ${t.offerOff ? row('Descuentos de internet', `-${clp(t.offerOff)}`, 'save') : ''}
    ${t.promoOff ? row('Promociones', `-${clp(t.promoOff)}`, 'save') : ''}
    ${t.clubOff ? row('Club Piedra', `-${clp(t.clubOff)}`, 'club') : ''}
    ${t.couponOff ? row(`Cupón ${esc(t.coupon.code)}`, `-${clp(t.couponOff)}`, 'save') : ''}
    ${row('Despacho', shipping === null ? `<span class="muted">${shippingLabel}</span>` : shipping === 0 ? '<b style="color:var(--ok)">Gratis</b>' : clp(shipping))}
  </div>
  <div class="summary__total"><span>Total${shipping === null ? ' (sin despacho)' : ''}</span><b>${clp(total)}</b></div>`;
}

export function cartPage() {
  const items = cartItems();
  if (!items.length) {
    return {
      title: 'Tu carro',
      rerender: ['cart', 'user', 'location', 'catalog'],
      html: `<div class="wrap page">
        ${stepsHtml(1)}
        ${emptyState({ icon: 'bag', title: 'Tu carro está vacío', text: 'Agrega productos desde el buscador, las categorías o las ofertas de la semana.', actions: '<a class="btn btn--primary" href="#/ofertas" data-link>Ver ofertas</a><a class="btn btn--ghost" href="#/" data-link>Ir al inicio</a>' })}
        ${rail('Lo más vendido', bestSellers(12))}
      </div>`,
    };
  }
  const t = totals();
  const ctx = priceCtx();
  const user = currentUser();
  const zone = zoneOf(state.location);
  const free = freeShippingFrom(zone);
  const left = Math.max(0, free - t.total);
  const pct = Math.min(100, Math.round((t.total / free) * 100));
  const savings = t.offerOff + t.promoOff + t.clubOff + t.couponOff;
  const notes = [];
  if (t.hasRx) notes.push(notice('warn', `Tu carro tiene <b>medicamentos con receta</b>. Deberás adjuntar una foto o PDF de la receta al pagar.${t.hasRetenida ? ' Para los de <b>receta retenida</b>, entrega la receta original al recibir o retirar.' : ''}`, 'file'));
  if (t.hasCold) notes.push(notice('info', 'Tienes productos que requieren <b>cadena de frío</b>: se despachan refrigerados solo en la Región Metropolitana. En otras regiones, retíralos en farmacia.', 'snow'));
  if (t.hasCheque) notes.push(notice('danger', 'Tu carro tiene productos con receta cheque, que solo se venden en farmacia. Quítalos para continuar.'));
  const relatedSeed = items[0].product;

  const lines = t.lines.map((l) => {
    const p = l.product;
    const saveTxt = l.promoOff ? `Promoción ${PROMO_LABEL[p.promo]}: -${clp(l.promoOff)}` : l.clubOff ? `Club Piedra: -${clp(l.clubOff)}` : '';
    return `<div class="cline" data-line="${p.id}">
      <a href="#/producto/${p.slug}" data-link tabindex="-1" aria-hidden="true"><img class="cline__img" src="${productImg(p)}" alt="" width="92" height="92"></a>
      <div class="cline__info">
        <span class="cline__brand">${esc(p.brand)}</span>
        <a class="cline__name" href="#/producto/${p.slug}" data-link>${esc(p.name)}</a>
        <div class="cline__tags">${p.isMedicine || p.rx !== 'directa' ? rxChip(p) : ''}${promoBadge(p)}${p.cold ? `<span class="badge badge--cold">${icon('snow')}Frío</span>` : ''}</div>
        <span class="cline__unit">${clp(l.info.sale)} c/u${l.info.offPct ? ` · antes ${clp(l.info.list)}` : ''}</span>
      </div>
      <div class="cline__side">
        <div class="cline__total">${clp(l.total)}${l.listTotal > l.total ? `<s>${clp(l.listTotal)}</s>` : ''}</div>
        ${saveTxt ? `<span class="cline__save">${esc(saveTxt)}</span>` : ''}
        ${stepper(p, l.qty)}
        <button type="button" class="btn btn--link btn--sm" data-remove="${p.id}">Quitar</button>
      </div>
    </div>`;
  }).join('');

  const couponBlock = t.coupon
    ? `<div class="coupon-tag"><span>${icon('tag')} ${esc(t.coupon.code)} aplicado${t.couponOff ? ` (-${clp(t.couponOff)})` : ''}</span><button type="button" class="btn btn--link btn--sm" data-coupon-off>Quitar</button></div>`
    : `<form class="field" id="coupon-form" novalidate><label for="f-coupon">¿Tienes un cupón?</label><div class="coupon"><input class="input" id="f-coupon" name="coupon" placeholder="Ej: BIENVENIDA10" autocomplete="off" value="${esc(state.coupon || '')}"><button class="btn btn--ghost" type="submit">Aplicar</button></div><p class="field__error" aria-live="polite">${state.coupon && t.couponError ? esc(t.couponError) : ''}</p></form>`;

  const html = `<div class="wrap page page--tight">
    ${stepsHtml(1)}
    <div class="page-head"><h1 class="page-title">Tu carro</h1></div>
    <div class="two-col">
      <div class="cart-lines">
        ${notes.join('')}
        ${lines}
        <button type="button" class="btn btn--link" data-clear-cart style="justify-self:start">Vaciar carro</button>
      </div>
      <aside class="sticky-col" aria-label="Resumen de compra">
        <div class="panel summary">
          <h2 class="panel__title">Resumen</h2>
          ${summaryRows(t)}
          ${savings ? `<p class="notice notice--ok">${icon('checkCircle')}<span>Estás ahorrando <b>${clp(savings)}</b> en esta compra.</span></p>` : ''}
          ${couponBlock}
          <div class="ship-bar">${left ? `<span>Te faltan <b>${clp(left)}</b> para despacho gratis en ${esc(state.location.comuna)}.</span>` : `<span><b>Despacho gratis</b> a ${esc(state.location.comuna)}.</span>`}<div class="ship-bar__track"><div class="ship-bar__fill" style="width:${pct}%"></div></div></div>
          ${t.hasCheque ? '<span class="btn btn--block btn--lg btn--disabled">Continuar compra</span>' : `<a class="btn btn--primary btn--lg btn--block" href="#/checkout" data-link>Continuar compra ${icon('arrowRight')}</a>`}
          <a class="btn btn--ghost btn--block" href="#/" data-link>Seguir comprando</a>
        </div>
        ${!ctx.member && t.clubPotential ? notice('club', `Con el <b>Club Piedra</b> ahorrarías <b>${clp(t.clubPotential)}</b> más en esta compra. <a href="#/${user ? 'cuenta' : 'registro'}" data-link>Únete gratis</a>`, 'star') : ''}
        <p class="field__hint">${icon('lock')} Pago seguro. Los medicamentos con receta se validan por un químico farmacéutico antes del despacho.</p>
      </aside>
    </div>
    ${rail('Te puede interesar', relatedTo(relatedSeed, 12).filter((p) => !items.some((i) => i.product.id === p.id)))}
  </div>`;

  return {
    title: 'Tu carro',
    rerender: ['cart', 'user', 'location', 'catalog'],
    html,
    mount(root) {
      root.addEventListener('click', async (e) => {
        const rm = e.target.closest('[data-remove]');
        if (rm) {
          const it = items.find((x) => x.product.id === rm.dataset.remove);
          if (await confirmDialog({ title: '¿Quitar este producto?', text: `Se quitará <b>${esc(it?.product.name || '')}</b> de tu carro.`, confirmText: 'Quitar', danger: true })) {
            removeFromCart(rm.dataset.remove);
            toast('Quitaste el producto del carro.', { tone: 'info' });
          }
          return;
        }
        if (e.target.closest('[data-clear-cart]')) {
          if (await confirmDialog({ title: '¿Vaciar el carro?', text: 'Se quitarán todos los productos.', confirmText: 'Vaciar carro', danger: true })) {
            for (const it of cartItems()) removeFromCart(it.product.id);
          }
          return;
        }
        if (e.target.closest('[data-coupon-off]')) { setCoupon(null); toast('Quitaste el cupón.', { tone: 'info' }); }
      });
      root.addEventListener('submit', (e) => {
        if (e.target.id !== 'coupon-form') return;
        e.preventDefault();
        const code = e.target.coupon.value.trim();
        const err = $('.field__error', e.target);
        if (!code) { err.textContent = 'Escribe el código del cupón.'; return; }
        const v = evaluateCoupon(code, totals(), priceCtx());
        if (!v.ok) { err.textContent = v.error; return; }
        setCoupon(code);
        toast(`Cupón <b>${esc(v.coupon.code)}</b> aplicado. ${esc(v.coupon.text)}`);
      });
      return null;
    },
  };
}

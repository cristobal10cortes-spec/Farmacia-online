// Panel de administración: productos y stock, productos nuevos, pedidos y movimientos.
// (El resumen de ventas está en admin-dashboard.js y los banners en admin-banners.js.)
// Es una aplicación aparte de la tienda: todo se guarda en el servidor.

import { $, $$, esc, formData, setErrors, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg, previewImg } from '../ui/art.js';
import { field, checkbox, notice, emptyState, pagination, rxChip, beSeal } from '../ui/components.js';
import { openModal, toast, confirmDialog, clearToasts } from '../ui/overlay.js';
import { go, href } from '../router.js';
import { RX, ZONES } from '../config.js';
import { STORES } from '../data/stores.js';
import { REGIONS, regionLabel } from '../data/regions.js';
import { ALL_SUBS, categoryById, subById } from '../data/categories.js';
import { normalizeProduct, artFor } from '../data/products.js';
import { byId, allProducts, productIndex, discountPct, salePrice } from '../engine/catalog.js';
import { getOverride } from '../engine/stockdata.js';
import { orderTimeline, statusLabel } from '../engine/orders.js';
import { PRODUCT_FORMATS, PRODUCT_UNITS, PRODUCT_ARTS } from '../engine/productdef.js';
import {
  bo, ZONE_IDS, locLabel, stockAt, stockSnapshot, stockTotals, stockLevel,
  changeStock, addStock, setPrice, setHidden, createProduct, updateProductDef, deleteProduct,
  adminOrders, findAdminOrder, recetaUrl,
  login, loginCode, setupFirstAdmin, changePassword, adminUser, friendlyError,
  setProductPhoto, removeProductPhoto, searchMovements,
} from '../admin/api.js';
import { todayIso } from '../engine/bannerlist.js';
import { loginView, passField, toggleEye, pwIssues } from '../admin/login.js';
import { preparePhoto, PHOTO_IDEAL, PHOTO_MIN, PHOTO_MAX_MB, px } from '../admin/photo.js';
import { fold } from '../engine/text.js';
import { clp, num, dateTime, shortDate } from '../engine/format.js';
import { contactPanelHtml, mountContact } from './admin-contact.js';
import { orderFlowHtml, mountOrderFlow } from './admin-orderflow.js';
import { deliveryWhen, isManaged, statusOf, dateText } from '../engine/orderflow.js';

export const ADMIN_TABS = [
  ['', 'Resumen', 'chart'],
  ['productos', 'Productos y stock', 'box'],
  ['pedidos', 'Pedidos', 'bag'],
  ['farmacias', 'Farmacias', 'store'],
  ['banners', 'Banners', 'image'],
  ['menu', 'Menú', 'menu'],
  ['servicios', 'Servicios Piedra', 'sparkle'],
  ['movimientos', 'Movimientos', 'list'],
  ['seguridad', 'Seguridad', 'shield'],
];

const RERENDER = ['backoffice'];

// ── Estructura común ─────────────────────────────────────────
export function modeBadge() {
  if (bo.offline) return `<span class="admin-mode admin-mode--local" title="No hay conexión con el servidor. Los datos pueden estar desactualizados.">${icon('alert')}Sin conexión · reintentando</span>`;
  return `<span class="admin-mode admin-mode--shared" title="Los cambios se guardan en el servidor y se ven en la tienda.">${icon('checkCircle')}Conectado al servidor</span>`;
}

export function adminShell(active, title, body, { sub = '', actions = '' } = {}) {
  return `<div class="wrap page page--tight admin">
    <div class="admin__head">
      <div class="admin__title"><p class="eyebrow">Panel de administración</p><h1 class="page-title">${esc(title)}</h1>${sub ? `<p class="page-sub">${sub}</p>` : ''}</div>
      <div class="admin__head-side">${modeBadge()}${actions}</div>
    </div>
    <nav class="admin__tabs" aria-label="Secciones del panel">${ADMIN_TABS.map(([id, label, ic]) => `<a href="#/admin${id ? `/${id}` : ''}" data-link class="${id === active ? 'is-on' : ''}"${id === active ? ' aria-current="page"' : ''}>${icon(ic)}${esc(label)}</a>`).join('')}
      <a href="#/admin/productos/nuevo" data-link class="admin__new${active === 'nuevo' ? ' is-on' : ''}"${active === 'nuevo' ? ' aria-current="page"' : ''}>${icon('plus')}Nuevo producto</a></nav>
    ${body}
  </div>`;
}

const waitPage = (text) => ({
  title: 'Panel de administración',
  rerender: ['backoffice'],
  html: `<div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>${esc(text)}</p></div></div>`,
});

/** Si aún no se puede ver el panel, devuelve la página a mostrar (carga o ingreso). */
export function adminGuard() {
  if (!bo.checked) return waitPage('Conectando con el servidor…');
  if (!bo.user) return adminLoginPage();
  if (!bo.ready) return waitPage('Cargando los datos de la farmacia…');
  return null;
}

// ── Ingresar administrador (cuadro azul claro) ───────────────
// La pantalla está en admin/login.js (es lo único del panel que se entrega sin
// sesión). Aquí se usa cuando la sesión termina con el panel abierto.
export function adminLoginPage() {
  const view = loginView({
    needsSetup: bo.needsSetup,
    actions: { login, code: loginCode, setup: setupFirstAdmin },
    onDone(kind, r) {
      clearToasts();
      const w = kind === 'setup' ? { html: `Listo, creaste el administrador <b>${esc(adminUser())}</b>. Ya estás dentro del panel.`, tone: 'ok' } : welcomeText(r);
      toast(w.html, { tone: w.tone, timeout: w.tone === 'warn' ? 12000 : 3800 });
      if (kind === 'setup') go('/admin', { replace: true });
    },
  });
  return {
    title: view.title,
    html: view.html,
    rerender: ['backoffice'],
    // Solo se repinta si cambia lo necesario (para no borrar lo que se escribe)
    onState(evt) {
      if (evt !== 'backoffice') return true;
      return !(bo.user || bo.needsSetup !== (view.setup || view.noAdmin));
    },
    mount: view.mount,
  };
}

/** Saludo al entrar: avisa si se usó un código de respaldo o si hubo intentos fallidos. */
export function welcomeText(r = {}) {
  let html = `Hola, <b>${esc(adminUser())}</b>. Entraste al panel de administración.`;
  let tone = 'ok';
  if (r.recoveryLeft != null) html += ` Usaste un código de respaldo: te ${r.recoveryLeft === 1 ? 'queda 1' : `quedan ${r.recoveryLeft}`}. Puedes crear nuevos en Seguridad.`;
  const a = r.alerts || {};
  if (a.failedCodes) {
    tone = 'warn';
    html += ` <b>Atención:</b> desde tu último ingreso alguien escribió bien tu contraseña pero falló el código del celular ${a.failedCodes === 1 ? '1 vez' : `${a.failedCodes} veces`}. Cambia tu contraseña en Seguridad.`;
  } else if (a.failedPasswords >= 3) {
    tone = 'warn';
    html += ` Hubo ${a.failedPasswords} intentos de ingreso con contraseña incorrecta desde tu último ingreso (revisa el registro en Seguridad).`;
  }
  return { html, tone };
}

export function openChangePassword() {
  openModal({
    title: `${icon('lock')} Cambiar contraseña`,
    size: 'sm',
    html: `<form id="cp-form" class="form-grid form-grid--1" novalidate>
      ${passField('cur', 'Contraseña actual', 'current-password')}
      ${passField('np', 'Nueva contraseña', 'new-password', 'Al menos 10 caracteres, con letras y números.')}
      ${passField('np2', 'Repite la nueva contraseña', 'new-password')}
      <p class="field__hint">Al cambiarla se cierran las sesiones abiertas en otros equipos.</p>
      <div class="full"><button class="btn btn--primary btn--block" type="submit">Guardar nueva contraseña</button></div>
    </form>`,
    onMount(api) {
      const f = $('#cp-form', api.el);
      api.el.addEventListener('click', (e) => {
        const eye = e.target.closest('[data-eye]');
        if (eye) toggleEye(eye);
      });
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = formData(f);
        const errors = {};
        if (!v.cur) errors.cur = 'Escribe tu contraseña actual.';
        const issues = pwIssues(v.np, adminUser());
        if (issues.length) errors.np = `La contraseña necesita ${issues.join(', ')}.`;
        if (v.np !== v.np2) errors.np2 = 'Las contraseñas no coinciden.';
        if (!setErrors(f, errors)) return;
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        const r = await changePassword(v.cur, v.np);
        btn.disabled = false;
        if (!r.ok) { setErrors(f, { cur: r.error }); return; }
        toast('Cambiaste la contraseña del administrador.');
        api.close();
      });
    },
  });
}

const KIND = {
  ingreso: ['Ingreso', 'ok'],
  ajuste: ['Ajuste', 'info'],
  venta: ['Venta', ''],
  anulacion: ['Anulación', 'club'],
  precio: ['Precio', 'info'],
  visibilidad: ['Visibilidad', ''],
  producto: ['Producto', 'info'],
  banner: ['Banner', 'club'],
  farmacia: ['Farmacia', 'info'],
  menu: ['Menú', 'club'],
  servicios: ['Servicios', 'club'],
};
export const kindChip = (k) => {
  const [label, tone] = KIND[k] || [k, ''];
  return `<span class="chip${tone ? ` chip--${tone}` : ''}">${esc(label)}</span>`;
};

const LEVEL = { ok: ['Con stock', 'ok'], bajo: ['Stock bajo', 'warn'], sin: ['Agotado', 'danger'] };
/** "$2.160 (43%)": ganancia por unidad y porcentaje sobre el precio de venta. */
export function marginText(price, cost) {
  const g = price - cost;
  return `${g < 0 ? '−' : ''}${clp(Math.abs(g))} (${price > 0 ? Math.round((g / price) * 100) : 0}%)`;
}
export function levelChip(p, t = stockTotals(p)) {
  if (p.hidden) return `<span class="chip">${icon('eyeOff')}Oculto</span>`;
  const [label, tone] = LEVEL[stockLevel(p, t)];
  return `<span class="chip chip--${tone}">${label}</span>`;
}

const REASONS = ['Recepción de proveedor', 'Devolución de cliente', 'Traslado entre farmacias', 'Ajuste por inventario', 'Producto vencido o dañado'];

function locOptions(selected = STORES.length ? 'all-s' : 'all-o') {
  const opt = (v, label) => `<option value="${v}"${v === selected ? ' selected' : ''}>${esc(label)}</option>`;
  const regions = REGIONS.map((r) => ({ r, stores: STORES.filter((s) => s.region === r.id) })).filter((x) => x.stores.length);
  return `${STORES.length ? opt('all-s', `Todas las farmacias (${STORES.length})`) : ''}${opt('all-o', `Todas las bodegas online (${ZONE_IDS.length} zonas)`)}
    <optgroup label="Bodegas online (despacho)">${ZONE_IDS.map((z) => opt(`o:${z}`, `Bodega · ${ZONES[z].name}`)).join('')}</optgroup>
    ${regions.map(({ r, stores }) => `<optgroup label="Farmacias · ${esc(regionLabel(r))}">${stores.map((s) => opt(`s:${s.id}`, `${s.name} (${s.comuna})`)).join('')}</optgroup>`).join('')}`;
}
const expandLoc = (v) => (v === 'all-s' ? STORES.map((s) => `s:${s.id}`) : v === 'all-o' ? ZONE_IDS.map((z) => `o:${z}`) : [v]);
const locName = (v) => (v === 'all-s' ? 'todas las farmacias' : v === 'all-o' ? 'todas las bodegas online' : locLabel(v));

export function saveError(err) {
  toast(esc(friendlyError(err)), { tone: 'warn', timeout: 6000 });
}

// Formulario "agregar stock" (modal y ficha)
function quickStockForm(p, idp = 'qs') {
  return `<form class="qstock" id="${idp}-form" data-pid="${p.id}" novalidate>
    <div class="field"><label for="${idp}-loc">¿Dónde?</label><select id="${idp}-loc" name="loc">${locOptions()}</select></div>
    <div class="field"><label for="${idp}-qty">Unidades a sumar</label><input id="${idp}-qty" name="qty" type="number" inputmode="numeric" min="1" max="99999" step="1" value="10" required><p class="field__error" aria-live="polite"></p></div>
    <div class="field"><label for="${idp}-why">Motivo</label><select id="${idp}-why" name="why">${REASONS.map((r) => `<option>${esc(r)}</option>`).join('')}</select></div>
    <p class="qstock__preview" id="${idp}-preview" aria-live="polite"></p>
    <button class="btn btn--primary" type="submit">${icon('plus')} Agregar unidades</button>
  </form>`;
}

function wireQuickStock(form, p, onDone) {
  const prev = $('.qstock__preview', form);
  const update = () => {
    const v = form.loc.value;
    const q = Math.round(Number(form.qty.value) || 0);
    if (q <= 0) { prev.textContent = ''; return; }
    if (v.startsWith('all')) {
      const locs = expandLoc(v);
      prev.innerHTML = `Se sumarán <b>${num(q)}</b> unidades en cada una de las <b>${locs.length}</b> ubicaciones (${num(q * locs.length)} en total).`;
    } else {
      const now = stockAt(p, v);
      prev.innerHTML = `Hoy hay <b>${num(now)}</b> · quedarán <b>${num(now + q)}</b> en ${esc(locLabel(v))}.`;
    }
  };
  form.addEventListener('input', update);
  form.addEventListener('change', update);
  update();
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const q = Math.round(Number(form.qty.value) || 0);
    if (!setErrors(form, q > 0 && q <= 99999 ? {} : { qty: 'Ingresa un número de unidades mayor que 0.' })) return;
    const btn = $('button[type=submit]', form);
    btn.disabled = true;
    try {
      const v = form.loc.value;
      await addStock(p.id, expandLoc(v), q, { note: form.why.value });
      toast(`Agregaste <b>${num(q)}</b> ${q === 1 ? 'unidad' : 'unidades'} de ${esc(p.name)} en ${esc(locName(v))}.`);
      onDone?.();
    } catch (err) {
      saveError(err);
    } finally {
      btn.disabled = false;
      update();
    }
  });
}

export function openQuickStock(p) {
  openModal({
    title: `${icon('plus')} Agregar stock`,
    size: 'sm',
    html: `<div class="qstock-head"><img src="${productImg(p)}" alt="" width="52" height="52"><div><b>${esc(p.name)}</b><span class="muted">${esc(p.brand)} · SKU ${esc(p.id)}</span></div></div>${quickStockForm(p, 'mqs')}`,
    onMount(api) { wireQuickStock($('#mqs-form', api.el), p, () => api.close()); },
  });
}

// ── Productos y stock ────────────────────────────────────────
const STATUS_FILTERS = [
  ['', 'Todos'],
  ['bajo', 'Stock bajo'],
  ['sin', 'Agotados'],
  ['oferta', 'Con oferta'],
  ['oculto', 'Ocultos'],
  ['nuevo', 'Creados por ti'],
];

function adminFind(q) {
  const f = fold(q);
  const direct = allProducts().filter((p) => fold(`${p.name} ${p.brand} ${p.id} ${getOverride(p.id)?.code || ''} ${p.ingredients.join(' ')}`).includes(f));
  if (direct.length) return { list: direct, corrected: null };
  const r = productIndex.search(q);
  return { list: r.items.map((it) => byId.get(it.id)).filter(Boolean), corrected: r.corrected };
}

export function adminProductsPage(params, query) {
  const guard = adminGuard();
  if (guard) return guard;
  const q = (query.q || '').trim();
  const catF = query.cat || '';
  const est = query.estado || '';
  let list;
  let corrected = null;
  if (q) ({ list, corrected } = adminFind(q));
  else list = allProducts();
  if (catF) list = list.filter((p) => p.cat === catF);
  const rows = list.map((p) => ({ p, t: stockTotals(p) })).map((x) => ({ ...x, level: stockLevel(x.p, x.t) }));
  const filtered = rows.filter(({ p, level }) => {
    if (est === 'bajo') return !p.hidden && level === 'bajo';
    if (est === 'sin') return !p.hidden && level === 'sin';
    if (est === 'oferta') return !!p.offer;
    if (est === 'oculto') return p.hidden;
    if (est === 'nuevo') return p.custom;
    return true;
  });
  if (!q) filtered.sort((a, b) => (b.p.custom ? 1 : 0) - (a.p.custom ? 1 : 0) || (est ? a.t.total - b.t.total : 0) || b.p.popularity - a.p.popularity);
  const size = 25;
  const pages = Math.max(1, Math.ceil(filtered.length / size));
  const page = Math.min(Math.max(1, +query.pag || 1), pages);
  const shown = filtered.slice((page - 1) * size, page * size);
  const make = (patch) => href('/admin/productos', { q, cat: catF, estado: est, ...patch });
  const counts = { all: rows.length, bajo: rows.filter((x) => !x.p.hidden && x.level === 'bajo').length, sin: rows.filter((x) => !x.p.hidden && x.level === 'sin').length };

  const table = shown.length ? `<div class="atable" role="table" aria-label="Productos">
      <div class="atable__row atable__row--head" role="row"><span role="columnheader">Producto</span><span role="columnheader">Precio</span><span role="columnheader" class="num">Bodega online</span><span role="columnheader" class="num">Farmacias</span><span role="columnheader">Estado</span><span role="columnheader"><span class="visually-hidden">Acciones</span></span></div>
      ${shown.map(({ p, t }) => `<div class="atable__row" role="row">
        <a class="aprod" role="cell" href="#/admin/productos/${p.id}" data-link><img src="${productImg(p)}" alt="" width="44" height="44"><span><b>${esc(p.name)}</b><small>${esc(p.brand)} · ${getOverride(p.id)?.code ? `Código ${esc(getOverride(p.id).code)} · <em>desde planilla</em>` : `SKU ${esc(p.id)}${p.custom ? ' · <em>creado por ti</em>' : ''}`}</small></span></a>
        <span role="cell" class="aprice">${p.offer ? `<b>${clp(p.offer)}</b><s>${clp(p.price)}</s>` : `<b>${clp(p.price)}</b>`}</span>
        <span role="cell" class="num"><span class="atable__lbl">Bodega online</span>${num(t.online)}</span>
        <span role="cell" class="num"><span class="atable__lbl">Farmacias</span>${num(t.stores)}</span>
        <span role="cell">${levelChip(p, t)}</span>
        <span role="cell" class="atable__act"><button type="button" class="btn btn--soft btn--sm" data-qstock="${p.id}">${icon('plus')} Stock</button><a class="btn btn--ghost btn--sm" href="#/admin/productos/${p.id}" data-link>Editar</a></span>
      </div>`).join('')}
    </div>${pagination(page, pages, (n) => make({ pag: n === 1 ? '' : n }))}`
    : emptyState({ icon: 'search', title: 'No hay productos con estos filtros', text: q ? `No encontramos “${q}”. Prueba con el nombre, la marca o el código (SKU).` : 'Prueba con otro filtro.', actions: '<a class="btn btn--primary" href="#/admin/productos" data-link>Ver todos</a>' });

  const body = `<form class="atools" id="ap-form" role="search" novalidate>
      <div class="search__box atools__search">${icon('search', 'search__ico')}<input id="ap-q" name="q" type="search" value="${esc(q)}" placeholder="Buscar por nombre, marca o SKU (acepta errores)" autocomplete="off" spellcheck="false"></div>
      <select id="ap-cat" name="cat" aria-label="Categoría"><option value="">Todas las categorías</option>${[...new Set(ALL_SUBS.map((s) => s.cat))].map((c) => `<option value="${c}"${c === catF ? ' selected' : ''}>${esc(categoryById(c).name)}</option>`).join('')}</select>
    </form>
    <div class="sub-chips admin-chips">${STATUS_FILTERS.map(([id, label]) => `<a href="#${make({ estado: id, pag: '' })}" data-link class="${id === est ? 'is-on' : ''}">${esc(label)}${id === 'bajo' && counts.bajo ? ` <span class="pill-n">${counts.bajo}</span>` : ''}${id === 'sin' && counts.sin ? ` <span class="pill-n pill-n--danger">${counts.sin}</span>` : ''}</a>`).join('')}</div>
    ${corrected ? notice('club', `Mostrando resultados para <b>${esc(corrected)}</b>.`, 'sparkle') : ''}
    <p class="toolbar__count"><b>${num(filtered.length)}</b> ${filtered.length === 1 ? 'producto' : 'productos'}</p>
    ${table}`;

  return {
    title: 'Productos y stock · Administración',
    rerender: RERENDER,
    html: adminShell('productos', 'Productos y stock', body, { sub: 'Busca un producto y agrega unidades a una farmacia, a la bodega online o a todas a la vez.', actions: `<a class="btn btn--soft btn--sm" href="#/admin/productos/carga-masiva" data-link id="ap-bulk">${icon('upload')} Carga masiva (Excel o CSV)</a>` }),
    mount(root) {
      const f = $('#ap-form', root);
      const apply = () => go(make({ q: f.q.value.trim(), cat: f.cat.value, pag: '' }), { replace: true, scroll: false });
      f.addEventListener('submit', (e) => { e.preventDefault(); apply(); });
      f.cat.addEventListener('change', apply);
      f.q.addEventListener('input', debounce(() => {
        const pos = f.q.selectionStart;
        apply();
        requestAnimationFrame(() => { const i = document.getElementById('ap-q'); if (i) { i.focus(); try { i.setSelectionRange(pos, pos); } catch { /* */ } } });
      }, 350));
      root.addEventListener('click', (e) => {
        const b = e.target.closest('[data-qstock]');
        if (b) { const p = byId.get(b.dataset.qstock); if (p) openQuickStock(p); }
      });
      return null;
    },
  };
}

// ── Ficha de administración de un producto ───────────────────
function stockEditor(p) {
  const snap = stockSnapshot(p);
  const regions = REGIONS.map((r) => ({ r, stores: STORES.filter((s) => s.region === r.id) })).filter((x) => x.stores.length);
  const inp = (loc, v, label) => `<input type="number" min="0" max="999999" step="1" inputmode="numeric" value="${v}" data-loc="${loc}" data-was="${v}" aria-label="${esc(label)}">`;
  return `<div class="stock-grid">
      <details class="stock-region" open><summary><span>${icon('warehouse')} Bodegas online (despacho a domicilio)</span><b>${num(Object.values(snap.o).reduce((a, b) => a + b, 0))} u.</b>${icon('chevronDown')}</summary>
        <div class="stock-rows">${ZONE_IDS.map((z) => `<label class="stock-row"><span>${esc(ZONES[z].name)}</span>${inp(`o:${z}`, snap.o[z], `Bodega ${ZONES[z].name}`)}</label>`).join('')}</div>
      </details>
      ${regions.map(({ r, stores }) => {
        const sum = stores.reduce((a, s) => a + snap.s[s.id], 0);
        return `<details class="stock-region"${regions.length <= 2 || r.id === 'RM' ? ' open' : ''}><summary><span>${icon('store')} ${esc(regionLabel(r))} · ${stores.length} ${stores.length === 1 ? 'farmacia' : 'farmacias'}</span><b>${num(sum)} u.</b>${icon('chevronDown')}</summary>
          <div class="stock-rows">${stores.map((s) => `<label class="stock-row"><span>${esc(s.name)}<small>${esc(s.comuna)}</small></span>${inp(`s:${s.id}`, snap.s[s.id], s.name)}</label>`).join('')}</div>
        </details>`;
      }).join('')}
      ${regions.length ? '' : `<p class="muted stock-none">${icon('store', 'inline-ico')} Aún no hay farmacias. Agrégalas en <a href="#/admin/farmacias" data-link>Farmacias</a> para manejar su stock.</p>`}
    </div>`;
}

const FORMATS = PRODUCT_FORMATS;
const UNITS = PRODUCT_UNITS;
const ARTS = PRODUCT_ARTS;
const splitList = (s) => String(s || '').split(/[,;\n]/).map((x) => x.trim()).filter(Boolean);

function productForm(def = {}, { isNew = true } = {}) {
  const c = def.c || 'medicamentos/dolor-y-fiebre';
  const isMed = c.startsWith('medicamentos/');
  const opts = (list, sel) => list.map((o) => {
    const [v, l] = Array.isArray(o) ? o : [o, o];
    return `<option value="${esc(v)}"${String(v) === String(sel ?? '') ? ' selected' : ''}>${esc(l)}</option>`;
  }).join('');
  return `<form id="pform" class="pform" novalidate>
    <fieldset class="panel form-grid"><legend class="panel__title">Datos del producto</legend>
      ${field({ label: 'Nombre del producto', name: 'n', value: def.n || '', required: true, full: true, placeholder: 'Ej: Paracetamol 500 mg 20 comprimidos', hint: 'Incluye concentración y contenido, como lo verá el cliente.' })}
      ${field({ label: 'Marca o laboratorio', name: 'b', value: def.b || '', required: true, placeholder: 'Ej: Lab. Andino' })}
      ${field({ label: 'Categoría', name: 'c', value: c, required: true, options: ALL_SUBS.map((s) => ({ value: `${s.cat}/${s.id}`, label: `${s.catName} › ${s.name}` })) })}
      <div class="field"><label for="f-f">Formato</label><select id="f-f" name="f">${opts(FORMATS, def.f || 'comprimidos')}</select></div>
      <div class="field field--pair"><label for="f-u">Contenido del envase</label><div class="pair"><input id="f-u" name="u" type="number" min="1" step="1" inputmode="numeric" value="${esc(def.u || 1)}" aria-label="Cantidad"><select name="un" aria-label="Unidad">${opts(UNITS, def.un || 'comprimido')}</select></div><p class="field__error" aria-live="polite"></p></div>
    </fieldset>
    <fieldset class="panel form-grid pform__med"${isMed ? '' : ' hidden'}><legend class="panel__title">Medicamento</legend>
      ${field({ label: 'Principio activo', name: 'ai', value: (def.ai || []).join(', '), required: true, placeholder: 'Ej: paracetamol (si son varios, sepáralos con coma)', full: true })}
      ${field({ label: 'Concentración', name: 'st', value: def.st || '', placeholder: 'Ej: 500 mg' })}
      ${field({ label: 'Condición de venta', name: 'rx', value: def.rx || 'directa', required: true, options: Object.entries(RX).map(([v, r]) => ({ value: v, label: r.label })) })}
      <div class="full form-checks">${checkbox({ name: 'be', label: '<b>Bioequivalente</b> (sello BE del ISP)', checked: !!def.be })}${checkbox({ name: 'cold', label: 'Requiere cadena de frío', checked: !!def.cold })}</div>
    </fieldset>
    <fieldset class="panel form-grid"><legend class="panel__title">Precio${isNew ? ' y stock inicial' : ''}</legend>
      ${field({ label: 'Precio normal (CLP)', name: 'p', type: 'number', value: def.p || '', required: true, inputmode: 'numeric', placeholder: 'Ej: 1990', attrs: 'min="1" step="1"' })}
      ${field({ label: 'Precio oferta (CLP)', name: 'o', type: 'number', value: def.o || '', inputmode: 'numeric', placeholder: 'Déjalo vacío si no tiene oferta', attrs: 'min="1" step="1"' })}
      ${isNew ? `${field({ label: 'Stock en cada bodega online', name: 'so', type: 'number', value: '20', inputmode: 'numeric', attrs: 'min="0" step="1"', hint: `Se aplica a las ${ZONE_IDS.length} zonas de despacho.` })}
      ${STORES.length ? field({ label: 'Stock en cada farmacia', name: 'ss', type: 'number', value: '5', inputmode: 'numeric', attrs: 'min="0" step="1"', hint: `Se aplica a ${STORES.length === 1 ? 'la farmacia' : `las ${STORES.length} farmacias`}. Después puedes ajustar cada una.` }) : ''}` : ''}
    </fieldset>
    <fieldset class="panel form-grid"><legend class="panel__title">Buscador y presentación</legend>
      ${field({ label: 'Palabras para encontrarlo', name: 't', value: (def.t || []).join(', '), full: true, placeholder: 'Ej: fiebre, dolor de cabeza, resfrío', hint: 'Síntomas, usos u otros nombres con que lo buscan. El buscador además tolera errores de escritura.' })}
      ${field({ label: 'Descripción', name: 'd', type: 'textarea', value: def.d || '', full: true, placeholder: 'Para qué sirve, cómo se usa, advertencias…' })}
      <div class="field"><label for="f-art">Dibujo del envase</label><select id="f-art" name="art">${opts(ARTS, def.art || '')}</select><p class="field__hint">Se usa mientras el producto no tenga foto.</p></div>
    </fieldset>
    ${isNew ? `<fieldset class="panel"><legend class="panel__title">Foto del producto (opcional)</legend>${photoPicker('np')}</fieldset>` : ''}
    <div class="pform__actions"><button class="btn btn--primary btn--lg" type="submit">${isNew ? `${icon('plus')} Crear producto` : 'Guardar datos'}</button><a class="btn btn--ghost btn--lg" href="#/admin/productos" data-link>Cancelar</a></div>
  </form>`;
}

function defFromForm(v) {
  const isMed = v.c.startsWith('medicamentos/');
  const def = { n: v.n.trim(), b: v.b.trim(), c: v.c, f: v.f, u: Math.max(1, Math.round(+v.u || 1)), un: v.un, p: Math.round(+v.p || 0), t: splitList(v.t).map((x) => x.toLowerCase()), d: v.d.trim(), s: 60 };
  if (+v.o) def.o = Math.round(+v.o);
  if (v.art) def.art = v.art;
  if (isMed) {
    def.ai = splitList(v.ai).map((x) => x.toLowerCase());
    if (v.st.trim()) def.st = v.st.trim();
    def.rx = v.rx || 'directa';
    if (v.be) def.be = 1;
  } else {
    def.rx = 'directa';
  }
  if (v.cold) def.cold = 1;
  return def;
}

function validateDef(v, { imported = false } = {}) {
  const errors = {};
  if (!v.n.trim()) errors.n = 'Escribe el nombre del producto.';
  if (!v.b.trim()) errors.b = 'Escribe la marca o el laboratorio.';
  if (!(+v.p > 0)) errors.p = 'Ingresa el precio normal.';
  if (+v.o && +v.o >= +v.p) errors.o = 'La oferta debe ser menor que el precio normal.';
  if (!(+v.u >= 1)) errors.u = 'Indica cuánto contiene el envase.';
  if (v.c.startsWith('medicamentos/') && !splitList(v.ai).length && !imported) errors.ai = 'Indica el principio activo (para el buscador y los bioequivalentes).';
  return errors;
}

function previewCard(def, photo = '') {
  let p;
  try { p = normalizeProduct({ ...def, n: def.n || 'Nombre del producto', b: def.b || 'Marca', p: def.p || 0 }, 'PREVIEW', 'preview'); } catch { return ''; }
  if (!def.art) p.art = artFor(def.f);
  return `<article class="pcard pcard--preview" aria-label="Vista previa">
    <div class="pcard__media"><img src="${photo || previewImg(p)}" alt="" width="200" height="200" style="object-fit:contain"></div>
    <div class="pcard__body"><p class="pcard__brand">${esc(p.brand)}</p><h3 class="pcard__name">${esc(p.name)}</h3>
      <div class="pcard__chips">${p.isMedicine || p.rx !== 'directa' ? rxChip(p) : ''}${p.be ? '<span class="be-chip"><b>BE</b>Bioequivalente</span>' : ''}</div>
      <div class="price"><div class="price__row"><span class="price__now">${clp(salePrice(p))}</span>${discountPct(p) ? `<span class="badge badge--sale">-${discountPct(p)}%</span>` : ''}</div>${p.offer ? `<span class="price__was">Normal <s>${clp(p.price)}</s></span>` : ''}</div>
    </div></article>`;
}

function wireProductForm(root, { onSubmit, imported = false }) {
  const f = $('#pform', root);
  const pv = $('#pform-preview', root);
  let photo = null; // foto elegida para un producto nuevo (se sube al crearlo)
  const refresh = () => {
    const v = formData(f);
    $('.pform__med', root).hidden = !v.c.startsWith('medicamentos/');
    if (pv) pv.innerHTML = previewCard(defFromForm(v), photo?.dataUrl || '');
  };
  if ($('#np-file', root)) {
    wirePhotoPicker(root, 'np', {
      onReady(r) { photo = r; refresh(); },
      onClear() { photo = null; refresh(); },
    });
  }
  f.addEventListener('input', debounce((e) => { if (e.target.type !== 'file') refresh(); }, 150));
  f.addEventListener('change', (e) => { if (e.target.type !== 'file') refresh(); });
  refresh();
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = formData(f);
    if (!setErrors(f, validateDef(v, { imported }))) return;
    const btn = $('button[type=submit]', f);
    btn.disabled = true;
    try { await onSubmit(defFromForm(v), v, photo); } catch (err) { saveError(err); } finally { btn.disabled = false; }
  });
}

// ── Fotos de productos ───────────────────────────────────────
// Selector de foto: dice la medida en píxeles y si sirve, antes de guardarla.
function photoPicker(prefix, { has = false } = {}) {
  return `<div class="pphoto__spec">
      <p><b>Medida ideal: ${px(PHOTO_IDEAL, PHOTO_IDEAL)}</b> (cuadrada)</p>
      <p class="muted">Mínimo ${px(PHOTO_MIN, PHOTO_MIN)} · JPG o PNG · hasta ${PHOTO_MAX_MB} MB</p>
    </div>
    <label class="rx-upload__drop pphoto__drop" id="${prefix}-drop">${icon('upload')}<span><b>${has ? 'Cambiar foto' : 'Subir foto'}</b> · JPG o PNG<small>Toca para elegirla o arrástrala aquí</small></span><input type="file" id="${prefix}-file" accept="image/jpeg,image/png,.jpg,.jpeg,.png"></label>
    <div class="pphoto__check" id="${prefix}-check" aria-live="polite" hidden></div>
    <p class="field__hint">Consejo: el producto centrado, sobre fondo blanco (o PNG con fondo transparente), sin textos ni bordes.</p>`;
}

function photoCheckHtml(r) {
  if (!r.ok) return `<p class="pphoto__bad">${icon('alert')}<span>${esc(r.error)}</span></p>`;
  const resized = r.outWidth !== r.width || r.outHeight !== r.height;
  return `<p class="pphoto__good">${icon('checkCircle')}<span>Tu foto mide <b>${px(r.width, r.height)}</b> (${esc(r.label)}).${resized ? ` Se guardará en ${px(r.outWidth, r.outHeight)} para que cargue rápido.` : ''}</span></p>
    ${r.notes.map((n) => `<p class="pphoto__warn">${icon('info')}<span>${esc(n)}</span></p>`).join('')}`;
}

function wirePhotoPicker(root, prefix, { onReady, onClear } = {}) {
  const input = $(`#${prefix}-file`, root);
  const drop = $(`#${prefix}-drop`, root);
  const check = $(`#${prefix}-check`, root);
  let busy = false;
  const handle = async (file) => {
    if (!file || busy) return;
    busy = true;
    check.hidden = false;
    check.innerHTML = `<p class="muted">${icon('refresh')}<span>Revisando la foto…</span></p>`;
    const r = await preparePhoto(file);
    busy = false;
    check.innerHTML = photoCheckHtml(r);
    input.value = '';
    if (r.ok) onReady?.(r); else onClear?.();
  };
  input.addEventListener('change', () => handle(input.files?.[0]));
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-drag'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('is-drag'));
  drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('is-drag'); handle(e.dataTransfer?.files?.[0]); });
  return {
    reset() { check.hidden = true; check.innerHTML = ''; input.value = ''; },
  };
}

function photoPanel(p) {
  const has = !!p.photo;
  return `<section class="panel pphoto" aria-labelledby="pp-title">
    <div class="panel__head"><h2 class="panel__title" id="pp-title">Foto del producto</h2>${has ? '<span class="chip chip--ok">Foto propia</span>' : '<span class="chip">Dibujo automático</span>'}</div>
    <div class="pphoto__row">
      <div class="pphoto__box"><img id="pp-img" src="${productImg(p)}" alt="${has ? 'Foto actual' : 'Dibujo actual'} de ${esc(p.name)}" width="132" height="132"></div>
      <div class="pphoto__now">${has ? `<p>Foto actual: <b>${px(p.photo.w, p.photo.h)}</b></p>` : '<p>Hoy se muestra un dibujo del envase.</p>'}<p class="muted">Se ve en la tienda, el carro, los pedidos y los banners.</p></div>
    </div>
    ${photoPicker('pp', { has })}
    <div class="btn-row pphoto__actions" id="pp-actions" hidden><button type="button" class="btn btn--primary" data-pp-save>Guardar foto</button><button type="button" class="btn btn--ghost" data-pp-cancel>Cancelar</button></div>
    ${has ? '<button type="button" class="btn btn--link btn--sm pphoto__remove" data-pp-remove>Quitar foto y volver al dibujo</button>' : ''}
  </section>`;
}

function wirePhotoPanel(root, p) {
  const img = $('#pp-img', root);
  const original = img.getAttribute('src');
  const actions = $('#pp-actions', root);
  let ready = null;
  const picker = wirePhotoPicker(root, 'pp', {
    onReady(r) { ready = r; img.src = r.dataUrl; actions.hidden = false; },
    onClear() { ready = null; img.src = original; actions.hidden = true; },
  });
  root.addEventListener('click', async (e) => {
    if (e.target.closest('[data-pp-cancel]')) {
      ready = null;
      img.src = original;
      actions.hidden = true;
      picker.reset();
      return;
    }
    const save = e.target.closest('[data-pp-save]');
    if (save && ready) {
      save.disabled = true;
      try {
        await setProductPhoto(p.id, ready.dataUrl);
        toast('Guardamos la foto. Ya se ve en la tienda.');
      } catch (err) { saveError(err); save.disabled = false; }
      return;
    }
    if (e.target.closest('[data-pp-remove]')) {
      if (!(await confirmDialog({ title: '¿Quitar la foto?', text: `<b>${esc(p.name)}</b> volverá a mostrarse con el dibujo del envase.`, confirmText: 'Quitar foto', danger: true }))) return;
      try { await removeProductPhoto(p.id); toast('Quitaste la foto. Se muestra el dibujo del envase.', { tone: 'info' }); } catch (err) { saveError(err); }
    }
  });
}

export function adminNewProductPage() {
  const guard = adminGuard();
  if (guard) return guard;
  const body = `<div class="pform-layout">${productForm({}, { isNew: true })}<aside class="sticky-col pform__side"><p class="eyebrow">Vista previa</p><div id="pform-preview"></div><p class="field__hint">Así se verá en la tienda. Si no subes una foto, se dibuja el envase.</p></aside></div>`;
  return {
    title: 'Nuevo producto · Administración',
    html: adminShell('nuevo', 'Nuevo producto', body, { sub: 'Aparecerá en la tienda y en el buscador apenas lo crees.' }),
    onState: () => true, // no repintar mientras se escribe
    mount(root) {
      wireProductForm(root, {
        async onSubmit(def, v, photo) {
          const so = Math.max(0, Math.round(+v.so || 0));
          const ss = Math.max(0, Math.round(+v.ss || 0));
          const o = {};
          const s = {};
          for (const z of ZONE_IDS) o[z] = so;
          for (const st of STORES) s[st.id] = ss;
          const id = await createProduct(def, { o, s });
          let photoError = null;
          if (photo) {
            try { await setProductPhoto(id, photo.dataUrl); } catch (err) { photoError = err; }
          }
          if (photoError) toast(`Creaste <b>${esc(def.n)}</b>, pero la foto no se guardó: ${esc(friendlyError(photoError))} Vuelve a subirla aquí.`, { tone: 'warn', timeout: 9000 });
          else toast(`Creaste <b>${esc(def.n)}</b>. Ya está a la venta.`);
          go(`/admin/productos/${id}`);
        },
      });
      return null;
    },
  };
}

const movesSig = (pid) => JSON.stringify(bo.movements.filter((m) => m.pid === pid).slice(0, 12).map((m) => [m.at, m.delta, m.loc]));

export function adminProductPage(params) {
  const guard = adminGuard();
  if (guard) return guard;
  const p = byId.get(params.id);
  if (!p) {
    return { title: 'Producto no encontrado', html: adminShell('productos', 'Producto no encontrado', emptyState({ icon: 'box', title: 'No encontramos ese producto', text: 'Puede que se haya eliminado.', actions: '<a class="btn btn--primary" href="#/admin/productos" data-link>Volver a productos</a>' })) };
  }
  const t = stockTotals(p);
  const ov = getOverride(p.id);
  const sig = JSON.stringify(ov || null);
  const cat = categoryById(p.cat);
  const sub = subById(p.cat, p.sub);
  const orig = p._orig || { price: p.price, offer: p.offer };
  const moves = bo.movements.filter((m) => m.pid === p.id).slice(0, 12);
  const msig = movesSig(p.id);
  const priceChanged = !p.custom && ov?.priceSet;

  const body = `<div class="aprod-head panel">
      <img src="${productImg(p)}" alt="" width="96" height="96">
      <div class="aprod-head__main">
        <p class="muted">${esc(cat?.name || '')}${sub ? ` › ${esc(sub.name)}` : ''} · ${ov?.code ? 'Código' : 'SKU'} ${esc(ov?.code || p.id)}</p>
        <h2 class="aprod-head__name">${esc(p.name)}</h2>
        <p class="aprod-head__brand">${esc(p.brand)}</p>
        <div class="aprod-head__chips">${rxChip(p)}${p.be ? beSeal() : ''}${levelChip(p, t)}${p.custom ? `<span class="chip chip--info">${ov?.code ? 'Desde planilla' : 'Creado por ti'}</span>` : ''}</div>
      </div>
      <div class="aprod-head__stats">
        <div><span>Bodega online</span><b>${num(t.online)}</b></div>
        <div><span>Farmacias</span><b>${num(t.stores)}</b></div>
        <div><span>Precio</span><b>${clp(salePrice(p))}</b></div>
        ${ov?.cost != null ? `<div><span>Margen</span><b>${marginText(salePrice(p), ov.cost)}</b></div>` : ''}
      </div>
      ${p.hidden ? '' : `<a class="btn btn--ghost btn--sm aprod-head__view" href="#/producto/${p.slug}" data-link>${icon('external')} Ver en la tienda</a>`}
    </div>

    <div class="admin-cols">
      <div class="admin-cols__main">
        <section class="panel">
          <h2 class="panel__title">Agregar stock</h2>
          ${quickStockForm(p, 'eqs')}
        </section>
        <section class="panel">
          <div class="panel__head"><h2 class="panel__title">Stock por ubicación</h2><span class="muted">Escribe la cantidad exacta que hay en cada lugar.</span></div>
          <form id="stock-form" novalidate>
            ${stockEditor(p)}
            <div class="stock-actions">
              <div class="field"><label for="st-why">Motivo del ajuste</label><select id="st-why" name="why">${REASONS.slice().reverse().map((r) => `<option>${esc(r)}</option>`).join('')}</select></div>
              <p class="muted" id="st-changes" aria-live="polite">Sin cambios.</p>
              <button class="btn btn--primary" type="submit" disabled>Guardar stock</button>
            </div>
          </form>
        </section>
      </div>
      <div class="admin-cols__side">
        ${photoPanel(p)}
        <section class="panel">
          <h2 class="panel__title">Precio, oferta y costo</h2>
          <form id="price-form" class="form-grid form-grid--1" novalidate>
            ${field({ label: 'Precio normal (CLP)', name: 'price', type: 'number', value: p.price, required: true, inputmode: 'numeric', attrs: 'min="1" step="1"' })}
            ${field({ label: 'Precio oferta (CLP)', name: 'offer', type: 'number', value: p.offer || '', inputmode: 'numeric', placeholder: 'Sin oferta', attrs: 'min="1" step="1"' })}
            ${field({ label: 'Precio costo (CLP)', name: 'cost', type: 'number', value: ov?.cost ?? '', inputmode: 'numeric', placeholder: 'Sin costo registrado', hint: 'Solo lo ves tú en el panel: nunca aparece en la tienda.', attrs: 'min="0" step="1"' })}
            <p class="muted" id="pr-note" aria-live="polite"></p>
            <div class="btn-row"><button class="btn btn--primary" type="submit">Guardar precio</button>${p.offer ? '<button class="btn btn--ghost" type="button" data-nooffer>Quitar oferta</button>' : ''}</div>
            ${priceChanged ? `<p class="field__hint">Precio original: ${clp(orig.price)}${orig.offer ? ` (oferta ${clp(orig.offer)})` : ''}. <button type="button" class="btn btn--link btn--sm" data-resetprice>Volver al original</button></p>` : ''}
          </form>
        </section>
        <section class="panel">
          <h2 class="panel__title">Visibilidad</h2>
          <label class="switch"><input type="checkbox" id="vis" ${p.hidden ? '' : 'checked'}><span class="switch__track" aria-hidden="true"></span><span><b>${p.hidden ? 'Oculto en la tienda' : 'Visible en la tienda'}</b><small>${p.hidden ? 'Nadie puede verlo ni comprarlo.' : 'Aparece en el buscador, las categorías y se puede comprar.'}</small></span></label>
        </section>
        ${p.custom ? `<section class="panel"><h2 class="panel__title">${ov?.code ? 'Producto cargado desde planilla' : 'Producto creado por ti'}</h2><p class="muted">${ov?.code ? 'Revisa su categoría, principio activo y condición de venta; puedes cambiarlos o eliminarlo.' : 'Puedes cambiar sus datos o eliminarlo.'}</p><div class="btn-row"><a class="btn btn--soft btn--sm" href="#/admin/productos/${p.id}/editar" data-link>${icon('edit')} Editar datos</a><button type="button" class="btn btn--ghost btn--sm" data-delete>${icon('trash')} Eliminar</button></div></section>` : ''}
        <section class="panel">
          <div class="panel__head"><h2 class="panel__title">Últimos movimientos</h2><a class="link-more" href="#/admin/movimientos?q=${encodeURIComponent(p.id)}" data-link>Ver todos ${icon('arrowRight')}</a></div>
          ${moves.length ? `<ul class="moves">${moves.map((m) => `<li>${kindChip(m.kind)}<span><b>${m.delta > 0 ? '+' : ''}${m.delta ? num(m.delta) : ''}</b> ${esc(m.loc ? locLabel(m.loc) : m.note)}<small>${esc(dateTime(m.at))}${m.ref ? ` · ${esc(m.ref)}` : ''}</small></span></li>`).join('')}</ul>` : '<p class="muted">Aún no hay movimientos de este producto.</p>'}
        </section>
      </div>
    </div>`;

  return {
    title: `${p.name} · Administración`,
    html: adminShell('productos', 'Administrar producto', body, { actions: `<a class="btn btn--ghost btn--sm" href="#/admin/productos" data-link>${icon('arrowLeft')} Productos</a>` }),
    // Solo se repinta si cambió este producto (para no borrar lo que se está escribiendo)
    onState(evt) {
      if (evt !== 'backoffice') return true;
      return JSON.stringify(getOverride(p.id) || null) === sig && byId.get(p.id) === p && movesSig(p.id) === msig;
    },
    mount(root) {
      wireQuickStock($('#eqs-form', root), p);
      wirePhotoPanel(root, p);
      // Ajuste exacto por ubicación
      const sf = $('#stock-form', root);
      const changed = () => $$('input[data-loc]', sf).filter((i) => i.value !== '' && Math.round(+i.value) !== +i.dataset.was);
      sf.addEventListener('input', () => {
        const ch = changed();
        $$('input[data-loc]', sf).forEach((i) => i.classList.toggle('is-changed', ch.includes(i)));
        $('#st-changes', root).textContent = ch.length ? `${ch.length} ${ch.length === 1 ? 'ubicación modificada' : 'ubicaciones modificadas'}` : 'Sin cambios.';
        $('button[type=submit]', sf).disabled = !ch.length;
      });
      sf.addEventListener('submit', async (e) => {
        e.preventDefault();
        const ch = changed();
        if (!ch.length) return;
        if (ch.some((i) => !(Number(i.value) >= 0))) { toast('Revisa las cantidades: deben ser números de 0 o más.', { tone: 'warn' }); return; }
        const btn = $('button[type=submit]', sf);
        btn.disabled = true;
        try {
          const n = await changeStock(p.id, ch.map((i) => ({ loc: i.dataset.loc, qty: Math.round(+i.value) })), { kind: 'ajuste', note: sf.why.value });
          toast(`Guardamos el stock de <b>${n}</b> ${n === 1 ? 'ubicación' : 'ubicaciones'}.`);
        } catch (err) { saveError(err); btn.disabled = false; }
      });
      // Precio
      const pf = $('#price-form', root);
      const note = () => {
        const pr = +pf.price.value;
        const of = +pf.offer.value;
        const co = pf.cost.value === '' ? null : +pf.cost.value;
        const parts = [];
        if (pr > 0 && of > 0 && of < pr) parts.push(`Descuento de ${Math.round((1 - of / pr) * 100)}%.`);
        else if (of >= pr && of) parts.push('La oferta debe ser menor que el precio normal.');
        if (co != null && pr > 0) parts.push(`Margen: ${marginText(of > 0 && of < pr ? of : pr, co)}.`);
        $('#pr-note', root).textContent = parts.join(' ');
      };
      pf.addEventListener('input', note);
      note();
      pf.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errors = {};
        if (!(+pf.price.value > 0)) errors.price = 'Ingresa un precio válido.';
        if (+pf.offer.value && +pf.offer.value >= +pf.price.value) errors.offer = 'Debe ser menor que el precio normal.';
        if (pf.cost.value !== '' && !(+pf.cost.value >= 0)) errors.cost = 'Ingresa un costo válido o déjalo en blanco.';
        if (!setErrors(pf, errors)) return;
        try {
          await setPrice(p.id, +pf.price.value, +pf.offer.value || 0, pf.cost.value === '' ? null : Math.round(+pf.cost.value));
          toast('Guardamos el nuevo precio.');
        } catch (err) { saveError(err); }
      });
      root.addEventListener('click', async (e) => {
        if (e.target.closest('[data-nooffer]')) {
          try { await setPrice(p.id, p.price, 0); toast('Quitaste la oferta.', { tone: 'info' }); } catch (err) { saveError(err); }
          return;
        }
        if (e.target.closest('[data-resetprice]')) {
          try { await setPrice(p.id, orig.price, orig.offer || 0); toast('Volvió al precio original.', { tone: 'info' }); } catch (err) { saveError(err); }
          return;
        }
        if (e.target.closest('[data-delete]')) {
          if (!(await confirmDialog({ title: '¿Eliminar este producto?', text: `Se eliminará <b>${esc(p.name)}</b> de la tienda. Los pedidos anteriores no cambian.`, confirmText: 'Eliminar producto', danger: true }))) return;
          try { await deleteProduct(p.id); toast('Eliminaste el producto.', { tone: 'info' }); go('/admin/productos', { replace: true }); } catch (err) { saveError(err); }
        }
      });
      $('#vis', root).addEventListener('change', async (e) => {
        const visible = e.target.checked;
        try {
          await setHidden(p.id, !visible);
          toast(visible ? 'El producto vuelve a estar visible en la tienda.' : 'Ocultaste el producto: ya no se muestra ni se vende.', { tone: visible ? 'ok' : 'info' });
        } catch (err) { saveError(err); e.target.checked = !visible; }
      });
      return null;
    },
  };
}

export function adminEditProductPage(params) {
  const guard = adminGuard();
  if (guard) return guard;
  const p = byId.get(params.id);
  const ov = getOverride(params.id);
  if (!p || !p.custom || !ov?.def) return adminProductPage(params);
  const body = `<div class="pform-layout">${productForm(ov.def, { isNew: false })}<aside class="sticky-col pform__side"><p class="eyebrow">Vista previa</p><div id="pform-preview"></div></aside></div>`;
  return {
    title: `Editar ${p.name} · Administración`,
    html: adminShell('productos', 'Editar producto', body, { actions: `<a class="btn btn--ghost btn--sm" href="#/admin/productos/${p.id}" data-link>${icon('arrowLeft')} Volver</a>` }),
    onState: () => true,
    mount(root) {
      wireProductForm(root, {
        imported: !!ov.code,
        async onSubmit(def) {
          await updateProductDef(p.id, { ...def, s: ov.def.s || 60 });
          toast('Guardamos los datos del producto.');
          go(`/admin/productos/${p.id}`);
        },
      });
      return null;
    },
  };
}

// ── Pedidos ──────────────────────────────────────────────────
const ORDER_FILTERS = [['', 'Todos'], ['recibido', 'Por confirmar'], ['embalaje', 'En preparación'], ['salida', 'En camino o listos'], ['entregado', 'Entregados'], ['anulados', 'Anulados']];

function orderState(o) {
  if (o.cancelled) return 'anulados';
  if (!isManaged(o)) return orderTimeline(o).done ? 'entregado' : 'recibido'; // pedidos de antes de las etapas
  const s = statusOf(o);
  return s === 'camino' || s === 'listo' ? 'salida' : s;
}

export function adminOrdersPage(params, query) {
  const guard = adminGuard();
  if (guard) return guard;
  const q = (query.q || '').trim();
  const est = query.estado || '';
  const all = adminOrders();
  let list = all;
  if (q) {
    const f = fold(q);
    list = list.filter((o) => fold(`${o.id} ${o.customer?.nombre} ${o.customer?.apellidos} ${o.customer?.email} ${o.customer?.rut}`).includes(f));
  }
  if (est) list = list.filter((o) => orderState(o) === est);
  const size = 20;
  const pages = Math.max(1, Math.ceil(list.length / size));
  const page = Math.min(Math.max(1, +query.pag || 1), pages);
  const shown = list.slice((page - 1) * size, page * size);
  const make = (patch) => href('/admin/pedidos', { q, estado: est, ...patch });
  const counts = Object.fromEntries(ORDER_FILTERS.map(([id]) => [id, id ? all.filter((o) => orderState(o) === id).length : all.length]));

  const table = shown.length ? `<div class="atable atable--orders" role="table" aria-label="Pedidos">
      <div class="atable__row atable__row--head" role="row"><span role="columnheader">Pedido</span><span role="columnheader">Cliente</span><span role="columnheader">Entrega</span><span role="columnheader">Pago</span><span role="columnheader">Estado</span><span role="columnheader" class="num">Total</span></div>
      ${shown.map((o) => {
        const st = statusLabel(o);
        const units = (o.items || []).reduce((a, it) => a + it.qty, 0);
        return `<a class="atable__row atable__row--link" role="row" href="#/admin/pedidos/${o.id}" data-link>
          <span role="cell"><b>${esc(o.id)}</b><small>${esc(dateTime(o.createdAt))}</small></span>
          <span role="cell">${esc(`${o.customer?.nombre || ''} ${o.customer?.apellidos || ''}`.trim() || 'Cliente')}<small>${esc(o.customer?.email || '')}</small></span>
          <span role="cell">${o.delivery?.type === 'retiro' ? `Retiro · ${esc(o.delivery.storeName || '')}` : `Despacho · ${esc(o.delivery?.comuna || '')}`}<small>${num(units)} ${units === 1 ? 'unidad' : 'unidades'}${o.delivery?.date ? ` · ${esc(dateText(o.delivery.date))}` : ''}</small></span>
          <span role="cell">${esc(o.payment?.label || '')}<small>${o.payment?.status === 'aprobado' ? 'Pagado' : 'Pago pendiente'}</small></span>
          <span role="cell"><span class="chip chip--${st.tone}">${esc(st.text)}</span></span>
          <span role="cell" class="num"><b>${clp(o.totals?.total)}</b></span>
        </a>`;
      }).join('')}
    </div>${pagination(page, pages, (n) => make({ pag: n === 1 ? '' : n }))}`
    : emptyState({ icon: 'bag', title: all.length ? 'Ningún pedido calza con estos filtros' : 'Aún no hay pedidos', text: all.length ? 'Prueba con otro filtro.' : 'Cuando se compre en la tienda, los pedidos aparecerán aquí.', actions: all.length ? '<a class="btn btn--primary" href="#/admin/pedidos" data-link>Ver todos</a>' : '<a class="btn btn--primary" href="#/" data-link>Ir a la tienda</a>' });

  const body = `<form class="atools" id="ao-form" role="search" novalidate><div class="search__box atools__search">${icon('search', 'search__ico')}<input id="ao-q" name="q" type="search" value="${esc(q)}" placeholder="Buscar por número, nombre, correo o RUT" autocomplete="off"></div></form>
    <div class="sub-chips admin-chips">${ORDER_FILTERS.map(([id, label]) => `<a href="#${make({ estado: id, pag: '' })}" data-link class="${id === est ? 'is-on' : ''}">${esc(label)} <span class="pill-n">${counts[id]}</span></a>`).join('')}</div>
    ${table}`;
  return {
    title: 'Pedidos · Administración',
    rerender: RERENDER,
    html: adminShell('pedidos', 'Pedidos', body),
    mount(root) {
      const f = $('#ao-form', root);
      f.addEventListener('submit', (e) => { e.preventDefault(); go(make({ q: f.q.value.trim(), pag: '' }), { replace: true, scroll: false }); });
      return null;
    },
  };
}

export function adminOrderPage(params) {
  const guard = adminGuard();
  if (guard) return guard;
  const o = findAdminOrder(params.id);
  if (!o) return { title: 'Pedido no encontrado', rerender: RERENDER, html: adminShell('pedidos', 'Pedido no encontrado', emptyState({ icon: 'bag', title: 'No encontramos ese pedido', actions: '<a class="btn btn--primary" href="#/admin/pedidos" data-link>Volver a pedidos</a>' })) };
  const st = statusLabel(o);
  const d = o.delivery || {};
  const c = o.customer || {};
  const body = `<div class="admin-cols">
      <div class="admin-cols__main">
        ${orderFlowHtml(o)}
        <section class="panel">
          <div class="panel__head"><h2 class="panel__title">Productos</h2><span class="chip chip--${st.tone}">${esc(st.text)}</span></div>
          <div class="mini__lines">${(o.items || []).map((it) => {
            const p = byId.get(it.id);
            return `<div class="mini__line">${p ? `<img src="${productImg(p)}" alt="" width="58" height="58">` : '<span></span>'}<div>${p ? `<a href="#/admin/productos/${p.id}" data-link>${esc(it.name)}</a>` : esc(it.name)}<small>${it.qty} × ${clp(it.unit)} · ${esc(RX[it.rx]?.label || '')}</small></div><b>${clp(it.total)}</b></div>`;
          }).join('')}</div>
          <div class="summary__rows">
            <div class="summary__row"><span>Productos</span><span>${clp(o.totals?.listTotal)}</span></div>
            ${o.totals?.offerOff ? `<div class="summary__row save"><span>Descuentos de internet</span><span>-${clp(o.totals.offerOff)}</span></div>` : ''}
            ${o.totals?.promoOff ? `<div class="summary__row save"><span>Promociones</span><span>-${clp(o.totals.promoOff)}</span></div>` : ''}
            ${o.totals?.clubOff ? `<div class="summary__row club"><span>Club Piedra${o.claims?.member ? ' <small>(socio según el cliente)</small>' : ''}</span><span>-${clp(o.totals.clubOff)}</span></div>` : ''}
            ${o.totals?.couponOff ? `<div class="summary__row save"><span>Cupón ${esc(o.totals.coupon || '')}</span><span>-${clp(o.totals.couponOff)}</span></div>` : ''}
            <div class="summary__row"><span>${d.type === 'retiro' ? 'Retiro en farmacia' : 'Despacho'}</span><span>${o.totals?.shipping ? clp(o.totals.shipping) : 'Gratis'}</span></div>
          </div>
          <div class="summary__total"><span>Total</span><b>${clp(o.totals?.total)}</b></div>
        </section>
        <section class="panel">
          <h2 class="panel__title">Stock descontado</h2>
          ${(o.stockMoves || []).length ? `<ul class="moves">${o.stockMoves.map((m) => `<li>${kindChip(o.cancelled ? 'anulacion' : 'venta')}<span><b>${o.cancelled ? '+' : '−'}${num(m.qty)}</b> ${esc(byId.get(m.pid)?.name || m.pid)}<small>${esc(locLabel(m.loc))}</small></span></li>`).join('')}</ul>${o.cancelled ? '<p class="field__hint">El pedido se anuló y las unidades volvieron al stock.</p>' : ''}` : '<p class="muted">Este pedido no registró movimientos de stock.</p>'}
        </section>
      </div>
      <div class="admin-cols__side">
        ${contactPanelHtml(o)}
        <section class="panel">
          <h2 class="panel__title">${d.type === 'retiro' ? 'Retiro en farmacia' : 'Despacho'}</h2>
          <dl class="kv">${d.type === 'retiro'
            ? `<dt>Farmacia</dt><dd>${esc(d.storeName || '')}</dd><dt>Dirección</dt><dd>${esc(d.storeAddress || '')}</dd><dt>Cuándo</dt><dd>${esc(deliveryWhen(o))}</dd><dt>Retira</dt><dd>${d.pickupBy === 'otra' ? `${esc(d.pickupName)} (${esc(d.pickupRut)})` : 'El cliente'}</dd>`
            : `<dt>Dirección</dt><dd>${esc(d.address || '')}, ${esc(d.comuna || '')}</dd><dt>Región</dt><dd>${esc(d.regionName || '')}</dd><dt>Entrega</dt><dd>${esc(deliveryWhen(o))}${d.express ? ' (express)' : ''}</dd>${d.indicaciones ? `<dt>Indicaciones</dt><dd>${esc(d.indicaciones)}</dd>` : ''}`}
            <dt>Pago</dt><dd>${esc(o.payment?.label || '')} · ${o.payment?.status === 'aprobado' ? 'pagado' : 'pendiente'}</dd>
            <dt>Documento</dt><dd>${o.document?.type === 'factura' ? `Factura ${esc(o.document.razon || '')} (${esc(o.document.rut || '')})` : 'Boleta'}</dd>
            ${(o.prescriptions || []).length ? `<dt>Recetas</dt><dd class="rx-files">${o.prescriptions.map((r) => {
              const f = (o.files || []).find((x) => x.productId === r.productId && x.fileName === r.fileName && x.size);
              const pn = byId.get(r.productId)?.name;
              return f
                ? `<a href="${recetaUrl(o.id, f.id)}" target="_blank" rel="noopener">${icon('file')}${esc(r.fileName)}</a>${pn ? `<small>${esc(pn)}</small>` : ''}`
                : `<span>${icon('file')}${esc(r.fileName)} <small>(sin archivo: pedir al cliente)</small></span>`;
            }).join('')}</dd>` : ''}
            <dt>Realizado</dt><dd>${esc(dateTime(o.createdAt))}</dd></dl>
        </section>
      </div>
    </div>`;
  return {
    title: `Pedido ${o.id} · Administración`,
    rerender: RERENDER,
    html: adminShell('pedidos', `Pedido ${o.id}`, body, { actions: `<a class="btn btn--ghost btn--sm" href="#/admin/pedidos" data-link>${icon('arrowLeft')} Pedidos</a>` }),
    // Mientras se prepara un mensaje al cliente, la ficha no se repinta (no se pierde lo escrito)
    onState: (evt) => evt === 'backoffice' && !!document.querySelector('#ccontact[data-dirty]'),
    mount(root) {
      mountContact(root, o);
      mountOrderFlow(root, o.id);
      return null;
    },
  };
}

// ── Movimientos de stock ─────────────────────────────────────
const DAY_ISO = /^\d{4}-\d{2}-\d{2}$/;
const shiftDay = (iso, n) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * 86400000).toISOString().slice(0, 10);
const dmy = (iso) => iso.split('-').reverse().join('-');

/** Atajos de fechas (días de Chile): [etiqueta, desde, hasta]. */
function dateShortcuts() {
  const today = todayIso();
  const first = `${today.slice(0, 8)}01`;
  const prevLast = shiftDay(first, -1);
  return [
    ['Hoy', today, today],
    ['Ayer', shiftDay(today, -1), shiftDay(today, -1)],
    ['Últimos 7 días', shiftDay(today, -6), today],
    ['Últimos 30 días', shiftDay(today, -29), today],
    ['Este mes', first, today],
    ['Mes pasado', `${prevLast.slice(0, 8)}01`, prevLast],
  ];
}

function dateLabel(from, until) {
  const hit = dateShortcuts().find(([, f, u]) => f === from && u === until);
  if (hit) return hit[0];
  if (from && until) return from === until ? dmy(from) : `${dmy(from)} al ${dmy(until)}`;
  if (from) return `Desde el ${dmy(from)}`;
  if (until) return `Hasta el ${dmy(until)}`;
  return 'Todas las fechas';
}

// Resultados de la búsqueda en el servidor (se reutilizan mientras no cambien los datos)
let movesCache = { key: '', data: null };

function movesTable(list) {
  return `<div class="atable atable--moves" role="table" aria-label="Movimientos">
      <div class="atable__row atable__row--head" role="row"><span role="columnheader">Fecha</span><span role="columnheader">Producto</span><span role="columnheader">Tipo</span><span role="columnheader">Ubicación</span><span role="columnheader" class="num">Cambio</span><span role="columnheader" class="num">Queda</span></div>
      ${list.map((m) => `<div class="atable__row" role="row">
        <span role="cell">${esc(shortDate(m.at))}<small>${esc(dateTime(m.at).split(',').pop()?.trim() || '')}</small></span>
        <span role="cell">${byId.get(m.pid) ? `<a href="#/admin/productos/${esc(m.pid)}" data-link>${esc(m.name)}</a>` : esc(m.name)}<small>${esc(m.note || '')}${m.ref ? ` · ${esc(m.ref)}` : ''}</small></span>
        <span role="cell">${kindChip(m.kind)}</span>
        <span role="cell">${esc(m.loc ? locLabel(m.loc) : '—')}</span>
        <span role="cell" class="num ${m.delta > 0 ? 'is-up' : m.delta < 0 ? 'is-down' : ''}">${m.delta ? `${m.delta > 0 ? '+' : '−'}${num(Math.abs(m.delta))}` : '—'}</span>
        <span role="cell" class="num">${m.loc ? num(m.after) : '—'}</span>
      </div>`).join('')}
    </div>`;
}

export function adminMovesPage(params, query) {
  const guard = adminGuard();
  if (guard) return guard;
  const q = (query.q || '').trim();
  const kind = query.tipo || '';
  const from = DAY_ISO.test(query.desde || '') ? query.desde : '';
  const until = DAY_ISO.test(query.hasta || '') ? query.hasta : '';
  const loc = /^[os]:[A-Za-z0-9_-]{1,40}$/.test(query.local || '') ? query.local : '';
  const remote = !!(from || until || loc); // con fechas o farmacia se busca en todo el historial
  const make = (patch) => href('/admin/movimientos', { q, tipo: kind, desde: from, hasta: until, local: loc, ...patch });

  // Botón «Fechas»
  const shortcuts = dateShortcuts();
  const dateOn = !!(from || until);
  const datesPop = `<details class="fpop" id="am-dates">
      <summary class="fbtn${dateOn ? ' is-on' : ''}">${icon('calendar')}<span>${esc(dateLabel(from, until))}</span>${icon('chevronDown')}</summary>
      <div class="fpop__body">
        <p class="fpop__title">Filtrar por fechas</p>
        <div class="fpop__quick">${shortcuts.map(([label, f, u]) => `<a href="#${make({ desde: f, hasta: u })}" data-link class="${f === from && u === until ? 'is-on' : ''}">${esc(label)}</a>`).join('')}</div>
        <form class="fpop__range" id="am-dform" novalidate>
          <label>Desde<input type="date" name="desde" value="${esc(from)}" max="${esc(todayIso())}"></label>
          <label>Hasta<input type="date" name="hasta" value="${esc(until)}" max="${esc(todayIso())}"></label>
          <button class="btn btn--primary btn--sm" type="submit">Aplicar</button>
        </form>
        <p class="fpop__err" id="am-derr" aria-live="polite"></p>
        ${dateOn ? `<a class="fpop__clear" href="#${make({ desde: '', hasta: '' })}" data-link>${icon('x')} Quitar filtro de fechas</a>` : ''}
      </div>
    </details>`;

  // Botón «Farmacia»
  const locName = loc ? locLabel(loc) : 'Todas las farmacias';
  const storeOpts = STORES.slice().sort((a, b) => a.name.localeCompare(b.name, 'es'));
  const locLink = (id, label, sub = '') => `<a href="#${make({ local: id })}" data-link class="${id === loc ? 'is-on' : ''}" data-locname="${esc(fold(`${label} ${sub}`))}">${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</a>`;
  const locsPop = `<details class="fpop" id="am-locs">
      <summary class="fbtn${loc ? ' is-on' : ''}">${icon('store')}<span>${esc(locName)}</span>${icon('chevronDown')}</summary>
      <div class="fpop__body">
        <p class="fpop__title">Filtrar por farmacia</p>
        ${storeOpts.length > 8 ? `<input type="search" class="fpop__find" id="am-lfind" placeholder="Buscar farmacia o comuna" autocomplete="off">` : ''}
        <div class="fpop__list">
          ${locLink('', 'Todas las farmacias')}
          ${storeOpts.length ? storeOpts.map((st) => locLink(`s:${st.id}`, st.name, st.comuna)).join('') : '<p class="muted">Aún no hay farmacias.</p>'}
          <p class="fpop__group">Bodegas de la tienda online</p>
          ${ZONE_IDS.map((z) => locLink(`o:${z}`, `Bodega online · ${ZONES[z]?.name || z}`)).join('')}
        </div>
      </div>
    </details>`;

  // Resultados
  let results;
  let summary = '';
  let loading = false;
  const key = JSON.stringify([q, kind, from, until, loc, bo.version]);
  if (!remote) {
    let list = bo.movements;
    if (q) {
      const f = fold(q);
      list = list.filter((m) => fold(`${m.pid} ${m.name} ${m.ref}`).includes(f));
    }
    if (kind) list = list.filter((m) => m.kind === kind);
    results = list.length
      ? movesTable(list.slice(0, 200))
      : emptyState({ icon: 'list', title: q || kind ? 'No hay movimientos con estos filtros' : 'Aún no hay movimientos', text: q || kind ? 'Prueba con otra búsqueda o con otro tipo.' : 'Aquí verás cada ingreso, ajuste, venta y anulación de stock.' });
    if (bo.movements.length >= 400) summary = `<p class="am-sum muted">${icon('info', 'inline-ico')} Se muestran los últimos movimientos. Para ver más atrás, usa el botón <b>Todas las fechas</b>.</p>`;
  } else if (movesCache.key === key && movesCache.data) {
    const d = movesCache.data;
    results = d.movements.length ? movesTable(d.movements) : emptyState({ icon: 'list', title: 'No hay movimientos con estos filtros', text: 'Prueba con otras fechas, otra farmacia u otro tipo.' });
    summary = `<p class="am-sum"><b>${num(d.total)}</b> ${d.total === 1 ? 'movimiento' : 'movimientos'}${d.unitsIn || d.unitsOut ? ` · entraron <b class="is-up">+${num(d.unitsIn)} u.</b> · salieron <b class="is-down">−${num(d.unitsOut)} u.</b>` : ''}${d.total > d.movements.length ? ` · se muestran los ${num(d.movements.length)} más recientes` : ''}</p>`;
  } else {
    loading = true;
    results = '<div class="admin-wait"><div class="spinner" role="status" aria-label="Buscando"></div><p>Buscando movimientos…</p></div>';
  }

  const anyOn = from || until || loc || q || kind;
  const body = `<form class="atools" id="am-form" role="search" novalidate><div class="search__box atools__search">${icon('search', 'search__ico')}<input id="am-q" name="q" type="search" value="${esc(q)}" placeholder="Buscar por producto, SKU o pedido" autocomplete="off"></div></form>
    <div class="sub-chips admin-chips"><a href="#${make({ tipo: '' })}" data-link class="${!kind ? 'is-on' : ''}">Todos</a>${Object.entries(KIND).map(([k, [label]]) => `<a href="#${make({ tipo: k })}" data-link class="${k === kind ? 'is-on' : ''}">${esc(label)}</a>`).join('')}</div>
    <div class="mfilters">${datesPop}${locsPop}${anyOn ? `<a class="fclear" href="#${href('/admin/movimientos', {})}" data-link>${icon('x')} Limpiar filtros</a>` : ''}</div>
    ${summary}
    <div id="am-results">${results}</div>`;
  return {
    title: 'Movimientos · Administración',
    rerender: RERENDER,
    html: adminShell('movimientos', 'Movimientos de stock', body, { sub: 'Registro de los cambios de stock, precios, productos, banners y servicios. Filtra por tipo, por fechas o por farmacia.' }),
    mount(root) {
      const f = $('#am-form', root);
      f.addEventListener('submit', (e) => { e.preventDefault(); go(make({ q: f.q.value.trim() }), { replace: true, scroll: false }); });
      const df = $('#am-dform', root);
      df.addEventListener('submit', (e) => {
        e.preventDefault();
        const a = df.desde.value;
        const b = df.hasta.value;
        if (a && b && b < a) { $('#am-derr', root).textContent = 'La fecha «Hasta» debe ser igual o posterior a «Desde».'; return; }
        go(make({ desde: a, hasta: b }), { replace: true, scroll: false });
      });
      // Solo un botón abierto a la vez; se cierran al tocar fuera
      const pops = $$('.fpop', root);
      pops.forEach((d) => d.addEventListener('toggle', () => { if (d.open) pops.forEach((o) => { if (o !== d) o.open = false; }); }));
      const outside = (e) => { if (!e.target.closest('.fpop')) pops.forEach((d) => { d.open = false; }); };
      document.addEventListener('click', outside);
      const find = $('#am-lfind', root);
      find?.addEventListener('input', () => {
        const t = fold(find.value);
        $$('#am-locs [data-locname]', root).forEach((a) => { a.hidden = !!t && !a.dataset.locname.includes(t); });
      });
      if (loading) {
        searchMovements({ desde: from, hasta: until, local: loc, tipo: kind, q }).then((d) => {
          movesCache = { key, data: d };
          if (root.isConnected) go(make({}), { replace: true, scroll: false });
        }).catch((err) => {
          const box = $('#am-results', root);
          if (box) box.innerHTML = notice('danger', esc(friendlyError(err)));
        });
      }
      return () => document.removeEventListener('click', outside);
    },
  };
}

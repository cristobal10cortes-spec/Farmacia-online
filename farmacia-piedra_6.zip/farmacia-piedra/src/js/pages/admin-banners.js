// Panel: banners de la tienda (crear, editar, ordenar, pausar y programar).
// Dos lugares: el carrusel de arriba de la portada ('hero') y los banners
// de más abajo, después de «Ofertas destacadas» ('promo').

import { $, $$, esc, formData, setErrors, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { notice, emptyState } from '../ui/components.js';
import { toast, confirmDialog } from '../ui/overlay.js';
import { bannerSlideHtml, heroCarouselHtml, mountHeroCarousel, promoCardHtml, withLiveText, ART_LABELS, TONES } from '../ui/banners.js';
import { go } from '../router.js';
import { CATEGORIES, ALL_SUBS } from '../data/categories.js';
import { PRODUCTS, byId, getProduct } from '../engine/catalog.js';
import { placeOf } from '../engine/bannerlist.js';
import { adminShell, adminGuard, saveError } from './admin.js';
import { imageDropHtml, mountImageDrop, stageHtml, mountStages, sizeText } from '../admin/imgdrop.js';
import {
  bo, adminBannerList, liveBanners, bannerStatus, findBanner, saveBanner, deleteBanner, moveBanner, setBannerActive,
  PROMO_VISIBLE, MAX_PROMOS, PHOTO_SIZES,
} from '../admin/api.js';

const STATUS = {
  activo: ['En la tienda', 'ok'],
  pausado: ['Pausado', ''],
  programado: ['Programado', 'info'],
  vencido: ['Terminado', 'warn'],
};

// Cómo se ve cada lugar en la tienda (ancho real en computador y en celular) y
// cómo se prepara la foto que sube el dueño
const PLACES = {
  hero: { stage: 1232, phone: 358, size: PHOTO_SIZES.hero, maxW: 1600, maxChars: 700000, sizeM: PHOTO_SIZES.heroM, maxWM: 800, maxCharsM: 500000 },
  promo: { stage: 608, phone: 358, size: PHOTO_SIZES.promo, maxW: 1200, maxChars: 600000 },
};

const SECTIONS = [
  ['/ofertas', 'Ofertas'],
  ['/bioequivalentes', 'Bioequivalentes'],
  ['/club', 'Club Piedra'],
  ['/club?ver=tratamiento', 'Mi Tratamiento (Club)'],
  ['/cotizar-receta', 'Cotiza tu receta'],
  ['/farmacias', 'Farmacias y horarios'],
  ['/farmacias?turno=1', 'Farmacias de turno'],
  ['/seguimiento', 'Sigue tu pedido'],
  ['/marcas', 'Marcas'],
  ['/ayuda', 'Centro de ayuda'],
  ['/ayuda/contacto', 'Contacto'],
];
const CAT_DESTS = CATEGORIES.map((c) => [`/categoria/${c.id}`, c.name]);
const SUB_DESTS = ALL_SUBS.map((s) => [`/categoria/${s.cat}/${s.id}`, `${s.catName} › ${s.name}`]);
const KNOWN = new Map([...SECTIONS, ...CAT_DESTS, ...SUB_DESTS]);

export function destOf(to = '/ofertas') {
  if (KNOWN.has(to)) return { dest: to };
  if (to.startsWith('/buscar?q=')) return { dest: 'search', q: decodeURIComponent(to.slice(10).split('&')[0]) };
  if (to.startsWith('/producto/')) {
    const p = getProduct(to.slice(10));
    if (p) return { dest: 'product', dprod: p.id };
  }
  return { dest: 'custom', path: to };
}

export function destLabel(to = '') {
  const d = destOf(to);
  if (d.dest === 'search') return `Búsqueda “${d.q}”`;
  if (d.dest === 'product') return byId.get(d.dprod)?.name || 'Producto';
  if (d.dest === 'custom') return to;
  return KNOWN.get(d.dest) || to;
}

// Mientras llega la lista guardada (sitio publicado), se espera un momento
function bannersWait() {
  if (bo.ready) return null;
  return {
    title: 'Banners · Administración',
    rerender: ['banners', 'backoffice'],
    html: '<div class="wrap page"><div class="admin-wait"><div class="spinner" role="status" aria-label="Cargando"></div><p>Cargando los banners…</p></div></div>',
  };
}

const fmtDate = (iso) => (iso ? iso.split('-').reverse().join('-') : '');

function statusChip(b, hiddenByLimit) {
  if (hiddenByLimit) return `<span class="chip chip--warn" title="Abajo se ven ${PROMO_VISIBLE} banners a la vez. Sube este o pausa otro para que aparezca.">No cabe en la portada</span>`;
  const [label, tone] = STATUS[bannerStatus(b)];
  return `<span class="chip${tone ? ` chip--${tone}` : ''}">${esc(label)}</span>`;
}

function bannerRows(list, liveIds) {
  const one = list.length <= 1;
  return list.map((b, i) => {
    const status = bannerStatus(b);
    const over = status === 'activo' && !liveIds.has(b.id);
    const promo = placeOf(b) === 'promo';
    const prev = promo
      ? `<div class="bcard__prev bcard__prev--promo" aria-hidden="true">${stageHtml(promoCardHtml(b, { tag: 'div' }), { width: PLACES.promo.stage })}</div>`
      : `<div class="bcard__prev hero hero--mini" aria-hidden="true"><div class="hero__track">${bannerSlideHtml(b, 0, 1)}</div></div>`;
    const photoChip = b.visual === 'photo' ? `<span class="chip">${icon('image')}${b.photoOnly ? 'Solo foto' : 'Con foto'}${b.imageM ? ' · celular' : ''}</span>` : '';
    return `<li class="bcard${status === 'activo' && !over ? '' : ' is-off'}" data-banner="${esc(b.id)}">
      ${prev}
      <div class="bcard__info">
        <span class="bcard__pos">${i + 1}</span>
        <div><b>${esc(b.title)}</b>
          <small>${b.eyebrow ? `${esc(b.eyebrow)} · ` : ''}Botón «${esc(b.cta || 'Ver más')}» → ${esc(destLabel(b.to))}</small>
          <div class="bcard__chips">${statusChip(b, over)}${photoChip}${b.dynamic === 'club' ? `<span class="chip chip--club" title="Muestra la campaña del Club de cada día. Si editas su texto, queda fijo.">${icon('star')}Cambia solo cada día</span>` : ''}${b.from || b.until ? `<span class="chip">${icon('calendar')}${b.from ? `desde ${fmtDate(b.from)}` : ''}${b.from && b.until ? ' ' : ''}${b.until ? `hasta ${fmtDate(b.until)}` : ''}</span>` : ''}</div>
        </div>
      </div>
      <div class="bcard__act">
        <button type="button" class="icon-btn" data-bmove="-1" data-id="${esc(b.id)}" aria-label="Subir ${esc(b.title)}" ${i === 0 ? 'disabled' : ''}>${icon('arrowUp')}</button>
        <button type="button" class="icon-btn" data-bmove="1" data-id="${esc(b.id)}" aria-label="Bajar ${esc(b.title)}" ${i === list.length - 1 ? 'disabled' : ''}>${icon('arrowDown')}</button>
        <button type="button" class="btn btn--ghost btn--sm" data-bactive="${b.active ? '0' : '1'}" data-id="${esc(b.id)}">${icon(b.active ? 'pause' : 'play')} ${b.active ? 'Pausar' : 'Activar'}</button>
        <a class="btn btn--soft btn--sm" href="#/admin/banners/${esc(b.id)}" data-link>${icon('edit')} Editar</a>
        <button type="button" class="btn btn--ghost btn--sm" data-bdel="${esc(b.id)}" aria-label="Eliminar ${esc(b.title)}"${one ? ' disabled title="Debe quedar al menos uno. Si no quieres que se vea, páusalo."' : ''}>${icon('trash')}</button>
      </div>
    </li>`;
  }).join('');
}

// ── Lista ────────────────────────────────────────────────────
export function adminBannersPage(params, query = {}) {
  const guard = adminGuard() || bannersWait();
  if (guard) return guard;
  const list = adminBannerList('hero').map(withLiveText);
  const live = liveBanners('hero').map(withLiveText);
  const promos = adminBannerList('promo');
  const livePromos = liveBanners('promo');
  const fullPromos = promos.length >= MAX_PROMOS;
  const { hero, heroM, promo } = PHOTO_SIZES;

  const heroView = live.length
    ? `<div class="bnow__view">
        ${stageHtml(heroCarouselHtml(live, { id: 'bhero', label: 'Vista de la portada' }), { width: PLACES.hero.stage })}
        <button type="button" class="btn btn--primary btn--sm bnow__edit" id="bhero-edit">${icon('edit')} Editar este banner</button>
      </div>`
    : `<div class="chart-empty">${icon('image')}<p><b>No hay banners activos hoy.</b><br>La portada se muestra sin carrusel hasta que actives uno.</p></div>`;
  const promoView = livePromos.length
    ? stageHtml(`<div class="split">${livePromos.map((b) => `<div class="bnow__item">${promoCardHtml(b, { tag: 'div' })}<a class="btn btn--primary btn--sm bnow__edit" href="#/admin/banners/${esc(b.id)}" data-link>${icon('edit')} Editar</a></div>`).join('')}</div>`, { width: PLACES.hero.stage, id: 'bpromos' })
    : `<div class="chart-empty">${icon('image')}<p><b>No hay banners de abajo activos hoy.</b><br>La portada se muestra sin ellos hasta que actives uno.</p></div>`;
  const promoLive = new Set(livePromos.map((b) => b.id));

  const body = `<section class="panel bnow" id="b-hero">
      <div class="panel__head"><h2 class="panel__title">Así se ve hoy tu portada</h2><a class="link-more" href="#/" data-link>Ir a la portada ${icon('arrowRight')}</a></div>
      <p class="bnow__sizes">${icon('image')}<span>Medida de la foto del carrusel: <b>${sizeText(hero)}</b> para computador y <b>${sizeText(heroM)}</b> para celular (opcional). Toca <b>Editar este banner</b> para cambiar el que se ve.</span></p>
      ${heroView}
    </section>
    ${list.some((b) => b.builtin) ? notice('info', 'Estos son los <b>banners de ejemplo</b>. Apenas edites, agregues, ordenes o pauses alguno, pasan a ser tuyos.') : ''}
    ${list.length ? `<ol class="blist">${bannerRows(list, new Set(live.map((b) => b.id)))}</ol>` : emptyState({ icon: 'image', title: 'Aún no hay banners', text: 'Crea el primero para destacar ofertas, campañas o servicios en la portada.', actions: '<a class="btn btn--primary" href="#/admin/banners/nuevo" data-link>Crear banner</a>' })}

    <section class="panel bnow" id="b-promo">
      <div class="panel__head"><h2 class="panel__title">Banners de más abajo</h2><span class="muted">Los recuadros grandes después de «Ofertas destacadas»</span></div>
      <p class="bnow__sizes">${icon('image')}<span>Medida de la foto: <b>${sizeText(promo)}</b>. Se ven hasta ${PROMO_VISIBLE}, de a dos por fila; si queda uno solo en su fila, ocupa todo el ancho.</span></p>
      ${promoView}
    </section>
    ${promos.some((b) => b.builtin) ? notice('info', 'Estos son los <b>banners de ejemplo</b> de más abajo. Apenas edites, agregues, ordenes o pauses alguno, pasan a ser tuyos.') : ''}
    ${promos.filter((b) => bannerStatus(b) === 'activo').length > PROMO_VISIBLE ? notice('warn', `Tienes más de ${PROMO_VISIBLE} banners de abajo activos. Se muestran los primeros ${PROMO_VISIBLE} de la lista; ordénalos con las flechas.`) : ''}
    <ol class="blist blist--promo">${bannerRows(promos, promoLive)}</ol>
    <div class="blist__more">${fullPromos
      ? `<button type="button" class="btn btn--soft" disabled title="Puedes guardar hasta ${MAX_PROMOS}">${icon('plus')} Nuevo banner de abajo</button><span class="muted">Llegaste al máximo de ${MAX_PROMOS}.</span>`
      : `<a class="btn btn--soft" href="#/admin/banners/nuevo?lugar=abajo" data-link>${icon('plus')} Nuevo banner de abajo</a>`}</div>`;

  let stop = null;
  let unstage = null;
  return {
    title: 'Banners · Administración',
    rerender: ['banners', 'backoffice', 'catalog'],
    html: adminShell('banners', 'Banners de la portada', body, {
      sub: 'El carrusel de arriba de la portada y los banners grandes de más abajo. Edita el texto, sube tus fotos, ordénalos, pausa los que no quieras mostrar o programa fechas.',
      actions: `<a class="btn btn--primary btn--sm" href="#/admin/banners/nuevo" data-link>${icon('plus')} Nuevo banner</a>`,
    }),
    mount(root) {
      stop = mountHeroCarousel($('#bhero', root));
      unstage = mountStages(root);
      if (query.ver === 'abajo') $('#b-promo', root)?.scrollIntoView({ block: 'start' });
      // En la vista de la portada, el botón del banner abre su edición (no la tienda)
      const editShown = () => {
        const slides = $$('#bhero .hero__slide', root);
        const i = Math.max(0, slides.findIndex((s) => s.classList.contains('is-on')));
        if (live[i]) go(`/admin/banners/${live[i].id}`);
      };
      $('#bhero-edit', root)?.addEventListener('click', editShown);
      root.addEventListener('click', (e) => {
        if (!e.target.closest('#bhero a, #bpromos .promo-card')) return;
        e.preventDefault();
        e.stopPropagation();
        if (e.target.closest('#bhero')) editShown();
      }, true);
      root.addEventListener('click', async (e) => {
        const mv = e.target.closest('[data-bmove]');
        const ac = e.target.closest('[data-bactive]');
        const del = e.target.closest('[data-bdel]');
        const btn = mv || ac;
        try {
          if (mv) {
            mv.disabled = true;
            await moveBanner(mv.dataset.id, Number(mv.dataset.bmove));
          } else if (ac) {
            ac.disabled = true;
            await setBannerActive(ac.dataset.id, ac.dataset.bactive === '1');
            toast(ac.dataset.bactive === '1' ? 'El banner vuelve a la tienda.' : 'Pausaste el banner: ya no se muestra.', { tone: 'info' });
          } else if (del) {
            const b = findBanner(del.dataset.bdel);
            if (!(await confirmDialog({ title: '¿Eliminar este banner?', text: `Se eliminará <b>${esc(b?.title || '')}</b> de la portada.`, confirmText: 'Eliminar banner', danger: true }))) return;
            await deleteBanner(del.dataset.bdel);
            toast('Eliminaste el banner.', { tone: 'info' });
          }
        } catch (err) {
          saveError(err);
        } finally {
          if (btn?.isConnected) btn.disabled = false;
        }
      });
      return () => { stop?.(); unstage?.(); };
    },
  };
}

// ── Crear / editar ───────────────────────────────────────────
export function productOptions(sel) {
  return CATEGORIES.map((c) => `<optgroup label="${esc(c.name)}">${PRODUCTS.filter((p) => p.cat === c.id)
    .sort((a, b) => a.name.localeCompare(b.name, 'es'))
    .map((p) => `<option value="${p.id}"${p.id === sel ? ' selected' : ''}>${esc(p.name)} · ${esc(p.brand)}</option>`).join('')}</optgroup>`).join('');
}

export function destSelect(d, idp = 'b') {
  const opt = (v, l) => `<option value="${esc(v)}"${v === d.dest ? ' selected' : ''}>${esc(l)}</option>`;
  return `<select id="${idp}-dest" name="dest">
    <optgroup label="Secciones">${SECTIONS.map(([v, l]) => opt(v, l)).join('')}</optgroup>
    <optgroup label="Categorías">${CAT_DESTS.map(([v, l]) => opt(v, l)).join('')}</optgroup>
    <optgroup label="Subcategorías">${SUB_DESTS.map(([v, l]) => opt(v, l)).join('')}</optgroup>
    <optgroup label="Otro">${opt('search', 'Una búsqueda…')}${opt('product', 'Un producto…')}${opt('custom', 'Otra dirección del sitio…')}</optgroup>
  </select>`;
}

function bannerForm(b, isNew, place) {
  const d = destOf(b.to);
  const promo = place === 'promo';
  const visual = b.visual || (b.art ? 'art' : 'none');
  const radio = (name, value, label, checked) => `<label class="seg-radio"><input type="radio" name="${name}" value="${value}"${checked ? ' checked' : ''}><span>${label}</span></label>`;
  const visuals = promo
    ? `${radio('visual', 'none', 'Solo color', visual !== 'photo')}${radio('visual', 'photo', 'Foto propia', visual === 'photo')}`
    : `${radio('visual', 'art', 'Ilustración', visual === 'art')}${radio('visual', 'product', 'Dibujo de un producto', visual === 'product')}${radio('visual', 'photo', 'Foto propia', visual === 'photo')}${radio('visual', 'none', 'Sin imagen', visual === 'none')}`;
  return `<form id="bform" class="bform" novalidate>
    <fieldset class="panel form-grid"><legend class="panel__title">Texto</legend>
      <div class="field"><label for="b-eyebrow">Etiqueta superior <span class="field__opt">(opcional)</span></label><input id="b-eyebrow" name="eyebrow" maxlength="40" value="${esc(b.eyebrow || '')}" placeholder="Ej: Ofertas de la semana"><p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="b-cta">Texto del botón</label><input id="b-cta" name="cta" maxlength="30" value="${esc(b.cta || 'Ver más')}" required><p class="field__error" aria-live="polite"></p></div>
      <div class="field field--full"><label for="b-title">Título</label><input id="b-title" name="title" maxlength="90" value="${esc(b.title || '')}" required placeholder="Ej: Hasta 30% en vitaminas"><p class="field__error" aria-live="polite"></p></div>
      <div class="field field--full"><label for="b-text">Texto <span class="field__opt">(opcional)</span></label><textarea id="b-text" name="text" maxlength="180" rows="2" placeholder="Una frase corta que explique la oferta o el servicio">${esc(b.text || '')}</textarea><p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="b-dest">El botón lleva a</label>${destSelect(d)}<p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="search"${d.dest === 'search' ? '' : ' hidden'}><label for="b-q">Palabra a buscar</label><input id="b-q" name="q" value="${esc(d.q || '')}" placeholder="Ej: protector solar"><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="product"${d.dest === 'product' ? '' : ' hidden'}><label for="b-dprod">Producto</label><select id="b-dprod" name="dprod"><option value="">Elegir producto…</option>${productOptions(d.dprod)}</select><p class="field__error" aria-live="polite"></p></div>
      <div class="field" data-dest="custom"${d.dest === 'custom' ? '' : ' hidden'}><label for="b-path">Dirección (empieza con /)</label><input id="b-path" name="path" value="${esc(d.path || '')}" placeholder="Ej: /categoria/belleza"><p class="field__error" aria-live="polite"></p></div>
    </fieldset>
    <fieldset class="panel bform__design"><legend class="panel__title">Diseño</legend>
      <div class="bform__color" data-colorpick${visual === 'photo' ? ' hidden' : ''}><p class="bform__label">Color de fondo</p>
      <div class="swatches" role="radiogroup" aria-label="Color de fondo">${Object.entries(TONES).map(([k, label]) => `<label class="swatch swatch--${k}"><input type="radio" name="tone" value="${k}"${(b.tone || 'lapis') === k ? ' checked' : ''}><span class="swatch__chip" aria-hidden="true"></span><span>${esc(label)}</span></label>`).join('')}
        <label class="swatch__picker" data-tone="custom"${b.tone === 'custom' ? '' : ' hidden'}><span class="visually-hidden">Elegir color</span><input type="color" name="color" value="${esc(b.color || '#2F5BC4')}"></label></div></div>
      <p class="bform__label">Imagen del banner</p>
      <div class="seg seg--radios" role="radiogroup" aria-label="Imagen">${visuals}</div>
      ${promo ? '' : `<div class="field" data-visual="art"${visual === 'art' ? '' : ' hidden'}><label for="b-art">Ilustración</label><select id="b-art" name="art">${Object.entries(ART_LABELS).map(([k, l]) => `<option value="${k}"${(b.art || 'be') === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
      <div class="field" data-visual="product"${visual === 'product' ? '' : ' hidden'}><label for="b-vprod">Producto a mostrar</label><select id="b-vprod" name="vprod"><option value="">Elegir producto…</option>${productOptions(b.productId)}</select><p class="field__error" aria-live="polite"></p></div>`}
      <p class="bform__photo-hint" data-visual="photo"${visual === 'photo' ? '' : ' hidden'}>${icon('info', 'inline-ico')} La foto se sube en <a href="#bside" data-jump>«Carga la imagen aquí»</a>, al lado de la vista previa.</p>
    </fieldset>
    <fieldset class="panel form-grid"><legend class="panel__title">Publicación</legend>
      <div class="field full"><label class="switch"><input type="checkbox" name="active"${b.active === false ? '' : ' checked'}><span class="switch__track" aria-hidden="true"></span><span><b>Mostrar en la portada</b><small>Si lo apagas, el banner queda guardado pero no se ve.</small></span></label></div>
      <div class="field"><label for="b-from">Mostrar desde <span class="field__opt">(opcional)</span></label><input id="b-from" name="from" type="date" value="${esc(b.from || '')}"><p class="field__error" aria-live="polite"></p></div>
      <div class="field"><label for="b-until">Mostrar hasta <span class="field__opt">(opcional)</span></label><input id="b-until" name="until" type="date" value="${esc(b.until || '')}"><p class="field__error" aria-live="polite"></p></div>
    </fieldset>
    <div class="pform__actions"><button class="btn btn--primary btn--lg" type="submit">${isNew ? `${icon('plus')} Crear banner` : 'Guardar banner'}</button><a class="btn btn--ghost btn--lg" href="#/admin/banners${promo ? '?ver=abajo' : ''}" data-link>Cancelar</a>${isNew ? '' : `<button type="button" class="btn btn--ghost btn--lg bform__del" data-bdel>${icon('trash')} Eliminar</button>`}</div>
  </form>`;
}

/** Dirección del sitio elegida en el formulario (campos dest, q, dprod y path). */
export function destTo(v) {
  if (v.dest === 'search') return `/buscar?q=${encodeURIComponent(v.q.trim())}`;
  if (v.dest === 'product') { const p = byId.get(v.dprod); return p ? `/producto/${p.slug}` : '/'; }
  if (v.dest === 'custom') return v.path.trim();
  return v.dest;
}

/** Errores de la dirección elegida (los mismos para banners, tarjetas del menú y servicios). */
export function destErrors(v, e = {}) {
  if (v.dest === 'search' && !v.q.trim()) e.q = 'Escribe qué palabra buscar.';
  if (v.dest === 'product' && !v.dprod) e.dprod = 'Elige el producto.';
  if (v.dest === 'custom' && !/^\/(?!\/)[\w\-/?=&%.~+]*$/.test(v.path.trim())) e.path = 'Escribe una dirección del sitio que empiece con /.';
  return e;
}

function bannerFromForm(v, cur, place, pics) {
  const to = destTo(v);
  const visual = v.visual || 'none';
  const photo = visual === 'photo';
  return {
    ...cur,
    place,
    eyebrow: v.eyebrow.trim(),
    title: v.title.trim(),
    text: v.text.trim(),
    cta: v.cta.trim() || 'Ver más',
    to,
    tone: v.tone || 'lapis',
    color: v.tone === 'custom' ? v.color : '',
    visual,
    art: visual === 'art' ? v.art : '',
    productId: visual === 'product' ? v.vprod : '',
    image: photo ? (pics.image || '') : '',
    imageM: photo && place === 'hero' ? (pics.imageM || '') : '',
    photoOnly: photo && pics.photoOnly,
    active: !!v.active,
    from: v.from || '',
    until: v.until || '',
  };
}

function validate(v, image) {
  const e = {};
  if (!v.title.trim()) e.title = 'Escribe el título del banner.';
  if (!v.cta.trim()) e.cta = 'Escribe el texto del botón.';
  destErrors(v, e);
  if (v.visual === 'product' && !v.vprod) e.vprod = 'Elige el producto que se verá en el banner.';
  if (v.visual === 'photo' && !image) e.photo = 'Sube la foto del banner.';
  if (v.from && v.until && v.until < v.from) e.until = 'La fecha final debe ser posterior a la inicial.';
  return e;
}

/** Vista previa de un banner tal como se ve en la tienda (sin enlaces). */
function previewHtml(b, place, id) {
  if (place === 'promo') return `<div class="split" id="${id}">${promoCardHtml(b, { tag: 'div' })}</div>`;
  const slide = bannerSlideHtml(b, 0, 1);
  return `<div class="hero hero--preview${slide.includes('hero__slide--light') ? ' hero--light' : ''}" id="${id}"><div class="hero__track">${slide}</div></div>`;
}

export function adminBannerPage(params, query = {}) {
  const guard = adminGuard() || bannersWait();
  if (guard) return guard;
  const isNew = params.id === 'nuevo' || !params.id;
  const back = (place) => `<a class="btn btn--ghost btn--sm" href="#/admin/banners${place === 'promo' ? '?ver=abajo' : ''}" data-link>${icon('arrowLeft')} Banners</a>`;
  const newPlace = query.lugar === 'abajo' ? 'promo' : 'hero';
  if (isNew && newPlace === 'promo' && adminBannerList('promo').length >= MAX_PROMOS) {
    return { title: 'Banners · Administración', html: adminShell('banners', 'Nuevo banner de abajo', emptyState({ icon: 'image', title: `Ya tienes ${MAX_PROMOS} banners de abajo`, text: 'Elimina alguno que ya no uses para crear otro.', actions: '<a class="btn btn--primary" href="#/admin/banners?ver=abajo" data-link>Volver a banners</a>' }), { actions: back('promo') }) };
  }
  const cur = isNew
    ? (newPlace === 'promo'
      ? { place: 'promo', title: '', eyebrow: '', text: '', cta: 'Ver más', to: '/ofertas', tone: 'lapis', visual: 'none', active: true }
      : { place: 'hero', title: '', eyebrow: '', text: '', cta: 'Ver más', to: '/ofertas', tone: 'lapis', visual: 'art', art: 'be', active: true })
    : findBanner(params.id);
  if (!cur) {
    return { title: 'Banner no encontrado', html: adminShell('banners', 'Banner no encontrado', emptyState({ icon: 'image', title: 'No encontramos ese banner', text: 'Puede que se haya eliminado.', actions: '<a class="btn btn--primary" href="#/admin/banners" data-link>Volver a banners</a>' })) };
  }
  const place = placeOf(cur);
  const P = PLACES[place];
  const promo = place === 'promo';
  const start = withLiveText(cur);
  const hasPhoto = cur.visual === 'photo';
  const pics = { image: hasPhoto ? cur.image || '' : '', imageM: hasPhoto ? cur.imageM || '' : '', photoOnly: hasPhoto && cur.photoOnly === true };

  const side = `<aside class="beditor__side" id="bside">
      ${imageDropHtml({ name: 'photo', title: 'Carga la imagen aquí', size: P.size, image: pics.image, note: promo ? 'Si usas tu texto encima, deja más libre el lado izquierdo.' : 'Si usas tu texto encima, deja más libre el lado izquierdo: ahí va el texto.' })}
      ${promo ? '' : imageDropHtml({ name: 'photoM', title: 'Foto para celular', optional: true, size: P.sizeM, image: pics.imageM, note: 'Si no subes una, en el celular se usa la del computador, recortada al centro.' })}
      <fieldset class="beditor__mode"><legend class="bform__label">¿Cómo se usa la foto?</legend>
        <label class="radio-row"><input type="radio" name="photoOnly" value="0"${pics.photoOnly ? '' : ' checked'}><span><b>Con mi texto encima</b><small>Se oscurece un poco para que el texto se lea.</small></span></label>
        <label class="radio-row"><input type="radio" name="photoOnly" value="1"${pics.photoOnly ? ' checked' : ''}><span><b>Solo la foto</b><small>Para una imagen que ya trae su propio texto (por ejemplo, hecha en Canva). Todo el banner es el enlace.</small></span></label>
      </fieldset>
    </aside>`;

  const body = `<section class="panel beditor">
      <div class="panel__head"><h2 class="panel__title">Vista previa</h2><span class="muted">${promo ? 'Así se verá más abajo en la portada' : 'Así se verá en el carrusel de la portada'}</span></div>
      <div class="beditor__grid">
        <div class="beditor__prevs">
          <p class="beditor__dev">${icon('monitor')} En computador</p>
          ${stageHtml(previewHtml(start, place, 'bpreview'), { width: P.stage, id: 'bstage' })}
          <p class="beditor__dev">${icon('mobile')} En celular</p>
          <div class="beditor__phone">${stageHtml(previewHtml(start, place, 'bpreview-m'), { width: P.phone, id: 'bstage-m' })}</div>
        </div>
        ${side}
      </div>
    </section>
    ${cur.dynamic === 'club' ? notice('info', 'Hoy este banner muestra solo la <b>campaña del Club de cada día</b>. Si cambias la etiqueta, el título o el texto, quedará fijo con lo que escribas.') : ''}
    ${bannerForm(cur, isNew, place)}`;
  const title = isNew ? (promo ? 'Nuevo banner de abajo' : 'Nuevo banner') : (promo ? 'Editar banner de abajo' : 'Editar banner');
  return {
    title: `${title} · Administración`,
    html: adminShell('banners', title, body, { actions: back(place) }),
    onState: () => true, // no repintar mientras se edita
    mount(root) {
      const f = $('#bform', root);
      const prevD = $('#bstage .pstage__in', root);
      const prevM = $('#bstage-m .pstage__in', root);
      const unstage = mountStages(root);
      const sync = () => {
        const v = formData(f);
        $$('[data-dest]', f).forEach((el) => { el.hidden = el.dataset.dest !== v.dest; });
        $$('[data-visual]', f).forEach((el) => { el.hidden = el.dataset.visual !== v.visual; });
        $('[data-tone="custom"]', f).hidden = v.tone !== 'custom';
        $('[data-colorpick]', f).hidden = v.visual === 'photo';
        root.querySelector('.beditor__side').classList.toggle('is-photo', v.visual === 'photo');
        const draft = bannerFromForm(v, cur, place, pics);
        // El banner del Club sigue con su texto automático hasta que se edite
        const auto = cur.dynamic === 'club' && draft.title === cur.title && draft.text === (cur.text || '') && draft.eyebrow === (cur.eyebrow || '');
        const shown = auto ? withLiveText(draft) : draft;
        prevD.innerHTML = previewHtml(shown, place, 'bpreview');
        prevM.innerHTML = previewHtml(shown, place, 'bpreview-m');
      };
      const setVisual = (val) => {
        const r = f.querySelector(`input[name=visual][value="${val}"]`);
        if (r) r.checked = true;
      };
      const drop = mountImageDrop($('[data-idrop="photo"]', root), {
        size: P.size,
        maxW: P.maxW,
        maxChars: P.maxChars,
        onChange(url) {
          pics.image = url;
          if (url) setVisual('photo');
          else if (formData(f).visual === 'photo') setVisual(promo ? 'none' : 'art');
          sync();
        },
      });
      const boxM = $('[data-idrop="photoM"]', root);
      if (boxM) {
        mountImageDrop(boxM, {
          size: P.sizeM,
          maxW: P.maxWM,
          maxChars: P.maxCharsM,
          onChange(url) {
            pics.imageM = url;
            if (url && pics.image) setVisual('photo');
            sync();
          },
        });
      }
      $$('input[name=photoOnly]', root).forEach((r) => r.addEventListener('change', () => { pics.photoOnly = r.value === '1' && r.checked; sync(); }));
      f.addEventListener('input', debounce(sync, 120));
      f.addEventListener('change', sync);
      // Las vistas previas son solo para mirar: sus enlaces no navegan
      root.addEventListener('click', (e) => {
        if (e.target.closest('.beditor__prevs a')) { e.preventDefault(); e.stopPropagation(); }
        const jump = e.target.closest('[data-jump]');
        if (jump) { e.preventDefault(); $('#bside', root).scrollIntoView({ behavior: 'smooth', block: 'center' }); }
      }, true);
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = formData(f);
        const errors = validate(v, pics.image);
        drop.setError(errors.photo || '');
        if (!setErrors(f, errors)) {
          if (errors.photo && Object.keys(errors).length === 1) $('#bside', root).scrollIntoView({ behavior: 'smooth', block: 'center' });
          return;
        }
        const btn = $('button[type=submit]', f);
        btn.disabled = true;
        try {
          await saveBanner(bannerFromForm(v, isNew ? {} : cur, place, pics));
          toast(isNew ? 'Creaste el banner. Ya está en la portada.' : 'Guardamos los cambios del banner.');
          go(promo ? '/admin/banners?ver=abajo' : '/admin/banners');
        } catch (err) {
          saveError(err);
        } finally {
          btn.disabled = false;
        }
      });
      root.addEventListener('click', async (e) => {
        if (!e.target.closest('[data-bdel]')) return;
        if (!(await confirmDialog({ title: '¿Eliminar este banner?', text: `Se eliminará <b>${esc(cur.title)}</b> de la portada.`, confirmText: 'Eliminar banner', danger: true }))) return;
        try { await deleteBanner(cur.id); toast('Eliminaste el banner.', { tone: 'info' }); go(promo ? '/admin/banners?ver=abajo' : '/admin/banners', { replace: true }); } catch (err) { saveError(err); }
      });
      sync();
      return () => unstage();
    },
  };
}

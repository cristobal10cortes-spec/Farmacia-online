// Cotiza tu receta: escribe los medicamentos (con el buscador tolerante a errores)
// o envía una foto de la receta.

import { $, $$, esc, debounce, formData, setErrors } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { breadcrumbs, field, notice, rxChip, beSeal } from '../ui/components.js';
import { highlight } from '../engine/text.js';
import { productIndex, byId, alternativesFor, unitPrice } from '../engine/catalog.js';
import { priceInfo } from '../engine/pricing.js';
import { priceCtx, addToCart, maxQty } from '../engine/shop.js';
import { state, emit, currentUser } from '../engine/state.js';
import { validEmail, validPhone } from '../engine/rut.js';
import { clp } from '../engine/format.js';
import { toast } from '../ui/overlay.js';
import { go } from '../router.js';

const quote = { lines: [] }; // [{ id, qty }]

function linesHtml() {
  if (!quote.lines.length) return `<p class="muted">Aún no agregas medicamentos. Escríbelos arriba tal como aparecen en tu receta.</p>`;
  const ctx = priceCtx();
  return quote.lines.map((l) => {
    const p = byId.get(l.id);
    const info = priceInfo(p, ctx);
    const cheaper = alternativesFor(p).filter((a) => unitPrice(a) < unitPrice(p)).slice(0, 2);
    return `<div class="qline" data-q="${p.id}">
      <img src="${productImg(p)}" alt="" width="56" height="56">
      <div style="display:grid;gap:4px;min-width:0"><b>${esc(p.name)}</b><span class="muted" style="font-size:13px">${esc(p.brand)} · ${clp(info.sale)} c/u</span><div style="display:flex;gap:6px;flex-wrap:wrap">${rxChip(p)}${p.be ? beSeal() : ''}</div></div>
      <div style="display:grid;justify-items:end;gap:6px">
        <b>${clp(info.sale * l.qty)}</b>
        <div class="stepper stepper--inline" role="group" aria-label="Cantidad"><button type="button" class="stepper__btn" data-qq="-1" data-id="${p.id}" aria-label="${l.qty <= 1 ? 'Quitar' : 'Menos'}">${icon(l.qty <= 1 ? 'trash' : 'minus')}</button><span class="stepper__val">${l.qty}</span><button type="button" class="stepper__btn" data-qq="1" data-id="${p.id}" aria-label="Más" ${l.qty >= maxQty(p) ? 'disabled' : ''}>${icon('plus')}</button></div>
      </div>
      ${p.rx === 'cheque' ? `<div class="qline__alt">${icon('store')}<span>Receta cheque: solo venta presencial en farmacia. Te mostramos el precio como referencia.</span></div>` : ''}
      ${cheaper.length ? `<div class="qline__alt">${icon('scale')}<span>Alternativa más económica:</span>${cheaper.map((a) => `<button type="button" class="chip chip--ok" data-swap="${p.id}" data-to="${a.id}">${esc(a.brand)} ${clp(priceInfo(a, ctx).sale)}${a.be ? ' · BE' : ''}</button>`).join('')}</div>` : ''}
    </div>`;
  }).join('');
}

function totalHtml() {
  const ctx = priceCtx();
  const total = quote.lines.reduce((a, l) => a + priceInfo(byId.get(l.id), ctx).sale * l.qty, 0);
  const rx = quote.lines.some((l) => byId.get(l.id).rx !== 'directa');
  return `<div class="panel summary">
    <h2 class="panel__title">Tu cotización</h2>
    <div class="summary__rows"><div class="summary__row"><span>Medicamentos</span><span>${quote.lines.reduce((a, l) => a + l.qty, 0)}</span></div></div>
    <div class="summary__total"><span>Total estimado</span><b>${clp(total)}</b></div>
    ${rx ? '<p class="field__hint">Incluye medicamentos con receta: la adjuntarás al pagar.</p>' : ''}
    <button type="button" class="btn btn--primary btn--lg btn--block" data-q-all ${quote.lines.length ? '' : 'disabled'}>${icon('bag')} Agregar todo al carro</button>
    <button type="button" class="btn btn--ghost btn--block" data-q-clear ${quote.lines.length ? '' : 'disabled'}>Vaciar cotización</button>
    <p class="field__hint">Precios de internet vigentes. El despacho se calcula al pagar.</p>
  </div>`;
}

export function quotePage(params, query) {
  const u = currentUser();
  const tab = query.modo === 'foto' ? 'foto' : 'escribir';
  const html = `<div class="wrap page page--tight">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: 'Cotiza tu receta' }])}
    <div class="page-head"><h1 class="page-title">Cotiza tu receta</h1><p class="page-sub">Escribe los medicamentos de tu receta (aunque no sepas cómo se escriben) o envíanos una foto y te contactamos con la cotización.</p></div>
    <div class="tabs" role="tablist"><a class="tab ${tab === 'escribir' ? 'is-active' : ''}" role="tab" aria-selected="${tab === 'escribir'}" href="#/cotizar-receta" data-link>${icon('edit', 'inline-ico')} Escribir medicamentos</a><a class="tab ${tab === 'foto' ? 'is-active' : ''}" role="tab" aria-selected="${tab === 'foto'}" href="#/cotizar-receta?modo=foto" data-link>${icon('upload', 'inline-ico')} Enviar foto de la receta</a></div>
    ${tab === 'escribir' ? `<div class="quote">
      <div style="display:grid;gap:14px;min-width:0">
        <div class="quote-search">
          <label class="field" for="qs"><span style="font-weight:700;font-size:13.5px;color:var(--ink-2)">Medicamento</span></label>
          <div class="search__box" style="margin-top:6px">${icon('search', 'search__ico')}<input id="qs" type="search" placeholder="Ej: losartan 50, amoxisilina, paqazetami…" autocomplete="off" spellcheck="false" aria-controls="qac" aria-expanded="false" role="combobox"></div>
          <div class="ac" id="qac" role="listbox" hidden></div>
        </div>
        <div style="display:grid;gap:10px" id="qlines">${linesHtml()}</div>
      </div>
      <aside class="sticky-col" id="qtotal">${totalHtml()}</aside>
    </div>` : `<div class="quote">
      <form class="panel form-grid" id="photo-form" novalidate>
        <label class="rx-upload__drop full" style="position:relative">${icon('upload')}<span id="photo-name"><b>Sube la foto de tu receta</b> · JPG, PNG o PDF hasta 8 MB</span><input type="file" name="file" accept="image/*,application/pdf"></label>
        <p class="field__error full" id="photo-error" aria-live="polite"></p>
        ${field({ label: 'Nombre', name: 'nombre', value: u ? `${u.nombre} ${u.apellidoP}` : '', required: true })}
        ${field({ label: 'Celular', name: 'phone', type: 'tel', value: u?.phone || '', required: true, placeholder: '+56 9 1234 5678' })}
        ${field({ label: 'Correo', name: 'email', type: 'email', value: u?.email || '', required: true })}
        ${field({ label: 'Comuna', name: 'comuna', value: state.location.comuna, required: true })}
        ${field({ label: 'Comentarios', name: 'comentario', type: 'textarea', full: true, placeholder: 'Ej: prefiero alternativas bioequivalentes' })}
        <div class="full"><button class="btn btn--primary btn--lg" type="submit">Enviar receta</button></div>
      </form>
      <aside class="sticky-col">${notice('info', 'Un químico farmacéutico revisa tu receta y te envía la cotización con las alternativas más convenientes en menos de 2 horas hábiles. Tus datos de salud son confidenciales.', 'shield')}</aside>
    </div>`}
  </div>`;

  return {
    title: 'Cotiza tu receta',
    html,
    mount(root) {
      if (tab === 'foto') {
        const f = $('#photo-form', root);
        let file = null;
        f.file.addEventListener('change', () => {
          file = f.file.files?.[0] || null;
          $('#photo-name', root).innerHTML = file ? `<b>${esc(file.name)}</b> · listo para enviar` : '<b>Sube la foto de tu receta</b> · JPG, PNG o PDF hasta 8 MB';
        });
        f.addEventListener('submit', (e) => {
          e.preventDefault();
          const v = formData(f);
          const errors = {};
          if (!v.nombre.trim()) errors.nombre = 'Ingresa tu nombre.';
          if (!validPhone(v.phone)) errors.phone = 'Ingresa un celular de 9 dígitos que comience con 9.';
          if (!validEmail(v.email)) errors.email = 'Ingresa un correo válido.';
          if (!v.comuna.trim()) errors.comuna = 'Ingresa tu comuna.';
          const fileErr = !file ? 'Adjunta la foto o PDF de tu receta.' : file.size > 8 * 1024 * 1024 ? 'El archivo pesa más de 8 MB.' : '';
          $('#photo-error', root).textContent = fileErr;
          if (!setErrors(f, errors) || fileErr) return;
          const folio = `CT-${Math.floor(100000 + Math.random() * 899999)}`;
          state.quotes.unshift({ folio, at: Date.now(), nombre: v.nombre, email: v.email, file: file.name });
          emit('quotes');
          f.outerHTML = `<div class="panel" style="display:grid;gap:12px">${notice('ok', `Recibimos tu receta (folio <b>${folio}</b>). Te enviaremos la cotización a <b>${esc(v.email)}</b> y por WhatsApp. (Demostración: no se envían mensajes.)`)}<a class="btn btn--ghost" href="#/cotizar-receta" data-link style="justify-self:start">Mejor escribir los medicamentos</a></div>`;
        });
        return null;
      }
      const input = $('#qs', root);
      const ac = $('#qac', root);
      let idx = -1;
      const refresh = () => {
        $('#qlines', root).innerHTML = linesHtml();
        $('#qtotal', root).innerHTML = totalHtml();
      };
      const add = (id) => {
        const l = quote.lines.find((x) => x.id === id);
        if (l) l.qty = Math.min(maxQty(byId.get(id)), l.qty + 1);
        else quote.lines.push({ id, qty: 1 });
        input.value = '';
        ac.hidden = true;
        input.setAttribute('aria-expanded', 'false');
        refresh();
        input.focus();
      };
      const show = () => {
        const v = input.value.trim();
        idx = -1;
        if (v.length < 2) { ac.hidden = true; input.setAttribute('aria-expanded', 'false'); return; }
        const r = productIndex.search(v, { prefix: true });
        const items = r.items.map((it) => byId.get(it.id)).sort((a, b) => b.isMedicine - a.isMedicine).slice(0, 7);
        ac.innerHTML = items.length
          ? `${r.corrected ? `<p class="ac__fix">${icon('sparkle')}<span>Mostrando resultados para <b>${esc(r.corrected)}</b></span></p>` : ''}<div class="ac__col">${items.map((p, i) => `<button type="button" class="ac__opt ac__prod" role="option" id="qo${i}" data-add="${p.id}" style="width:100%;border:0;background:none;text-align:left"><img src="${productImg(p)}" alt="" width="46" height="46"><span class="ac__prod-main"><em>${esc(p.brand)}</em><span>${highlight(p.name, r.terms, esc)}</span></span><span class="ac__prod-price"><b>${clp(p.offer || p.price)}</b></span></button>`).join('')}</div>`
          : `<p class="ac__empty">No encontramos “${esc(v)}”. Prueba con el principio activo que aparece en la receta.</p>`;
        ac.hidden = false;
        input.setAttribute('aria-expanded', 'true');
      };
      input.addEventListener('input', debounce(show, 90));
      input.addEventListener('keydown', (e) => {
        const opts = $$('[data-add]', ac);
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          if (!opts.length) return;
          idx = e.key === 'ArrowDown' ? (idx + 1) % opts.length : (idx - 1 + opts.length) % opts.length;
          opts.forEach((o, i) => o.classList.toggle('is-active', i === idx));
        } else if (e.key === 'Enter') {
          e.preventDefault();
          const o = opts[idx >= 0 ? idx : 0];
          if (o) add(o.dataset.add);
        } else if (e.key === 'Escape') {
          ac.hidden = true;
        }
      });
      root.addEventListener('click', (e) => {
        const a = e.target.closest('[data-add]');
        if (a) { add(a.dataset.add); return; }
        const qq = e.target.closest('[data-qq]');
        if (qq) {
          const l = quote.lines.find((x) => x.id === qq.dataset.id);
          if (!l) return;
          l.qty += Number(qq.dataset.qq);
          if (l.qty <= 0) quote.lines = quote.lines.filter((x) => x !== l);
          refresh();
          return;
        }
        const sw = e.target.closest('[data-swap]');
        if (sw) {
          const l = quote.lines.find((x) => x.id === sw.dataset.swap);
          const dup = quote.lines.find((x) => x.id === sw.dataset.to);
          if (l && dup) {
            dup.qty = Math.min(maxQty(byId.get(dup.id)), dup.qty + l.qty);
            quote.lines = quote.lines.filter((x) => x !== l);
          } else if (l) l.id = sw.dataset.to;
          refresh();
          toast('Cambiamos a la alternativa más económica.');
          return;
        }
        if (e.target.closest('[data-q-clear]')) { quote.lines = []; refresh(); return; }
        if (e.target.closest('[data-q-all]')) {
          const online = quote.lines.filter((l) => byId.get(l.id).rx !== 'cheque');
          const store = quote.lines.length - online.length;
          for (const l of online) addToCart(l.id, l.qty);
          const n = online.length;
          quote.lines = quote.lines.filter((l) => byId.get(l.id).rx === 'cheque');
          if (!n) { refresh(); toast('Los medicamentos de receta cheque solo se venden en farmacia.', { tone: 'warn' }); return; }
          toast(`Agregamos ${n} ${n === 1 ? 'medicamento' : 'medicamentos'} a tu carro.${store ? ` ${store === 1 ? 'Uno es' : `${store} son`} de receta cheque y solo se ${store === 1 ? 'vende' : 'venden'} en farmacia.` : ''}`, { actionText: 'Ver carro', onAction: () => go('/carro') });
          go('/carro');
          return;
        }
        if (!e.target.closest('.quote-search')) ac.hidden = true;
      });
      return null;
    },
  };
}

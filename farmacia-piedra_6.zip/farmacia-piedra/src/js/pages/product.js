// Ficha de producto.

import { $, esc } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { productImg } from '../ui/art.js';
import { breadcrumbs, priceBlock, rxChip, beSeal, rail, favButton, unitPriceText, promoBadge, notice } from '../ui/components.js';
import { getProduct, alternativesFor, variantsOf, relatedTo, hasBioequivalent, unitPrice } from '../engine/catalog.js';
import { categoryById, subById } from '../data/categories.js';
import { THERAPEUTIC } from '../data/products.js';
import { REGIONS, regionById, regionLabel } from '../data/regions.js';
import { RX, CLUB } from '../config.js';
import { priceInfo, PROMO_TEXT, PROMO_LABEL, treatmentEligible } from '../engine/pricing.js';
import { priceCtx, qtyOf, maxQty, addToCart } from '../engine/shop.js';
import { productAvailability, storeStock, storeStatus } from '../engine/inventory.js';
import { state, currentUser } from '../engine/state.js';
import { toggleTreatment, joinClub } from '../engine/account.js';
import { clp, num, qtyUnits } from '../engine/format.js';
import { openModal, toast } from '../ui/overlay.js';
import { go } from '../router.js';

const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

function description(p) {
  if (!p.isMedicine) {
    // Medicamentos cargados desde una planilla sin principio activo
    if (p.cat === 'medicamentos' && !p.desc) return `<p>${esc(p.name)}. Contenido: ${esc(qtyUnits(p.units, p.unitName))}.</p><p><b>Ante cualquier duda, consulte a su médico o químico farmacéutico.</b></p>`;
    return `<p>${esc(p.desc || 'Producto de cuidado y bienestar.')}</p>`;
  }
  const cls = p.therapeutic ? THERAPEUTIC[p.therapeutic] : '';
  return `${cls ? `<p>${esc(cls)}</p>` : ''}
    <p>${esc(p.ingredients.map(cap).join(' + '))}${p.strength ? ` ${esc(p.strength)}` : ''}, ${esc(p.form)}. Contenido: ${esc(qtyUnits(p.units, p.unitName))}.</p>
    ${p.desc ? `<p>${esc(p.desc)}</p>` : ''}
    <p><b>Ante cualquier duda, consulte a su médico o químico farmacéutico.</b></p>`;
}

function usage(p) {
  const out = [];
  if (p.isMedicine) {
    out.push('Lee el folleto de información al paciente antes de usar y respeta la dosis indicada.');
    if (p.rx !== 'directa') out.push('Úsalo solo bajo prescripción médica y por el tiempo que indique tu médico.');
    else out.push('Si los síntomas persisten por más de 3 días o empeoran, consulta a un médico.');
    if (p.tags.includes('antibiotico')) out.push('Completa el tratamiento aunque te sientas mejor. No compartas antibióticos.');
  } else {
    out.push('Sigue las instrucciones de uso del envase.');
  }
  if (p.cold) out.push('Conservar refrigerado entre 2 °C y 8 °C. No congelar.');
  out.push('Mantener fuera del alcance de los niños. Guardar en un lugar fresco y seco.');
  return out.map((t) => `<p>${esc(t)}</p>`).join('');
}

function stockModal(p) {
  const regionOpts = (sel) => REGIONS.map((r) => `<option value="${r.id}"${r.id === sel ? ' selected' : ''}>${esc(regionLabel(r))}</option>`).join('');
  const comunaOpts = (rid, sel) => ['<option value="">Todas las comunas</option>', ...(regionById(rid)?.comunas || []).slice().sort((a, b) => a.localeCompare(b, 'es')).map((c) => `<option${c === sel ? ' selected' : ''}>${esc(c)}</option>`)].join('');
  const list = (rid, comuna) => {
    const av = productAvailability(p, { region: rid, comuna: comuna || regionById(rid).comunas[0] });
    const rows = av.stores.slice().sort((a, b) => (b.store.comuna === comuna) - (a.store.comuna === comuna));
    if (!rows.length) return `<p class="muted">No hay farmacias Piedra en esta región.</p>`;
    return rows.map(({ store, stock, status }) => {
      const tone = !stock ? 'danger' : stock < 4 ? 'warn' : 'ok';
      const txt = !stock ? 'Sin stock' : stock < 4 ? `Pocas unidades (${stock})` : 'Stock disponible';
      return `<div class="stock-item"><div><b>${esc(store.name)}</b><span>${esc(store.address)}, ${esc(store.comuna)}</span><br><span class="${status.open ? '' : 'muted'}">${esc(status.label)}</span></div><span class="chip chip--${tone}">${txt}</span></div>`;
    }).join('');
  };
  openModal({
    title: `${icon('store')} Stock en farmacias`,
    size: 'lg',
    html: `<p class="ov__text">Revisa en qué farmacias está disponible <b>${esc(p.name)}</b> para comprar o retirar.</p>
      <div class="form-grid" style="margin:14px 0">
        <div class="field"><label for="st-region">Región</label><select id="st-region">${regionOpts(state.location.region)}</select></div>
        <div class="field"><label for="st-comuna">Comuna</label><select id="st-comuna">${comunaOpts(state.location.region, state.location.comuna)}</select></div>
      </div>
      <div class="stock-list" id="st-list">${list(state.location.region, state.location.comuna)}</div>
      <p class="field__hint" style="margin-top:12px">La información de stock tiene un desfase de aproximadamente 30 minutos. Puede haber diferencias con las unidades disponibles en la farmacia.</p>`,
    onMount(api) {
      const r = $('#st-region', api.el);
      const c = $('#st-comuna', api.el);
      const box = $('#st-list', api.el);
      r.addEventListener('change', () => { c.innerHTML = comunaOpts(r.value, ''); box.innerHTML = list(r.value, ''); });
      c.addEventListener('change', () => { box.innerHTML = list(r.value, c.value); });
    },
  });
}

export function productPage(params) {
  const p = getProduct(params.slug);
  if (!p) return null;
  const ctx = priceCtx();
  const info = priceInfo(p, ctx);
  const av = productAvailability(p, state.location);
  const cat = categoryById(p.cat);
  const sub = subById(p.cat, p.sub);
  const alts = alternativesFor(p);
  const otherPres = alternativesFor(p, { sameStrength: false }).filter((x) => !alts.includes(x));
  const variants = variantsOf(p);
  const related = relatedTo(p, 12);
  const r = RX[p.rx];
  const user = currentUser();
  const inCart = qtyOf(p.id);
  const max = maxQty(p);
  const unit = unitPriceText(p, info);
  const beBanner = p.isMedicine && (hasBioequivalent(p) || (p.be && alts.length));
  const cheapest = alts.length ? alts[0] : null;
  const saving = cheapest && unitPrice(cheapest) < unitPrice(p) ? Math.round((unitPrice(p) - unitPrice(cheapest)) * p.units) : 0;

  const treatBlock = treatmentEligible(p) ? (() => {
    const enrolled = user?.treatment?.includes(p.id);
    let action;
    if (!user) action = `<a class="btn btn--club btn--sm" href="#/ingresar?volver=${encodeURIComponent(`/producto/${p.slug}`)}" data-link>Inicia sesión para inscribirlo</a>`;
    else if (!user.club) action = `<button type="button" class="btn btn--club btn--sm" data-join-club>Unirme al Club e inscribir</button>`;
    else action = `<button type="button" class="btn ${enrolled ? 'btn--ghost' : 'btn--club'} btn--sm" data-treat>${enrolled ? `${icon('check')} Inscrito · quitar` : 'Inscribir en Mi Tratamiento'}</button>`;
    return `<div class="treat"><div><b>${icon('refresh')} Programa Mi Tratamiento</b></div><p>¿Lo usas todos los meses? Inscríbelo y paga siempre ${CLUB.treatmentPct}% menos (socios Club, hasta ${CLUB.treatmentMax} productos).</p>${action}</div>`;
  })() : '';

  const buyArea = p.hidden
    ? `<span class="btn btn--block btn--disabled">${icon('alert')} No disponible por ahora</span>`
    : p.rx === 'cheque'
    ? `<span class="btn btn--block btn--disabled">${icon('store')} Venta solo presencial en farmacia</span>`
    : (!av.delivery.ok && !av.pickup.ok)
      ? (av.noStores
        ? `<span class="btn btn--block btn--disabled">${icon('truck')} ${esc(av.delivery.text)}</span>`
        : `<button type="button" class="btn btn--ghost btn--block btn--lg" data-stock>${icon('store')} Ver disponibilidad en farmacias</button>`)
      : `<div class="pdp__actions">
          <div class="stepper stepper--lg" role="group" aria-label="Cantidad">
            <button type="button" class="stepper__btn" data-pq="-1" aria-label="Menos">${icon('minus')}</button>
            <span class="stepper__val" id="pq">1</span>
            <button type="button" class="stepper__btn" data-pq="1" aria-label="Más">${icon('plus')}</button>
          </div>
          <button type="button" class="btn btn--primary btn--lg" data-add-qty>${icon('bag')} Agregar al carro</button>
        </div>
        <p class="field__hint" id="incart">${inCart ? `Ya tienes <b>${inCart}</b> en tu carro · <a href="#/carro" data-link>Ver carro</a>` : `Máximo ${max} unidades por compra.`}</p>`;

  const html = `<div class="wrap page page--tight">
    ${breadcrumbs([{ label: 'Inicio', href: '/' }, { label: cat.name, href: `/categoria/${cat.id}` }, { label: sub.name, href: `/categoria/${cat.id}/${sub.id}` }, { label: p.name }])}
    ${beBanner ? notice('be', `${beSeal()} <span>${p.be ? 'Este medicamento es <b>bioequivalente</b>' : 'Este medicamento tiene <b>alternativas bioequivalentes</b>'}${saving ? `. Puedes ahorrar hasta <b>${clp(saving)}</b>` : ''}. <a href="#alternativas" data-scroll="alternativas">Comparar alternativas</a></span>`, 'scale') : ''}
    <div class="pdp">
      <div class="pdp__gallery">
        <div class="pdp__img">
          <div class="pcard__flags">${info.offPct ? `<span class="badge badge--sale">-${info.offPct}%</span>` : ''}${promoBadge(p)}</div>
          ${favButton(p)}
          <img src="${productImg(p)}" alt="Envase de ${esc(p.name)}" width="420" height="420">
        </div>
        <p class="field__hint" style="text-align:center">Imagen ilustrativa.</p>
      </div>
      <div class="pdp__info">
        <div>
          <a class="pdp__brand" href="#/buscar?marca=${encodeURIComponent(p.brand)}" data-link>${esc(p.brand)}</a>
          <h1 class="pdp__title">${esc(p.name)}</h1>
          <div class="pdp__meta" style="margin-top:10px">${rxChip(p, { long: true })}${p.be ? beSeal(true) : ''}${p.cold ? `<span class="chip chip--info">${icon('snow')}Cadena de frío</span>` : ''}<span>SKU ${esc(p.id)}</span></div>
        </div>
        ${variants.length > 1 ? `<div><p class="field__hint" style="margin-bottom:8px"><b>Talla</b></p><div class="variants">${variants.map((v) => `<a href="#/producto/${v.slug}" data-link class="${v.id === p.id ? 'is-on' : ''}" aria-current="${v.id === p.id}">${esc(v.variant)}</a>`).join('')}</div></div>` : ''}
        <div class="pdp__buy">
          ${priceBlock(p, { info, size: 'lg' })}
          ${unit ? `<p class="pdp__unit">Precio por unidad: <b>${esc(unit)}</b></p>` : ''}
          ${p.promo ? `<div class="pdp__promo">${promoBadge(p)}<span>${esc(PROMO_TEXT[p.promo])} Se aplica automáticamente en el carro.</span></div>` : ''}
          ${info.clubPrice ? (ctx.member
            ? notice('club', `Precio Club aplicado: <b>${clp(info.clubPrice)}</b> (${esc(info.clubLabel)}).`, 'star')
            : notice('club', `Socios Club pagan <b>${clp(info.clubPrice)}</b> (${esc(info.clubLabel)}). <a href="#/${user ? 'cuenta' : 'registro'}" data-link>${user ? 'Únete gratis' : 'Inscríbete gratis'}</a>`, 'star')) : ''}
          <div class="rx-box rx-box--${r.tone}">${icon(p.rx === 'directa' ? 'checkCircle' : 'file')}<div><b>${esc(r.label)}</b>${esc(r.info)}</div></div>
          ${buyArea}
        </div>
        <div class="avail" aria-label="Disponibilidad">
          <div class="avail__row ${av.delivery.ok ? 'ok' : 'no'}">${icon('truck')}<div><b>Despacho a domicilio</b><span>${esc(av.delivery.text)} · ${esc(state.location.comuna)}</span></div><button type="button" class="btn btn--link" data-action="open-location">Cambiar</button></div>
          <div class="avail__row ${av.pickup.ok ? 'ok' : 'no'}">${icon('store')}<div><b>Retiro en farmacia</b><span>${esc(av.pickup.text)}</span></div>${av.noStores ? '' : '<button type="button" class="btn btn--link" data-stock>Ver stock</button>'}</div>
        </div>
        ${treatBlock}
        <div>
          <details class="acc" open><summary>Descripción ${icon('chevronDown')}</summary><div class="acc__body">${description(p)}</div></details>
          <details class="acc"><summary>Ficha técnica ${icon('chevronDown')}</summary><div class="acc__body"><dl class="kv">
            ${p.ingredients.length ? `<dt>Principio activo</dt><dd>${esc(p.ingredients.map(cap).join(' + '))}</dd>` : ''}
            ${p.strength ? `<dt>Concentración</dt><dd>${esc(p.strength)}</dd>` : ''}
            <dt>Formato</dt><dd>${esc(cap(p.form || 'unidad'))}</dd>
            <dt>Contenido</dt><dd>${esc(qtyUnits(p.units, p.unitName))}</dd>
            <dt>Marca / laboratorio</dt><dd>${esc(p.brand)}</dd>
            <dt>Condición de venta</dt><dd>${esc(r.label)}</dd>
            ${p.isMedicine ? `<dt>Bioequivalente</dt><dd>${p.be ? 'Sí' : 'No'}</dd>` : ''}
            <dt>Código</dt><dd>${esc(p.id)}</dd>
          </dl></div></details>
          <details class="acc"><summary>Uso y advertencias ${icon('chevronDown')}</summary><div class="acc__body">${usage(p)}</div></details>
          <details class="acc"><summary>Aviso legal ${icon('chevronDown')}</summary><div class="acc__body"><p>Las imágenes son ilustrativas. La información de este producto es referencial y no reemplaza la indicación de un profesional de la salud. Los precios publicados son válidos solo para compras en este sitio.</p></div></details>
        </div>
      </div>
    </div>
    ${alts.length ? `<section id="alternativas" style="display:grid;gap:14px;scroll-margin-top:160px">
      <div class="sec-head"><div><h2 class="sec-title">Alternativas con ${esc(p.ingredients.map(cap).join(' + '))} ${esc(p.strength)}</h2><p class="sec-sub">Mismo principio activo y concentración, ordenadas por precio por unidad.</p></div></div>
      <div class="table-wrap alts-wrap"><table class="table alts-table">
        <thead><tr><th>Producto</th><th>Bioequivalente</th><th class="num">Por unidad</th><th class="num">Precio</th><th></th></tr></thead>
        <tbody>${[p, ...alts].sort((a, b) => unitPrice(a) - unitPrice(b)).map((x) => {
          const xi = priceInfo(x, ctx);
          const diff = Math.round((unitPrice(x) - unitPrice(p)) * p.units);
          return `<tr class="${x.id === p.id ? 'is-current' : ''}">
            <td class="alt-prod"><a href="#/producto/${x.slug}" data-link class="alt-prod__link"><img src="${productImg(x)}" alt="" width="44" height="44"><span><b class="alt-prod__brand">${esc(x.brand)}</b>${esc(x.name)}${x.id === p.id ? ' <span class="chip chip--info">Estás viendo</span>' : ''}</span></a></td>
            <td class="alt-be">${x.be ? `${beSeal()}<span class="alt-lbl"> Bioequivalente</span>` : '<span class="muted">—</span>'}</td>
            <td class="num alt-unit">${clp(unitPrice(x))}<span class="alt-lbl"> c/u</span></td>
            <td class="num alt-price"><b>${clp(xi.sale)}</b>${x.id !== p.id && diff < 0 ? `<span class="alt-save">Ahorras ${clp(-diff)}</span>` : ''}</td>
            <td class="alt-act">${x.id === p.id ? '' : `<button type="button" class="btn btn--soft btn--sm" data-action="add" data-id="${x.id}">Agregar</button>`}</td>
          </tr>`;
        }).join('')}</tbody>
      </table></div>
    </section>` : ''}
    ${otherPres.length ? rail('Otras presentaciones', otherPres) : ''}
    ${rail('Otros clientes también vieron', related)}
  </div>
  ${p.rx !== 'cheque' && !p.hidden && (av.delivery.ok || av.pickup.ok) ? `<div class="buybar" id="buybar"><div class="buybar__price"><b>${clp(info.sale)}</b><span>${info.offPct ? `Normal ${clp(info.list)}` : esc(unit)}</span></div><button type="button" class="btn btn--primary btn--lg buybar__cta" data-add-qty>${icon('bag')} Agregar</button></div>` : ''}`;

  return {
    title: p.name,
    html,
    mount(root) {
      let q = 1;
      const qEl = $('#pq', root);
      const onClick = async (e) => {
        const pq = e.target.closest('[data-pq]');
        if (pq) {
          q = Math.max(1, Math.min(max - qtyOf(p.id) || 1, q + Number(pq.dataset.pq)));
          if (qEl) qEl.textContent = String(q);
          return;
        }
        if (e.target.closest('[data-add-qty]')) {
          const before = qtyOf(p.id);
          if (before >= max) { toast(`Puedes llevar hasta ${max} unidades de este producto.`, { tone: 'warn' }); return; }
          const after = addToCart(p.id, q);
          toast(`Agregaste <b>${after - before}</b> × ${esc(p.name)}`, { actionText: 'Ver carro', onAction: () => go('/carro') });
          q = 1;
          if (qEl) qEl.textContent = '1';
          return;
        }
        if (e.target.closest('[data-stock]')) { stockModal(p); return; }
        if (e.target.closest('[data-treat]')) {
          const res = toggleTreatment(p.id);
          if (!res.ok) toast(res.error, { tone: 'warn' });
          else toast(res.enrolled ? `Inscribiste <b>${esc(p.name)}</b> en Mi Tratamiento: pagas ${CLUB.treatmentPct}% menos.` : 'Quitaste el producto de Mi Tratamiento.');
          return;
        }
        if (e.target.closest('[data-join-club]')) {
          joinClub();
          toggleTreatment(p.id);
          toast(`¡Bienvenido al Club Piedra! Inscribimos <b>${esc(p.name)}</b> en Mi Tratamiento.`);
          return;
        }
        const sc = e.target.closest('[data-scroll]');
        if (sc) {
          e.preventDefault();
          document.getElementById(sc.dataset.scroll)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      };
      root.addEventListener('click', onClick);
      const bar = document.getElementById('buybar');
      const target = $('.pdp__buy', root);
      let raf = 0;
      // La barra fija aparece solo cuando el botón principal ya quedó arriba
      // (se revisa en cada scroll: un salto brusco no la deja sin actualizar).
      const sync = () => {
        raf = 0;
        if (!bar || !target || !target.isConnected) return;
        const on = target.getBoundingClientRect().bottom < 0;
        bar.classList.toggle('is-on', on);
        document.body.classList.toggle('has-buybar', on);
      };
      const onScroll = () => { if (!raf) raf = requestAnimationFrame(sync); };
      if (bar && target) {
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', onScroll, { passive: true });
        sync();
      }
      return () => {
        window.removeEventListener('scroll', onScroll);
        window.removeEventListener('resize', onScroll);
        if (raf) cancelAnimationFrame(raf);
        document.body.classList.remove('has-buybar');
      };
    },
    onState(evt) {
      if (evt === 'cart') {
        const el = document.getElementById('incart');
        const n = qtyOf(p.id);
        if (el) el.innerHTML = n ? `Ya tienes <b>${n}</b> en tu carro · <a href="#/carro" data-link>Ver carro</a>` : `Máximo ${max} unidades por compra.`;
        return true;
      }
      return false;
    },
  };
}

export { num };

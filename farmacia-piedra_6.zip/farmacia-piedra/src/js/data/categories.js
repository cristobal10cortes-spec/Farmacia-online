// Árbol de categorías (categoría → subcategorías).
// "icon" corresponde a un ícono de ui/icons.js; "keywords" ayuda al buscador.

export const CATEGORIES = [
  {
    id: 'medicamentos', name: 'Medicamentos', icon: 'pill', hue: 216,
    keywords: ['remedios', 'farmacos', 'medicinas'],
    subs: [
      { id: 'dolor-y-fiebre', name: 'Dolor y fiebre', keywords: ['analgesicos', 'antiinflamatorios', 'dolor', 'fiebre'] },
      { id: 'resfrio-y-tos', name: 'Resfrío y tos', keywords: ['antigripales', 'tos', 'gripe', 'jarabes'] },
      { id: 'alergias-y-respiratorio', name: 'Alergias y respiratorio', keywords: ['antialergicos', 'asma', 'rinitis'] },
      { id: 'sistema-digestivo', name: 'Sistema digestivo', keywords: ['estomago', 'acidez', 'guata', 'intestino'] },
      { id: 'cardiovascular', name: 'Cardiovascular', keywords: ['presion', 'corazon', 'colesterol'] },
      { id: 'diabetes-y-endocrino', name: 'Diabetes y endocrino', keywords: ['diabetes', 'tiroides', 'glicemia', 'azucar'] },
      { id: 'antibioticos-e-infecciones', name: 'Antibióticos e infecciones', keywords: ['infeccion', 'antibiotico', 'hongos'] },
      { id: 'salud-mental-y-sueno', name: 'Salud mental y sueño', keywords: ['animo', 'ansiedad', 'dormir'] },
      { id: 'dermatologia', name: 'Dermatología', keywords: ['piel', 'cremas medicadas'] },
      { id: 'ojos-y-oidos', name: 'Ojos y oídos', keywords: ['ojos', 'oidos', 'lagrimas', 'lentes de contacto'] },
      { id: 'huesos-y-articulaciones', name: 'Huesos y articulaciones', keywords: ['articulaciones', 'huesos', 'rodilla'] },
      { id: 'anticonceptivos', name: 'Anticonceptivos y salud femenina', keywords: ['anticonceptivos', 'mujer', 'ginecologia'] },
      { id: 'bienestar-sexual', name: 'Bienestar sexual', keywords: ['preservativos', 'condones', 'lubricantes', 'sexual'] },
      { id: 'monitores-y-diagnostico', name: 'Monitores y diagnóstico', keywords: ['termometro', 'tensiometro', 'test'] },
      { id: 'primeros-auxilios', name: 'Primeros auxilios', keywords: ['botiquin', 'curitas', 'heridas', 'antisepticos'] },
      { id: 'otros-medicamentos', name: 'Otros medicamentos', keywords: ['urologia', 'prostata', 'corticoides'], onlyIfUsed: true },
    ],
  },
  {
    id: 'dermocosmetica', name: 'Dermocosmética', icon: 'sparkle', hue: 196,
    keywords: ['dermo', 'skincare', 'piel'],
    subs: [
      { id: 'proteccion-solar', name: 'Protección solar', keywords: ['bloqueador', 'protector solar', 'fps', 'sol'] },
      { id: 'limpieza-facial', name: 'Limpieza facial', keywords: ['micelar', 'limpiador', 'desmaquillante'] },
      { id: 'hidratacion', name: 'Hidratación', keywords: ['hidratante', 'crema', 'piel seca'] },
      { id: 'piel-grasa-y-acne', name: 'Piel grasa y acné', keywords: ['acne', 'espinillas', 'grasa'] },
      { id: 'antiedad', name: 'Antiedad', keywords: ['arrugas', 'serum', 'retinol', 'vitamina c'] },
      { id: 'cuidado-corporal', name: 'Cuidado corporal', keywords: ['cuerpo', 'locion', 'urea', 'rosa mosqueta'] },
    ],
  },
  {
    id: 'vitaminas-y-suplementos', name: 'Vitaminas y suplementos', icon: 'leaf', hue: 32,
    keywords: ['suplementos', 'vitaminas', 'minerales'],
    subs: [
      { id: 'vitaminas-y-minerales', name: 'Vitaminas y minerales', keywords: ['multivitaminico', 'vitamina', 'zinc', 'hierro'] },
      { id: 'magnesio-y-colageno', name: 'Magnesio, colágeno y omega', keywords: ['magnesio', 'colageno', 'omega'] },
      { id: 'sueno-y-energia', name: 'Sueño, energía y estrés', keywords: ['melatonina', 'dormir', 'cansancio'] },
      { id: 'nutricion-deportiva', name: 'Nutrición deportiva', keywords: ['proteina', 'creatina', 'whey', 'gym'] },
      { id: 'nutricion-clinica', name: 'Nutrición clínica', keywords: ['suplemento nutricional', 'adulto mayor'] },
      { id: 'naturales', name: 'Productos naturales', keywords: ['hierbas', 'homeopatia', 'fitoterapia', 'natural'], onlyIfUsed: true },
    ],
  },
  {
    id: 'infantil-y-mama', name: 'Infantil y mamá', icon: 'baby', hue: 340,
    keywords: ['bebe', 'guagua', 'nino', 'mama', 'maternidad'],
    subs: [
      { id: 'panales-y-toallitas', name: 'Pañales y toallitas', keywords: ['panales', 'toallitas humedas'] },
      { id: 'cuidado-del-bebe', name: 'Cuidado del bebé', keywords: ['shampoo bebe', 'coceduras', 'colonia'] },
      { id: 'alimentacion-y-lactancia', name: 'Alimentación y lactancia', keywords: ['mamadera', 'chupete', 'lactancia'] },
      { id: 'medicamentos-infantiles', name: 'Medicamentos infantiles', keywords: ['pediatrico', 'jarabe infantil', 'gotas'] },
      { id: 'maternidad', name: 'Maternidad', keywords: ['embarazo', 'prenatal', 'estrias'] },
    ],
  },
  {
    id: 'cuidado-personal', name: 'Cuidado personal', icon: 'drop', hue: 168,
    keywords: ['higiene', 'aseo personal'],
    subs: [
      { id: 'cuidado-bucal', name: 'Cuidado bucal', keywords: ['pasta dental', 'cepillo', 'enjuague', 'dientes'] },
      { id: 'cuidado-capilar', name: 'Cuidado capilar', keywords: ['shampoo', 'pelo', 'cabello', 'caspa'] },
      { id: 'desodorantes-y-jabones', name: 'Desodorantes y jabones', keywords: ['desodorante', 'jabon', 'ducha'] },
      { id: 'afeitado', name: 'Afeitado y depilación', keywords: ['maquina de afeitar', 'gillette', 'depilacion'] },
      { id: 'higiene-femenina', name: 'Higiene femenina', keywords: ['toallas higienicas', 'tampones', 'copa menstrual'] },
      { id: 'adulto-mayor', name: 'Adulto mayor e incontinencia', keywords: ['incontinencia', 'panales adulto'] },
    ],
  },
  {
    id: 'belleza', name: 'Belleza', icon: 'lipstick', hue: 300,
    keywords: ['maquillaje', 'unas'],
    subs: [
      { id: 'maquillaje', name: 'Maquillaje', keywords: ['mascara', 'labial', 'pestanas'] },
      { id: 'unas-y-labios', name: 'Uñas y labios', keywords: ['esmalte', 'balsamo labial'] },
      { id: 'desmaquillantes', name: 'Desmaquillantes', keywords: ['bifasico', 'desmaquillante'] },
    ],
  },
  {
    id: 'mascotas', name: 'Mascotas', icon: 'paw', hue: 25,
    keywords: ['veterinaria', 'perro', 'gato', 'mascota'],
    subs: [
      { id: 'antiparasitarios', name: 'Antiparasitarios', keywords: ['pulgas', 'garrapatas', 'parasitos'] },
      { id: 'higiene-mascotas', name: 'Higiene de mascotas', keywords: ['shampoo perro'] },
    ],
  },
];

export const categoryById = (id) => CATEGORIES.find((c) => c.id === id) || null;

export function subById(catId, subId) {
  const c = categoryById(catId);
  return c ? c.subs.find((s) => s.id === subId) || null : null;
}

// Lista plana de subcategorías con referencia a su categoría
export const ALL_SUBS = CATEGORIES.flatMap((c) => c.subs.map((s) => ({ ...s, cat: c.id, catName: c.name })));

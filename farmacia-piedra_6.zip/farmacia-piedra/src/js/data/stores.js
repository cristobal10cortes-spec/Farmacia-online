// Farmacias de la cadena. Las agrega, edita y elimina el administrador desde
// el panel (se guardan en el servidor). La tienda parte sin farmacias: mientras
// no haya ninguna, solo se vende con despacho a domicilio.
//
// Cada farmacia: { id, name, address, comuna, region, phone, h24, services,
//   hours: { wk, sat, sun }, turnos }
//   hours: [apertura, cierre] en horas (8.5 = 08:30, 24 = medianoche) o null (cerrado)
//   turnos: días de turno 'AAAA-MM-DD' (ese día atiende toda la noche)

export const STORES = [];

export const storeById = (id) => STORES.find((s) => s.id === id) || null;

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const span = (h) => (Array.isArray(h) && h.length === 2 && Number.isFinite(+h[0]) && Number.isFinite(+h[1]) && +h[0] < +h[1] ? [+h[0], +h[1]] : null);

/** Deja una farmacia con todos sus campos (para datos que vienen del servidor). */
export function normalizeStore(s) {
  if (!s || typeof s !== 'object' || !s.id || !s.name) return null;
  const hours = s.hours || {};
  return {
    id: String(s.id),
    name: String(s.name),
    address: String(s.address || ''),
    comuna: String(s.comuna || ''),
    region: String(s.region || ''),
    phone: String(s.phone || ''),
    h24: !!s.h24,
    services: Array.isArray(s.services) ? s.services.map(String) : ['retiro'],
    hours: { wk: span(hours.wk), sat: span(hours.sat), sun: span(hours.sun) },
    turnos: Array.isArray(s.turnos) ? s.turnos.filter((d) => DAY.test(String(d))) : [],
  };
}

/** Reemplaza la lista de farmacias (llega del servidor). */
export function setStores(list) {
  const next = (Array.isArray(list) ? list : []).map(normalizeStore).filter(Boolean);
  next.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  STORES.length = 0;
  STORES.push(...next);
}

// Textos del sitio: carrusel, servicios, preguntas frecuentes y páginas informativas.
// Los textos legales son DE EJEMPLO y deben ser reemplazados por los oficiales.

export const HERO = [
  {
    id: 'be', tone: 'lapis', eyebrow: 'Bioequivalentes',
    title: 'El mismo efecto, a menor precio',
    text: 'Compara tu medicamento con alternativas bioequivalentes certificadas y ahorra en cada compra.',
    cta: 'Comparar alternativas', to: '/bioequivalentes', art: 'be',
  },
  {
    id: 'club', tone: 'pyrite', eyebrow: 'Club Piedra',
    title: 'Descuentos para socios toda la semana',
    text: 'Inscríbete gratis y accede a precios Club, campañas por día y el programa Mi Tratamiento.',
    cta: 'Conocer beneficios', to: '/club', art: 'club',
  },
  {
    id: 'sol', tone: 'sky', eyebrow: 'Protección solar',
    title: 'Bloqueadores con hasta 20% de descuento',
    text: 'Protectores faciales, corporales e infantiles de las mejores marcas dermocosméticas.',
    cta: 'Ver protección solar', to: '/categoria/dermocosmetica/proteccion-solar', art: 'sun',
  },
  {
    id: 'receta', tone: 'basalt', eyebrow: 'Cotiza tu receta',
    title: 'Sube tu receta y te decimos cuánto cuesta',
    text: 'Escribe tus medicamentos o adjunta una foto. Te mostramos el precio y las alternativas más convenientes.',
    cta: 'Cotizar ahora', to: '/cotizar-receta', art: 'rx',
  },
];

// Banners de más abajo (los recuadros grandes después de «Ofertas destacadas»)
export const PROMOS = [
  {
    id: 'abajo-bioeq', tone: 'lapis', eyebrow: 'Ley de fármacos',
    title: 'Compara con bioequivalentes',
    text: 'Mismo principio activo, misma eficacia certificada por el ISP. Te mostramos la alternativa más conveniente en cada medicamento.',
    cta: 'Ver bioequivalentes', to: '/bioequivalentes',
  },
  {
    id: 'abajo-receta', tone: 'basalt', eyebrow: 'Rápido y sin filas',
    title: 'Cotiza tu receta en minutos',
    text: 'Escribe los medicamentos de tu receta (aunque no sepas cómo se escriben) y arma tu compra con el mejor precio.',
    cta: 'Cotizar receta', to: '/cotizar-receta',
  },
];

// Recuadros de «Servicios Piedra» (se cambian en el panel, pestaña Servicios Piedra)
export const SERVICES_TITLE = 'Servicios Piedra';
export const SERVICES = [
  { icon: 'store', title: 'Farmacias y turnos', text: 'Horarios, farmacias abiertas ahora y de turno.', to: '/farmacias' },
  { icon: 'file', title: 'Cotiza tu receta', text: 'Precio de tu receta en minutos.', to: '/cotizar-receta' },
  { icon: 'refresh', title: 'Mi Tratamiento', text: '15% permanente en tus remedios crónicos.', to: '/club?ver=tratamiento' },
  { icon: 'scale', title: 'Bioequivalentes', text: 'Encuentra la alternativa que te conviene.', to: '/bioequivalentes' },
  { icon: 'box', title: 'Sigue tu pedido', text: 'Revisa en qué etapa va tu compra.', to: '/seguimiento' },
  { icon: 'phone', title: 'Venta telefónica', text: 'Compra con ayuda de un asesor.', to: '/ayuda/contacto' },
];

export const PROMISES = [
  { icon: 'truck', title: 'Despacho a domicilio', text: 'A todo Chile. Gratis en la RM sobre $29.990.' },
  { icon: 'store', title: 'Retiro en farmacia', text: 'Listo en 2 horas y sin costo.' },
  { icon: 'shield', title: 'Compra segura', text: 'Pago protegido y datos resguardados.' },
  { icon: 'user', title: 'Químico farmacéutico', text: 'Validamos cada receta antes de despachar.' },
];

export const FAQ = [
  {
    id: 'compras', title: 'Compras y pagos', items: [
      { q: '¿Qué medios de pago aceptan?', a: 'Puedes pagar con tarjetas de débito, crédito o prepago a través de la pasarela de pago, con transferencia bancaria o, si eliges retiro en farmacia, al momento de retirar.' },
      { q: '¿Necesito una cuenta para comprar?', a: 'No. Puedes comprar como invitado. Con una cuenta guardas tus direcciones, recetas y favoritos, ves tus pedidos y accedes a los precios del Club Piedra.' },
      { q: '¿Cómo uso un cupón de descuento?', a: 'En el carro, escribe el código en "¿Tienes un cupón?" y presiona Aplicar. Los cupones no aplican a medicamentos con receta ni a productos que ya tienen una promoción.' },
      { q: '¿Puedo pedir boleta o factura?', a: 'Sí. Al pagar eliges boleta o factura. Para factura necesitas el RUT, la razón social y el giro de la empresa.' },
    ],
  },
  {
    id: 'despacho', title: 'Despacho y retiro', items: [
      { q: '¿Cuánto demora el despacho?', a: 'En la Región Metropolitana llega al día hábil siguiente si compras antes de las 20:00. En las zonas centro, norte y sur demora de 2 a 3 días hábiles, y en la zona austral hasta 5 días hábiles.' },
      { q: '¿Cuánto cuesta el despacho?', a: 'En la RM cuesta $2.990 y es gratis sobre $29.990. En regiones va de $3.990 a $6.990 y es gratis sobre $49.990 ($59.990 en zona austral). El despacho express (3 horas) cuesta $4.990 en comunas habilitadas.' },
      { q: '¿Cómo funciona el retiro en farmacia?', a: 'Eliges la farmacia al pagar. Si tiene stock, tu pedido está listo en 2 horas; te avisamos por correo. Presenta tu carnet y el número de pedido. Si retira otra persona, indícalo al comprar.' },
      { q: '¿Despachan productos refrigerados?', a: 'Los productos que requieren cadena de frío, como la insulina, se despachan en la Región Metropolitana en contenedores refrigerados. En otras regiones se pueden retirar en farmacia.' },
    ],
  },
  {
    id: 'recetas', title: 'Recetas médicas', items: [
      { q: '¿Puedo comprar un medicamento con receta online?', a: 'Sí. Al pagar adjuntas una foto o PDF de tu receta. Un químico farmacéutico la valida antes de preparar el pedido. Si la receta no es válida, te contactamos y anulamos ese producto sin costo.' },
      { q: '¿Qué pasa con la receta retenida?', a: 'Para medicamentos de receta retenida debes adjuntar la receta al comprar y entregar el original al recibir el despacho o al retirar en farmacia. Sin el original no podemos entregar el medicamento.' },
      { q: '¿Qué es un medicamento bioequivalente?', a: 'Es un medicamento que demostró ante el ISP tener la misma eficacia y seguridad que el medicamento de referencia. Lo reconoces por el sello amarillo "BE".' },
      { q: '¿Venden medicamentos con receta cheque?', a: 'No en línea. Los medicamentos con receta cheque solo se venden de forma presencial en farmacia.' },
    ],
  },
  {
    id: 'cambios', title: 'Cambios y devoluciones', items: [
      { q: '¿Puedo devolver un producto?', a: 'Tienes 10 días desde la entrega para cambiar o devolver productos sin abrir y en su envase original. Por seguridad, los medicamentos no tienen cambio salvo que lleguen dañados o equivocados.' },
      { q: 'Mi pedido llegó incompleto o dañado, ¿qué hago?', a: 'Escríbenos dentro de 48 horas con tu número de pedido y una foto. Te enviamos el producto faltante o te devolvemos el dinero.' },
      { q: '¿Cuándo recibo mi reembolso?', a: 'Con tarjeta de crédito, en tu siguiente estado de cuenta. Con débito o transferencia, hasta 10 días hábiles.' },
    ],
  },
  {
    id: 'club', title: 'Club Piedra', items: [
      { q: '¿Cómo me inscribo en el Club Piedra?', a: 'Al crear tu cuenta marca la opción del Club. Si ya tienes cuenta, entra a Mi cuenta y presiona "Unirme al Club". Es gratis.' },
      { q: '¿Qué es el programa Mi Tratamiento?', a: 'Si eres socio, puedes inscribir hasta 5 medicamentos de uso crónico con receta simple y obtener 15% de descuento permanente en ellos.' },
      { q: '¿Los descuentos del Club se suman a otras promociones?', a: 'No. Si un producto tiene una promoción (por ejemplo 2x1) y descuento Club, se aplica automáticamente el que te conviene más.' },
    ],
  },
];

export const LEGAL = {
  'terminos': {
    title: 'Términos y condiciones',
    body: [
      ['Uso del sitio', 'Este sitio permite comprar productos de farmacia para despacho a domicilio o retiro en farmacia. Al usarlo aceptas estos términos. Texto de ejemplo: reemplázalo por los términos oficiales de tu empresa.'],
      ['Precios y stock', 'Los precios publicados en el sitio son válidos solo para compras en línea y pueden diferir de los precios en farmacias. El stock por farmacia se informa con un desfase aproximado de 30 minutos.'],
      ['Medicamentos con receta', 'La venta de medicamentos con receta está sujeta a la validación de la receta por un químico farmacéutico. Nos reservamos el derecho de anular la venta si la receta no cumple la normativa vigente.'],
      ['Promociones', 'Las promociones y descuentos no son acumulables entre sí, salvo que se indique lo contrario. Los cupones no aplican a medicamentos con receta.'],
      ['Derecho a retracto', 'Puedes retractarte de la compra de productos no medicamentosos dentro de 10 días desde su recepción, conforme a la Ley 19.496 sobre Protección de los Derechos de los Consumidores.'],
    ],
  },
  'privacidad': {
    title: 'Política de privacidad',
    body: [
      ['Datos que tratamos', 'Nombre, RUT, datos de contacto, dirección de despacho, historial de compras y, cuando corresponde, recetas médicas. Texto de ejemplo: reemplázalo por la política oficial.'],
      ['Para qué los usamos', 'Para procesar tus pedidos, validar recetas, gestionar tu cuenta y, si lo autorizas, enviarte ofertas y consejos de salud.'],
      ['Datos de salud', 'Las recetas y datos de salud son datos sensibles: solo los ven químicos farmacéuticos y personal autorizado, y se usan exclusivamente para dispensar tus medicamentos.'],
      ['Tus derechos', 'Puedes pedir acceso, rectificación, cancelación u oposición al tratamiento de tus datos escribiendo a nuestro correo de contacto.'],
    ],
  },
  'uso-racional': {
    title: 'Uso racional de medicamentos',
    body: [
      ['Usa solo lo que necesitas', 'Usa los medicamentos en la dosis y por el tiempo que indica tu médico o el folleto. No los compartas ni reutilices recetas antiguas.'],
      ['Antibióticos', 'Los antibióticos solo sirven para infecciones bacterianas y deben usarse con receta. Completa siempre el tratamiento indicado, aunque te sientas mejor.'],
      ['Automedicación responsable', 'Los medicamentos de venta directa también tienen riesgos. Si los síntomas persisten más de 3 días, consulta a un profesional de la salud.'],
      ['Pregunta a tu químico farmacéutico', 'En todas nuestras farmacias hay un químico farmacéutico que puede orientarte sobre interacciones, dosis y alternativas bioequivalentes.'],
    ],
  },
  'cambios-y-devoluciones': {
    title: 'Cambios y devoluciones',
    body: [
      ['Plazo', 'Tienes 10 días desde la entrega para solicitar el cambio o la devolución de productos sin abrir.'],
      ['Medicamentos', 'Por seguridad sanitaria, los medicamentos no tienen cambio ni devolución, salvo productos dañados, vencidos o despachados por error.'],
      ['Cómo hacerlo', 'Escríbenos con tu número de pedido. Puedes devolver en cualquier farmacia Piedra o coordinar un retiro a domicilio.'],
    ],
  },
  'despacho': {
    title: 'Cobertura y despacho',
    body: [
      ['Región Metropolitana', 'Despacho al día hábil siguiente por $2.990, gratis sobre $29.990. Despacho express en 3 horas por $4.990 en comunas habilitadas, de lunes a sábado hasta las 18:00.'],
      ['Regiones', 'Zona centro (Valparaíso, O\'Higgins y Maule): 2 días hábiles, $3.990. Zona norte y sur: 3 días hábiles, $4.990. Gratis sobre $49.990. Zona austral (Aysén y Magallanes): 5 días hábiles, $6.990, gratis sobre $59.990.'],
      ['Sin cobertura', 'Algunas comunas aisladas no tienen despacho a domicilio por ahora (por ejemplo Isla de Pascua y Juan Fernández). Si hay una farmacia Piedra cercana, puedes retirar allí.'],
      ['Cadena de frío', 'Los productos refrigerados se despachan solo en la Región Metropolitana. En otras regiones están disponibles para retiro en farmacia.'],
    ],
  },
  'quienes-somos': {
    title: 'Quiénes somos',
    body: [
      ['Farmacias Piedra', 'Somos una cadena de farmacias chilena con presencia de Arica a Punta Arenas. Nuestro nombre viene de lo que queremos ser para cada familia: algo firme y confiable. Texto de ejemplo.'],
      ['Nuestro compromiso', 'Precios claros, alternativas bioequivalentes siempre a la vista y químicos farmacéuticos disponibles para orientarte.'],
      ['El logo', 'Nuestra piedra es de lapislázuli, la piedra nacional de Chile, con destellos dorados de pirita.'],
    ],
  },
  'trabaja-con-nosotros': {
    title: 'Trabaja con nosotros',
    body: [
      ['Únete al equipo', 'Buscamos químicos farmacéuticos, auxiliares de farmacia y personas para atención al cliente y logística en todo Chile. Texto de ejemplo: agrega aquí el enlace a tu portal de empleos.'],
    ],
  },
};

export const LEGAL_LINKS = [
  ['terminos', 'Términos y condiciones'],
  ['privacidad', 'Política de privacidad'],
  ['uso-racional', 'Uso racional de medicamentos'],
  ['cambios-y-devoluciones', 'Cambios y devoluciones'],
  ['despacho', 'Cobertura y despacho'],
];

export const PREVISIONES = ['Fonasa', 'Isapre Banmédica', 'Isapre Colmena', 'Isapre Consalud', 'Isapre Cruz Blanca', 'Isapre Nueva Masvida', 'Isapre Vida Tres', 'Isapre Esencial', 'Dipreca', 'Capredena', 'Particular / otra'];

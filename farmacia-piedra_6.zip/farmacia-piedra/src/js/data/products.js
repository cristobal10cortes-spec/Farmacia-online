// ─────────────────────────────────────────────────────────────
//  CATÁLOGO DE EJEMPLO
//  Cada producto es un objeto. Campos cortos para que sea fácil
//  de mantener; normalize() (al final) completa el resto.
//
//  n   nombre visible               b   marca o laboratorio
//  c   'categoria/subcategoria'     also  categorías adicionales
//  ai  principios activos           st  concentración ("500 mg")
//  f   forma/formato                u   unidades del envase
//  un  nombre de la unidad (para "precio por unidad")
//  rx  'directa' | 'simple' | 'retenida' | 'cheque'
//  be  1 = bioequivalente           cold 1 = cadena de frío
//  p   precio normal (CLP)          o   precio oferta (opcional)
//  promo '2x1' | '3x2' | '2da-50'   club  % extra Club Piedra
//  t   etiquetas (la 1ª de un medicamento es su clase terapéutica)
//  d   descripción (los medicamentos la generan desde su clase)
//  art forma del envase dibujado    s   popularidad (más vendidos)
//  grp/v  grupo de variantes (p. ej. tallas de pañales)
//  Precios, stock y laboratorios genéricos son DE EJEMPLO.
// ─────────────────────────────────────────────────────────────

const ANDINO = 'Lab. Andino';
const AUSTRAL = 'Austral Pharma';
const CORDILLERA = 'Lab. Cordillera';
const PACIFICO = 'Genéricos del Pacífico';
const ATACAMA = 'Lab. Atacama';
const PIEDRA = 'Piedra';
const SALUD = 'Piedra Salud';
const VITAL = 'Piedra Vital';
const SPORT = 'Piedra Sport';
const BEBE = 'Piedra Bebé';

const INF = 'infantil-y-mama/medicamentos-infantiles';

const RAW = [
  // ── Medicamentos · Dolor y fiebre ─────────────────────────
  { n: 'Paracetamol 500 mg 16 comprimidos', b: PIEDRA, c: 'medicamentos/dolor-y-fiebre', ai: ['paracetamol'], st: '500 mg', f: 'comprimidos', u: 16, un: 'comprimido', rx: 'directa', be: 1, p: 990, o: 790, t: ['analgesico', 'dolor', 'fiebre', 'antipiretico', 'dolor de cabeza'], s: 990 },
  { n: 'Paracetamol 500 mg 16 comprimidos', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', ai: ['paracetamol'], st: '500 mg', f: 'comprimidos', u: 16, un: 'comprimido', rx: 'directa', be: 1, p: 1190, t: ['analgesico', 'dolor', 'fiebre', 'antipiretico'], s: 700 },
  { n: 'Paracetamol 500 mg 20 comprimidos', b: AUSTRAL, c: 'medicamentos/dolor-y-fiebre', ai: ['paracetamol'], st: '500 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'directa', be: 1, p: 1590, o: 1290, t: ['analgesico', 'dolor', 'fiebre'], s: 520 },
  { n: 'Paracetamol 1 g 10 comprimidos', b: CORDILLERA, c: 'medicamentos/dolor-y-fiebre', ai: ['paracetamol'], st: '1 g', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'directa', be: 1, p: 1990, t: ['analgesico', 'dolor', 'fiebre'], s: 610 },
  { n: 'Paracetamol 160 mg/5 ml jarabe 100 ml', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', also: [INF], ai: ['paracetamol'], st: '160 mg/5 ml', f: 'jarabe', u: 100, un: 'ml', rx: 'directa', p: 2990, t: ['analgesico', 'fiebre', 'infantil', 'pediatrico'], s: 480 },
  { n: 'Paracetamol 100 mg/ml gotas 15 ml', b: AUSTRAL, c: 'medicamentos/dolor-y-fiebre', also: [INF], ai: ['paracetamol'], st: '100 mg/ml', f: 'gotas', u: 15, un: 'ml', rx: 'directa', p: 2690, o: 2290, t: ['analgesico', 'fiebre', 'infantil', 'bebe'], s: 450 },
  { n: 'Paracetamol 125 mg 6 supositorios infantiles', b: ATACAMA, c: 'medicamentos/dolor-y-fiebre', also: [INF], ai: ['paracetamol'], st: '125 mg', f: 'supositorios', u: 6, un: 'supositorio', rx: 'directa', p: 2040, t: ['analgesico', 'fiebre', 'infantil'], s: 120 },
  { n: 'Ibuprofeno 400 mg 20 comprimidos', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', ai: ['ibuprofeno'], st: '400 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 1590, t: ['aine', 'dolor', 'inflamacion', 'fiebre'], s: 640 },
  { n: 'Ibuprofeno 400 mg 20 comprimidos', b: PIEDRA, c: 'medicamentos/dolor-y-fiebre', ai: ['ibuprofeno'], st: '400 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 1390, t: ['aine', 'dolor', 'inflamacion'], s: 300 },
  { n: 'Ibuprofeno 600 mg 20 comprimidos', b: PACIFICO, c: 'medicamentos/dolor-y-fiebre', ai: ['ibuprofeno'], st: '600 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 2090, t: ['aine', 'dolor', 'inflamacion'], s: 380 },
  { n: 'Ibuprofeno 400 mg 10 cápsulas blandas', b: CORDILLERA, c: 'medicamentos/dolor-y-fiebre', ai: ['ibuprofeno'], st: '400 mg', f: 'cápsulas blandas', u: 10, un: 'cápsula', rx: 'simple', be: 1, p: 3990, o: 3490, t: ['aine', 'dolor', 'inflamacion', 'menstrual'], s: 260 },
  { n: 'Ibuprofeno 200 mg/5 ml suspensión oral 100 ml', b: AUSTRAL, c: 'medicamentos/dolor-y-fiebre', also: [INF], ai: ['ibuprofeno'], st: '200 mg/5 ml', f: 'suspensión oral', u: 100, un: 'ml', rx: 'directa', p: 3490, t: ['aine', 'fiebre', 'dolor', 'infantil', 'pediatrico'], s: 410 },
  { n: 'Ibuprofeno 100 mg/5 ml suspensión oral 100 ml', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', also: [INF], ai: ['ibuprofeno'], st: '100 mg/5 ml', f: 'suspensión oral', u: 100, un: 'ml', rx: 'directa', p: 3140, t: ['aine', 'fiebre', 'infantil'], s: 300 },
  { n: 'Naproxeno sódico 550 mg 10 comprimidos', b: ATACAMA, c: 'medicamentos/dolor-y-fiebre', ai: ['naproxeno'], st: '550 mg', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'simple', be: 1, p: 3390, o: 2990, t: ['aine', 'dolor', 'inflamacion', 'menstrual'], s: 330 },
  { n: 'Naproxeno 275 mg 10 comprimidos', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', ai: ['naproxeno'], st: '275 mg', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'directa', be: 1, p: 2490, t: ['aine', 'dolor', 'menstrual'], s: 260 },
  { n: 'Ácido acetilsalicílico 500 mg 20 comprimidos', b: CORDILLERA, c: 'medicamentos/dolor-y-fiebre', ai: ['ácido acetilsalicílico'], st: '500 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'directa', be: 1, p: 1790, t: ['analgesico', 'dolor', 'fiebre', 'aas'], s: 350 },
  { n: 'Ketoprofeno 50 mg 20 cápsulas', b: AUSTRAL, c: 'medicamentos/dolor-y-fiebre', ai: ['ketoprofeno'], st: '50 mg', f: 'cápsulas', u: 20, un: 'cápsula', rx: 'simple', be: 1, p: 3540, t: ['aine', 'dolor', 'inflamacion'], s: 150 },
  { n: 'Ketorolaco 10 mg 10 comprimidos', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', ai: ['ketorolaco'], st: '10 mg', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'simple', be: 1, p: 2490, t: ['aine', 'dolor', 'dolor intenso'], s: 260 },
  { n: 'Metamizol sódico 300 mg 20 comprimidos', b: PACIFICO, c: 'medicamentos/dolor-y-fiebre', ai: ['metamizol'], st: '300 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'directa', be: 1, p: 2380, t: ['analgesico', 'dolor', 'fiebre', 'dipirona'], s: 280 },
  { n: 'Diclofenaco dietilamonio 1,16% gel 30 g', b: ATACAMA, c: 'medicamentos/dolor-y-fiebre', ai: ['diclofenaco'], st: '1,16%', f: 'gel', u: 30, un: 'g', rx: 'directa', p: 2640, o: 2290, t: ['aine_topico', 'dolor muscular', 'golpes', 'moreton', 'inflamacion'], art: 'tube', s: 300 },
  { n: 'Diclofenaco sódico 50 mg 20 comprimidos', b: CORDILLERA, c: 'medicamentos/dolor-y-fiebre', ai: ['diclofenaco'], st: '50 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 1990, t: ['aine', 'dolor', 'inflamacion'], s: 200 },
  { n: 'Meloxicam 15 mg 10 comprimidos', b: AUSTRAL, c: 'medicamentos/dolor-y-fiebre', ai: ['meloxicam'], st: '15 mg', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'simple', be: 1, p: 2090, t: ['aine', 'dolor', 'artrosis'], s: 140 },
  { n: 'Celecoxib 200 mg 10 cápsulas', b: ANDINO, c: 'medicamentos/dolor-y-fiebre', ai: ['celecoxib'], st: '200 mg', f: 'cápsulas', u: 10, un: 'cápsula', rx: 'simple', be: 1, p: 9990, o: 8490, t: ['aine', 'dolor', 'artrosis'], s: 120 },
  { n: 'Parche térmico lumbar autoadhesivo 2 unidades', b: PIEDRA, c: 'medicamentos/dolor-y-fiebre', f: 'parches', u: 2, un: 'parche', rx: 'directa', p: 4990, promo: '2da-50', t: ['calor', 'dolor lumbar', 'espalda', 'contractura'], d: 'Parche de calor que se adhiere a la ropa y entrega calor constante por hasta 8 horas. Alivia molestias musculares de la zona lumbar sin medicamentos.', s: 160 },

  // ── Medicamentos · Resfrío y tos ──────────────────────────
  { n: 'Antigripal día y noche 12 comprimidos', b: PIEDRA, c: 'medicamentos/resfrio-y-tos', ai: ['paracetamol', 'fenilefrina', 'clorfenamina'], st: '500/10/4 mg', f: 'comprimidos', u: 12, un: 'comprimido', rx: 'directa', p: 2990, o: 2490, t: ['antigripal', 'resfrio', 'gripe', 'congestion', 'malestar'], s: 520 },
  { n: 'Antigripal sabor limón 6 sobres', b: ANDINO, c: 'medicamentos/resfrio-y-tos', ai: ['paracetamol', 'fenilefrina'], st: '500/10 mg', f: 'sobres', u: 6, un: 'sobre', rx: 'directa', p: 3990, t: ['antigripal', 'resfrio', 'gripe', 'congestion'], s: 300 },
  { n: 'Ambroxol 30 mg/5 ml jarabe adulto 100 ml', b: ANDINO, c: 'medicamentos/resfrio-y-tos', ai: ['ambroxol'], st: '30 mg/5 ml', f: 'jarabe', u: 100, un: 'ml', rx: 'directa', be: 1, p: 3490, t: ['mucolitico', 'tos', 'flema', 'desgarro', 'expectorante'], s: 330 },
  { n: 'Ambroxol 15 mg/5 ml jarabe pediátrico 100 ml', b: AUSTRAL, c: 'medicamentos/resfrio-y-tos', also: [INF], ai: ['ambroxol'], st: '15 mg/5 ml', f: 'jarabe', u: 100, un: 'ml', rx: 'directa', p: 3290, t: ['mucolitico', 'tos', 'flema', 'infantil'], s: 260 },
  { n: 'Dextrometorfano 15 mg/5 ml jarabe 120 ml', b: CORDILLERA, c: 'medicamentos/resfrio-y-tos', ai: ['dextrometorfano'], st: '15 mg/5 ml', f: 'jarabe', u: 120, un: 'ml', rx: 'directa', p: 4290, t: ['antitusivo', 'tos', 'tos seca'], s: 180 },
  { n: 'Acetilcisteína 600 mg 10 comprimidos efervescentes', b: PACIFICO, c: 'medicamentos/resfrio-y-tos', ai: ['acetilcisteína'], st: '600 mg', f: 'comprimidos efervescentes', u: 10, un: 'comprimido', rx: 'simple', p: 5990, t: ['mucolitico', 'flema', 'desgarro', 'tos'], art: 'tubeEff', s: 140 },
  { n: 'Suero fisiológico 0,9% 20 ampollas de 5 ml', b: PIEDRA, c: 'medicamentos/resfrio-y-tos', also: ['infantil-y-mama/cuidado-del-bebe'], ai: ['cloruro de sodio'], st: '0,9%', f: 'ampollas', u: 20, un: 'ampolla', rx: 'directa', p: 3290, o: 2790, t: ['lavado nasal', 'nebulizacion', 'suero', 'nariz', 'bebe'], d: 'Solución estéril de cloruro de sodio al 0,9% en ampollas monodosis. Útil para lavados nasales, limpieza de ojos y nebulizaciones.', s: 420 },
  { n: 'Agua de mar isotónica spray nasal 100 ml', b: PIEDRA, c: 'medicamentos/resfrio-y-tos', f: 'spray nasal', u: 100, un: 'ml', rx: 'directa', p: 5990, o: 4990, t: ['lavado nasal', 'congestion', 'nariz tapada', 'higiene nasal'], d: 'Spray de agua de mar isotónica para la higiene nasal diaria. Ayuda a despejar la nariz y a eliminar secreciones de forma suave.', art: 'spray', s: 260 },
  { n: 'Oximetazolina 0,05% solución nasal 15 ml', b: AUSTRAL, c: 'medicamentos/resfrio-y-tos', ai: ['oximetazolina'], st: '0,05%', f: 'solución nasal', u: 15, un: 'ml', rx: 'simple', be: 1, p: 3990, t: ['descongestionante', 'congestion', 'nariz tapada', 'sinusitis'], art: 'spray', s: 200 },
  { n: 'Pastillas para la garganta miel y limón 24 unidades', b: PIEDRA, c: 'medicamentos/resfrio-y-tos', f: 'pastillas', u: 24, un: 'pastilla', rx: 'directa', p: 2490, promo: '3x2', t: ['garganta', 'dolor de garganta', 'tos', 'carraspera'], d: 'Pastillas para chupar con miel y limón que suavizan la garganta irritada y alivian la carraspera.', s: 300 },
  { n: 'Ungüento mentolado para el pecho 50 g', b: CORDILLERA, c: 'medicamentos/resfrio-y-tos', ai: ['alcanfor', 'mentol', 'eucalipto'], f: 'ungüento', u: 50, un: 'g', rx: 'directa', p: 3990, t: ['descongestionante_topico', 'resfrio', 'pecho', 'congestion'], art: 'jar', s: 220 },

  // ── Medicamentos · Alergias y respiratorio ────────────────
  { n: 'Loratadina 10 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/alergias-y-respiratorio', ai: ['loratadina'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 1390, t: ['antihistaminico', 'alergia', 'rinitis', 'estornudos'], s: 600 },
  { n: 'Loratadina 10 mg 30 comprimidos', b: PIEDRA, c: 'medicamentos/alergias-y-respiratorio', ai: ['loratadina'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 1190, o: 990, t: ['antihistaminico', 'alergia', 'rinitis'], s: 420 },
  { n: 'Loratadina 5 mg/5 ml jarabe 60 ml', b: AUSTRAL, c: 'medicamentos/alergias-y-respiratorio', also: [INF], ai: ['loratadina'], st: '5 mg/5 ml', f: 'jarabe', u: 60, un: 'ml', rx: 'simple', p: 3990, t: ['antihistaminico', 'alergia', 'infantil'], s: 160 },
  { n: 'Clorfenamina 4 mg 20 comprimidos', b: ANDINO, c: 'medicamentos/alergias-y-respiratorio', ai: ['clorfenamina'], st: '4 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 690, t: ['antihistaminico', 'alergia', 'picazon'], s: 210 },
  { n: 'Cetirizina 10 mg 30 comprimidos', b: CORDILLERA, c: 'medicamentos/alergias-y-respiratorio', ai: ['cetirizina'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 4990, o: 4290, t: ['antihistaminico', 'alergia', 'rinitis', 'urticaria'], s: 300 },
  { n: 'Desloratadina 5 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/alergias-y-respiratorio', ai: ['desloratadina'], st: '5 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 7390, t: ['antihistaminico', 'alergia', 'rinitis'], s: 280 },
  { n: 'Levocetirizina 5 mg 30 comprimidos', b: PACIFICO, c: 'medicamentos/alergias-y-respiratorio', ai: ['levocetirizina'], st: '5 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 7590, t: ['antihistaminico', 'alergia', 'rinitis'], s: 200 },
  { n: 'Fexofenadina 180 mg 30 comprimidos', b: ATACAMA, c: 'medicamentos/alergias-y-respiratorio', ai: ['fexofenadina'], st: '180 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 19990, o: 17990, t: ['antihistaminico', 'alergia', 'rinitis'], s: 150 },
  { n: 'Montelukast 10 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/alergias-y-respiratorio', ai: ['montelukast'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 14990, t: ['antileucotrieno', 'asma', 'alergia', 'rinitis', 'cronico'], s: 160 },
  { n: 'Mometasona 50 mcg suspensión nasal 140 dosis', b: CORDILLERA, c: 'medicamentos/alergias-y-respiratorio', ai: ['mometasona'], st: '50 mcg/dosis', f: 'spray nasal', u: 140, un: 'dosis', rx: 'retenida', p: 16390, t: ['corticoide_nasal', 'rinitis', 'alergia', 'congestion'], art: 'spray', s: 140 },
  { n: 'Salbutamol 100 mcg inhalador 200 dosis', b: AUSTRAL, c: 'medicamentos/alergias-y-respiratorio', ai: ['salbutamol'], st: '100 mcg/dosis', f: 'inhalador', u: 200, un: 'dosis', rx: 'simple', p: 3690, t: ['broncodilatador', 'asma', 'inhalador', 'puff'], art: 'inhaler', s: 260 },
  { n: 'Budesonida 200 mcg inhalador 200 dosis', b: ANDINO, c: 'medicamentos/alergias-y-respiratorio', ai: ['budesonida'], st: '200 mcg/dosis', f: 'inhalador', u: 200, un: 'dosis', rx: 'retenida', p: 12990, t: ['corticoide_inhalado', 'asma', 'inhalador', 'cronico'], art: 'inhaler', s: 90 },

  // ── Medicamentos · Sistema digestivo ──────────────────────
  { n: 'Omeprazol 20 mg 30 cápsulas', b: ANDINO, c: 'medicamentos/sistema-digestivo', ai: ['omeprazol'], st: '20 mg', f: 'cápsulas', u: 30, un: 'cápsula', rx: 'simple', be: 1, p: 2690, t: ['ipb', 'acidez', 'reflujo', 'gastritis', 'estomago', 'cronico'], s: 640 },
  { n: 'Omeprazol 20 mg 60 cápsulas', b: ANDINO, c: 'medicamentos/sistema-digestivo', ai: ['omeprazol'], st: '20 mg', f: 'cápsulas', u: 60, un: 'cápsula', rx: 'simple', be: 1, p: 4290, o: 3860, t: ['ipb', 'acidez', 'reflujo', 'gastritis', 'cronico'], s: 300 },
  { n: 'Omeprazol 20 mg 30 cápsulas', b: PIEDRA, c: 'medicamentos/sistema-digestivo', ai: ['omeprazol'], st: '20 mg', f: 'cápsulas', u: 30, un: 'cápsula', rx: 'simple', be: 1, p: 2290, t: ['ipb', 'acidez', 'reflujo', 'cronico'], s: 320 },
  { n: 'Esomeprazol 40 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/sistema-digestivo', ai: ['esomeprazol'], st: '40 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 16390, o: 14990, t: ['ipb', 'acidez', 'reflujo', 'cronico'], s: 180 },
  { n: 'Pantoprazol 40 mg 30 comprimidos', b: CORDILLERA, c: 'medicamentos/sistema-digestivo', ai: ['pantoprazol'], st: '40 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 12990, t: ['ipb', 'acidez', 'reflujo', 'cronico'], s: 140 },
  { n: 'Famotidina 40 mg 10 comprimidos', b: PACIFICO, c: 'medicamentos/sistema-digestivo', ai: ['famotidina'], st: '40 mg', f: 'comprimidos', u: 10, un: 'comprimido', rx: 'simple', be: 1, p: 1260, t: ['antih2', 'acidez', 'ulcera'], s: 130 },
  { n: 'Domperidona 10 mg 30 comprimidos', b: ATACAMA, c: 'medicamentos/sistema-digestivo', ai: ['domperidona'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 5990, t: ['procinetico', 'nauseas', 'vomitos', 'digestion lenta'], s: 170 },
  { n: 'Loperamida 2 mg 6 comprimidos', b: ANDINO, c: 'medicamentos/sistema-digestivo', ai: ['loperamida'], st: '2 mg', f: 'comprimidos', u: 6, un: 'comprimido', rx: 'simple', p: 1190, t: ['antidiarreico', 'diarrea'], s: 220 },
  { n: 'Sales de rehidratación oral sabor naranja 4 sobres', b: PIEDRA, c: 'medicamentos/sistema-digestivo', also: [INF], ai: ['sales de rehidratación'], f: 'sobres', u: 4, un: 'sobre', rx: 'directa', p: 5490, t: ['rehidratante', 'diarrea', 'deshidratacion', 'vomitos', 'calor'], s: 300 },
  { n: 'Simeticona 80 mg 20 comprimidos masticables', b: AUSTRAL, c: 'medicamentos/sistema-digestivo', ai: ['simeticona'], st: '80 mg', f: 'comprimidos masticables', u: 20, un: 'comprimido', rx: 'directa', p: 4990, o: 3990, t: ['antiflatulento', 'gases', 'hinchazon', 'guata'], s: 210 },
  { n: 'Antiácido magaldrato + simeticona 10 comprimidos masticables', b: CORDILLERA, c: 'medicamentos/sistema-digestivo', ai: ['magaldrato', 'simeticona'], st: '480/100 mg', f: 'comprimidos masticables', u: 10, un: 'comprimido', rx: 'directa', p: 2990, t: ['antiacido', 'acidez', 'ardor', 'gases'], s: 260 },
  { n: 'Antiácido efervescente sabor limón 10 sobres', b: PIEDRA, c: 'medicamentos/sistema-digestivo', ai: ['bicarbonato de sodio', 'ácido cítrico'], f: 'sobres', u: 10, un: 'sobre', rx: 'directa', p: 2490, promo: '2da-50', t: ['antiacido', 'acidez', 'sal de fruta', 'indigestion'], s: 240 },
  { n: 'Lactulosa 65% solución oral 200 ml', b: ANDINO, c: 'medicamentos/sistema-digestivo', ai: ['lactulosa'], st: '65%', f: 'solución oral', u: 200, un: 'ml', rx: 'simple', p: 8990, t: ['laxante', 'estitiquez', 'estrenimiento'], s: 150 },
  { n: 'Trimebutina 200 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/sistema-digestivo', ai: ['trimebutina'], st: '200 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 9990, t: ['antiespasmodico', 'colon irritable', 'dolor abdominal', 'guata'], s: 120 },
  { n: 'Ondansetrón 4 mg 10 comprimidos bucodispersables', b: ATACAMA, c: 'medicamentos/sistema-digestivo', ai: ['ondansetrón'], st: '4 mg', f: 'comprimidos bucodispersables', u: 10, un: 'comprimido', rx: 'simple', be: 1, p: 9990, t: ['antiemetico', 'nauseas', 'vomitos'], s: 90 },
  { n: 'Probiótico Lactobacillus 10 cápsulas', b: VITAL, c: 'medicamentos/sistema-digestivo', ai: ['lactobacillus'], f: 'cápsulas', u: 10, un: 'cápsula', rx: 'directa', p: 8990, o: 7490, t: ['probiotico', 'flora intestinal', 'diarrea', 'digestion'], d: 'Suplemento con bacterias probióticas que ayudan a mantener el equilibrio de la flora intestinal, por ejemplo durante o después de un tratamiento antibiótico.', s: 200 },

  // ── Medicamentos · Cardiovascular ─────────────────────────
  { n: 'Losartán 50 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/cardiovascular', ai: ['losartán'], st: '50 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 2690, t: ['antihipertensivo', 'presion alta', 'hipertension', 'cronico'], s: 520 },
  { n: 'Losartán 100 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/cardiovascular', ai: ['losartán'], st: '100 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 4990, t: ['antihipertensivo', 'presion alta', 'cronico'], s: 220 },
  { n: 'Losartán 50 mg 30 comprimidos', b: PIEDRA, c: 'medicamentos/cardiovascular', ai: ['losartán'], st: '50 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 2290, t: ['antihipertensivo', 'presion alta', 'cronico'], s: 260 },
  { n: 'Enalapril 10 mg 20 comprimidos', b: CORDILLERA, c: 'medicamentos/cardiovascular', ai: ['enalapril'], st: '10 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 1390, t: ['antihipertensivo', 'presion alta', 'hipertension', 'cronico'], s: 300 },
  { n: 'Amlodipino 5 mg 30 comprimidos', b: PACIFICO, c: 'medicamentos/cardiovascular', ai: ['amlodipino'], st: '5 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 2090, t: ['antihipertensivo', 'presion alta', 'cronico'], s: 280 },
  { n: 'Amlodipino 10 mg 30 comprimidos', b: PACIFICO, c: 'medicamentos/cardiovascular', ai: ['amlodipino'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 2590, t: ['antihipertensivo', 'presion alta', 'cronico'], s: 200 },
  { n: 'Atorvastatina 20 mg 30 comprimidos', b: ATACAMA, c: 'medicamentos/cardiovascular', ai: ['atorvastatina'], st: '20 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 2590, t: ['hipolipemiante', 'colesterol', 'trigliceridos', 'cronico'], s: 450 },
  { n: 'Atorvastatina 40 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/cardiovascular', ai: ['atorvastatina'], st: '40 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 4590, t: ['hipolipemiante', 'colesterol', 'cronico'], s: 200 },
  { n: 'Rosuvastatina 10 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/cardiovascular', ai: ['rosuvastatina'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 9790, o: 8790, t: ['hipolipemiante', 'colesterol', 'cronico'], s: 210 },
  { n: 'Ácido acetilsalicílico 100 mg 30 comprimidos', b: PIEDRA, c: 'medicamentos/cardiovascular', ai: ['ácido acetilsalicílico'], st: '100 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'directa', be: 1, p: 1490, t: ['antiagregante', 'corazon', 'prevencion cardiovascular', 'aas'], s: 380 },
  { n: 'Clopidogrel 75 mg 28 comprimidos', b: CORDILLERA, c: 'medicamentos/cardiovascular', ai: ['clopidogrel'], st: '75 mg', f: 'comprimidos', u: 28, un: 'comprimido', rx: 'simple', be: 1, p: 6990, t: ['antiagregante', 'corazon', 'cronico'], s: 130 },
  { n: 'Hidroclorotiazida 50 mg 20 comprimidos', b: ANDINO, c: 'medicamentos/cardiovascular', ai: ['hidroclorotiazida'], st: '50 mg', f: 'comprimidos', u: 20, un: 'comprimido', rx: 'simple', be: 1, p: 1290, t: ['diuretico', 'presion alta', 'hipertension', 'cronico'], s: 120 },

  // ── Medicamentos · Diabetes y endocrino ───────────────────
  { n: 'Metformina 850 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/diabetes-y-endocrino', ai: ['metformina'], st: '850 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 1990, t: ['antidiabetico', 'diabetes', 'glicemia', 'azucar', 'cronico'], s: 480 },
  { n: 'Metformina XR 1000 mg 30 comprimidos de liberación prolongada', b: AUSTRAL, c: 'medicamentos/diabetes-y-endocrino', ai: ['metformina'], st: '1000 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 9990, o: 8990, t: ['antidiabetico', 'diabetes', 'glicemia', 'cronico'], s: 200 },
  { n: 'Levotiroxina 100 mcg 50 comprimidos', b: CORDILLERA, c: 'medicamentos/diabetes-y-endocrino', ai: ['levotiroxina'], st: '100 mcg', f: 'comprimidos', u: 50, un: 'comprimido', rx: 'simple', be: 1, p: 7990, t: ['tiroides', 'hipotiroidismo', 't4', 'cronico'], s: 260 },
  { n: 'Levotiroxina 50 mcg 50 comprimidos', b: CORDILLERA, c: 'medicamentos/diabetes-y-endocrino', ai: ['levotiroxina'], st: '50 mcg', f: 'comprimidos', u: 50, un: 'comprimido', rx: 'simple', be: 1, p: 7490, t: ['tiroides', 'hipotiroidismo', 'cronico'], s: 200 },
  { n: 'Insulina glargina 100 UI/ml lápiz prellenado 3 ml', b: AUSTRAL, c: 'medicamentos/diabetes-y-endocrino', ai: ['insulina glargina'], st: '100 UI/ml', f: 'solución inyectable', u: 1, un: 'lápiz', rx: 'simple', cold: 1, p: 24990, t: ['insulina', 'diabetes', 'cadena de frio', 'cronico'], art: 'pen', s: 90 },
  { n: 'Glucómetro digital con 10 tiras reactivas', b: SALUD, c: 'medicamentos/diabetes-y-endocrino', also: ['medicamentos/monitores-y-diagnostico'], f: 'kit', u: 1, un: 'kit', rx: 'directa', p: 19990, o: 15990, t: ['glucometro', 'diabetes', 'glicemia', 'medidor de azucar'], d: 'Medidor de glucosa en sangre con resultado en 5 segundos, memoria de 500 mediciones y promedio de 7, 14 y 30 días. Incluye 10 tiras, lancetero y estuche.', art: 'device:drop', s: 140 },
  { n: 'Tiras reactivas para glucómetro 50 unidades', b: SALUD, c: 'medicamentos/diabetes-y-endocrino', f: 'tiras', u: 50, un: 'tira', rx: 'directa', p: 14990, t: ['tiras reactivas', 'glicemia', 'diabetes'], d: 'Tiras reactivas compatibles con el glucómetro digital Piedra Salud. Envase con 50 tiras.', s: 180 },
  { n: 'Lancetas estériles 100 unidades', b: SALUD, c: 'medicamentos/diabetes-y-endocrino', f: 'lancetas', u: 100, un: 'lanceta', rx: 'directa', p: 5990, t: ['lancetas', 'diabetes', 'glicemia'], d: 'Lancetas estériles de un solo uso, calibre fino, para la toma de muestras de sangre capilar.', s: 100 },

  // ── Medicamentos · Antibióticos e infecciones ─────────────
  { n: 'Amoxicilina 500 mg 21 cápsulas', b: ANDINO, c: 'medicamentos/antibioticos-e-infecciones', ai: ['amoxicilina'], st: '500 mg', f: 'cápsulas', u: 21, un: 'cápsula', rx: 'retenida', be: 1, p: 4990, t: ['antibiotico', 'infeccion'], s: 300 },
  { n: 'Amoxicilina 250 mg/5 ml polvo para suspensión 60 ml', b: AUSTRAL, c: 'medicamentos/antibioticos-e-infecciones', also: [INF], ai: ['amoxicilina'], st: '250 mg/5 ml', f: 'suspensión oral', u: 60, un: 'ml', rx: 'retenida', p: 3990, t: ['antibiotico', 'infeccion', 'infantil'], s: 160 },
  { n: 'Amoxicilina + ácido clavulánico 875/125 mg 14 comprimidos', b: CORDILLERA, c: 'medicamentos/antibioticos-e-infecciones', ai: ['amoxicilina', 'ácido clavulánico'], st: '875/125 mg', f: 'comprimidos', u: 14, un: 'comprimido', rx: 'retenida', be: 1, p: 12990, t: ['antibiotico', 'infeccion'], s: 200 },
  { n: 'Azitromicina 500 mg 3 comprimidos', b: PACIFICO, c: 'medicamentos/antibioticos-e-infecciones', ai: ['azitromicina'], st: '500 mg', f: 'comprimidos', u: 3, un: 'comprimido', rx: 'retenida', be: 1, p: 2990, t: ['antibiotico', 'infeccion'], s: 260 },
  { n: 'Ciprofloxacino 500 mg 6 comprimidos', b: ATACAMA, c: 'medicamentos/antibioticos-e-infecciones', ai: ['ciprofloxacino'], st: '500 mg', f: 'comprimidos', u: 6, un: 'comprimido', rx: 'retenida', be: 1, p: 1990, t: ['antibiotico', 'infeccion', 'infeccion urinaria'], s: 160 },
  { n: 'Cefadroxilo 500 mg 8 cápsulas', b: ANDINO, c: 'medicamentos/antibioticos-e-infecciones', ai: ['cefadroxilo'], st: '500 mg', f: 'cápsulas', u: 8, un: 'cápsula', rx: 'retenida', be: 1, p: 3790, t: ['antibiotico', 'infeccion'], s: 120 },
  { n: 'Nitrofurantoína 100 mg 10 cápsulas', b: AUSTRAL, c: 'medicamentos/antibioticos-e-infecciones', ai: ['nitrofurantoína'], st: '100 mg', f: 'cápsulas', u: 10, un: 'cápsula', rx: 'retenida', be: 1, p: 3990, t: ['antibiotico', 'infeccion urinaria', 'cistitis'], s: 110 },
  { n: 'Fluconazol 150 mg 2 cápsulas', b: CORDILLERA, c: 'medicamentos/antibioticos-e-infecciones', ai: ['fluconazol'], st: '150 mg', f: 'cápsulas', u: 2, un: 'cápsula', rx: 'simple', be: 1, p: 2990, t: ['antimicotico', 'hongos', 'candidiasis'], s: 180 },
  { n: 'Clotrimazol 100 mg 6 óvulos', b: ATACAMA, c: 'medicamentos/antibioticos-e-infecciones', also: ['medicamentos/anticonceptivos'], ai: ['clotrimazol'], st: '100 mg', f: 'óvulos', u: 6, un: 'óvulo', rx: 'simple', p: 3290, t: ['antimicotico', 'hongos', 'candidiasis vaginal'], s: 100 },

  // ── Medicamentos · Salud mental y sueño ───────────────────
  { n: 'Sertralina 50 mg 30 comprimidos', b: ANDINO, c: 'medicamentos/salud-mental-y-sueno', ai: ['sertralina'], st: '50 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 5990, t: ['antidepresivo', 'depresion', 'ansiedad', 'cronico'], s: 220 },
  { n: 'Escitalopram 10 mg 30 comprimidos', b: AUSTRAL, c: 'medicamentos/salud-mental-y-sueno', ai: ['escitalopram'], st: '10 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'simple', be: 1, p: 5890, t: ['antidepresivo', 'depresion', 'ansiedad', 'cronico'], s: 200 },
  { n: 'Clonazepam 0,5 mg 30 comprimidos', b: CORDILLERA, c: 'medicamentos/salud-mental-y-sueno', ai: ['clonazepam'], st: '0,5 mg', f: 'comprimidos', u: 30, un: 'comprimido', rx: 'retenida', be: 1, p: 4890, t: ['ansiolitico', 'ansiedad', 'crisis de panico'], s: 150 },
  { n: 'Valeriana 300 mg 30 cápsulas', b: VITAL, c: 'medicamentos/salud-mental-y-sueno', ai: ['valeriana'], st: '300 mg', f: 'cápsulas', u: 30, un: 'cápsula', rx: 'directa', p: 4990, o: 3990, t: ['fitoterapico', 'dormir', 'insomnio', 'nervios', 'relajante'], s: 140 },

  // ── Medicamentos · Dermatología ───────────────────────────
  { n: 'Clotrimazol 1% crema 20 g', b: ANDINO, c: 'medicamentos/dermatologia', ai: ['clotrimazol'], st: '1%', f: 'crema', u: 20, un: 'g', rx: 'directa', p: 1990, t: ['antimicotico', 'hongos', 'pie de atleta'], s: 260 },
  { n: 'Ketoconazol 2% crema 20 g', b: AUSTRAL, c: 'medicamentos/dermatologia', ai: ['ketoconazol'], st: '2%', f: 'crema', u: 20, un: 'g', rx: 'simple', p: 2990, t: ['antimicotico', 'hongos', 'dermatitis seborreica'], s: 150 },
  { n: 'Ketoconazol 1% shampoo medicado 150 ml', b: CORDILLERA, c: 'medicamentos/dermatologia', also: ['cuidado-personal/cuidado-capilar'], ai: ['ketoconazol'], st: '1%', f: 'shampoo', u: 150, un: 'ml', rx: 'directa', p: 9990, o: 8490, t: ['antimicotico', 'caspa', 'shampoo medicado', 'dermatitis seborreica'], art: 'pump', s: 160 },
  { n: 'Betametasona 0,05% crema 15 g', b: PACIFICO, c: 'medicamentos/dermatologia', ai: ['betametasona'], st: '0,05%', f: 'crema', u: 15, un: 'g', rx: 'simple', p: 1490, t: ['corticoide_topico', 'picazon', 'dermatitis', 'eczema'], s: 160 },
  { n: 'Hidrocortisona 1% crema 15 g', b: ATACAMA, c: 'medicamentos/dermatologia', ai: ['hidrocortisona'], st: '1%', f: 'crema', u: 15, un: 'g', rx: 'simple', p: 3990, t: ['corticoide_topico', 'picazon', 'picaduras', 'dermatitis'], s: 120 },
  { n: 'Mupirocina 2% ungüento 15 g', b: ANDINO, c: 'medicamentos/dermatologia', ai: ['mupirocina'], st: '2%', f: 'ungüento', u: 15, un: 'g', rx: 'simple', p: 8990, t: ['antibiotico_topico', 'herida infectada', 'impetigo'], s: 100 },
  { n: 'Aciclovir 5% crema 15 g', b: AUSTRAL, c: 'medicamentos/dermatologia', ai: ['aciclovir'], st: '5%', f: 'crema', u: 15, un: 'g', rx: 'simple', p: 2240, t: ['antiviral', 'herpes labial', 'fuego', 'calentura'], s: 200 },
  { n: 'Terbinafina 1% crema 15 g', b: CORDILLERA, c: 'medicamentos/dermatologia', ai: ['terbinafina'], st: '1%', f: 'crema', u: 15, un: 'g', rx: 'simple', p: 4990, t: ['antimicotico', 'hongos', 'pie de atleta', 'tina'], s: 110 },
  { n: 'Permetrina 1% loción pediculicida 60 ml', b: PACIFICO, c: 'medicamentos/dermatologia', also: ['infantil-y-mama/cuidado-del-bebe'], ai: ['permetrina'], st: '1%', f: 'loción', u: 60, un: 'ml', rx: 'directa', p: 5990, t: ['pediculicida', 'piojos', 'liendres'], s: 150 },

  // ── Medicamentos · Ojos y oídos ───────────────────────────
  { n: 'Lágrimas artificiales hialuronato de sodio 0,15% 10 ml', b: CORDILLERA, c: 'medicamentos/ojos-y-oidos', ai: ['hialuronato de sodio'], st: '0,15%', f: 'gotas oftálmicas', u: 10, un: 'ml', rx: 'directa', p: 6990, o: 5990, t: ['lubricante_ocular', 'ojo seco', 'ojos cansados', 'lagrimas'], s: 220 },
  { n: 'Solución multipropósito para lentes de contacto 360 ml', b: PIEDRA, c: 'medicamentos/ojos-y-oidos', f: 'solución', u: 360, un: 'ml', rx: 'directa', p: 8990, promo: '2da-50', t: ['lentes de contacto', 'limpieza de lentes'], d: 'Limpia, enjuaga, desinfecta y conserva lentes de contacto blandos. Incluye estuche portalentes.', art: 'bottle', s: 150 },
  { n: 'Gotas óticas para remover cerumen 10 ml', b: ANDINO, c: 'medicamentos/ojos-y-oidos', ai: ['peróxido de carbamida'], st: '6,5%', f: 'gotas óticas', u: 10, un: 'ml', rx: 'directa', p: 4990, t: ['cerumenolitico', 'cerumen', 'oidos tapados', 'cera'], s: 90 },

  // ── Medicamentos · Huesos y articulaciones ────────────────
  { n: 'Glucosamina + condroitina 60 comprimidos', b: VITAL, c: 'medicamentos/huesos-y-articulaciones', ai: ['glucosamina', 'condroitina'], st: '1500/1200 mg', f: 'comprimidos', u: 60, un: 'comprimido', rx: 'directa', p: 14990, o: 12990, t: ['articulaciones', 'rodilla', 'cartilago', 'artrosis'], d: 'Suplemento con glucosamina y condroitina, componentes del cartílago, que contribuye al cuidado de las articulaciones.', art: 'jar', s: 200 },
  { n: 'Calcio 600 mg + vitamina D3 60 comprimidos', b: VITAL, c: 'medicamentos/huesos-y-articulaciones', also: ['vitaminas-y-suplementos/vitaminas-y-minerales'], ai: ['calcio', 'vitamina D3'], st: '600 mg/400 UI', f: 'comprimidos', u: 60, un: 'comprimido', rx: 'directa', p: 7990, t: ['huesos', 'osteoporosis', 'calcio', 'menopausia'], d: 'Calcio con vitamina D3 para contribuir a la mantención de huesos y dientes normales.', art: 'jar', s: 210 },
  { n: 'Rodillera elástica ajustable talla única', b: SALUD, c: 'medicamentos/huesos-y-articulaciones', f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 9990, t: ['rodilla', 'ortopedia', 'soporte', 'deporte'], d: 'Rodillera de neopreno con cierre ajustable y orificio rotuliano. Entrega soporte y compresión durante la actividad física.', s: 70 },

  // ── Medicamentos · Anticonceptivos y salud femenina ───────
  { n: 'Levonorgestrel 1,5 mg 1 comprimido', b: ANDINO, c: 'medicamentos/anticonceptivos', ai: ['levonorgestrel'], st: '1,5 mg', f: 'comprimido', u: 1, un: 'comprimido', rx: 'directa', be: 1, p: 9990, t: ['anticonceptivo_emergencia', 'pildora del dia despues', 'pae', 'emergencia'], s: 200 },
  { n: 'Levonorgestrel 0,15 mg + etinilestradiol 0,03 mg 28 comprimidos', b: AUSTRAL, c: 'medicamentos/anticonceptivos', ai: ['levonorgestrel', 'etinilestradiol'], st: '0,15/0,03 mg', f: 'comprimidos', u: 28, un: 'comprimido', rx: 'simple', be: 1, p: 6990, t: ['anticonceptivo', 'pastillas anticonceptivas', 'cronico'], s: 260 },
  { n: 'Drospirenona 3 mg + etinilestradiol 0,02 mg 28 comprimidos', b: CORDILLERA, c: 'medicamentos/anticonceptivos', ai: ['drospirenona', 'etinilestradiol'], st: '3/0,02 mg', f: 'comprimidos', u: 28, un: 'comprimido', rx: 'simple', be: 1, p: 9990, o: 8990, t: ['anticonceptivo', 'pastillas anticonceptivas', 'cronico'], s: 220 },
  { n: 'Test de embarazo 1 unidad', b: SALUD, c: 'medicamentos/anticonceptivos', also: ['infantil-y-mama/maternidad', 'medicamentos/monitores-y-diagnostico'], f: 'test', u: 1, un: 'test', rx: 'directa', p: 3490, promo: '2da-50', t: ['embarazo', 'prueba de embarazo', 'test'], d: 'Test de embarazo de lectura rápida (3 minutos) con más de 99% de precisión desde el día de la falta.', s: 260 },

  // ── Medicamentos · Bienestar sexual ───────────────────────
  { n: 'Preservativos Clásico 12 unidades', b: 'Durex', c: 'medicamentos/bienestar-sexual', f: 'preservativos', u: 12, un: 'unidad', rx: 'directa', p: 6990, o: 5990, t: ['preservativos', 'condones', 'proteccion'], d: 'Preservativos de látex natural lubricados, de forma anatómica. Ayudan a prevenir embarazos e infecciones de transmisión sexual.', s: 300 },
  { n: 'Preservativos Invisible ultra delgados 3 unidades', b: 'Durex', c: 'medicamentos/bienestar-sexual', f: 'preservativos', u: 3, un: 'unidad', rx: 'directa', p: 3490, promo: '3x2', t: ['preservativos', 'condones', 'delgados'], d: 'Preservativos de látex extra delgados para mayor sensibilidad, lubricados.', s: 220 },
  { n: 'Lubricante íntimo base agua 50 ml', b: PIEDRA, c: 'medicamentos/bienestar-sexual', f: 'gel', u: 50, un: 'ml', rx: 'directa', p: 4990, t: ['lubricante', 'intimo', 'sequedad'], d: 'Gel lubricante íntimo a base de agua, compatible con preservativos de látex. Sin fragancia.', art: 'tube', s: 160 },
  { n: 'Sildenafil 50 mg 4 comprimidos', b: ATACAMA, c: 'medicamentos/bienestar-sexual', ai: ['sildenafil'], st: '50 mg', f: 'comprimidos', u: 4, un: 'comprimido', rx: 'simple', be: 1, p: 4990, t: ['disfuncion_erectil', 'salud masculina'], s: 160 },
  { n: 'Tadalafil 20 mg 4 comprimidos', b: AUSTRAL, c: 'medicamentos/bienestar-sexual', ai: ['tadalafil'], st: '20 mg', f: 'comprimidos', u: 4, un: 'comprimido', rx: 'simple', be: 1, p: 6990, t: ['disfuncion_erectil', 'salud masculina'], s: 110 },

  // ── Medicamentos · Monitores y diagnóstico ────────────────
  { n: 'Termómetro digital punta flexible', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', also: ['infantil-y-mama/cuidado-del-bebe'], f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 3990, o: 3290, t: ['termometro', 'fiebre', 'temperatura'], d: 'Termómetro digital de punta flexible, resistente al agua, con lectura en 60 segundos y alarma de fiebre.', art: 'device:thermo', s: 320 },
  { n: 'Termómetro infrarrojo sin contacto', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 24990, o: 19990, t: ['termometro', 'fiebre', 'temperatura', 'frente'], d: 'Mide la temperatura en la frente en 1 segundo, sin contacto. Pantalla con luz de color según el resultado y memoria de 32 lecturas.', art: 'device:thermo', s: 120 },
  { n: 'Tensiómetro digital de brazo', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 39990, o: 34990, t: ['tensiometro', 'presion arterial', 'hipertension', 'medir la presion'], d: 'Tensiómetro automático de brazo con brazalete de 22 a 42 cm, detección de pulso irregular y memoria para 2 usuarios.', art: 'device:cuff', s: 180 },
  { n: 'Oxímetro de pulso de dedo', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 14990, t: ['oximetro', 'saturacion', 'oxigeno', 'pulso'], d: 'Mide la saturación de oxígeno (SpO2) y la frecuencia cardiaca en segundos. Pantalla OLED y apagado automático.', art: 'device:pulse', s: 120 },
  { n: 'Nebulizador de compresor', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', f: 'unidad', u: 1, un: 'unidad', rx: 'directa', p: 34990, t: ['nebulizador', 'asma', 'nebulizaciones', 'inhalaciones'], d: 'Nebulizador de compresor para uso domiciliario. Incluye mascarillas para adulto y niño, boquilla y filtros de repuesto.', art: 'device:neb', s: 80 },
  { n: 'Test rápido de antígeno COVID-19 1 unidad', b: SALUD, c: 'medicamentos/monitores-y-diagnostico', f: 'test', u: 1, un: 'test', rx: 'directa', p: 3990, t: ['covid', 'antigeno', 'test rapido'], d: 'Test de antígeno de autodiagnóstico con muestra nasal y resultado en 15 minutos.', s: 100 },

  // ── Medicamentos · Primeros auxilios ──────────────────────
  { n: 'Alcohol gel 70% 500 ml', b: PIEDRA, c: 'medicamentos/primeros-auxilios', ai: ['alcohol etílico'], st: '70%', f: 'gel', u: 500, un: 'ml', rx: 'directa', p: 2990, promo: '2da-50', t: ['antiseptico', 'manos', 'desinfectante'], d: 'Gel antiséptico para manos con 70% de alcohol etílico y glicerina. No necesita enjuague.', art: 'pump', s: 300 },
  { n: 'Alcohol etílico 70% 250 ml', b: PIEDRA, c: 'medicamentos/primeros-auxilios', ai: ['alcohol etílico'], st: '70%', f: 'solución', u: 250, un: 'ml', rx: 'directa', p: 1990, t: ['antiseptico', 'desinfectante', 'heridas'], d: 'Alcohol etílico al 70% para la desinfección de piel intacta y superficies.', art: 'bottle', s: 200 },
  { n: 'Agua oxigenada 10 volúmenes 120 ml', b: PIEDRA, c: 'medicamentos/primeros-auxilios', ai: ['peróxido de hidrógeno'], st: '10 vol', f: 'solución', u: 120, un: 'ml', rx: 'directa', p: 990, t: ['antiseptico', 'heridas', 'limpieza de heridas'], d: 'Solución de peróxido de hidrógeno para la limpieza de heridas superficiales.', art: 'bottle', s: 150 },
  { n: 'Povidona yodada 10% solución tópica 60 ml', b: ANDINO, c: 'medicamentos/primeros-auxilios', ai: ['povidona yodada'], st: '10%', f: 'solución', u: 60, un: 'ml', rx: 'directa', p: 2490, t: ['antiseptico', 'heridas', 'desinfeccion'], art: 'bottle', s: 100 },
  { n: 'Parches curitas surtidos 40 unidades', b: PIEDRA, c: 'medicamentos/primeros-auxilios', f: 'parches', u: 40, un: 'parche', rx: 'directa', p: 2490, t: ['curitas', 'parches', 'heridas', 'banditas'], d: 'Parches adhesivos de tela en tamaños surtidos para proteger cortes y heridas pequeñas.', s: 260 },
  { n: 'Gasas estériles 10 x 10 cm 10 unidades', b: PIEDRA, c: 'medicamentos/primeros-auxilios', f: 'gasas', u: 10, un: 'gasa', rx: 'directa', p: 1990, t: ['gasa', 'heridas', 'curacion'], d: 'Gasas de algodón estériles, envasadas individualmente, para curaciones.', s: 120 },
  { n: 'Venda elástica 10 cm x 4,5 m', b: PIEDRA, c: 'medicamentos/primeros-auxilios', f: 'venda', u: 1, un: 'unidad', rx: 'directa', p: 1990, t: ['venda', 'esguince', 'torcedura'], d: 'Venda elástica de algodón para inmovilización y compresión de esguinces y torceduras.', s: 90 },
  { n: 'Mascarillas desechables 3 pliegues 50 unidades', b: PIEDRA, c: 'medicamentos/primeros-auxilios', f: 'mascarillas', u: 50, un: 'mascarilla', rx: 'directa', p: 3990, o: 2990, t: ['mascarilla', 'tapabocas', 'proteccion'], d: 'Mascarillas de tres pliegues con elásticos y clip nasal.', art: 'pack', s: 150 },

  // ── Dermocosmética · Protección solar ─────────────────────
  { n: 'Anthelios UVMune 400 fluido invisible FPS 50+ 50 ml', b: 'La Roche-Posay', c: 'dermocosmetica/proteccion-solar', f: 'fluido', u: 50, un: 'ml', p: 24990, o: 19990, t: ['protector solar', 'bloqueador', 'fps 50', 'facial', 'piel sensible'], d: 'Protector solar facial de muy alta protección UVA/UVB, textura fluida e invisible. Apto para piel sensible.', art: 'tube', s: 420 },
  { n: 'Sun gel-crema oil control FPS 50+ 50 ml', b: 'Eucerin', c: 'dermocosmetica/proteccion-solar', f: 'gel-crema', u: 50, un: 'ml', p: 21990, o: 17590, t: ['protector solar', 'bloqueador', 'piel grasa', 'efecto mate', 'facial'], d: 'Protector solar facial con efecto mate y textura gel-crema de rápida absorción, para piel grasa o con tendencia acneica.', art: 'tube', s: 380 },
  { n: 'Fotoprotector Fusion Water Magic FPS 50 50 ml', b: 'ISDIN', c: 'dermocosmetica/proteccion-solar', f: 'emulsión', u: 50, un: 'ml', p: 23990, o: 20390, t: ['protector solar', 'bloqueador', 'facial', 'textura ligera'], d: 'Fotoprotector facial de textura ultraligera que se absorbe al instante. Se puede aplicar sobre piel húmeda.', art: 'tube', s: 400 },
  { n: 'Capital Soleil UV-Age Daily FPS 50+ 40 ml', b: 'Vichy', c: 'dermocosmetica/proteccion-solar', also: ['dermocosmetica/antiedad'], f: 'fluido', u: 40, un: 'ml', p: 25990, t: ['protector solar', 'antiedad', 'bloqueador', 'facial'], d: 'Protector solar facial de uso diario que ayuda a prevenir el fotoenvejecimiento. Textura acuosa.', art: 'tube', s: 180 },
  { n: 'Photoderm spray FPS 50+ 200 ml', b: 'Bioderma', c: 'dermocosmetica/proteccion-solar', f: 'spray', u: 200, un: 'ml', p: 24990, o: 19990, t: ['protector solar', 'bloqueador', 'corporal', 'spray'], d: 'Spray de protección solar muy alta para rostro y cuerpo, resistente al agua.', art: 'spray', s: 200 },
  { n: 'Spray muy alta protección FPS 50+ 200 ml', b: 'Avène', c: 'dermocosmetica/proteccion-solar', f: 'spray', u: 200, un: 'ml', p: 27990, t: ['protector solar', 'bloqueador', 'corporal', 'piel sensible'], d: 'Protección solar muy alta en spray para pieles sensibles, con agua termal.', art: 'spray', s: 150 },
  { n: 'Protector solar infantil FPS 50+ 120 ml', b: PIEDRA, c: 'dermocosmetica/proteccion-solar', also: ['infantil-y-mama/cuidado-del-bebe'], f: 'crema', u: 120, un: 'ml', p: 9990, o: 7990, t: ['protector solar', 'bloqueador', 'ninos', 'infantil', 'bebe'], d: 'Protector solar para niños desde los 6 meses, con filtros minerales, sin perfume y resistente al agua.', art: 'tube', s: 260 },
  { n: 'Protector solar corporal FPS 50 200 ml', b: PIEDRA, c: 'dermocosmetica/proteccion-solar', f: 'loción', u: 200, un: 'ml', p: 8990, promo: '2da-50', t: ['protector solar', 'bloqueador', 'corporal', 'familiar'], d: 'Loción de protección solar alta para todo el cuerpo, resistente al agua y de absorción rápida.', art: 'pump', s: 300 },

  // ── Dermocosmética · Limpieza facial ──────────────────────
  { n: 'Sensibio H2O agua micelar 500 ml', b: 'Bioderma', c: 'dermocosmetica/limpieza-facial', f: 'agua micelar', u: 500, un: 'ml', p: 19990, o: 15990, t: ['agua micelar', 'desmaquillante', 'piel sensible', 'limpieza'], d: 'Agua micelar que limpia y desmaquilla rostro y ojos sin enjuague, respetando la piel sensible.', art: 'pump', s: 360 },
  { n: 'Agua termal spray 300 ml', b: 'Avène', c: 'dermocosmetica/limpieza-facial', f: 'spray', u: 300, un: 'ml', p: 19990, o: 15990, t: ['agua termal', 'piel sensible', 'calmante'], d: 'Agua termal en spray que calma, suaviza y refresca la piel sensible o irritada.', art: 'spray', s: 200 },
  { n: 'Limpiador espumoso 236 ml', b: 'CeraVe', c: 'dermocosmetica/limpieza-facial', f: 'gel', u: 236, un: 'ml', p: 14990, t: ['limpiador facial', 'piel grasa', 'ceramidas'], d: 'Gel limpiador espumoso con ceramidas y niacinamida para piel normal a grasa. Elimina el exceso de sebo sin resecar.', art: 'pump', s: 260 },
  { n: 'Loción limpiadora suave 473 ml', b: 'Cetaphil', c: 'dermocosmetica/limpieza-facial', f: 'loción', u: 473, un: 'ml', p: 16990, o: 13590, t: ['limpiador', 'piel sensible', 'piel seca'], d: 'Limpiador suave para rostro y cuerpo, sin jabón y sin fragancia, ideal para piel sensible.', art: 'pump', s: 180 },
  { n: 'Toleriane limpiador hidratante 400 ml', b: 'La Roche-Posay', c: 'dermocosmetica/limpieza-facial', f: 'crema limpiadora', u: 400, un: 'ml', p: 19990, t: ['limpiador', 'piel sensible', 'hidratante'], d: 'Limpiador cremoso que limpia sin alterar la barrera cutánea, con ceramidas y niacinamida.', art: 'pump', s: 120 },

  // ── Dermocosmética · Hidratación ──────────────────────────
  { n: 'Crema hidratante 340 g', b: 'CeraVe', c: 'dermocosmetica/hidratacion', also: ['dermocosmetica/cuidado-corporal'], f: 'crema', u: 340, un: 'g', p: 19990, o: 16990, t: ['hidratante', 'piel seca', 'ceramidas', 'cuerpo', 'rostro'], d: 'Crema hidratante con 3 ceramidas esenciales y ácido hialurónico para piel seca a muy seca. Rostro y cuerpo.', art: 'jar', s: 340 },
  { n: 'Hydro Boost gel de agua 50 g', b: 'Neutrogena', c: 'dermocosmetica/hidratacion', f: 'gel', u: 50, un: 'g', p: 15990, o: 12790, t: ['hidratante facial', 'acido hialuronico', 'gel', 'piel mixta'], d: 'Gel hidratante facial con ácido hialurónico, textura fresca y libre de aceites.', art: 'jar', s: 220 },
  { n: 'Mineral 89 sérum fortificante 50 ml', b: 'Vichy', c: 'dermocosmetica/hidratacion', f: 'sérum', u: 50, un: 'ml', p: 29990, o: 23990, t: ['serum', 'acido hialuronico', 'hidratacion', 'agua volcanica'], d: 'Sérum diario con 89% de agua volcánica mineralizante y ácido hialurónico que fortalece e hidrata la piel.', art: 'dropper', s: 180 },
  { n: 'Cicaplast Baume B5+ 40 ml', b: 'La Roche-Posay', c: 'dermocosmetica/hidratacion', f: 'bálsamo', u: 40, un: 'ml', p: 14990, t: ['reparadora', 'piel irritada', 'pantenol', 'cicatrizante'], d: 'Bálsamo reparador con pantenol y madecassoside para piel irritada, seca o dañada. Rostro y cuerpo, apto para toda la familia.', art: 'tube', s: 240 },

  // ── Dermocosmética · Piel grasa y acné ────────────────────
  { n: 'Effaclar Duo+M 40 ml', b: 'La Roche-Posay', c: 'dermocosmetica/piel-grasa-y-acne', f: 'crema', u: 40, un: 'ml', p: 22990, o: 18390, t: ['acne', 'espinillas', 'imperfecciones', 'piel grasa'], d: 'Tratamiento anti-imperfecciones que reduce granos, marcas y brillo. Para piel grasa con tendencia acneica.', art: 'tube', s: 260 },
  { n: 'Effaclar gel limpiador purificante 400 ml', b: 'La Roche-Posay', c: 'dermocosmetica/piel-grasa-y-acne', also: ['dermocosmetica/limpieza-facial'], f: 'gel', u: 400, un: 'ml', p: 19990, t: ['acne', 'limpiador', 'piel grasa', 'espinillas'], d: 'Gel limpiador que purifica y elimina el exceso de sebo de la piel grasa sensible.', art: 'pump', s: 180 },
  { n: 'Sébium gel espumoso 200 ml', b: 'Bioderma', c: 'dermocosmetica/piel-grasa-y-acne', f: 'gel', u: 200, un: 'ml', p: 14990, promo: '2da-50', t: ['piel grasa', 'limpiador', 'acne', 'poros'], d: 'Gel limpiador purificante para piel mixta a grasa. Limpia y reduce la apariencia de poros dilatados.', art: 'pump', s: 140 },
  { n: 'Gel de limpieza con ácido salicílico 200 ml', b: PIEDRA, c: 'dermocosmetica/piel-grasa-y-acne', f: 'gel', u: 200, un: 'ml', p: 7990, t: ['acne', 'espinillas', 'acido salicilico', 'puntos negros'], d: 'Gel limpiador con 2% de ácido salicílico que destapa poros y ayuda a prevenir espinillas y puntos negros.', art: 'pump', s: 120 },

  // ── Dermocosmética · Antiedad ─────────────────────────────
  { n: 'Hyaluron-Filler crema de día FPS 30 50 ml', b: 'Eucerin', c: 'dermocosmetica/antiedad', f: 'crema', u: 50, un: 'ml', p: 32990, o: 26390, t: ['antiedad', 'arrugas', 'acido hialuronico'], d: 'Crema de día antiarrugas con ácido hialurónico y protección solar FPS 30.', art: 'jar', s: 160 },
  { n: 'Hyaluron-Filler contorno de ojos 15 ml', b: 'Eucerin', c: 'dermocosmetica/antiedad', f: 'crema', u: 15, un: 'ml', p: 27990, t: ['contorno de ojos', 'ojeras', 'arrugas', 'patas de gallo'], d: 'Crema para el contorno de ojos que rellena arrugas y suaviza las patas de gallo.', art: 'tube', s: 90 },
  { n: 'Revitalift sérum ácido hialurónico 1,5% 30 ml', b: "L'Oréal Paris", c: 'dermocosmetica/antiedad', f: 'sérum', u: 30, un: 'ml', p: 19990, o: 15990, t: ['serum', 'antiedad', 'acido hialuronico', 'arrugas'], d: 'Sérum facial con 1,5% de ácido hialurónico que hidrata y rellena líneas de expresión.', art: 'dropper', s: 200 },
  { n: 'Sérum vitamina C 10% 30 ml', b: PIEDRA, c: 'dermocosmetica/antiedad', f: 'sérum', u: 30, un: 'ml', p: 9990, promo: '2da-50', t: ['vitamina c', 'luminosidad', 'manchas', 'serum'], d: 'Sérum con 10% de vitamina C estabilizada que unifica el tono y aporta luminosidad. Usar con protector solar.', art: 'dropper', s: 210 },
  { n: 'Sérum retinol 0,3% 30 ml', b: PIEDRA, c: 'dermocosmetica/antiedad', f: 'sérum', u: 30, un: 'ml', p: 10990, t: ['retinol', 'arrugas', 'antiedad', 'serum', 'textura'], d: 'Sérum de noche con retinol al 0,3% que mejora la textura de la piel y suaviza arrugas finas.', art: 'dropper', s: 150 },

  // ── Dermocosmética · Cuidado corporal ─────────────────────
  { n: 'UreaRepair Plus loción 10% urea 250 ml', b: 'Eucerin', c: 'dermocosmetica/cuidado-corporal', f: 'loción', u: 250, un: 'ml', p: 18990, o: 15190, t: ['piel muy seca', 'urea', 'cuerpo', 'hidratante'], d: 'Loción corporal con 10% de urea para piel seca, áspera y con descamación. Hidratación por 48 horas.', art: 'pump', s: 160 },
  { n: 'Aceite de rosa mosqueta 100% puro 30 ml', b: PIEDRA, c: 'dermocosmetica/cuidado-corporal', f: 'aceite', u: 30, un: 'ml', p: 6990, promo: '2da-50', t: ['rosa mosqueta', 'cicatrices', 'estrias', 'manchas', 'regenerador'], d: 'Aceite puro de rosa mosqueta prensado en frío, de origen chileno. Ayuda a regenerar la piel y a mejorar la apariencia de cicatrices y estrías.', art: 'dropper', s: 300 },
  { n: 'Crema corporal de avena 400 ml', b: PIEDRA, c: 'dermocosmetica/cuidado-corporal', f: 'crema', u: 400, un: 'ml', p: 5990, t: ['hidratante corporal', 'piel sensible', 'avena'], d: 'Crema corporal con avena coloidal que hidrata y calma la piel seca y sensible.', art: 'pump', s: 180 },
  { n: 'Crema humectante clásica 150 ml', b: 'Nivea', c: 'dermocosmetica/cuidado-corporal', f: 'crema', u: 150, un: 'ml', p: 4990, o: 3990, t: ['crema humectante', 'piel seca', 'clasica'], d: 'Crema humectante para rostro, manos y cuerpo. Fórmula clásica en lata.', art: 'jar', s: 300 },

  // ── Vitaminas y suplementos ───────────────────────────────
  { n: 'Vitamina C 1000 mg 30 comprimidos efervescentes', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['vitamina C'], st: '1000 mg', f: 'comprimidos efervescentes', u: 30, un: 'comprimido', p: 4990, promo: '2da-50', t: ['vitamina c', 'defensas', 'inmunidad', 'acido ascorbico'], d: 'Vitamina C efervescente sabor naranja que contribuye al funcionamiento normal del sistema inmune.', art: 'tubeEff', s: 500 },
  { n: 'Vitamina C + zinc 30 comprimidos efervescentes', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['vitamina C', 'zinc'], st: '1000/10 mg', f: 'comprimidos efervescentes', u: 30, un: 'comprimido', p: 5990, o: 4990, t: ['vitamina c', 'zinc', 'defensas'], d: 'Combinación de vitamina C y zinc para apoyar las defensas. Sabor limón.', art: 'tubeEff', s: 300 },
  { n: 'Vitamina D3 2000 UI 60 cápsulas blandas', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['vitamina D3'], st: '2000 UI', f: 'cápsulas blandas', u: 60, un: 'cápsula', p: 7990, t: ['vitamina d', 'huesos', 'defensas'], d: 'Vitamina D3 (colecalciferol) que contribuye a la absorción del calcio y al funcionamiento del sistema inmune.', art: 'jar', s: 320 },
  { n: 'Complejo B 30 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['vitamina B1', 'vitamina B6', 'vitamina B12'], f: 'comprimidos', u: 30, un: 'comprimido', p: 3990, t: ['vitamina b', 'b12', 'energia', 'cansancio'], d: 'Vitaminas del complejo B que contribuyen a disminuir el cansancio y la fatiga.', art: 'jar', s: 200 },
  { n: 'Multivitamínico A-Z adulto 60 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', f: 'comprimidos', u: 60, un: 'comprimido', p: 9990, o: 7990, t: ['multivitaminico', 'vitaminas', 'minerales', 'energia'], d: 'Fórmula completa con 23 vitaminas y minerales para complementar la alimentación diaria del adulto.', art: 'jar', s: 380 },
  { n: 'Hierro + vitamina C 30 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['hierro', 'vitamina C'], f: 'comprimidos', u: 30, un: 'comprimido', p: 5990, t: ['hierro', 'anemia', 'cansancio'], d: 'Hierro con vitamina C, que mejora su absorción. Contribuye a la formación normal de glóbulos rojos.', art: 'jar', s: 150 },
  { n: 'Zinc 50 mg 60 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['zinc'], st: '50 mg', f: 'comprimidos', u: 60, un: 'comprimido', p: 4990, t: ['zinc', 'defensas', 'piel'], d: 'Zinc que contribuye al funcionamiento normal del sistema inmune y a la mantención de piel, cabello y uñas.', art: 'jar', s: 120 },
  { n: 'Biotina 5000 mcg 60 cápsulas', b: VITAL, c: 'vitaminas-y-suplementos/vitaminas-y-minerales', ai: ['biotina'], st: '5000 mcg', f: 'cápsulas', u: 60, un: 'cápsula', p: 8990, promo: '2da-50', t: ['biotina', 'cabello', 'unas', 'caida del pelo'], d: 'Biotina (vitamina B7) que contribuye a la mantención del cabello y la piel en condiciones normales.', art: 'jar', s: 220 },
  { n: 'Magnesio citrato en polvo 200 g', b: VITAL, c: 'vitaminas-y-suplementos/magnesio-y-colageno', ai: ['citrato de magnesio'], f: 'polvo', u: 200, un: 'g', p: 7990, o: 6390, t: ['magnesio', 'calambres', 'musculos', 'estres'], d: 'Citrato de magnesio en polvo, de alta absorción. Contribuye al funcionamiento normal de músculos y sistema nervioso.', art: 'jar', s: 420 },
  { n: 'Magnesio + vitamina B6 60 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/magnesio-y-colageno', ai: ['magnesio', 'vitamina B6'], f: 'comprimidos', u: 60, un: 'comprimido', p: 6990, t: ['magnesio', 'cansancio', 'calambres'], d: 'Magnesio con vitamina B6 para disminuir el cansancio y la fatiga.', art: 'jar', s: 260 },
  { n: 'Colágeno hidrolizado + vitamina C 300 g', b: VITAL, c: 'vitaminas-y-suplementos/magnesio-y-colageno', ai: ['colágeno hidrolizado', 'vitamina C'], f: 'polvo', u: 300, un: 'g', p: 12990, o: 10990, t: ['colageno', 'articulaciones', 'piel', 'unas'], d: 'Colágeno hidrolizado en polvo con vitamina C, sin sabor, para disolver en agua o jugo.', art: 'jar', s: 330 },
  { n: 'Omega 3 1000 mg 60 cápsulas blandas', b: VITAL, c: 'vitaminas-y-suplementos/magnesio-y-colageno', ai: ['omega 3'], st: '1000 mg', f: 'cápsulas blandas', u: 60, un: 'cápsula', p: 8990, t: ['omega 3', 'epa', 'dha', 'corazon', 'aceite de pescado'], d: 'Aceite de pescado con ácidos grasos EPA y DHA que contribuyen al funcionamiento normal del corazón.', art: 'jar', s: 300 },
  { n: 'Ginkgo biloba 120 mg 60 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/magnesio-y-colageno', ai: ['ginkgo biloba'], st: '120 mg', f: 'comprimidos', u: 60, un: 'comprimido', p: 7990, t: ['ginkgo', 'memoria', 'circulacion'], d: 'Extracto estandarizado de hojas de Ginkgo biloba.', art: 'jar', s: 100 },
  { n: 'Melatonina 3 mg 60 comprimidos', b: VITAL, c: 'vitaminas-y-suplementos/sueno-y-energia', ai: ['melatonina'], st: '3 mg', f: 'comprimidos', u: 60, un: 'comprimido', p: 6990, o: 5590, t: ['melatonina', 'dormir', 'insomnio', 'sueno', 'jet lag'], d: 'Melatonina que contribuye a reducir el tiempo necesario para conciliar el sueño.', art: 'jar', s: 380 },
  { n: 'Melatonina 1 mg gotas 30 ml', b: VITAL, c: 'vitaminas-y-suplementos/sueno-y-energia', ai: ['melatonina'], st: '1 mg', f: 'gotas', u: 30, un: 'ml', p: 7990, t: ['melatonina', 'dormir', 'gotas'], d: 'Melatonina en gotas sabor frutilla, fácil de dosificar.', art: 'dropper', s: 120 },
  { n: 'Ashwagandha 500 mg 60 cápsulas', b: VITAL, c: 'vitaminas-y-suplementos/sueno-y-energia', ai: ['ashwagandha'], st: '500 mg', f: 'cápsulas', u: 60, un: 'cápsula', p: 9990, t: ['estres', 'ansiedad', 'adaptogeno'], d: 'Extracto de raíz de ashwagandha, planta adaptógena de uso tradicional.', art: 'jar', s: 110 },
  { n: 'Proteína whey sabor vainilla 907 g', b: SPORT, c: 'vitaminas-y-suplementos/nutricion-deportiva', f: 'polvo', u: 907, un: 'g', p: 29990, o: 24990, t: ['proteina', 'whey', 'musculo', 'gimnasio'], d: 'Proteína de suero de leche con 24 g de proteína por porción. Sabor vainilla.', art: 'jar', s: 200 },
  { n: 'Creatina monohidrato 300 g', b: SPORT, c: 'vitaminas-y-suplementos/nutricion-deportiva', ai: ['creatina'], f: 'polvo', u: 300, un: 'g', p: 19990, o: 16990, t: ['creatina', 'fuerza', 'gimnasio'], d: 'Creatina monohidrato micronizada, sin sabor. 60 porciones de 5 g.', art: 'jar', s: 240 },
  { n: 'Electrolitos en polvo sabor limón 10 sobres', b: SPORT, c: 'vitaminas-y-suplementos/nutricion-deportiva', f: 'sobres', u: 10, un: 'sobre', p: 6990, t: ['electrolitos', 'hidratacion', 'deporte', 'calor'], d: 'Electrolitos para preparar una bebida de hidratación durante y después del ejercicio.', s: 100 },
  { n: 'Fórmula nutricional completa adulto vainilla 900 g', b: VITAL, c: 'vitaminas-y-suplementos/nutricion-clinica', also: ['cuidado-personal/adulto-mayor'], f: 'polvo', u: 900, un: 'g', p: 21990, o: 18990, t: ['suplemento nutricional', 'adulto mayor', 'nutricion completa'], d: 'Alimento en polvo con proteínas, vitaminas y minerales para complementar la alimentación del adulto.', art: 'jar', s: 160 },
  { n: 'Fórmula nutricional para diabéticos vainilla 400 g', b: VITAL, c: 'vitaminas-y-suplementos/nutricion-clinica', f: 'polvo', u: 400, un: 'g', p: 15990, t: ['diabetes', 'suplemento nutricional', 'sin azucar'], d: 'Fórmula nutricional de bajo índice glicémico para personas con diabetes.', art: 'jar', s: 70 },

  // ── Infantil y mamá ───────────────────────────────────────
  { n: 'Pañales Premium talla M 52 unidades', b: 'Babysec', c: 'infantil-y-mama/panales-y-toallitas', f: 'pañales', u: 52, un: 'pañal', p: 13990, o: 11190, grp: 'babysec-premium', v: 'M', t: ['panales', 'bebe', 'guagua'], d: 'Pañales con cubierta de tela suave, gel absorbente y elásticos en la cintura. Talla M (5 a 9,5 kg).', art: 'pack', s: 400 },
  { n: 'Pañales Premium talla G 48 unidades', b: 'Babysec', c: 'infantil-y-mama/panales-y-toallitas', f: 'pañales', u: 48, un: 'pañal', p: 13990, o: 11190, grp: 'babysec-premium', v: 'G', t: ['panales', 'bebe', 'guagua'], d: 'Pañales con cubierta de tela suave, gel absorbente y elásticos en la cintura. Talla G (8,5 a 12,5 kg).', art: 'pack', s: 520 },
  { n: 'Pañales Premium talla XG 44 unidades', b: 'Babysec', c: 'infantil-y-mama/panales-y-toallitas', f: 'pañales', u: 44, un: 'pañal', p: 13990, o: 11190, grp: 'babysec-premium', v: 'XG', t: ['panales', 'bebe', 'guagua'], d: 'Pañales con cubierta de tela suave, gel absorbente y elásticos en la cintura. Talla XG (11 a 15 kg).', art: 'pack', s: 430 },
  { n: 'Pañales Premium talla XXG 40 unidades', b: 'Babysec', c: 'infantil-y-mama/panales-y-toallitas', f: 'pañales', u: 40, un: 'pañal', p: 13990, o: 11190, grp: 'babysec-premium', v: 'XXG', t: ['panales', 'bebe', 'guagua'], d: 'Pañales con cubierta de tela suave, gel absorbente y elásticos en la cintura. Talla XXG (más de 13 kg).', art: 'pack', s: 330 },
  { n: 'Toallitas húmedas sin fragancia 80 unidades', b: BEBE, c: 'infantil-y-mama/panales-y-toallitas', f: 'toallitas', u: 80, un: 'toallita', p: 2490, promo: '3x2', t: ['toallitas humedas', 'bebe', 'muda'], d: 'Toallitas húmedas hipoalergénicas sin fragancia ni alcohol, para la muda del bebé.', art: 'pack', s: 450 },
  { n: 'Toallitas húmedas pack 3 x 80 unidades', b: BEBE, c: 'infantil-y-mama/panales-y-toallitas', f: 'toallitas', u: 240, un: 'toallita', p: 5990, t: ['toallitas humedas', 'bebe', 'pack'], d: 'Pack ahorro de 3 paquetes de toallitas húmedas hipoalergénicas sin fragancia.', art: 'pack', s: 220 },
  { n: 'Shampoo bebé original 400 ml', b: "Johnson's", c: 'infantil-y-mama/cuidado-del-bebe', f: 'shampoo', u: 400, un: 'ml', p: 4990, o: 3990, t: ['shampoo bebe', 'no mas lagrimas', 'cabello'], d: 'Shampoo suave para bebé con fórmula que no irrita los ojos.', art: 'pump', s: 260 },
  { n: 'Crema para coceduras con óxido de zinc 60 g', b: BEBE, c: 'infantil-y-mama/cuidado-del-bebe', ai: ['óxido de zinc'], f: 'crema', u: 60, un: 'g', p: 3990, t: ['coceduras', 'panalitis', 'oxido de zinc', 'muda'], d: 'Crema protectora con óxido de zinc que previene y alivia las coceduras de la zona del pañal.', art: 'tube', s: 300 },
  { n: 'Hydra Bébé loción corporal 300 ml', b: 'Mustela', c: 'infantil-y-mama/cuidado-del-bebe', f: 'loción', u: 300, un: 'ml', p: 14990, o: 11990, t: ['hidratante bebe', 'piel del bebe'], d: 'Loción hidratante para la piel normal del bebé, con palta (aguacate). Desde el nacimiento.', art: 'pump', s: 120 },
  { n: 'Aspirador nasal para bebé', b: BEBE, c: 'infantil-y-mama/cuidado-del-bebe', f: 'unidad', u: 1, un: 'unidad', p: 4990, t: ['aspirador nasal', 'mocos', 'congestion bebe'], d: 'Aspirador nasal de succión bucal con filtro, para despejar la nariz del bebé de forma segura.', art: 'device:baby', s: 140 },
  { n: 'Colonia bebé 200 ml', b: BEBE, c: 'infantil-y-mama/cuidado-del-bebe', f: 'colonia', u: 200, un: 'ml', p: 4490, t: ['colonia', 'bebe', 'perfume suave'], d: 'Colonia suave sin alcohol, con aroma delicado para bebés.', art: 'bottle', s: 90 },
  { n: 'Mamadera anticólicos 260 ml', b: BEBE, c: 'infantil-y-mama/alimentacion-y-lactancia', f: 'unidad', u: 1, un: 'unidad', p: 7990, t: ['mamadera', 'biberon', 'colicos'], d: 'Mamadera libre de BPA con válvula anticólicos y chupete de silicona de flujo lento.', art: 'babybottle', s: 180 },
  { n: 'Chupete de silicona 0-6 meses 2 unidades', b: BEBE, c: 'infantil-y-mama/alimentacion-y-lactancia', f: 'unidad', u: 2, un: 'unidad', p: 5990, t: ['chupete', 'chupon'], d: 'Chupetes de silicona con forma ortodóncica y estuche de transporte.', s: 160 },
  { n: 'Extractor de leche manual', b: BEBE, c: 'infantil-y-mama/alimentacion-y-lactancia', f: 'unidad', u: 1, un: 'unidad', p: 24990, o: 21990, t: ['extractor de leche', 'lactancia'], d: 'Extractor de leche manual con copa de silicona suave y mamadera de 150 ml.', art: 'device:baby', s: 70 },
  { n: 'Protectores mamarios desechables 30 unidades', b: BEBE, c: 'infantil-y-mama/alimentacion-y-lactancia', f: 'protectores', u: 30, un: 'unidad', p: 4990, t: ['protectores mamarios', 'lactancia'], d: 'Protectores mamarios ultra absorbentes con adhesivo, envasados individualmente.', art: 'pack', s: 110 },
  { n: 'Multivitamínico prenatal con ácido fólico 30 cápsulas', b: VITAL, c: 'infantil-y-mama/maternidad', ai: ['ácido fólico', 'hierro', 'DHA'], f: 'cápsulas', u: 30, un: 'cápsula', p: 9990, t: ['prenatal', 'embarazo', 'acido folico'], d: 'Multivitamínico para el embarazo y la lactancia con ácido fólico, hierro y DHA.', art: 'jar', s: 140 },
  { n: 'Crema antiestrías 200 ml', b: PIEDRA, c: 'infantil-y-mama/maternidad', f: 'crema', u: 200, un: 'ml', p: 8990, promo: '2da-50', t: ['estrias', 'embarazo', 'hidratante'], d: 'Crema elástica para prevenir y atenuar estrías durante el embarazo, con centella asiática y rosa mosqueta.', art: 'pump', s: 130 },

  // ── Cuidado personal ──────────────────────────────────────
  { n: 'Pasta dental Total 12 Clean Mint 90 g', b: 'Colgate', c: 'cuidado-personal/cuidado-bucal', f: 'pasta', u: 90, un: 'g', p: 2990, promo: '3x2', t: ['pasta de dientes', 'dental', 'caries'], d: 'Pasta dental con flúor que protege dientes y encías por 12 horas.', art: 'tube', s: 420 },
  { n: 'Pasta dental Repara y Protege 100 g', b: 'Sensodyne', c: 'cuidado-personal/cuidado-bucal', f: 'pasta', u: 100, un: 'g', p: 5990, o: 4790, t: ['sensibilidad dental', 'pasta de dientes', 'dientes sensibles'], d: 'Pasta dental para dientes sensibles que repara y protege las zonas vulnerables.', art: 'tube', s: 300 },
  { n: 'Cepillo dental suave 2 unidades', b: PIEDRA, c: 'cuidado-personal/cuidado-bucal', f: 'unidad', u: 2, un: 'unidad', p: 2990, t: ['cepillo de dientes', 'dental'], d: 'Cepillos dentales de cerdas suaves con limpiador de lengua.', s: 220 },
  { n: 'Cepillo eléctrico recargable Vitality 100', b: 'Oral-B', c: 'cuidado-personal/cuidado-bucal', f: 'unidad', u: 1, un: 'unidad', p: 34990, o: 27990, t: ['cepillo electrico', 'dental'], d: 'Cepillo eléctrico recargable con cabezal redondo oscilante y temporizador de 2 minutos.', art: 'device:brush', s: 90 },
  { n: 'Enjuague bucal Cool Mint 500 ml', b: 'Listerine', c: 'cuidado-personal/cuidado-bucal', f: 'enjuague', u: 500, un: 'ml', p: 5490, o: 4390, t: ['enjuague bucal', 'mal aliento', 'colutorio'], d: 'Enjuague bucal antiséptico que combate la placa bacteriana y el mal aliento.', art: 'bottle', s: 260 },
  { n: 'Hilo dental menta 50 m', b: PIEDRA, c: 'cuidado-personal/cuidado-bucal', f: 'unidad', u: 1, un: 'unidad', p: 1990, t: ['hilo dental', 'seda dental'], d: 'Hilo dental encerado con sabor a menta.', s: 140 },
  { n: 'Shampoo limpieza renovadora 375 ml', b: 'Head & Shoulders', c: 'cuidado-personal/cuidado-capilar', f: 'shampoo', u: 375, un: 'ml', p: 5490, o: 4390, t: ['shampoo', 'caspa', 'cabello'], d: 'Shampoo anticaspa de uso diario para todo tipo de cabello.', art: 'pump', s: 260 },
  { n: 'Shampoo neutro 400 ml', b: PIEDRA, c: 'cuidado-personal/cuidado-capilar', f: 'shampoo', u: 400, un: 'ml', p: 3490, promo: '2da-50', t: ['shampoo', 'cabello normal', 'uso diario'], d: 'Shampoo de pH neutro para uso diario y toda la familia.', art: 'pump', s: 160 },
  { n: 'Acondicionador reparación 400 ml', b: PIEDRA, c: 'cuidado-personal/cuidado-capilar', f: 'acondicionador', u: 400, un: 'ml', p: 3490, t: ['acondicionador', 'cabello danado'], d: 'Acondicionador con keratina para cabello dañado o teñido.', art: 'pump', s: 110 },
  { n: 'Desodorante roll-on mujer 50 ml', b: 'Nivea', c: 'cuidado-personal/desodorantes-y-jabones', f: 'roll-on', u: 50, un: 'ml', p: 2990, promo: '2x1', t: ['desodorante', 'antitranspirante', 'roll on'], d: 'Desodorante antitranspirante roll-on con protección por 48 horas.', art: 'bottle', s: 260 },
  { n: 'Desodorante antitranspirante clinical 48 g', b: 'Rexona', c: 'cuidado-personal/desodorantes-y-jabones', f: 'barra', u: 48, un: 'g', p: 5990, o: 4790, t: ['desodorante', 'sudor', 'antitranspirante'], d: 'Desodorante en barra de protección clínica contra el sudor excesivo.', art: 'stick', s: 200 },
  { n: 'Jabón en barra original 90 g', b: 'Dove', c: 'cuidado-personal/desodorantes-y-jabones', f: 'jabón', u: 90, un: 'g', p: 1490, promo: '3x2', t: ['jabon', 'piel', 'barra'], d: 'Jabón en barra con un cuarto de crema humectante.', art: 'soap', s: 260 },
  { n: 'Gel de ducha de avena 750 ml', b: PIEDRA, c: 'cuidado-personal/desodorantes-y-jabones', f: 'gel', u: 750, un: 'ml', p: 3990, t: ['gel de ducha', 'jabon liquido', 'piel sensible'], d: 'Gel de ducha con avena, sin jabón, que limpia suavemente la piel sensible.', art: 'pump', s: 150 },
  { n: 'Máquina de afeitar Mach3 + 2 repuestos', b: 'Gillette', c: 'cuidado-personal/afeitado', f: 'unidad', u: 1, un: 'unidad', p: 9990, o: 7990, t: ['afeitar', 'rasuradora', 'maquina de afeitar'], d: 'Máquina de afeitar de 3 hojas con banda lubricante y 2 repuestos.', s: 160 },
  { n: 'Espuma de afeitar piel sensible 200 ml', b: PIEDRA, c: 'cuidado-personal/afeitado', f: 'espuma', u: 200, un: 'ml', p: 2990, t: ['espuma de afeitar', 'piel sensible'], d: 'Espuma de afeitar con aloe vera para piel sensible.', art: 'spray', s: 90 },
  { n: 'Toallas higiénicas nocturnas con alas 8 unidades', b: PIEDRA, c: 'cuidado-personal/higiene-femenina', f: 'toallas', u: 8, un: 'toalla', p: 2490, promo: '3x2', t: ['toallas higienicas', 'menstruacion', 'nocturnas'], d: 'Toallas higiénicas extra largas con alas para la noche.', art: 'pack', s: 260 },
  { n: 'Tampones regular 16 unidades', b: PIEDRA, c: 'cuidado-personal/higiene-femenina', f: 'tampones', u: 16, un: 'tampón', p: 3990, t: ['tampones', 'menstruacion'], d: 'Tampones de absorción regular con aplicador.', s: 120 },
  { n: 'Copa menstrual talla S', b: PIEDRA, c: 'cuidado-personal/higiene-femenina', f: 'unidad', u: 1, un: 'unidad', p: 14990, o: 11990, t: ['copa menstrual', 'menstruacion', 'reutilizable'], d: 'Copa menstrual de silicona médica reutilizable, talla S. Incluye bolsa de algodón.', s: 80 },
  { n: 'Protectores diarios 40 unidades', b: PIEDRA, c: 'cuidado-personal/higiene-femenina', f: 'protectores', u: 40, un: 'unidad', p: 2490, t: ['protectores diarios'], d: 'Protectores diarios delgados y respirables.', art: 'pack', s: 150 },
  { n: 'Pañales para adulto talla M 8 unidades', b: PIEDRA, c: 'cuidado-personal/adulto-mayor', f: 'pañales', u: 8, un: 'pañal', p: 9990, o: 8490, t: ['panales adulto', 'incontinencia', 'adulto mayor'], d: 'Pañales para adulto con barreras antifiltración e indicador de humedad. Talla M.', art: 'pack', s: 150 },
  { n: 'Apósitos para incontinencia leve 10 unidades', b: PIEDRA, c: 'cuidado-personal/adulto-mayor', f: 'apósitos', u: 10, un: 'unidad', p: 5990, t: ['incontinencia', 'apositos'], d: 'Apósitos discretos para incontinencia leve, con control de olor.', art: 'pack', s: 110 },
  { n: 'Pastillero semanal 7 días', b: PIEDRA, c: 'cuidado-personal/adulto-mayor', f: 'unidad', u: 1, un: 'unidad', p: 3990, t: ['pastillero', 'organizador de remedios', 'adulto mayor'], d: 'Pastillero con 7 compartimentos (uno por día) y tapas fáciles de abrir.', s: 130 },

  // ── Belleza ───────────────────────────────────────────────
  { n: 'Máscara de pestañas Lash Sensational', b: 'Maybelline', c: 'belleza/maquillaje', f: 'máscara', u: 1, un: 'unidad', p: 10990, o: 7990, t: ['mascara de pestanas', 'rimel', 'pestanas'], d: 'Máscara de pestañas que da volumen y alarga sin grumos. Color negro.', art: 'stick', s: 200 },
  { n: 'Base líquida Fit Me 30 ml', b: 'Maybelline', c: 'belleza/maquillaje', f: 'base', u: 30, un: 'ml', p: 11990, t: ['base de maquillaje', 'maquillaje'], d: 'Base de maquillaje líquida de acabado natural, para piel normal a grasa.', art: 'bottle', s: 110 },
  { n: 'Esmalte fortalecedor de uñas 10 ml', b: PIEDRA, c: 'belleza/unas-y-labios', f: 'esmalte', u: 10, un: 'ml', p: 2990, promo: '2da-50', t: ['esmalte', 'unas debiles', 'fortalecedor'], d: 'Base fortalecedora transparente para uñas débiles o quebradizas.', art: 'polish', s: 100 },
  { n: 'Bálsamo labial FPS 15', b: PIEDRA, c: 'belleza/unas-y-labios', f: 'bálsamo', u: 4, un: 'g', p: 1990, t: ['balsamo labial', 'labios secos', 'protector labial'], d: 'Bálsamo labial humectante con protección solar FPS 15.', art: 'stick', s: 200 },
  { n: 'Desmaquillante bifásico ojos y labios 150 ml', b: PIEDRA, c: 'belleza/desmaquillantes', f: 'bifásico', u: 150, un: 'ml', p: 4990, t: ['desmaquillante', 'waterproof', 'ojos'], d: 'Desmaquillante de doble fase que elimina incluso el maquillaje a prueba de agua.', art: 'bottle', s: 110 },

  // ── Mascotas ──────────────────────────────────────────────
  { n: 'Pipeta antiparasitaria externa perros 10 a 20 kg', b: 'Vet Andes', c: 'mascotas/antiparasitarios', f: 'pipeta', u: 1, un: 'pipeta', p: 8990, t: ['pulgas', 'garrapatas', 'perro', 'pipeta'], d: 'Pipeta de aplicación tópica que protege contra pulgas y garrapatas por 30 días. Uso veterinario.', s: 120 },
  { n: 'Antiparasitario interno perros y gatos 2 comprimidos', b: 'Vet Andes', c: 'mascotas/antiparasitarios', f: 'comprimidos', u: 2, un: 'comprimido', p: 4990, t: ['parasitos internos', 'desparasitante', 'perro', 'gato'], d: 'Comprimidos antiparasitarios de amplio espectro para perros y gatos. Uso veterinario.', s: 90 },
  { n: 'Shampoo hipoalergénico para mascotas 250 ml', b: 'Vet Andes', c: 'mascotas/higiene-mascotas', f: 'shampoo', u: 250, un: 'ml', p: 5990, t: ['shampoo perro', 'mascota', 'piel sensible'], d: 'Shampoo suave con avena para perros y gatos de piel sensible.', art: 'pump', s: 70 },
];

// ── Clases terapéuticas: texto base de la descripción ─────────
export const THERAPEUTIC = {
  analgesico: 'Analgésico y antipirético: alivia el dolor leve a moderado y ayuda a bajar la fiebre.',
  aine: 'Antiinflamatorio no esteroidal (AINE): alivia el dolor, la inflamación y la fiebre.',
  aine_topico: 'Antiinflamatorio de uso tópico para el alivio local de dolores musculares, golpes y torceduras.',
  antigripal: 'Alivia los síntomas del resfrío y la gripe: congestión nasal, dolor de cabeza, fiebre y malestar general.',
  mucolitico: 'Mucolítico: fluidifica las secreciones bronquiales y facilita su eliminación con la tos.',
  antitusivo: 'Antitusivo: calma la tos seca e irritativa.',
  descongestionante: 'Descongestionante nasal de acción local para el alivio de la nariz tapada.',
  descongestionante_topico: 'Ungüento de uso externo que entrega sensación de alivio respiratorio en resfríos.',
  antihistaminico: 'Antihistamínico: alivia estornudos, picazón, secreción nasal y otros síntomas de alergia.',
  antileucotrieno: 'Antileucotrieno para el control del asma y la rinitis alérgica, según indicación médica.',
  corticoide_nasal: 'Corticoide de uso nasal para el tratamiento de la rinitis alérgica.',
  broncodilatador: 'Broncodilatador de acción rápida para el alivio de los síntomas del asma.',
  corticoide_inhalado: 'Corticoide inhalado para el control a largo plazo del asma.',
  ipb: 'Inhibidor de la bomba de protones: reduce la producción de ácido del estómago. Se usa en reflujo, acidez y gastritis según indicación médica.',
  antih2: 'Reduce la secreción de ácido gástrico para el tratamiento de la acidez y la úlcera.',
  procinetico: 'Procinético: ayuda a aliviar náuseas, vómitos y la sensación de digestión lenta.',
  antidiarreico: 'Antidiarreico para el control sintomático de la diarrea aguda.',
  rehidratante: 'Repone el agua y las sales minerales que se pierden por diarrea, vómitos o calor excesivo.',
  antiflatulento: 'Alivia los gases y la sensación de hinchazón abdominal.',
  antiacido: 'Antiácido: neutraliza la acidez estomacal y alivia la sensación de ardor.',
  laxante: 'Laxante osmótico para el tratamiento del estreñimiento.',
  antiespasmodico: 'Regula el movimiento intestinal y alivia el dolor abdominal asociado al colon irritable.',
  antiemetico: 'Antiemético: previene y trata náuseas y vómitos.',
  probiotico: 'Suplemento probiótico para el equilibrio de la flora intestinal.',
  antihipertensivo: 'Medicamento para el control de la presión arterial alta.',
  diuretico: 'Diurético utilizado en el tratamiento de la hipertensión arterial.',
  hipolipemiante: 'Reduce el colesterol y los triglicéridos en la sangre.',
  antiagregante: 'Antiagregante plaquetario para la prevención de eventos cardiovasculares, según indicación médica.',
  antidiabetico: 'Antidiabético oral para el control de la glicemia en la diabetes tipo 2.',
  insulina: 'Insulina de acción prolongada para el control de la diabetes. Requiere cadena de frío.',
  tiroides: 'Hormona tiroidea para el tratamiento del hipotiroidismo.',
  antibiotico: 'Antibiótico para el tratamiento de infecciones bacterianas. Debe usarse solo con receta y completando el tratamiento indicado.',
  antimicotico: 'Antimicótico para el tratamiento de infecciones causadas por hongos.',
  antidepresivo: 'Antidepresivo para el tratamiento de la depresión y trastornos de ansiedad, según indicación médica.',
  ansiolitico: 'Ansiolítico para el tratamiento de trastornos de ansiedad, según indicación médica.',
  fitoterapico: 'Fitofármaco de uso tradicional como relajante suave y para favorecer el sueño.',
  corticoide_topico: 'Corticoide tópico que alivia la inflamación y la picazón de la piel.',
  antibiotico_topico: 'Antibiótico tópico para infecciones superficiales de la piel.',
  antiviral: 'Antiviral de uso tópico para el tratamiento del herpes labial.',
  pediculicida: 'Pediculicida: elimina piojos y liendres del cuero cabelludo.',
  lubricante_ocular: 'Lubricante ocular que alivia la sequedad, el ardor y el cansancio visual.',
  cerumenolitico: 'Ablanda y ayuda a remover el cerumen acumulado en el oído.',
  anticonceptivo: 'Anticonceptivo oral combinado de uso diario.',
  anticonceptivo_emergencia: 'Anticonceptivo de emergencia. No es un método anticonceptivo de uso regular.',
  disfuncion_erectil: 'Medicamento para el tratamiento de la disfunción eréctil.',
};

// ── Normalización ─────────────────────────────────────────────
export function slugify(s) {
  return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

export function artFor(f = '') {
  const x = f.toLowerCase();
  if (/jarabe|suspensi|soluci[oó]n oral/.test(x)) return 'bottle';
  if (/gotas/.test(x)) return 'dropper';
  if (/crema|gel|ung[uü]ento|pasta|b[aá]lsamo|pomada/.test(x)) return 'tube';
  if (/spray|nasal/.test(x)) return 'spray';
  if (/inhalador/.test(x)) return 'inhaler';
  if (/efervescente/.test(x)) return 'tubeEff';
  if (/pa[nñ]ales|toallitas|toallas|ap[oó]sitos|protectores/.test(x)) return 'pack';
  if (/polvo/.test(x)) return 'jar';
  if (/shampoo|loci[oó]n|limpiador|micelar|acondicionador/.test(x)) return 'pump';
  return 'box';
}

/** Convierte un producto en formato corto (ver campos arriba) al formato completo. */
export function normalizeProduct(r, id, slug) {
  const [cat, sub] = r.c.split('/');
  const isMed = cat === 'medicamentos' && !!(r.ai && r.ai.length) && r.rx;
  const offer = r.o && r.o < r.p ? r.o : null;
  return {
    id: String(id),
    slug,
    name: r.n,
    brand: r.b,
    cat, sub,
    also: (r.also || []).map((x) => { const [c, s] = x.split('/'); return { cat: c, sub: s }; }),
    ingredients: r.ai || [],
    strength: r.st || '',
    form: r.f || '',
    units: r.u || 1,
    unitName: r.un || 'unidad',
    rx: r.rx || 'directa',
    isMedicine: !!isMed,
    be: !!r.be,
    cold: !!r.cold,
    price: r.p,
    offer,
    promo: r.promo || null,
    clubPct: r.club || 0,
    tags: r.t || [],
    therapeutic: isMed && THERAPEUTIC[(r.t || [])[0]] ? (r.t || [])[0] : null,
    desc: r.d || '',
    art: r.art || artFor(r.f),
    popularity: r.s || 50,
    group: r.grp || null,
    variant: r.v || null,
    chronic: (r.t || []).includes('cronico'),
  };
}

export function normalize(raw) {
  const seen = new Map();
  return raw.map((r, i) => {
    let slug = slugify(`${r.n} ${r.b}`);
    const n = seen.get(slug) || 0;
    seen.set(slug, n + 1);
    if (n) slug += `-${n + 1}`;
    return normalizeProduct(r, 420101 + i, slug);
  });
}

export const PRODUCTS = normalize(RAW);
